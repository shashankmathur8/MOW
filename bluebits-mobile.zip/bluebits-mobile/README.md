# Introduction 
Mobile application to be used for BITS field sales operations in NAM by the field sales persons. This mobile application will enable the user to perform inventory, Sales , Job related transactions and integrated with various sytems like SAP, FDP, FLM etc., This application is the replacement of the current application (Athand) that BDT users are using.

https://slb-it.visualstudio.com/es-global-traceability/_wiki/wikis/es-global-traceability_MIGRATING.wiki?wikiVersion=GBwikiMaster&_a=edit&pagePath=/Global%20Traceability/GT%20Applications/BlueBits%20%5BBFSE%20(BITS%20Field%20Sales%20Enablement)%5D&pageId=60091

# Getting Started
TODO: Guide users through getting your code up and running on their own system. In this section you can talk about:
1.	Installation process
2.	Software dependencies
3.	Latest releases
4.	API references

# Build and Test
TODO: Describe and show how to build your code and run the tests. 

# Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)