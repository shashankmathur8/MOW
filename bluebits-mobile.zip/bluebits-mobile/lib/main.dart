import 'package:flutter/material.dart';

import '/flavors/build_config.dart';
import '/flavors/env_config.dart';
import '/flavors/environment_enum.dart';
import 'app/common_binding/initial_binding.dart';
import 'app/environments/environment.dart';
import 'app/my_app.dart';

Future<void> main() async {
  Environment env = Environment();
  env.initConfig(EnvironmentEnum.DEV);

  EnvConfig envConfig = EnvConfig(
    urlConfigBasedOnEnv: env.urlConfigBasedOnEnv!,
    appName: "DEV",
    baseUrl: env.urlConfigBasedOnEnv!.apiHost,
    shouldCollectCrashLog: true,
  );

  BuildConfig.instantiate(
    envType: env.urlConfigBasedOnEnv!.env_name!,
    envConfig: envConfig,
  );
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();

  await InitialBinding.init();
  Paint.enableDithering = true;
  runApp(const MyApp());
}
