import 'package:get/get.dart';
import 'package:logger/logger.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/environments/base_config.dart';

class EnvConfig {
  final String appName;
  final String baseUrl;
  final URLConfigBasedOnEnv urlConfigBasedOnEnv;
  final bool shouldCollectCrashLog;

  late final Logger logger;

  EnvConfig({
    required this.urlConfigBasedOnEnv,
    required this.appName,
    required this.baseUrl,
    this.shouldCollectCrashLog = false,
  }) {
    /*logger.v("Verbose log");

    logger.d("Debug log");

    logger.i("Info log");

    logger.w("Warning log");

    logger.e("Error log");

    logger.wtf("What a terrible failure log");*/

    logger = Logger(
      printer: PrettyPrinter(
          methodCount: AppValues.loggerMethodCount,
          // number of method calls to be displayed
          errorMethodCount: AppValues.loggerErrorMethodCount,
          // number of method calls if stacktrace is provided
          lineLength: AppValues.loggerLineLength,
          // width of the output
          colors: true,
          // Colorful log messages
          printEmojis: true,
          // Print an emoji for each log message
          printTime: false // Should each log print contain a timestamp
          ),
    );
  }
}
