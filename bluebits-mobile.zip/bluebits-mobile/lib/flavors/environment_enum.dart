// ignore_for_file: constant_identifier_names

enum EnvironmentEnum { DEV, QA, PROD }
