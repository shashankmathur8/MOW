import 'dart:ui';

import 'package:get/get.dart';

class AppLanguageItem {
  const AppLanguageItem(this.name, this.countryCode, this.languageCode);

  final String name;
  final String countryCode;
  final String languageCode;

  @override
  String toString() {
    return name;
  }
}

const List<AppLanguageItem> appLanguagesList = <AppLanguageItem>[
  AppLanguageItem('English', 'en', 'US'),
  AppLanguageItem('Korean', 'ko', 'KR'),

];

_setLocale(locale) {
  // find locale by name
  var w = appLanguagesList.firstWhere((element) => element.name == locale);
  Get.updateLocale(Locale(w.countryCode, w.languageCode));
}
