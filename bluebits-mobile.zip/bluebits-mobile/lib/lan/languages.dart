import 'package:get/get.dart';

import 'en_us.dart';
import 'ja_jp.dart';

class Languages extends Translations {

  @override
  Map<String, Map<String, String>> get keys => {
    'en_US': enUS, // lang/en_us.dart
    'ja_JP': jaJP, // lang/ja_jp.dart
  };
}