// Japanese Translations
const Map<String, String> jaJP = {
  'hello': '今日は!',
};