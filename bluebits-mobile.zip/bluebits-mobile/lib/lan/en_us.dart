// English Translations
const Map<String, String> enUS = {
  //SignIn
  'hello': 'Hello!',
  'email': 'email',
  'sign_in': 'Sign In',
  'invalid_email': 'The Email you entered is invalid. Please try again',
  'schlumberger': '@2021 Schlumberger LLC.',
  'all_rights_reserved': 'All Rights Reserved',
  'privacy_policy': 'Privacy Policy',
  'terms': 'Terms',
  'terms&condition':'Terms & Condition',
  'need_access':"You need access",
  'request_access':"You do not currently have permission to view this page. If you need access,request it.",
  'contact_support':"Contact support",
  'go_back':"Go Back",

  //Dashboard
  'requests': 'Requests',
  'search_by': 'Search by order type,well or status',
  'home': 'Home',
  'wells': 'Wells',
  'new': 'New',
  'cancel': 'Cancel',
  'schedule': 'Schedule',
  'open_order': 'Open Orders',
  'saved_for_later': 'Saved for Later',
  'close_order': 'Close Orders',
};
