import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/modules/bottomNavigation/dashboard.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/binding/consign_binding.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/screens/consign_bits_screen.dart';
import 'package:slb_gt_mobile/app/modules/login/binding/login_binding.dart';
import 'package:slb_gt_mobile/app/modules/login/screens/login_screen.dart';
import 'package:slb_gt_mobile/app/modules/login/screens/splash_screen.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/binding/ticketing_bits_binding.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/screens/ticketing_bits_screen.dart';

import '../modules/bottomNavigation/binding/dashboard_binding.dart';
import '../modules/inventory/models/consignmentSchema.dart';

part 'app_routes.dart';

class AppPages {
  AppPages._();

  static const initial = Routes.splash;

  static final routes = [
    GetPage(
        name: _Paths.splash,
        page: () => const SplashScreen(),
        transition: Transition.native,
        transitionDuration: const Duration(milliseconds: 300)),
    GetPage(
        name: _Paths.LOGIN,
        page: () => LoginScreen(),
        binding: LoginBinding(),
        transition: Transition.noTransition,
        transitionDuration: const Duration(milliseconds: 0)),
    GetPage(
        name: _Paths.dashboard,
        page: () => Dashboard(pageIndex: 0),
        binding: DashboardBinding(),
        transition: Transition.native,
        transitionDuration: const Duration(milliseconds: 300)),
    GetPage(
        name: _Paths.consign,
        page: () => ConsignBits(isDraftEdit: false, selectedBits: const []),
        binding: ConsignBinding(),
        transition: Transition.native,
        transitionDuration: const Duration(milliseconds: 300)),
    GetPage(
        name: _Paths.ticketingBits,
        page: () => TicketingBits(isDraftEdit: false,selectedBits: const [],currentConsignment: null as Consignment),
        binding: TicketingBitsBinding(),
        transition: Transition.native,
        transitionDuration: const Duration(milliseconds: 300)),
  ];
}
