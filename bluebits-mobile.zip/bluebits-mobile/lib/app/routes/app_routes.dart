part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();

  static const splash = _Paths.splash;
  static const LOGIN = _Paths.LOGIN;
  static const dashboard = _Paths.dashboard;
  static const HOME = _Paths.HOME;
  static const INVENTORY = _Paths.INVENTORY;
  static const consign = _Paths.consign;
  static const ticketingBits = _Paths.ticketingBits;
}

abstract class _Paths {
  static const splash = '/splash';
  static const LOGIN = '/login';
  static const dashboard = '/dashboard';
  static const HOME = '/home';
  static const INVENTORY = '/inventory';
  static const consign = '/consign';
  static const ticketingBits = '/ticketingBits';
}
