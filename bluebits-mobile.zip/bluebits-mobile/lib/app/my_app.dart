import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:overlay_support/overlay_support.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/modules/login/screens/login_screen.dart';
import 'package:slb_gt_mobile/app/routes/app_pages.dart';

import '/flavors/build_config.dart';
import '/flavors/env_config.dart';
import '../lan/languages.dart';
import 'common_binding/initial_binding.dart';
import 'core/utils/size_config.dart';
import 'modules/login/screens/splash_screen.dart';

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    SizeConfig().init(context);
    super.initState();
  }

  final EnvConfig _envConfig = BuildConfig.instance.config;
  final logger = BuildConfig.instance.config.logger;

  @override
  Widget build(BuildContext context) {
    logger.d("Build type ${_envConfig.urlConfigBasedOnEnv.env_name}");
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(
        statusBarColor: AppColors.colorPrimary,
      ),
      child: OverlaySupport(
        child: GetMaterialApp(
          title: _envConfig.appName,
          initialRoute: AppPages.initial,
          home: const SplashScreen(),
          initialBinding: InitialBinding(),
          translations: Languages(),
          /** need to check */
          getPages: AppPages.routes,
          //localizationsDelegates: AppLocalizations.localizationsDelegates,
          supportedLocales: _getSupportedLocal(),
          locale: Get.deviceLocale,
          fallbackLocale: const Locale('en', 'US'),
          theme: ThemeData(
              // Define the default brightness and colors.
              brightness: Brightness.light,
              primaryColor: AppColors.colorPrimary,
              //CHANGE AS PER OUR APP COLOR// Define the default font family.
              fontFamily: AppValues.fontFamily,
              //WILL CHANGE FROM COMMON CONSTANTS
              highlightColor: AppColors.colorPrimary,
              splashColor: AppColors.transparentColor,
              appBarTheme: const AppBarTheme(),
              //NEED TO DEFINE  COLOR ;TEXTTHEME
              textTheme: const TextTheme(
                displayLarge: TextStyle(
                    fontSize: SizeConstants.dp72, fontWeight: FontWeight.bold),
                titleLarge: TextStyle(
                    fontSize: SizeConstants.dp36, fontStyle: FontStyle.italic),
                bodyMedium: TextStyle(
                    fontSize: SizeConstants.dp16,
                    fontFamily: AppValues.fontFamily,
                    fontStyle: FontStyle.normal),
              ),
              inputDecorationTheme: InputDecorationTheme(
                filled: true,
                fillColor: AppColors.colorLightWhite,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(SizeConstants.dp2),
                  borderSide: const BorderSide(
                    color: AppColors.colorGrayLight,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(SizeConstants.dp2),
                  borderSide: const BorderSide(
                    color: AppColors.colorGrayLight,
                  ),
                ),
                focusedErrorBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(SizeConstants.dp2),
                  borderSide: const BorderSide(
                    color: AppColors.colorGrayLight,
                  ),
                ),
                errorBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(SizeConstants.dp2),
                  borderSide: const BorderSide(
                    color: AppColors.colorGrayLight,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(SizeConstants.dp2),
                  borderSide: const BorderSide(
                    color: AppColors.colorGrayLight,
                  ),
                ),
              ),
              buttonTheme: const ButtonThemeData(
                buttonColor: AppColors.colorWhite,
              )),
          debugShowCheckedModeBanner: false,
        ),
      ),
    );
  }

  List<Locale> _getSupportedLocal() {
    return [
      const Locale('en', ''),
      const Locale('bn', ''),
    ];
  }
}
