import 'package:intl/intl.dart';
import 'package:slb_gt_mobile/app/core/utils/logger_common.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';

class TimeUtils {
  ///This method is used to get the time display in past or upcoming future.
  String pickDateTime(
    String? dateTime,
  ) {
    try {
      DateTime tempDate =
          DateFormat(AppStrings.defaultDateFormat).parse(dateTime!, true);

      if (!tempDate.isAfter(DateTime.now().toUtc())) {
        return _timeAgo(tempDate);
      }
    } catch (e) {
      ApplicationLogger().printError(
          'pickDateTime ${e.toString()}', 'TimeUtils().pickDateTime');
    }
    return '';
  }

  ///This method is used to display time in Past
  String _timeAgo(DateTime d) {
    Duration diff = DateTime.now().toUtc().difference(d);
    final yesterday = DateTime(
        DateTime.now().year, DateTime.now().month, DateTime.now().day - 1).toUtc();

    if (DateFormat(AppStrings.ddMMYYYYDateFormat).format(d) ==
        DateFormat(AppStrings.ddMMYYYYDateFormat).format(yesterday)) {
      String formattedTime = DateFormat.jm().format(d);
      return '${AppStrings.yesterday}, $formattedTime';
    } else if (diff.inDays >= 1) {
      DateFormat format = DateFormat(AppStrings.ddMMYYYYDateFormat);
      String formattedTime = DateFormat.jm().format(d);
      return '${format.format(d)}, $formattedTime';
    } else if (diff.inMinutes >= 120 && diff.inHours <= 24) {
      return "${diff.inHours} ${AppStrings.hoursAgo}";
    } else if (diff.inMinutes >= 59 && diff.inMinutes <= 119) {
      return AppStrings.oneHourAgo;
    } else if (diff.inMinutes >= 2 && diff.inMinutes <= 59) {
      return "${diff.inMinutes} ${AppStrings.minutesAgo}";
    } else if (diff.inSeconds >= 59 && diff.inSeconds <= 120) {
      return AppStrings.oneMinuteAgo;
    } else {
      return AppStrings.now;
    }
  }
}
