import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';

class SizeConfig {
  static late MediaQueryData _mediaQueryData;
  static late double screenWidth;
  static late double screenHeight;
  static double? defaultSize;
  static Orientation? orientation;

  void init(BuildContext context) {
    Get.width.toString();
    //_mediaQueryData = MediaQuery.of(context);
    screenHeight = Get.height;
    screenWidth = Get.width;

    print("${screenHeight}+${screenWidth}");
  }
}

// Get the proportionate height as per screen size
double getHeight(double inputHeight) {
  double screenHeight = SizeConfig.screenHeight;
  // 812 is the layout height
  return (inputHeight / AppValues.deviceHeight) * screenHeight;
}

// Get the proportionate height as per screen size
double getWidth(double inputWidth) {
  double screenWidth = SizeConfig.screenWidth;
  // 375 is the layout width
  return (inputWidth / AppValues.deviceWidth) * screenWidth;
}

double getScreenHeight() {
  return SizeConfig.screenHeight;
}

double getScreenWidth() {
  return SizeConfig.screenWidth;
}

double getHugScreenWidth(double padding) {
  double screenWidth = SizeConfig.screenWidth;
  // 375 is the layout width
  return screenWidth - (padding * 2);
}
