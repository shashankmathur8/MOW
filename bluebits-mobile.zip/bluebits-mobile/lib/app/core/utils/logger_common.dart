import 'package:get/get.dart';
import '../../../flavors/build_config.dart';
import '../../common_binding/realm_initial.dart';
import '../values/logger_level.dart';

class ApplicationLogger {
  final logger = BuildConfig.instance.config.logger;

  String selectedLogLevel=LoggerLevelConstants.error;

  printInfo(String message, String origin) {
    logger.i(message);
    _printLog(message, LoggerLevelConstants.info, origin);
  }

  printError(String message, String origin) {
    logger.e(message);
    _printLog(message, LoggerLevelConstants.error, origin);
  }

  printVerbose(String message, String origin) {
    logger.v(message);
    _printLog(message, LoggerLevelConstants.verbose, origin);
  }

  printDebug(String message, String origin) {
    logger.d(message);
    _printLog(message, LoggerLevelConstants.debug, origin);
  }

  printWarning(String message, String origin) {
    logger.w(message);
    _printLog(message, LoggerLevelConstants.warning, origin);
  }

  printDefault(String message, String origin) {
    logger.wtf(message);
    _printLog(message, LoggerLevelConstants.whatATerribleFailureLog, origin);
  }

  _printLog(String message, String logLevel, String origin) {
    RealmInitial realm = Get.find(tag: (RealmInitial).toString());

    if (selectedLogLevel == logLevel) {
      switch (selectedLogLevel) {
        case LoggerLevelConstants.info:
          {
            realm.insertAppLogs(message, logLevel, origin);
          }
          break;
        case LoggerLevelConstants.error:
          {
            realm.insertAppLogs(message, logLevel, origin);
          }
          break;
        case LoggerLevelConstants.verbose:
          {
            realm.insertAppLogs(message, logLevel, origin);
          }
          break;
        case LoggerLevelConstants.debug:
          {
            realm.insertAppLogs(message, logLevel, origin);
          }
          break;
        case LoggerLevelConstants.warning:
          {
            realm.insertAppLogs(message, logLevel, origin);
          }
          break;
        default:
          {
            realm.insertAppLogs(message, logLevel, origin);
          }
      }
    }
  }
}
