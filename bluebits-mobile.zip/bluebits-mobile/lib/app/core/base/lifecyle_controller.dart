import 'package:get/get.dart';

import '../../../flavors/build_config.dart';
import '../../common_binding/realm_initial.dart';
import '../connectivity_utils/connectivity_controller.dart';

class LifeCycleController extends SuperController {
  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());
  final ConnectivityController connectivity = Get.find();
  final logger = BuildConfig.instance.config.logger;
  @override
  void onDetached() {}

  @override
  void onInactive() {}

  @override
  void onPaused() {}

  @override
  void onResumed() {
    final isConnected = connectivity.isConnected.value;
    if (isConnected) {
      realm.initialSetup();
      logger.i(
          'Background to foreground detect : Realm will sync with mongo server if internet connectivity');
    }
  }
}
