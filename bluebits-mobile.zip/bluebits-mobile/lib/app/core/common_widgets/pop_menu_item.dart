import 'package:flutter/material.dart';

enum filterOptions { Warehouse, Truck }

class PopMenuItems {
  final ImageIcon icon;
  final String title;
  final filterOptions? type;

  PopMenuItems({
    required this.icon,
    required this.title,
    this.type,
  });
}
