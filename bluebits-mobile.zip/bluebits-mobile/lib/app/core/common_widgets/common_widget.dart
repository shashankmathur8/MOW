import 'package:flutter/material.dart';
import 'package:slb_gt_mobile/app/core/common_widgets/pop_menu_item.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';

import '../utils/size_config.dart';
import '../values/app_strings.dart';

class CustomWidgets {
  List<PopupMenuEntry<dynamic>> popMenuList = List.empty(growable: true);

  List<PopupMenuItem> buildPopupMenu(List<PopMenuItems> items) {
    List<PopupMenuItem> menuItems = [];
    for (int i = 0; i < items.length; i++) {
      PopupMenuItem item = PopupMenuItem(
        value: items[i].type,
        child: Column(
          children: [
            Row(children: [
              items[i].icon,
              const SizedBox(
                width: SizeConstants.dp17,
              ),
              Text(
                items[i].title,
                style: const TextStyle(
                    fontWeight: AppValues.fontWeight400,
                    fontSize: SizeConstants.dp15),
              )
            ]),
          ],
        ),
      );
      menuItems.add(item);
    }
    return menuItems;
  }

  PopupMenuButton buildPopupMenuButton(List<PopMenuItems> items) {
    for (int i = 0; i < items.length; i++) {
      popMenuList
          .add(_buildPopupMenuItem(items[i].title, items[i].icon, false));
    }
    return PopupMenuButton(itemBuilder: (ctx) => popMenuList);
  }

  PopupMenuItem _buildPopupMenuItem(
      String title, ImageIcon iconData, bool isLastParameter) {
    return PopupMenuItem(
      padding: const EdgeInsets.all(0),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(AppValues.padding_24),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                iconData,
                const SizedBox(
                  width: SizeConstants.dp20,
                ),
                Text(title),
              ],
            ),
          ),
          Visibility(
            visible: isLastParameter,
            child: const Divider(
              indent: 0,
              thickness: SizeConstants.dp2,
              color: AppColors.colorGrey300,
            ),
          )
        ],
      ),
    );
  }

  roundIconWidget(String imagePath,
      {double iconWidth = SizeConstants.dp60,
      double iconHeight = SizeConstants.dp60}) {
    return Image.asset(imagePath, width: iconWidth, height: iconHeight, fit: BoxFit.fill,);
  }

  headerTitle(String titleText, TextStyle style) {
    return Flexible(
      child: Text(
        titleText,
        style: style,
      ),
    );
  }
}
