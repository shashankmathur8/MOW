import 'package:flutter/material.dart';

import '../values/app_colors.dart';
import 'app_bar_title.dart';

//Default appbar customized with the design of our app
class CustomAppBar extends StatelessWidget {
  //with PreferredSizeWidget {
  final String appBarTitleText;
  final List<Widget>? actions;
  final bool isBackButtonEnabled;

  const CustomAppBar({
    Key? key,
    required this.appBarTitleText,
    this.actions,
    this.isBackButtonEnabled = true,
  }) : super(key: key);

 /* @override
  Size get preferredSize => AppBar().preferredSize;*/

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: AppColors.colorPrimaryLight,
      centerTitle: true,
      elevation: 0,
      automaticallyImplyLeading: isBackButtonEnabled,
      actions: actions,
      iconTheme: const IconThemeData(color: AppColors.colorWhite),
      title: AppBarTitle(text: appBarTitleText),
    );
  }
}
