import 'package:flutter/material.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';

import '../values/app_colors.dart';

class NoResultsScreen extends StatelessWidget {
  final double? iconWidth;
  final double? iconHeight;
  final String imagePath;
  final String titleText;
  final String descriptionText;
  final String? buttonText;
  final TextStyle? titleStyle;
  final TextStyle? descriptionStyle;
  final TextStyle? buttonStyle;
  final VoidCallback onPressCallback;

  const NoResultsScreen(
      {Key? key,
      this.iconWidth = SizeConstants.dp98,
      this.iconHeight = SizeConstants.dp117,
      required this.imagePath,
      required this.titleText,
      required this.descriptionText,
      this.titleStyle,
      this.descriptionStyle,
      this.buttonText,
      this.buttonStyle,
      required this.onPressCallback})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Image.asset(
          imagePath,
          width: getWidth(iconWidth!),
          height: getHeight(iconHeight!),
          fit: BoxFit.fitWidth,
        ),
        const SizedBox(
          height: SizeConstants.dp15,
        ),
        Text(
          titleText,
          style: titleStyle,
        ),
        const SizedBox(
          height: SizeConstants.dp15,
        ),
        Text(descriptionText, style: descriptionStyle, textAlign: TextAlign.center),
        if (buttonText?.trim().isNotEmpty == true)
          const SizedBox(
            height: SizeConstants.dp15,
          ),
        if (buttonText?.trim().isNotEmpty == true)
          InkWell(
              highlightColor: AppColors.transparentColor,
              splashColor: AppColors.transparentColor,
              splashFactory: NoSplash.splashFactory,
              onTap: onPressCallback,
              child: Text(
                buttonText!,
                style: buttonStyle,
              )),
      ],
    );
  }
}
