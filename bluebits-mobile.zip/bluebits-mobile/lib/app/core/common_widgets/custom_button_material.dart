import 'package:flutter/material.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';

class CustomButtonMaterial extends StatelessWidget {
  final double? width;
  final double? height;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final double? borderRadius;
  final String text;
  final TextStyle? style;
  final BorderSide? side;
  final String? iconPath;
  final VoidCallback onPressCallback;

  const CustomButtonMaterial(
      {Key? key,
      this.width,
      this.height,
      this.backgroundColor,
      this.foregroundColor,
      this.borderRadius,
      required this.text,
      this.style,
      this.side,
      required this.onPressCallback,
      this.iconPath})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: backgroundColor,
          foregroundColor: foregroundColor,
          splashFactory: NoSplash.splashFactory,
          elevation: 0,
          side: side,
          shape: borderRadius != null
              ? RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(borderRadius!))
              : null,
        ),
        onPressed: () {
          onPressCallback();
        },
        child: iconPath == null
            ? Text(
                text,
                style: style,
              )
            : Wrap(
              crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Image.asset(iconPath!),
                  const SizedBox(
                    width: SizeConstants.dp8,
                  ),
                  Text(
                    text,
                    style: style,
                  )
                ],
              ),
      ),
    );
  }
}
