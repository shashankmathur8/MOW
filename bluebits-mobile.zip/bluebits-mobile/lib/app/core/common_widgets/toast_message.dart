import 'package:flutter/material.dart';

import '../utils/size_config.dart';
import '../values/app_colors.dart';
import '../values/app_images.dart';
import '../values/app_values.dart';
import '../values/size_constants.dart';
import '../values/text_styles.dart';

enum ToastStatus { success, failure, info, warning }

class ToastMessage extends ModalRoute<void> {
  String message;
  ToastStatus status;

  ToastMessage({required this.message, required this.status});

  @override
  Duration get transitionDuration => const Duration(milliseconds: 0);

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => false;

  @override
  Color get barrierColor => AppColors.colorBlack.withOpacity(0);

  @override
  String get barrierLabel => '';

  @override
  bool get maintainState => true;

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    // This makes sure that text and other content follows the material style
    return Material(
      type: MaterialType.transparency,
      // make sure that the overlay content is not cut off
      child: SafeArea(
        child: _buildOverlayContent(context),
      ),
    );
  }

  Widget _buildOverlayContent(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: SizeConstants.dp30),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: getHeight(SizeConstants.dp50),
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.colorGrey.withOpacity(0.3),
                      spreadRadius: AppValues.radius_2,
                      blurRadius: AppValues.radius_7,
                      offset: const Offset(0, 3), // changes position of shadow
                    ),
                  ],
                  color: AppColors.colorPrimary,
                  borderRadius: const BorderRadius.all(
                      Radius.circular(SizeConstants.dp6)),
                  border: Border.all(
                      width: SizeConstants.dp1,
                      color: AppColors.colorPrimary),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: SizeConstants.dp20,
                      vertical: SizeConstants.dp5),
                  child: Row(
                    children: [
                      InkWell(
                        child: Container(
                            height: getWidth(SizeConstants.dp24),
                            width: getWidth(SizeConstants.dp24),
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage(status == ToastStatus.success
                                    ? AppImages.success
                                    : status == ToastStatus.failure
                                        ? AppImages.failure
                                        : AppImages.icInfoW),
                                fit: BoxFit.fill,
                              ),
                            ),
                            child: null),
                      ),
                      SizedBox(
                        width: getWidth(SizeConstants.dp15),
                      ),
                      Text(
                        message,
                        style: tSw400dp14fontF.copyWith(
                          color: AppColors.colorWhite,
                          fontSize: SizeConstants.dp17,
                        ),
                      ),
                      SizedBox(
                        width: getWidth(SizeConstants.dp15),
                      ),
                      InkWell(
                        child: const Icon(
                          Icons.close,
                          color: AppColors.colorWhite,
                          size: SizeConstants.dp25,
                        ),
                        onTap: () {
                          //Navigator.of(context).pop();
                        },
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        )
      ],
    );
  }

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    // You can add your own animations for the overlay content
    return FadeTransition(
      opacity: animation,
      child: ScaleTransition(
        scale: animation,
        child: child,
      ),
    );
  }
}
