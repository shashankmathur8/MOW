abstract class AppStrings {
  static const String login = 'Login';
  static const String signout = 'Sign Out';
  static const String primary = 'Primary';
  static const String searchHintText =
      "Search by BOM, Serial Number, Bit Size or Bit Type";
  static const String recentSearches = "Recent Searches";
  static const String hintConsignSearch =
      "Consignment ID, serial number, customer, rig name";
  static const String hintBilledBitsSearch =
      "Billing ID, serial number, customer, rig name";

  static const String inventory = 'Inventory';
  static const String consignedBits = 'Consigned Bits';
  static const String billedBits = 'Ticketed Bits';
  static const String trackRequest = 'Track Request';
  static const String bitAdvisor = 'Bit Advisor';

  static const String syncNow = 'Sync Now';

  static const String noInternetConnection = 'No Internet Connection';
  static const String noInternetConnectionDes =
      'Please check you internet connection\nand try again';
  static const String tryAgain = 'Try Again';

  static const String requestbit = 'Request Bit';
  static const String customername = 'Enter Customer Name';
  static const String customerNameSmall = 'Enter customer name';
  static const String customer = 'Customer';
  static const String customerRequired = 'Customer*';
  static const String selectCustomer = 'Select Customer ';
  static const String rigname = 'Enter Rig Name';
  static const String rig = 'Rig';
  static const String rigRequired = 'Rig*';
  static const String selectRig = 'Select Rig ';
  static const String selectsize = 'Select Size';
  static const String size = 'Size';
  static const String selectprobability = 'Select Probability';
  static const String probability = 'Probability';
  static const String selectbit = 'Select Bit Type';
  static const String bittype = 'Bit Type';
  static const String dateformat = 'DD-MM-YYYY';
  static const String requestbitby = 'Request Bit By';
  static const String selectjobtype = 'Select Job Type';
  static const String jobtype = 'Job Type';
  static const String followrunup = 'FOLLOW-UP RUN';
  static const String keycustomer = 'KEY CUSTOMER';
  static const String targetgrowthcustomer = 'TARGET GROWTH CUSTOMER';
  static const String comments = 'Comments';
  static const String writecomments = 'Write Comments';
  static const String bitrequest =
      'Bit request will be sent to all the admins via email.';
  static const String addSignatureInfo =
      'By signing this document with an electronic signature, I agree that such signature will be as valid as handwritten signatures to the extent allowed by local law.';
  static const String cancel = 'Cancel';
  static const String submit = 'Submit';
  static const String selecttruck = 'Select Truck';
  static const String confirm = 'Confirm';
  static const String acceptSign = 'Accept & Sign';
  static const String downloadComplete = "Download Complete";
  static const String quotePDFExt = '.pdf';
  static const String pleaseSign = 'Please Sign Here';
  static const String clear = 'Clear';
  static const String movebitToMyTruck = 'Move Bit(s) to My Truck?';
  static const String moveBitToWarehouse = 'Move Bit(s) to Warehouse?';
  static const String prevConsignmentQuote = 'Preview Consignment Quote';
  static const String prevBilledTicket = 'Preview Billed Ticket';
  static const String returnBits = "Return Bits";
  static const String alltheselected = 'All the selected';
  static const String doyouwanttoproceed = 'Do you want to proceed?';
  static const String willbemoved = 'Will be moved to';
  static const String allSelected = "All the selected ";
  static const String willBeReturned = " will be returned to ";

  static const String myTruckInventory = "My\nTruck Inventory.";

  static const String billingTicketGen =
      "Billing ticket will be generated for Sr. Nbr.";
  static const String forConsign = "for consignment ";
  static const String pendingInfo = 'Pending Information';
  static const String pendingInfoMsg =
      'Some of the mandatory fields needs to be\nupdated before signing the document.';
  static const String actionNeeded = 'Action Needed';

  // static const String wantToProceed = "Do you want to proceed?";
  static const String bits = 'Bits';
  static const String willbemovestoproceed =
      'Will be moved to preferred'; //warehouse
  static const String warehouse = 'Warehouse';
  static const String moveToTruck = "Move to Truck";
  static const String moveToWarehouse = "Move to Warehouse";
  static const String addCustomerSignature = "Add Customer Name and Signature";
  static const String addSignature = "Add User Name and Signature";
  static const String addNameSignature = "Add Name and Signature";
  static const String enterYourNameHint = "Enter sales representative name";
  static const String firstLastName = "FirstName LastName";
  static const String district = 'District';
  static const String plant = 'Plant';
  static const String truck = 'Truck';
  static const String myTruck = "My Truck";
  static const String myDistrict = "My District";
  static const String slocPrefix = "SLOC - ";
  static const String districtPrefix = "District - ";
  static const String warehouseShort = "OH";
  static const String consign = "Consign";
  static const String truckShort = "TRK";
  static const String otherDistrict = "Other Districts";
  static const String otherDistrictValue = "US/Canada Land";
  static List<String> listProbability = [
    '10',
    '20',
    '30',
    '40',
    '50',
    '60',
    '70',
    '80',
    '90',
    '100'
  ];
  static const String consignBits = 'Consign Bits';

  static const String discardChanges = 'Apply changes';
  static const String discardChangesDes =
      'Do you want to apply the recent changes ?';

  static const String noBitsToConsign = 'No Bits to consign';
  static const String noBitsToConsignDes =
      'You will have no bits to consign once you confirm it. \n\nDo you want to Proceed.';

  static const String pendingConsignments = 'Pending Consignments';
  static const String pendingBillings = 'Pending Tickets';
  static const String draft = "Draft";
  static const String processing = "Processing";
  static const String completed = "Completed";
  static const String myConsignments = 'My Consignments';
  static const String myBilledBits = 'My Tickets';

  static const String pendingConsignmentsDesPrefix =
      'You have still few bits left to consign. If you\nwill leave this page, your consignment will be\nsaved as a draft in ';
  static const String pendingBillDesPrefix =
      'You have still few bits left to ticket. If you will leave this page, your tickets will be saved as\na draft in ';
  static const String pendingConsignmentsDesBold = '“Consigned Bits”';
  static const String pendingBilledDesBold = '“Ticketed Bits”';
  static const String pendingConsignmentsDesSuffix =
      '\n\nDo you want to Proceed.';

  static const String noResultsFound = 'No Results Found';
  static const String noResultsDescription =
      'Sorry! We couldn\’t find any results.';

  static const String inch = 'in';
  static const String mm = 'mm';

  static const String next = 'Next';
  static const String quotePreview = 'Quote Preview';
  static const String ok = 'OK';
  static const String add = 'Add';
  static const String apply = 'Apply';
  static const String filters = 'Filters';
  static const String reset = 'Reset';
  static const String resetTitle = 'Reset to default?';
  static const String resetMsg1 = 'You will lose any changes which you have';
  static const String resetMsg2 = 'made to column settings.';
  static const String resetMsg3 = 'Do you want Proceed?';
  static const String search = 'Search';
  static const String more = 'More';
  static const String clearAll = 'Clear All';
  static const String save = 'Save';
  static const String columnSettings = 'Column Settings';
  static const String close = 'Close';
  static const String no = 'No';
  static const String yes = 'Yes';
  static const String returnBit = 'Return';

  static const String only8ColumnsSelectMessage =
      'Only 8 columns can be selected';

  static const String enterDetails = 'Enter Details';
  static const String selectPricebook = 'Select Pricebook';
  static const String quote = 'Quote';
  static const String ticket = 'Ticket';
  static const String ticketLater = 'Ticket Later';
  static const String ticketNow = 'Ticket Now';
  static const String ticketBits = 'Ticket Bits';
  static const String ticketBit = 'Ticket Bit';
  static const String ticketed = 'Ticketed';
  static const String ticketLaterDescription =
      'You will not be able to edit it once moved to “Ticket Later”. Are you sure you want to move bits  ';
  static const String consignmentTicketSubmitted =
      'Consignment ticket submitted';
  static const String billingTicketSubmitted = 'Billing ticket submitted';
  static const String ticketingId = 'Ticketing ID: ';
  static const String consignmentId = 'Consignment ID: ';
  static const String ticketCopy =
      'Ticket copy will be sent to you and customer via email';
  static const String consignmentCopy =
      'Consignment copy will be sent to you and customer via email';

  static const String selectedBits = 'Selected Bit(s) ';

  static const String customerEmailReq = 'Customer Email*';
  static const String hintEmail = 'email@address.com';
  static const String errorEmail = 'Enter a valid email';

  static const String bitSuccessMsg = 'Requested bit submitted successfully';
  static const String bitFailureMsg = 'Requested bit failed to submit';

  static const String wareHouseMoveSuccessMsg =
      'Bits moved to warehouse successfully';
  static const String wareHouseMoveFailureMsg = 'Bits failed to move warehouse';
  static const String truckMoveSuccessMsg = 'Bits moved to truck successfully';
  static const String truckeMoveFailureMsg = 'Bits failed to move in the truck';
  static const String backToConsignedBits = 'Back to Consigned Bits';
  static const String backToInventory = 'Back to Inventory';
  static const String gotoTicketedBits = 'Go to Ticketed Bits';
  static const String gotoConsignedBits = 'Go to Consigned Bits';
  static const String signatureConfirmation = 'Signature Confirmation';
  static const String download = "Download";
  static const String signatureConfirmationMsg =
      'Your Signature has been successfully saved\nwith the quotation. If the quote is changed\nyour signature becomes invalid.';

  static const String deleteDraftTitle = 'Delete Draft';
  static const String deleteDraftMsg = 'Do you want to delete draft?';

  static const String searchPricebookMasterCode =
      'Search Pricebook, Master Code, SLB\nMaterial & SLB Description';
  static const String addPricebook = 'Add Pricebook';
  static const String addLineItem = 'Add Line Item';

  // static const String selectPriceBookDropDown = 'Select Pricebook';
  static const String searchByMasterCode = 'Search by Master Code';
  static const String searchBySlbMaterial = 'Search by SLB Material';
  static const String searchBySlbDescription = 'Search by SLB Description';
  static const String searchFilterPriceBook =
      'Search by Master Code, SLB Material or SLB Description';

  static const String rowId = 'Row ID';
  static const String description = 'Description';
  static const String material = 'Material';
  static const String uom = 'UoM';
  static const String code = 'Code';
  static const String revenueAccount = 'Revenue Account';
  static const String unitPrice = 'Unit Price';
  static const String currency = 'Currency';
  static const String hLReference = 'HL Reference';
  static const String sHLReference = 'SHL Reference';

  static const String required = '*';
  static const String bestPrice = 'Best Price';
  static const String lineComments = 'Comments';
  static const String drilled = 'Drilled';
  static const String hintDrilled = 'Enter';
  static const String priceper = 'Price per';
  static const String hintbestPrice = '00.00';
  static const String hintlineComments = 'Enter comments';
  static const String bestPriceErr = 'Enter best price';
  static const String price = 'Price';
  static const String editValue = 'Edit the values before proceeding';
  static const String deleteItem = 'Delete a Line Item?';
  static const String deleteConfirmation =
      'You are going to delete a line item from the pricebook.\n\nAre you sure?';

  static const String errorBestPrice = 'Enter best price';
  static const String errorEnter = 'Enter '; //last char space required
  static const String errorDrilled = ' drilled'; //first char space required
  static const String errorPricePer =
      'Enter price per '; //last char space required

  static const String quoteBit = "Bit";
  static const String quoteBitSr = "JK631";
  static const String manualSign = "Manual Sign";
  static const String digitalSign = "Digital Sign";
  static const String signCaptured = 'Signature Captured';
  static const String uploadSignedQuote = 'Upload Signed Quote';
  static const String print = 'Print';
  static const String quoteUploaded = 'Quote Uploaded';
  static const String infoMessageForDisableStepsDigital =
      'To enable/edit “Enter Details” & “Select Pricebook” please delete the signed quote';
  static const String infoMessageForDisableStepsManual =
      'To enable “Enter Details” & “Select Pricebook” please delete the uploaded quote';
  static const String infoBillLaterProceed =
      'Select “Ticket Later” if you want to ticket it later from FDP. Do you want to proceed?';
  static const String infoTicketLater =
      'All these tickets have to be processed/ticketed through FDP/FMS';

  static const String noDataFound = 'No data found';
  static const String feet = 'Feet';
  static const String meter = 'Meter';
  static const String day = 'Day';
  static const String hour = 'Hour';
  static const String week = 'Week';
  static const String chooseFile = 'Choose File';
  static const String toUpload = 'to upload';
  static const String warningMbSize = 'Max File Size 20MB';
  static const String pdfExtension = '.pdf';
  static const String iAgreeStatementOnUploadAttachment =
      'I agree that the attachment is validated and it has a valid Consignment ID or GT Reference ID.';

  static const String bitSize = 'bitSize';
  static const String serialNumber = 'serialNumber';
  static const String materialNumber = 'materialNumber';

  static const String isDigital = "isDigital";
  static const String isManual = "isManual";
  static const String tag = "tag";
  static const String htmlMime = "text/html";
  static const String updatedValue = "updatedValue";

  static const notification = 'Notifications';

  /*App Cleanup*/
  //Realm_initial
  static const String mailId = 'mailId == \$0';
  static String noOfRuns = "No. of Runs";
  static String used = 'Used';
  static String newChar = 'New';
  static String currentLocation = "Current Location";
  static String slocDesc = "SLOC/Description";
  static String status = "Status";
  static String noInternet =
      "No Internet. Data will be synced when back online.";

  static String materialDesc = "Material Description";

  static const String noTicketToConsign = 'No Bits to ticket';
  static const String noTicketToConsignDes =
      'You will have no bits to ticket once you confirm it. \n\nDo you want to Proceed.';

  static searchBitsQuery(String value) {
    return "bitSize == '$value' OR serialNumber == '$value' OR bitType == '$value' OR materialNumber == '$value'";
  }

  static const myTrucStorageLocQuery = 'storageLoc == \$0';
  static const myDistrictQuery = 'plant == \$0';
  static const otherDistrictQuery = 'storageLoc != \$0 && storageLoc != \$1';
  static const recentSearchesQuery = "_id == oid(6489513d657ab68eb05d4f2f)";
  static const bitTypeKey = "bitType";
  static const commentsKey = "comments";
  static const customerKey = "customer";
  static const jobTypeKey = "jobType";
  static const probabilityKey = "probability";
  static const requestBitKey = "requestBitBy";
  static const rigKey = "rig";
  static const sizeKey = "size";
  static const truckUserMappingId = 1;
  static const user = "Sales representative";
  static const recentSearchDataObjectHex = "6489513d657ab68eb05d4f2f";
  static const deviceIDQuery = 'deviceID == \$0';
  static const testUser = "TestUser";
  static const selected = "Selected";

  static const timeoutException = 'Timeout exception';

  static const sign1 = 'Signature 1';
  static const sign2 = 'Signature 2';
  static const prefixConsignmentID = "C";
  static const prefixQuoteID = "Q";
  static const prefixTicketID = "T";
  static const prefixReturnID = "R";

  static const pendingAction1 = '1';
  static const pendingAction2 = '2';

  static const imagePickErrorMessage = 'Invalid image data.';
  static const fillNullStringWithDash = '-';

  static const switchToManualTitle = 'Switch to Manual Sign?';
  static const switchToDigitalTitle = 'Switch to Digital Sign?';

  static const switchToManualMsg =
      'By selecting this option, you will lose all the\ninformation added in Digital Sign.\n\nDo you want to proceed?';
  static const switchToDigitalMsg =
      'By selecting this option, you will lose all the\ninformation added in Manual Sign.\n\nDo you want to proceed?';

  static const nullString = 'null';
  static const zeroSpaceCharacter = '\u200B';

  static const usCountryCode = 'US';
  static const genericLineItemCode = 'BITSOPSGEN';

  static const bitIsEitherInDraftOrConsigned =
      "Bit is either in draft or consigned";
  static const bitIsRemovedFromTheDraft = "Bit is removed from the draft";

  static const signIssue = "Some error occured, Please try again";
  static const maximumNumOfFilesAllowed = "Maximum 20 files are allowed !!";
  static const refresh = 'Refresh';
  static const defaultDateFormat = 'yyyy-MM-dd HH:mm:ss';
  static const ddMMYYYYDateFormat = 'dd-MM-yyyy';
  static const yesterday = 'Yesterday';
  static const hoursAgo = 'hours ago';
  static const oneHourAgo = '1 hour ago';
  static const minutesAgo = 'minutes ago';
  static const oneMinuteAgo = 'a minute ago';
  static const now = 'Now';

  static const selectWell = 'Type & Search Well';
  static const wellRequired = 'Well*';
  static const startDateRequired = 'Start Date*';
  static const endDateRequired = 'End Date*';
  static const consumptionTypeRequired = 'Consumption Type*';
  static const consumptionTypeHint = 'Select Consumption Type';
  static const selectConditionHint = 'Select Condition*';
  static const billToRequired = 'Bill To*';
  static const shipToRequired = 'Ship To*';
  static const selectAddressHint = 'Select Address';
  static const salesRepresentativeRequired = 'Sales Representative (CEC)*';
  static const officeSalesManRequired = 'Office Sales Man (Design Engineer)*';
  static const selectNameHint = 'Select Name';
  static const errSelectValidWell = 'Select a valid Well';
  static const errEnterDate = 'Enter a date';
  static const errEnterValidDate =
      'End date should not be less than Start date';
  static const errSelectConsumptionType = 'Select Consumption Type';
  static const errSelectBillTo = 'Select Bill To';
  static const errSelectShipTo = 'Select Ship To';
  static const errSelectCEC = 'Select Sales Representative (CEC)';
  static const errSelectOfcSalesman = 'Select Office Sales Man';
  static const wellType = 'Well';
  static const consumptionType = 'Consumption';
  static const billToType = 'BillTo';
  static const shipToType = 'ShipTo';
  static const cecType = 'CEC';
  static const designEnggType = 'DesignEngineer';

  static const wentWrong = 'Something went wrong. Please try again.';

  static const containsSuccess = 'Success';
  static const containsFailed = 'Failed';
  static const returnInitiated = 'Return has been initiated';

  static const rentalConsumptionType = 'Rental';

  static List<String> listConsumptionType = [
    'Rental',
    'Rental + LIH',
    'Rental + DBR',
    'Sold'
  ];

  static List<String> conditionType = [
    ConsignStep.dbr,
    ConsignStep.rental,
    ConsignStep.rentalByDay,
    ConsignStep.rentalByHour,
    ConsignStep.rentalByFeet,
    ConsignStep.rentalByMeter,
    ConsignStep.rentalByWeek,
    ConsignStep.lih,
    ConsignStep.sale
  ];
}

class ConsignStep {
  static const stepTitle1 = 'Enter Details';
  static const stepDescription1 =
      'Enter Customer and Rig details for selected bits';

  static const stepTitle2 = 'Select Pricebook';
  static const stepDescription2 =
      'Select Pricebook for each bit to create quote';

  static const stepTitle3 = 'Quote';
  static const stepDescription3 = 'Review the quotation and consign the bit';

  static const stepTitle4 = 'Confirmation';
  static const stepDescription4 = 'Confirmation message with consignment ID';

  static const dbr = 'Damaged Beyond Repair';
  static const rental = 'Rental';
  static const rentalByDay = 'Rental by Day';
  static const rentalByHour = 'Rental by Hour';
  static const rentalByFeet = 'Rental by Feet';
  static const rentalByWeek = 'Rental by Week';
  static const rentalByMeter = 'Rental by Meter';
  static const lih = 'Lost In Hole';
  static const sale = 'Sale';
}

class TicketingBitsStep {
  static const stepTitle1 = 'Enter Details';
  static const stepDescription1 = 'Enter well, date range and other details';

  static const stepTitle2 = 'Select Pricebook';
  static const stepDescription2 =
      'Select pricebook line item for each bit to create a ticket';

  static const stepTitle3 = 'Ticket';
  static const stepDescription3 =
      'Review the billing ticket and ticket the bit';

  static const stepTitle4 = 'Confirmation';
  static const stepDescription4 = 'Confirmation message with billing ID';
}

class ConsignedBitsColumn {
  static const consignmentID = 'Consignment ID';
  static const customer = 'Customer';
  static const rigNameAndNo = 'Rig Name & No.';
  static const dateConsigned = 'Date Consigned';
  static const noOfBitsConsigned = 'No. of Bits Consigned';
  static const consignmentStatus = 'Consignment Status';
  static const emptyTitle = '';

  //Inner column name
  static const srNbr = 'Sr. Nbr';
  static const size = 'Size';
  static const type = 'Type';
  static const bom = 'BOM';
  static const noOfRuns = 'No. of Runs';
  static const daysInStatus = 'Days in Status';
  static const status = 'Status';
  static const selected = 'Selected';
}

class TicketedBitsColumn {
  static const billingID = 'Billing ID';
  static const customer = 'Customer';
  static const rigNameAndNo = 'Rig Name & No.';
  static const wellNameAndNo = 'Well Name & No.';
  static const dateTicketed = 'Date Ticketed';
  static const ticketStatus = 'Ticket Status';
  static const emptyTitle = '';
  static const datePushed = 'Date pushed to FDP';
  static const ticketingCompleted = 'Ticketing completed';

  //Inner column name
  static const srNbr = 'Sr. Nbr';
  static const size = 'Size';
  static const type = 'Type';
  static const bom = 'BOM';
  static const amountForBits = '\$ for Bit';
  static const status = 'Status';
}
