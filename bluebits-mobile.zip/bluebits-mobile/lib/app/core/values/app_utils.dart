import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:slb_gt_mobile/app/core/common_widgets/toast_message.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';

import 'app_strings.dart';

extension StringExtension on String? {
  String? useCorrectEllipsis() {
    return this?.replaceAll('', AppStrings.zeroSpaceCharacter);
  }

  String formatStringIfNull() {
    if (this == null || this?.isEmpty == true || this?.trim() == AppStrings.nullString) {
      return AppStrings.fillNullStringWithDash;
    }
    return this!;
  }
}

void printLog(String? msg) {
  if (msg != null) {
    print(msg);
  }
}

void showToastMsg(BuildContext? context, String message, ToastStatus status) {
  if (context != null) {
    Timer(const Duration(milliseconds: AppValues.milliseconds400), () {
      var msg = ToastMessage(
        message: message,
        status: status,
      );
      Navigator.of(context).push(msg);
      Timer(const Duration(seconds: AppValues.timeDuration1), () {
        Navigator.of(context).pop();
      });
    });
  }
}