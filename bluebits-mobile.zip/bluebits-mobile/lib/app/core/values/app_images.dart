abstract class AppImages {
  static const String appLogo = 'assets/images/logo.png';
  static const String brandLogo = 'assets/images/brandLogo.png';
  static const String user = 'assets/images/user.png';
  static const String down_arrow = 'assets/images/ic_down_arrow.png';
  static const String up_arrow = 'assets/images/ic_up_arrow.png';
  static const String user_small = 'assets/images/user_small.png';
  static const String filter = 'assets/images/Filter.png';
  static const String filterApplied = 'assets/images/ic_filter_applied.png';
  static const String billBits = 'assets/images/bill_bits.png';
  static const String trackRequest = 'assets/images/ic_track_request.png';
  static const String bitAdvisor = 'assets/images/ic_bit_advisor.png';
  static const String inventory = 'assets/images/inventory.png';
  static const String consignBits = 'assets/images/consign_bits.png';
  static const String rig = 'assets/images/drillrig.png';
  static const String dots = 'assets/images/dots.png';
  static const String noResults = 'assets/images/ic_no_results.png';

  static const String settings = 'assets/images/settings.png';
  static const String upArrow = 'assets/images/pagination_arrow.png';
  static const String warehouse = 'assets/images/warehouse.png';
  static const String warehouseIcon = 'assets/images/ic_warehouse.png';
  static const String money = 'assets/images/money.png';
  static const String previewColoredBig =
      'assets/images/preview_colored_big.png';
  static const String attachment = 'assets/images/attachment.png';
  static const String returnImage = 'assets/images/return.png';
  static const String truck = 'assets/images/truck.png';
  static const String myTruck = 'assets/images/my_truck.png';
  static const String selectedCheck = 'assets/images/selected_check.png';
  static const String cancelBlack = 'assets/icons/ic_cancel_black.svg';
  static const String icPriceBookPipe = 'assets/icons/ic_pricebook_pipe.svg';
  static const String icAddPriceBook = 'assets/images/ic_add_pricebook.png';
  static const String icAddPriceBookMini =
      'assets/images/ic_add_pricebook_mini.png';
  static const String icBillingColoredBig =
      'assets/images/billing_colored_big.png';

  static const String tickingClock = "assets/images/tickingClock.png";
  static const String icAddWhite = 'assets/images/ic_add_white.png';
  static const String icAddColored = 'assets/images/ic_add_primary.png';
  static const String cancelBlackPng = 'assets/images/ic_cancel_black.png';
  static const String navBack = 'assets/images/ic_nav_back.png';

  static const String icBlueTickMark = 'assets/images/ic_blue_tick_mark.png';
  static const String alertNoBitsConsign =
      'assets/images/ic_alert_no_bits_consign.png'; //
  static const String icEditPen = 'assets/images/ic_edit_pen.png';
  static const String drill = 'assets/images/drill.png';
  static const String ic_info = 'assets/images/ic_info.png';
  static const String icInfoW = 'assets/images/ic_info_w.png';

  static const String ic_drag = 'assets/images/ic_drag.png';

  static const String requestBit = 'assets/images/request_bit.png';
  static const String calendar = 'assets/images/ic_calendar.png';
  static const String info = 'assets/images/info.png';
  static const String searchHistory = 'assets/images/search_history.png';
  static const String search = 'assets/images/search.png';
  static const String success = 'assets/images/ic_success.png';
  static const String failure = 'assets/images/ic_failure.png';
  static const String tktSubmittedIcon = 'assets/images/ic_tkt_submitted.png';
  static const String icSignaturePen = 'assets/images/ic_signature_pen.png';
  static const String icSignaturePenBackground =
      'assets/images/ic_signature_pen_background.png';
  static const String icSignature = 'assets/images/ic_signature.png';

  static const String edit = 'assets/images/edit.png';
  static const String delete = 'assets/images/delete.png';
  static const String clone = 'assets/images/clone.png';
  static const String arrowRight = 'assets/images/arrowRight.png';
  static const String arrowDown = 'assets/images/arrowDown.png';
  static const String pricetag = 'assets/images/pricetag.png';
  static const String greenTick = 'assets/images/ic_green_tick.png';

  static const String quoteSignBg = 'assets/images/sign_bg.png';
  static const String quoteSignPressed = 'assets/images/img_sign_pressed.png';
  static const String quoteSignUnPressed =
      'assets/images/img_sign_unpressed.png';
  static const String quoteDeleteIcon = 'assets/images/ic_delete.png';
  static const String verticalDivider = 'assets/images/ic_v_divider.png';

  static const String usertruck = 'assets/images/usertruck.png';
  static const String userplant = 'assets/images/userplant.png';
  static const String userlogout = 'assets/images/userlogout.png';
  static const String userdistrict = 'assets/images/userdistrict.png';
  static const String uploadSignQuote = 'assets/images/uploadSignQuote.png';
  static const String uploadAttachmentFolderIcon =
      'assets/images/uploadAttachmentFolderIcon.png';
  static const String galleryUploadIcon = 'assets/images/galleryUploadIcon.png';

  static const String icArrowUpward = 'assets/images/ic_arrow_upward.png';
  static const String icArrowDownward = 'assets/images/ic_arrow_downward.png';
  static const String notificationIcon =
      'assets/images/ic_notification_lineal.png';
  static const String helpIcon = 'assets/images/ic_help.png';
  static const String backArrow = 'assets/images/ic_back.png';
  static const String warning = 'assets/images/warning.png';

  static const String notiWarning = 'assets/images/ic_noti_warning.png';
  static const String notiFail = 'assets/images/ic_noti_fail.png';
  static const String notiInfo = 'assets/images/ic_noti_info.png';
  static const String notiSuccess = 'assets/images/ic_noti_success.png';
  static const String wellIcon = 'assets/images/ic_well.png';

  static const String icTick = 'assets/images/ic_tick.png';
  static const String icCross = 'assets/images/ic_cross.png';

  static const String noInternetLogin = 'assets/images/no_internet_login.png';
}

abstract class AppIcons {
  static const String rightPathIcon = 'assets/icons/right_path.svg';
}
