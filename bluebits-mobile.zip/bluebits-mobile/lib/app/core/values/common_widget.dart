import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';

import 'app_colors.dart';

final filteringTextInputFormatter = FilteringTextInputFormatter.deny(
    RegExp(
        '(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])'),
    replacementString: '');

final filteringTextInputFormatterDecimal = FilteringTextInputFormatter.allow(
    RegExp(r'(^\d*\.?\d{0,2})'));


OutlineInputBorder outLineBorderDecor(double radius, double width, Color color) {
  return OutlineInputBorder(
    borderRadius: BorderRadius.circular(radius),
    borderSide: BorderSide(
        width: width, color: color),
  );
}

Widget noDataWidget(String message) {
  return Center(
    child: Text(
      message,
      style: tSw500dp16fontF.copyWith(
          color: AppColors.colorMainText),
      textAlign: TextAlign.center,
    ),
  );
}