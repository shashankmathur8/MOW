import 'package:flutter/material.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';

import 'app_colors.dart';
import 'app_values.dart';

const pageTitleStyle = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w600,
    height: 1.15,
    color: AppColors.colorWhite);

const smartSearchInputStyle = TextStyle(
    color: AppColors.colorMainText,
    fontSize: SizeConstants.dp14,
    fontWeight: FontWeight.w400,
    fontFamily: AppValues.fontFamily);

final bottomTabNotificationStyle = tSw500dp16fontF.copyWith(
  color: Colors.white,
  fontSize: SizeConstants.dp14,
);

const smartSearchFontStyle = TextStyle(
    color: AppColors.colorMainText,
    fontSize: SizeConstants.dp16,
    fontWeight: AppValues.fontWeight400,
    fontFamily: AppValues.fontFamily);

const dropDownTextStylePriceBook = TextStyle(
    color: AppColors.colorMainText,
    fontSize: SizeConstants.dp16,
    fontWeight: AppValues.fontWeight400,
    fontFamily: AppValues.fontFamily);

const dropDownListStyle = TextStyle(
    color: AppColors.colorMainText,
    fontSize: SizeConstants.dp16,
    fontWeight: AppValues.fontWeight400,
    fontFamily: AppValues.fontFamily);

const pageTitleWhiteStyle = TextStyle(
    fontSize: 28,
    fontWeight: FontWeight.w600,
    height: 1.15,
    color: AppColors.colorWhite);

const extraBigTitleStyle = TextStyle(
  fontSize: 40,
  fontWeight: FontWeight.w600,
  height: 1.12,
);

const bigTitleStyle = TextStyle(
  fontSize: 28,
  fontWeight: FontWeight.w700,
  height: 1.15,
);

const mediumTitleStyle = TextStyle(
  fontSize: 24,
  fontWeight: FontWeight.w500,
  height: 1.15,
);

const descriptionTextStyle = TextStyle(
  fontSize: 16,
);

const bigTitleWhiteStyle = TextStyle(
  fontSize: 28,
  fontWeight: FontWeight.w700,
  height: 1.15,
  color: AppColors.colorWhite,
);

final outlineBorderMultiLine = OutlineInputBorder(
  borderRadius: BorderRadius.circular(AppValues.radius_10),
  borderSide: const BorderSide(
      width: SizeConstants.dp1, color: AppColors.colorSeparatorLine),
);

final inputDecoration = BoxDecoration(
  color: AppColors.colorGreyInputBox,
  border:
      Border.all(width: SizeConstants.dp1, color: AppColors.colorSeparatorLine),
  borderRadius: BorderRadius.circular(SizeConstants.dp10),
);

final inputDecorationPriceBook = BoxDecoration(
  color: AppColors.colorF5F6F5,
  border:
      Border.all(width: SizeConstants.dp1, color: AppColors.colorSeparatorLine),
  borderRadius: const BorderRadius.all(Radius.circular(SizeConstants.dp10)),
);

final smartSearchDecoration = inputDecoration.copyWith(
  color: AppColors.colorGreyInputBox.withOpacity(0.8),
  borderRadius: BorderRadius.circular(AppValues.radius_4),
  border:
      Border.all(width: SizeConstants.dp1, color: AppColors.colorSeparatorLine),
);

final smartSearchErrorDecoration = inputDecoration.copyWith(
  color: AppColors.colorGreyInputBox.withOpacity(0.8),
  borderRadius: BorderRadius.circular(AppValues.radius_4),
  border: Border.all(width: SizeConstants.dp1, color: AppColors.colorRedError),
);

const overLayPadding = EdgeInsets.symmetric(
    vertical: SizeConstants.dp10, horizontal: SizeConstants.dp16);

final overlayDecoration = BoxDecoration(
  color: AppColors.colorBg,
  border:
      Border.all(width: SizeConstants.dp1, color: AppColors.colorSeparatorLine),
  borderRadius: const BorderRadius.all(Radius.circular(SizeConstants.dp10)),
);

final overlayDecorationPriceBook = BoxDecoration(
  color: AppColors.colorF5F6F5,
  border:
      Border.all(width: SizeConstants.dp1, color: AppColors.colorSeparatorLine),
  borderRadius: const BorderRadius.all(Radius.circular(SizeConstants.dp10)),
);

const warehouseTextStyle = TextStyle(
    color: AppColors.colorBlack,
    fontSize: SizeConstants.dp26,
    fontWeight: FontWeight.w700,
    fontFamily: AppValues.fontFamily);

const wareHouseStaticTextStyle = TextStyle(
    color: AppColors.colorBlack,
    fontSize: SizeConstants.dp18,
    fontWeight: FontWeight.w400,
    fontFamily: AppValues.fontFamily);

final consignScreenTextStyle = tSw400dp14fontF.copyWith(
  color: AppColors.colorMainText,
  overflow: TextOverflow.ellipsis,
  fontSize: SizeConstants.dp15,
);

const wareHouseBitsTextStyle = TextStyle(
    color: AppColors.colorBlack,
    fontSize: SizeConstants.dp18,
    fontWeight: FontWeight.w600,
    fontFamily: AppValues.fontFamily);

const fontFamilyStyle = TextStyle(
  fontFamily: AppValues.fontFamily,
);

final tSw400dp11fontF = fontFamilyStyle.copyWith(
    fontWeight: FontWeight.w400, fontSize: SizeConstants.dp11);

final tSw400dp12fontF = fontFamilyStyle.copyWith(
    fontWeight: FontWeight.w400, fontSize: SizeConstants.dp12);

final tSw400dp14fontF = fontFamilyStyle.copyWith(
  fontWeight: FontWeight.w400,
  fontSize: SizeConstants.dp14,
);

final tSw400dp24fontF = fontFamilyStyle.copyWith(
  fontWeight: FontWeight.w400,
  fontSize: SizeConstants.dp24,
);

final tSw500dp12fontF = fontFamilyStyle.copyWith(
  fontWeight: FontWeight.w500,
  fontSize: SizeConstants.dp12,
);

final tSw400dp16fontF = fontFamilyStyle.copyWith(
  fontWeight: FontWeight.w400,
  fontSize: SizeConstants.dp16,
);

final tSw500dp16fontF = fontFamilyStyle.copyWith(
  fontWeight: FontWeight.w500,
  fontSize: SizeConstants.dp16,
);

final tSw500dp18fontF = fontFamilyStyle.copyWith(
  fontWeight: FontWeight.w500,
  fontSize: SizeConstants.dp18,
);

final tSw600dp14fontF = fontFamilyStyle.copyWith(
  fontWeight: FontWeight.w600,
  fontSize: SizeConstants.dp14,
);

final tSw600dp16fontF = fontFamilyStyle.copyWith(
  fontWeight: FontWeight.w600,
  fontSize: SizeConstants.dp16,
);

final tSw700fontF = fontFamilyStyle.copyWith(
  fontWeight: FontWeight.w700,
);

final tSw400dp18fontF = fontFamilyStyle.copyWith(
  fontWeight: FontWeight.w400,
  fontSize: SizeConstants.dp18,
);

final tSw500dp15fontF = fontFamilyStyle.copyWith(
  fontWeight: FontWeight.w500,
  fontSize: SizeConstants.dp15,
);

const tabLabelStyle = TextStyle(
  fontSize: SizeConstants.dp14,
  fontWeight: FontWeight.w600,
);
