class SecureStorageKeys {
  static const String authToken = "AUTH_TOKEN";

}