class PreferenceConstants {
  static const isTabletKey = "isTablet";
  static const isAndroid = "isAndroid";
  static const isIOS = "isIOS";
  static const accessToken = "accessToken";
  static const refreshToken = "refreshToken";
  static const idToken = "idToken";
  static const isAcceptedTndC = "isAcceptedTndC";
  static const isUserLoggedIn = "isUserLoggedIn";
  static const userEmail = "userEmail";
  static const userName = "userName";
  static const userTruckMapping = "userTruckMapping";
  static const isMovementHappen = "isMovementHappend";

}
