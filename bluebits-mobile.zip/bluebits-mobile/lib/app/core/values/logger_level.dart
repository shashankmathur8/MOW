class LoggerLevelConstants {
  static const info = "info";
  static const error = "error";
  static const debug = "debug";
  static const warning = "warning";
  static const whatATerribleFailureLog = "whatATerribleFailureLog";
  static const verbose = "verbose";
}
