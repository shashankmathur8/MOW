
import 'app_strings.dart';

enum NextButtonState {
  hide,
  disable,
  enable;
}

enum UnitState {
  EA,
  FT,
  M,
  DAY,
  HR,
  WK;
}

enum LineCondition {
  dbr(ConsignStep.dbr),
  rental(ConsignStep.rental),
  rentalByDay(ConsignStep.rentalByDay),//DAY
  rentalByHour(ConsignStep.rentalByHour),//HR
  rentalByFeet(ConsignStep.rentalByFeet),//FT
  rentalByMeter(ConsignStep.rentalByMeter),//M
  rentalByWeek(ConsignStep.rentalByWeek),//WK
  lih(ConsignStep.lih),
  sale(ConsignStep.sale);

  const LineCondition(this.value);
  final String value;
}

enum DropDownValue {
  masterCode,
  slbMaterial,
  slbDescription;
}

enum InputFieldType { unitDrilled, pricePerUnit, comments, bestPrice, lineCondition }