import 'dart:ui';

abstract class AppValues {
  static const double padding = 16;
  static const double halfPadding = 8;
  static const double smallPadding = 10;
  static const double extraSmallPadding = 6;
  static const double largePadding = 24;
  static const double extraLargePadding = 32;
  static const double padding_4 = 4;
  static const double padding_2 = 2;
  static const double padding_3 = 3;
  static const double padding_7 = 7;
  static const double padding_10 = 10;
  static const double padding_11 = 11;
  static const double padding_15 = 15;
  static const double padding_14 = 14;
  static const double padding_19 = 19;
  static const double padding_20 = 20;
  static const double padding_24 = 24;
  static const double padding_25 = 25;
  static const double padding_28 = 28;
  static const double padding_29 = 29;
  static const double padding_30 = 30;
  static const double padding_34 = 34;
  static const double padding_35 = 35;
  static const double padding_40 = 40;
  static const double buttonVerticalPadding = 12;

  static const double deviceHeight = 744.0;
  static const double deviceWidth = 1194.0;

  static const double margin = 16;
  static const double marginZero = 0;
  static const double smallMargin = 8;
  static const double extraSmallMargin = 6;
  static const double largeMargin = 24;
  static const double margin_40 = 40;
  static const double margin_32 = 32;
  static const double margin_35 = 35;
  static const double margin_18 = 18;
  static const double margin_2 = 2;
  static const double margin_3 = 3;
  static const double margin_4 = 4;
  static const double margin_5 = 5;
  static const double margin_6 = 6;
  static const double margin_7 = 7;
  static const double margin_8 = 8;
  static const double margin_11 = 11;
  static const double margin_12 = 12;
  static const double margin_13 = 13;
  static const double margin_15 = 15;
  static const double margin_14 = 14;
  static const double margin_10 = 10;
  static const double margin_19 = 19;
  static const double margin_24 = 24;
  static const double margin_25 = 25;
  static const double margin_28 = 28;
  static const double margin_29 = 29;
  static const double margin_30 = 30;
  static const double margin_33 = 33;
  static const double margin_34 = 34;
  static const double margin_36 = 36;
  static const double margin_20 = 20;
  static const double margin_22 = 22;
  static const double margin_47 = 47;
  static const double margin_49 = 49;
  static const double margin_75 = 75;
  static const double margin_76 = 76;
  static const double margin_89 = 89;
  static const double margin_100 = 100;
  static const double extraLargeMargin = 36;
  static const double marginBelowVerticalLine = 64;
  static const double extraLargeSpacing = 96;

  static const double cancelButtonHeight = 45;
  static const double cancelButtonWidth = 102;
  static const double saveButtonHeight = 45;
  static const double saveButtonWidth = 130;

  static const double radius = 16;
  static const double radiusZero = 0;
  static const double smallRadius = 8;

  static const double radius_1 = 1;
  static const double radius_2 = 2;
  static const double radius_4 = 4;
  static const double radius_5 = 5;
  static const double radius_6 = 6;
  static const double radius_7 = 7;
  static const double radius_10 = 10;
  static const double radius_12 = 12;
  static const double radius_13 = 13;
  static const double radius_25 = 25;
  static const double radius_20 = 20;
  static const double radius_30 = 30;
  static const double radius_32 = 32;
  static const double largeRadius = 24;
  static const double roundedButtonRadius = 24;
  static const double extraLargeRadius = 36;

  static const double elevation = 16;
  static const double smallElevation = 8;
  static const double extraSmallElevation = 4;
  static const double largeElevation = 24;

  static const double circularImageDefaultSize = 90;
  static const double circularImageSize_30 = 30;
  static const double circularImageDefaultBorderSize = 0;
  static const double circularImageDefaultElevation = 0;
  static const double momentThumbnailDefaultSize = 80;
  static const double momentSmallThumbnailDefaultSize = 32;
  static const double collectionThumbnailDefaultSize = 150;
  static const double defaultViewPortFraction = 0.9;
  static const int defaultAnimationDuration = 300;
  static const double listBottomEmptySpace = 200;
  static const double maxButtonWidth = 496;
  static const double stackedImageDefaultBorderSize = 4;
  static const double stackedImageDefaultSpaceFactor = 0.4;
  static const double stackedImageDefaultSize = 30;
  static const double profilePopupWidth = 349;
  static const double signConfirmPopupWidth = 571;
  static const double signConfirmPopupHeight = 267;

  static const double iconDefaultSize = 24;
  static const double emoticonDefaultSize = 22;
  static const double iconSize_20 = 20;
  static const double iconSize_22 = 22;
  static const double iconSize_18 = 18;
  static const double iconSmallSize = 16;
  static const double iconSmallerSize = 12;
  static const double iconSize_14 = 14;
  static const double iconSize_28 = 28;
  static const double iconSize_30 = 30;
  static const double iconLargeSize = 36;
  static const double iconSize_80 = 80;
  static const double iconExtraLargerSize = 96;
  static const double appBarIconSize = 32;

  static const double customAppBarSize = 144.0;
  static const double collapsedAppBarSize = 70.0;

  static const int loggerLineLength = 120;
  static const int loggerErrorMethodCount = 8;
  static const int loggerMethodCount = 2;

  static const double fullViewPort = 1;
  static const double indicatorDefaultSize = 8;
  static const double indicatorShadowBlurRadius = 1;
  static const double indicatorShadowSpreadRadius = 0;
  static const double appbarActionRippleRadius = 50;
  static const double activeIndicatorSize = 8;
  static const double inactiveIndicatorSize = 10;
  static const double datePickerHeightOnIos = 270;
  static const int maxCharacterCountOfQuote = 108;
  static const double barrierColorOpacity = 0.4;

  static const int defaultPageSize = 10;
  static const int defaultPageNumber = 1;
  static const int defaultDebounceTimeInMilliSeconds = 1000;
  static const int defaultThrottleTimeInMilliSeconds = 500;

  static const double height_16 = 16;

  static const int connectionTimeOutInMilliSeconds = 120000;
  static const int receiveTimeOutInMilliSeconds = 120000;
  static const int paddingZero = 0;
  static const int paddingOne = 1;
  static const int paddingTwo = 2;
  static const int paddingThree = 3;
  static const int paddingFour = 4;
  static const int paddingFive = 5;
  static const int paddingSix = 6;
  static const int paddingSeven = 7;
  static const int paddingEight = 8;
  static const int paddingNine = 9;
  static const int paddingTen = 10;

  //Custom Lib for bottom layout Constant
  static const double circleSize = 50;
  static const double arcHeight = 60;
  static const double arcWidth = 60;
  static const double circleOutline = 15;
  static const double shadowAllowance = 20;
  static const double barHeight = 70;
  static const double imageHeight = 24;
  static const int tabLength = 5;
  static const int tabCurrentPosition = 2;

  static const double iconOff = -3;
  static const double iconOn = 0;
  static const double textOff = 3;
  static const double textOn = 1;
  static const double alphaOff = 0;
  static const double alphaOn = 1;
  static const int animDuration = 300;
  static const int timeDuration0 = 0;
  static const int timeDuration1 = 1;
  static const int timeDuration2 = 2;
  static const int timeDuration3 = 3;
  static const int milliseconds400 = 400;

  static const double height_60 = 60;

  static const double width_365 = 365;

  //Tab
  static const int initialTab = 2;

  //Strings
  static const String fontFamily = 'SF Pro Display';
  static const String privacyUrl = 'https://www.slb.com/who-we-are/privacy';
  static const String termsUrl =
      'https://www.software.slb.com/terms-and-conditions';

  // To be moved to app strings
  static const String dashboardStr = "Dashboard";
  static const String bitsInvStr = "Bits Inventory";
  static const String myTruckTabStr = "My Truck";
  static const String myDistrictTabStr = "My District";
  static const String otherDistrictTabStr = "Other Districts";
  static const String requestBitStr = "Request Bit";
  static const String filterStr = "Filter";
  static const String consignedBitsStr = "Consigned Bits";
  static const String billedBitsStr = "Ticketed Bits";

  //FontWeight
  static const fontWeight200 = FontWeight.w200;
  static const fontWeight300 = FontWeight.w300;
  static const fontWeight400 = FontWeight.w400;
  static const fontWeight500 = FontWeight.w500;
  static const fontWeight600 = FontWeight.w600;
  static const fontWeight700 = FontWeight.w700;
}
