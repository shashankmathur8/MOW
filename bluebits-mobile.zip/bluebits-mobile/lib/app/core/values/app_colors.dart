import 'package:flutter/material.dart';

abstract class AppColors {
  static const Color textColorGreyLight = Color(0xFFABABAB);

  static Color elevatedContainerColorOpacity = colorGrey.withOpacity(0.5);

  static const colorGrey = Color(0xFFAAAAAA);
  static const colorGrey300 = Color(0xFFE0E0E0);

  static const colorLightWhite = Color(0xFFF3F3F3);
  static const colorGrayLight = Color(0xFFCECECE);
  static const colorGreyTransparent = Color(0xFFBFBFBF);

  ////
  static const transparentColor = Colors.transparent;
  static const bgColorTabSelected = Color(0xFF0A6E47);
  static const bgColorTabUnSelected = Color(0xFF617681);
  static const borderSelectedColor = Color(0xFF2B606B);
  static const topColorPrimaryDark = Color(0xFF2B606B);
  static const bottomColorPrimaryDark = Color(0xFF01713D);
  static const colorPrimary = Color(0xFF1E2E42);
  static const colorPrimaryLight = Color(0xFF147558);
  static const colorProfileRadius = Color(0xFFC1CFC1);
  static const colorDisabled = Color(0xFFCACDD1); //Disable button color
  static const colorDisabled2 = Color(0xFFEFF0F1); //Disable button text color
  static const colorWhite = Colors.white;
  static const colorConsignLeftPanel = Color(0xFFEBEFEB);
  static const colorRedError = Color(0xFFD11F1F);
  static const colorNotification = Color(0xFFF43A20);
  static const colorOrange = Color(0xFFFF5413);
  static const colorOrangeDraft = Color(0xFFEB8C00);
  static const colorGreen = Color(0xFF149C14);
  static const colorMainText = Color(0xFF272C39);
  static const colorSubText = Color(0xFF6B7885);
  static const colorPrimaryDarkText = Color(0xFF01713D);
  static const colorSeparatorLine = Color(0xFFBEC6BE);
  static const colorBlack = Colors.black;
  static const colorOffline = Color(0xFFD9D9D9);
  static const colorGreyInputBox = Color(0xFFF9F9F9);
  static const colorFilterTag = Color(0xFFCDDFCD);
  static const colorFilterTagBorder = Color(0xFFBCDBBC);
  static const colorSelection = Color(0xFFFFF0D7);
  static const colorLeftPanel = Color(0xFFE7EFE7);
  static const colorTopPanel = Color(0xFFE5ECE5);
  static const colorBg = Color(0xFFF5F6F5); //BG
  static const colorBackgroundPanel = Color(0xFFF2F5F2);
  static const colorF5F6F5 = Color(0xFFF5F6F5);
  static const colorCircleIcon = Color(0xFFF3F5F8);
  static const colorPrimaryDarkStep = Color(0xFF01713D);
  static const colorCheckBoxSelected = Color(0xFF01713D);
  static const colorCheckBoxUnselected = Color(0xFF6B7885);
  static const color5A7793 = Color(0xFF5A7793);
  static const colorCircleProgress = Color(0xFF2A9F7F);
  static const colorF1F4F9 = Color(0xFF1F4F9F);
}
