import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/base/base_controller.dart';
import 'package:slb_gt_mobile/app/core/utils/logger_common.dart';

import '../../modules/inventory/controller/inventory_controller.dart';

class ConnectivityController extends BaseController {
  final Connectivity _connectivity = Connectivity();
  RxBool isConnected = false.obs;

  late StreamSubscription streamSubscription;

  @override
  void onInit() {
    super.onInit();
    _checkInternetConnectivity();
    streamSubscription =
        _connectivity.onConnectivityChanged.listen((connectivityResult) {
      _checkInternetConnectivity();
    });
  }

  Future<void> _checkInternetConnectivity() async {
    var connectivityResult = await _connectivity.checkConnectivity();
    isConnected.value = (connectivityResult != ConnectivityResult.none);
    ApplicationLogger().printWarning('Internet connected :- ${isConnected.value}', 'ConnectivityController');
    try {
      final InventoryController inventoryController = Get.find();
      inventoryController.hitBitMovementApi(isConnected.value);
    } catch (e) {
      ApplicationLogger().printWarning(e.toString(), 'ConnectivityController');
    }
  }

  @override
  void onClose() {
    super.onClose();
    streamSubscription.cancel();
  }
}
