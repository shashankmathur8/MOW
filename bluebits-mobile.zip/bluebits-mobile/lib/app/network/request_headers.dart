import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:slb_gt_mobile/app/core/values/preference_constants.dart';

class RequestHeaderInterceptor extends InterceptorsWrapper {
  final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
  final String xEnvironment;

  RequestHeaderInterceptor(this.xEnvironment);

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    getCustomHeaders().then((customHeaders) {
      options.headers.addAll(customHeaders);
      super.onRequest(options, handler);
    });
  }

  Future<Map<String, String>> getCustomHeaders() async {
    final SharedPreferences prefs = await _prefs;
    var customHeaders = {
      'x-apikey': 'k8xf2yxe9K3rOFWLTUtytGyA8pvLtnK9',
      'Authorization': 'Bearer ${prefs.getString(PreferenceConstants.accessToken)}',
      'Connection': 'keep-alive',
      'Accept-Encoding': 'gzip, deflate, br',
      'Content-Type': 'application/json',
      'x-environment': xEnvironment
    };

    return customHeaders;
  }
}
