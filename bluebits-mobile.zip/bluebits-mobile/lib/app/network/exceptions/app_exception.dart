import '/app/network/exceptions/base_exception.dart';

class AppCustomException extends BaseException {
  AppCustomException({
    String message = "",
  }) : super(message: message);
}
