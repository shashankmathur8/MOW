import '/app/network/exceptions/app_exception.dart';

abstract class BaseApiException extends AppCustomException {
  final int httpCode;
  final String status;

  BaseApiException({this.httpCode = -1, this.status = "", String message = ""})
      : super(message: message);
}
