/* 

azure_application_insights: ^3.1.0


main.dart file

TelemetryClient telemetryClient = getTelemetryClient();

void logToAnalytics() async {
  TelemetryClient telemetryClient = getTelemetryClient();

  // You can include additional properties with any telemetry items, which is the second way of including properties.
  // In this case, the properties you provide are only attached to this particular telemetry item (in addition to those
  // on the telemetry client's context).
  telemetryClient.trackTrace(
    severity: Severity.verbose,
    message: 'Here is a trace with additional properties',
    additionalProperties: <String, Object>{
      'answer': 42,
    },
  );

  // Here is an event with different properties.
  telemetryClient.trackEvent(
    name: 'started',
    additionalProperties: <String, Object>{
      'timestamp': DateTime.now().toUtc().toIso8601String(),
    },
  );
}
  
TelemetryClient getTelemetryClient() {
  final client = Client();

  final processor = BufferedProcessor(
    next: TransmissionProcessor(
      instrumentationKey: '{AppKey}',
      httpClient: client,
      timeout: const Duration(seconds: 10),
    ),
  );

  final telemetryClient = TelemetryClient(
    processor: processor,
  );
  // specified below, but not the user ID. However, the user ID will still be present inside the customDimensions
  // for each trace event.
  telemetryClient.context
    ..applicationVersion = 'V1'
    ..user.id = 'flutter_mobileapp';

  // All the above helper properties do is provide a convenient means of setting key/value pairs inside
  // context.properties, which is the second way to set properties and is demonstrated here.
  telemetryClient.context.properties['custom'] = 'a custom property value';

  // Now we can send telemetry of various kinds. Here is a simple trace.
  telemetryClient.trackTrace(
    severity: Severity.information,
    message: 'Hello from Dart!',
  );
  return telemetryClient;
}


 */