import 'dart:convert';

import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:msal_flutter/msal_flutter.dart';
import 'package:slb_gt_mobile/app/core/values/app_utils.dart';
import 'package:slb_gt_mobile/app/core/values/logger_level.dart';
import 'package:slb_gt_mobile/app/core/values/preference_constants.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../flavors/build_config.dart';
import '../core/utils/logger_common.dart';
import '../modules/billed_bits/controller/ticketed_bits_controller.dart';
import '../modules/consigned_bits/controller/consigned_bits_controller.dart';
import '../modules/inventory/controller/inventory_controller.dart';
import '../modules/notification/controller/notification_controller.dart';

class AADAuthentication {
  final logger = BuildConfig.instance.config.logger;
  final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();

  static const String _authority =
      "https://login.microsoftonline.com/41ff26dc-250f-4b13-8981-739be8610c21";
  static const String _redirectUri = "msauth.com.slb.bluebits.ios://auth";
  static const String _clientId = "fffffad7-66e6-4742-82be-88264f4547d0";
  String _output = 'NONE';

  PublicClientApplication? pca;

  AADAuthentication._privateConstructor();

  static final AADAuthentication instance =
      AADAuthentication._privateConstructor();

//var applicationLogger= ApplicationLogger();

/*  Future<void> initialSetup() async {
    await initializingObject();

  }
  AADAuthentication.initalSync(){
    initialSetup();
  }*/

  initializingObject() async {
    try {
      // storage = const FlutterSecureStorage();
      if (pca == null) {
        Future.delayed(const Duration(milliseconds: 10000), () {
// Here you can write your code

          ApplicationLogger()
              .printInfo("Creating PCA", "MSAL initializingObject");
        });

        pca = await PublicClientApplication.createPublicClientApplication(
            _clientId,
            authority: _authority,
            iosRedirectUri: _redirectUri,
            privateSession: true);
        ApplicationLogger().printInfo("PCA Created", "MSAL initializingObject");
      }
    } catch (e) {
      logger.i("PCA not created");
      logger.e(" Exception Caught ${e.toString()}");
    }
  }

  Future<String?> acquireToken(context) async {
    //create the PCA if not already created

    String res;
    try {
      res = await pca!.acquireToken(
          ["api://7ad3f4ae-082a-4082-ba04-5c8198fb83d5/access_as_user"]);

      var fake_token =
          'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyJ9.eyJhdWQiOiI3YWQzZjRhZS0wODJhLTQwODItYmEwNC01YzgxOThmYjgzZDUiLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vNDFmZjI2ZGMtMjUwZi00YjEzLTg5ODEtNzM5YmU4NjEwYzIxL3YyLjAiLCJpYXQiOjE2OTA3OTg3MzYsIm5iZiI6MTY5MDc5ODczNiwiZXhwIjoxNjkwODc4MjM2LCJhaW8iOiJBWFFBaS84VUFBQUFHNVhOaGplSHRRcmlxY0U1MXN6NlNKb1phTVovTkdad3crZk5CczVIcHdxL25QaVBrTE9saFY5aHp0bExYTGFWMVlkcGJnMmFPYU9XN2FOQmVrQzIzZkxSeHdlMkt6eXhicWRodGhzKzAxSlIrZWI0clNkbGVDaWtSWWZuNEVya3E2UU5XY3Jwd1N1VWxLQmxZNXFMa0E9PSIsImF6cCI6ImZmZmZmYWQ3LTY2ZTYtNDc0Mi04MmJlLTg4MjY0ZjQ1NDdkMCIsImF6cGFjciI6IjAiLCJuYW1lIjoiU2h1YmhhbSBNaXR0YWwiLCJvaWQiOiJlM2VlNTVmZS00YTViLTRmMTUtOTg4OS00ZThmMTFmZmRhNjkiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJTTWl0dGFsNEBzbGIuY29tIiwicmgiOiIwLkFSRUEzQ2JfUVE4bEUwdUpnWE9iNkdFTUlhNzAwM29xQ0lKQXVnUmNnWmo3ZzlVUkFHNC4iLCJzY3AiOiJhY2Nlc3NfYXNfdXNlciIsInN1YiI6InpaMmF1VFhIZUNOMkVQMXNvRjB1eDZFdEM5WW5JR3MtMHN1MnZObjl1ZUUiLCJ0aWQiOiI0MWZmMjZkYy0yNTBmLTRiMTMtODk4MS03MzliZTg2MTBjMjEiLCJ1cG4iOiJTTWl0dGFsNEBzbGIuY29tIiwidXRpIjoiU3RjY3dqdFZEVUt0OVBuUHMzUUhBQSIsInZlciI6IjIuMCJ9.XVe2VcrkuIryU2s-A8J_2rAX-LIoalalVM9Fsn7dw47wyzb1VZK_EciWLViJ49y2ctYqgZPpV4WyeD_IxzIfi0406zynU0NYmkdEntwiqBM4oyKXd_bdT4Ewlys3Hzuht01xxzCp2DHhkAKLoliLcd7klFWAfuk-HtKcN98pknUTINicA4TRXTelot4wWgadJ7npv78o5pXWRgdBsJbhgIK72phu30q7JaUyvqBBzTCskWoz1Jubhv5ySVf-vWjeK2FxetL3mochgatyLigZeqw0Da9Lxc5S1169651A0RDk5Jfr8263Rv78JJKOAj5ADD8ZJ1KzpOwJP1WuwKrpM';

      final SharedPreferences prefs = await _prefs;

      prefs.setString(PreferenceConstants.accessToken, res);
      //prefs.setString(PreferenceConstants.accessToken, fake_token);
      prefs.setBool(PreferenceConstants.isUserLoggedIn, true);

      _output = parseJwt(res);
      Map<String, dynamic> map = jsonDecode(_output);
      prefs.setString(PreferenceConstants.userEmail, map['preferred_username']);
      prefs.setString(PreferenceConstants.userName, map['name']);
    } on MsalUserCancelledException {
      logger.e("User cancelled");
      res = "User cancelled";
    } on MsalNoAccountException {
      logger.e("no account");
      res = "no account";
    } on MsalInvalidConfigurationException {
      logger.e("invalid config");
      res = "invalid config";
    } on MsalInvalidScopeException {
      logger.e("Invalid scope");
      res = "Invalid scope";
    } on MsalException {
      logger.e("Error getting token. Unspecified reason");
      res = "Error getting token. Unspecified reason";
    }
    return _output;
  }

  Future<void> acquireTokenSilently() async {
    String res;
    try {
      if (pca == null) {
        logger.i("Initializing PCA");
        pca = await PublicClientApplication.createPublicClientApplication(
            _clientId,
            iosRedirectUri: _redirectUri,
            authority: _authority);
      }

      res = await pca!.acquireTokenSilent(
          ["api://7ad3f4ae-082a-4082-ba04-5c8198fb83d5/access_as_user"]);
      final SharedPreferences prefs = await _prefs;

      prefs.setString(PreferenceConstants.accessToken, res);
      prefs.setBool(PreferenceConstants.isUserLoggedIn, true);

      _output = parseJwt(res);
      Map<String, dynamic> map = jsonDecode(_output);
      prefs.setString(PreferenceConstants.userEmail, map['preferred_username']);
      prefs.setString(PreferenceConstants.userName, map['name']);
    } on MsalUserCancelledException {
      logger.e("User cancelled");
      res = "User cancelled";
    } on MsalNoAccountException {
      logger.e("no account");
      res = "no account";
    } on MsalInvalidConfigurationException {
      logger.e("invalid config");
      res = "invalid config";
    } on MsalInvalidScopeException {
      logger.e("Invalid scope");
      res = "Invalid scope";
    } on MsalException {
      logger.e("Error getting token. Unspecified reason");
      res = "Error getting token. Unspecified reason";
    }
    logger.i("Token Received");

    _output = res;
  }

  Future logout() async {
    logger.i("called logout");
    pca ??= await PublicClientApplication.createPublicClientApplication(
        _clientId,
        authority: _authority);

    logger.e("PCA is not null");
    String res;
    try {
      await pca!.logout(browserLogout: true);

      logger.e("Account removed");
      res = "Account removed";
    } on MsalException catch (e) {
      logger.e("Error signing out");
      res = "Error signing out:- ${e.errorMessage}";
    } on PlatformException catch (e) {
      logger.e("some other exception");
      res = "some other exception ${e.toString()}";
    }

    final SharedPreferences prefs = await _prefs;

    prefs.setString(PreferenceConstants.accessToken, '');
    prefs.setBool(PreferenceConstants.isUserLoggedIn, false);
    prefs.setString(PreferenceConstants.userEmail, '');
    prefs.setString(PreferenceConstants.userName, '');

    Get.delete<InventoryController>(force: true);
    Get.delete<ConsignedBitController>(
        tag: (ConsignedBitController).toString(), force: true);
    Get.delete<TicketedBitsController>(
        tag: (TicketedBitsController).toString(), force: true);
    Get.delete<NotificationController>(
        tag: (NotificationController).toString(), force: true);
    _output = res;
  }
}

dynamic parseJwt(String token) {
  final parts = token.split('.');
  if (parts.length != 3) {
    throw Exception('invalid token');
  }

  final payload = _decodeBase64(parts[1]);
  final payloadMap = json.decode(payload);

  /*  if (payloadMap is! Map<String, dynamic>) {
    throw Exception('invalid payload');
  } */

  return payload;
}

String _decodeBase64(String str) {
  String output = str.replaceAll('-', '+').replaceAll('_', '/');

  switch (output.length % 4) {
    case 0:
      break;
    case 2:
      output += '==';
      break;
    case 3:
      output += '=';
      break;
    default:
      throw Exception('Illegal base64url string!"');
  }
  return utf8.decode(base64Url.decode(output));
}
