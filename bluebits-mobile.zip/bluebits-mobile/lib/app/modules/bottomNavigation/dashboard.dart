import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/modules/billed_bits/screens/ticketed_bits_screen.dart';
import 'package:slb_gt_mobile/app/modules/consigned_bits/controller/consigned_bits_controller.dart';
import 'package:slb_gt_mobile/app/modules/consigned_bits/screens/consigned_bits_screen.dart';
import 'package:slb_gt_mobile/app/modules/inventory/widget/navigation_bar.dart';
import 'package:slb_gt_mobile/app/modules/inventory/controller/inventory_controller.dart';
import 'package:slb_gt_mobile/app/modules/notification/controller/notification_controller.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/values/app_colors.dart';
import '../../core/values/app_images.dart';
import '../../core/values/app_strings.dart';
import '../../core/values/app_values.dart';
import '../../core/values/size_constants.dart';
import '../../core/values/text_styles.dart';
import '../inventory/screens/inventory_screen.dart';

class Dashboard extends StatefulWidget {
  Dashboard({Key? key, required this.pageIndex}) : super(key: key);
  int pageIndex;

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
   late final pages ;
  late var Visible = true.obs;

  @override
  void initState() {
    super.initState();
    scrollController = ScrollController(keepScrollOffset: false);
    scrollController.addListener(() {
      _scrollListener();
    });

  }
  var ListIndex = 0.obs;
  int bottomTabNotificationIndex = 0;
  _scrollListener() {
    ListIndex.value = bottomTabNotificationIndex;
    if (scrollController.position.userScrollDirection ==
        ScrollDirection.reverse) {
      Visible.value = false;
    }
    if (scrollController.position.userScrollDirection ==
        ScrollDirection.forward) {
      Visible.value = true;
    }
    if (scrollController.position.pixels <= 50) {
      Visible.value = true;
    }
  }
  void bitListScroolToTop() {
    scrollController.animateTo(
      //go to top of scroll
        0.0, //scroll offset to go
        duration: const Duration(milliseconds: 1), //duration of scroll
        curve: Curves.bounceIn //scroll type
    );
  }

  late final ScrollController scrollController;

  String title = '';
  Uri bitsAdvisorUrl = Uri.parse("https://bitadvisor.smith.slb.com/");

  updatePage(int pageNo, String pageTitle) {
    setState(() {
      widget.pageIndex = pageNo;
      title = pageTitle;
      bitListScroolToTop();
    });
  }

  launchBitsAdvisor(Uri url) async {
    try {
      if (await canLaunchUrl(url)) {
        await launchUrl(url);
      } else {
        throw 'Could not launch Bits Advisor';
      }
    } catch (error) {
      print(error);
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      InventoryScreen(scrollController: scrollController,visible:Visible),
      ConsignedBitsScreen(scrollController: scrollController,visible:Visible),
      TicketedBitsScreen(scrollController: scrollController,visible:Visible),
    ];
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(SizeConstants.dp50),
          child: Navigation_Bar(
            title: title,
          )),
      body: pages[widget.pageIndex],
      bottomNavigationBar: buildMyNavBar(context),
    );
  }

  Widget buildMyNavBar(BuildContext context) {
    return Obx(
      () => Visibility(
        visible: Visible.value,
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.colorWhite,
            border: Border.all(color: AppColors.colorSeparatorLine),
          ),
          height: getHeight(SizeConstants.dp70),
          width: double.maxFinite,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () {
                  updatePage(0, AppValues.bitsInvStr);
                },
                child: SizedBox(
                  width: getWidth(SizeConstants.dp90),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            ImageIcon(
                              const AssetImage(AppImages.inventory),
                              size: SizeConstants.dp40,
                              color: widget.pageIndex == 0
                                  ? AppColors.bgColorTabSelected
                                  : AppColors.bgColorTabUnSelected,
                            ),
                            Text(AppStrings.inventory,
                                style: tSw600dp14fontF.copyWith(
                                    color: widget.pageIndex == 0
                                        ? AppColors.bgColorTabSelected
                                        : AppColors.bgColorTabUnSelected)),
                          ]),
                      Divider(
                          height: SizeConstants.dp4,
                          thickness: 5,
                          color: widget.pageIndex == 0
                              ? AppColors.bgColorTabSelected
                              : AppColors.transparentColor),
                    ],
                  ),
                ),
              ),
              SizedBox(
                width: getWidth(SizeConstants.dp40),
              ),
              GestureDetector(
                onTap: () {
                  updatePage(1, AppValues.consignedBitsStr);
                },
                child: SizedBox(
                  width: getWidth(SizeConstants.dp100),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            ImageIcon(
                              const AssetImage(AppImages.consignBits),
                              size: SizeConstants.dp40,
                              color: widget.pageIndex == 1
                                  ? AppColors.bgColorTabSelected
                                  : AppColors.bgColorTabUnSelected,
                            ),
                            Text(AppStrings.consignedBits,
                                style: tSw600dp14fontF.copyWith(
                                    color: widget.pageIndex == 1
                                        ? AppColors.bgColorTabSelected
                                        : AppColors.bgColorTabUnSelected)),
                          ]),
                      Divider(
                          height: SizeConstants.dp4,
                          thickness: 5,
                          color: widget.pageIndex == 1
                              ? AppColors.bgColorTabSelected
                              : AppColors.transparentColor),
                    ],
                  ),
                ),
              ),
              SizedBox(
                width: getWidth(SizeConstants.dp40),
              ),
              GestureDetector(
                onTap: () {
                  updatePage(2, AppValues.billedBitsStr);
                  // Get.toNamed(Routes.billBits);
                },
                child: SizedBox(
                  width: getWidth(SizeConstants.dp90),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            ImageIcon(
                              const AssetImage(AppImages.billBits),
                              size: SizeConstants.dp40,
                              color: widget.pageIndex == 2
                                  ? AppColors.bgColorTabSelected
                                  : AppColors.bgColorTabUnSelected,
                            ),
                            Text(AppStrings.billedBits,
                                style: tSw600dp14fontF.copyWith(
                                    color: widget.pageIndex == 2
                                        ? AppColors.bgColorTabSelected
                                        : AppColors.bgColorTabUnSelected)),
                          ]),
                      Divider(
                          thickness: 5,
                          height: SizeConstants.dp4,
                          color: widget.pageIndex == 2
                              ? AppColors.bgColorTabSelected
                              : AppColors.transparentColor),
                    ],
                  ),
                ),
              ),
              // Track Request
              SizedBox(
                width: getWidth(SizeConstants.dp40),
              ),
              GestureDetector(
                onTap: () {
                  //updatePage(2, AppValues.billedBitsStr);
                },
                child: SizedBox(
                  width: getWidth(SizeConstants.dp100),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            ImageIcon(
                              const AssetImage(AppImages.trackRequest),
                              size: SizeConstants.dp40,
                              color: widget.pageIndex == 3
                                  ? AppColors.bgColorTabSelected
                                  : AppColors.bgColorTabUnSelected,
                            ),
                            Text(AppStrings.trackRequest,
                                style: tSw600dp14fontF.copyWith(
                                    color: widget.pageIndex == 3
                                        ? AppColors.bgColorTabSelected
                                        : AppColors.bgColorTabUnSelected)),
                          ]),
                      Divider(
                          thickness: 5,
                          height: SizeConstants.dp4,
                          color: widget.pageIndex == 3
                              ? AppColors.bgColorTabSelected
                              : AppColors.transparentColor),
                    ],
                  ),
                ),
              ),
              //Bit Advisor
              SizedBox(
                width: getWidth(SizeConstants.dp40),
              ),
              GestureDetector(
                onTap: () {
                  launchBitsAdvisor(bitsAdvisorUrl);
                },
                child: SizedBox(
                  width: getWidth(SizeConstants.dp90),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            ImageIcon(
                              const AssetImage(AppImages.bitAdvisor),
                              size: SizeConstants.dp40,
                              color: widget.pageIndex == 4
                                  ? AppColors.bgColorTabSelected
                                  : AppColors.bgColorTabUnSelected,
                            ),
                            Text(AppStrings.bitAdvisor,
                                style: tSw600dp14fontF.copyWith(
                                    color: widget.pageIndex == 4
                                        ? AppColors.bgColorTabSelected
                                        : AppColors.bgColorTabUnSelected)),
                          ]),
                      Divider(
                          thickness: 5,
                          height: SizeConstants.dp4,
                          color: widget.pageIndex == 4
                              ? AppColors.bgColorTabSelected
                              : AppColors.transparentColor),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
