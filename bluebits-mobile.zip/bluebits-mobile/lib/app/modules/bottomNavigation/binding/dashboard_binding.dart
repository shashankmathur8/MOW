import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/utils/logger_common.dart';

import '../../../core/values/logger_level.dart';
import '../../billed_bits/controller/ticketed_bits_controller.dart';
import '../../consigned_bits/controller/consigned_bits_controller.dart';
import '../../inventory/controller/inventory_controller.dart';

class DashboardBinding extends Bindings {
  @override
  void dependencies() {
    ApplicationLogger().printInfo('InventoryController Created', 'DashboardBinding');
    Get.put<InventoryController>(InventoryController());
  }
}
