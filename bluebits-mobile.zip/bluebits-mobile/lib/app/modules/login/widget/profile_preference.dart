import 'package:flutter/material.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';

import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';

class ProfilePreference extends StatefulWidget {
  const ProfilePreference(
      this.strTitle, this.strValue, this.isArrowVisible, this.strImage,
      {super.key});

  final String strTitle;
  final String strValue;
  final String strImage;
  final bool isArrowVisible;

  @override
  State<ProfilePreference> createState() => _ProfilePreferenceState();
}

class _ProfilePreferenceState extends State<ProfilePreference> {
  double get popupWidth => AppValues.profilePopupWidth;

  var _expanded = false;
  final List<String> _trucks = ['T346291', 'T346292', 'T346293'];
  var _selectedTruck = 'T346291';

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.symmetric(horizontal: getWidth(AppValues.margin_18)),
        width: getWidth(popupWidth),
        height: getHeight(SizeConstants.dp72),
        child: Column(
          children: [
            const Divider(
              color: AppColors.colorConsignLeftPanel,
              height: SizeConstants.dp0_3,
            ),
            Expanded(
              child: InkWell(
                onTap: () {
                  if (widget.isArrowVisible) {
                    if (_trucks.length > 1) {
                      setState(() {
                        _expanded = !_expanded;
                      });
                    }
                  }
                },
                child: Container(
                  color: _expanded
                      ? AppColors.colorBackgroundPanel
                      : AppColors.colorWhite,
                  padding: const EdgeInsets.symmetric(
                      horizontal: AppValues.margin_18,
                      vertical: AppValues.margin_10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Image.asset(
                        widget.strImage,
                        fit: BoxFit.fill,
                        width: getWidth(SizeConstants.dp18),
                        height: getWidth(SizeConstants.dp18),
                      ),
                      SizedBox(
                        width: getWidth(SizeConstants.dp18),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    widget.strTitle,
                                    style: tSw400dp12fontF.copyWith(
                                      color: AppColors.colorSubText,
                                    ),
                                  ),
                                  SizedBox(
                                    height: getHeight(SizeConstants.dp5),
                                  ),
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Text(
                                        widget.strValue,
                                        style: tSw500dp15fontF.copyWith(
                                          color: AppColors.colorMainText,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                      widget.strImage == AppImages.usertruck
                                          ? Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                  width: getWidth(
                                                      SizeConstants.dp5),
                                                ),
                                                Text(
                                                  AppStrings.primary,
                                                  style: tSw700fontF.copyWith(
                                                    color:
                                                        AppColors.colorSubText,
                                                    fontSize:
                                                        SizeConstants.dp11,
                                                  ),
                                                )
                                              ],
                                            )
                                          : const Text('')
                                    ],
                                  ),
                                ],
                              ),
                              if (widget.isArrowVisible)
                                Visibility(
                                  visible: _trucks.length > 1 ? true : false,
                                  child: InkWell(
                                    child: Container(
                                        height: _expanded
                                            ? SizeConstants.dp9
                                            : SizeConstants.dp16,
                                        width: _expanded
                                            ? SizeConstants.dp16
                                            : SizeConstants.dp9,
                                        decoration: BoxDecoration(
                                          image: DecorationImage(
                                            image: AssetImage(_expanded
                                                ? AppImages.down_arrow
                                                : AppImages.up_arrow),
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        child: null),
                                  ),
                                )
                            ],
                          ),
                          if (_expanded)
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: AppValues.margin_15),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    vertical: AppValues.margin_10),
                                height: _trucks.length * SizeConstants.dp50,
                                child: ListView(
                                  children: _trucks
                                      .map((name) => Padding(
                                            padding: const EdgeInsets.symmetric(
                                                vertical: AppValues.margin_10),
                                            child: InkWell(
                                              onTap: () {
                                                setState(() {
                                                  _selectedTruck = name;
                                                });
                                              },
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  Icon(
                                                      name == _selectedTruck
                                                          ? Icons
                                                              .radio_button_on
                                                          : Icons
                                                              .radio_button_off,
                                                      size: SizeConstants.dp26,
                                                      color: name ==
                                                              _selectedTruck
                                                          ? AppColors
                                                              .colorPrimary
                                                          : AppColors
                                                              .colorSeparatorLine),
                                                  const SizedBox(
                                                    width: SizeConstants.dp10,
                                                  ),
                                                  Text(
                                                    name,
                                                    style: const TextStyle(
                                                        color: AppColors
                                                            .colorBlack,
                                                        fontSize:
                                                            SizeConstants.dp14,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        fontFamily: AppValues
                                                            .fontFamily),
                                                  ),
                                                  const SizedBox(
                                                    width: SizeConstants.dp5,
                                                  ),
                                                  widget.isArrowVisible &&
                                                          _expanded &&
                                                          name == 'T346291'
                                                      ? Column(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceEvenly,
                                                          children: [
                                                            SizedBox(
                                                              height:
                                                                  SizeConstants
                                                                      .dp2,
                                                            ),
                                                            Text(
                                                              AppStrings
                                                                  .primary,
                                                              style: TextStyle(
                                                                  color: AppColors
                                                                      .colorSubText,
                                                                  fontSize:
                                                                      SizeConstants
                                                                          .dp11,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  fontFamily:
                                                                      AppValues
                                                                          .fontFamily),
                                                            ),
                                                          ],
                                                        )
                                                      : const Text('')
                                                ],
                                              ),
                                            ),
                                          ))
                                      .toList(),
                                ),
                              ),
                            )
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ) // This trailing comma makes auto-formatting nicer for build methods.
        );
  }
}
