import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/modules/login/widget/profile_preference.dart';
import 'package:slb_gt_mobile/app/modules/login/widget/profile_normal_ui.dart';
import '../../../core/common_widgets/toast_message.dart';
import '../../../core/connectivity_utils/connectivity_controller.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_utils.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/text_styles.dart';
import '../../../routes/app_pages.dart';
import '../../../utils/msal_login.dart';
import '../../inventory/controller/inventory_controller.dart';
import '../controller/login_controller.dart';
import './profile_view.dart';

class ProfileOverlay extends ModalRoute<void> {
  @override
  Duration get transitionDuration => const Duration(milliseconds: 0);

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => true;

  @override
  Color get barrierColor => AppColors.colorBlack.withOpacity(0.3);

  @override
  String get barrierLabel => '';

  @override
  bool get maintainState => true;

  final LoginController loginController = Get.find();

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    // This makes sure that text and other content follows the material style
    return Material(
      type: MaterialType.transparency,
      // make sure that the overlay content is not cut off
      child: SafeArea(
        child: _buildOverlayContent(context),
      ),
    );
  }

  Widget appVersionView() {
    return Container(
        width: getWidth(AppValues.profilePopupWidth),
        margin: EdgeInsets.symmetric(horizontal: getWidth(AppValues.margin_18)),
        height: getHeight(SizeConstants.dp30),
        child: ClipRRect(
          borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(AppValues.margin_5),
              bottomRight: Radius.circular(AppValues.margin_5)),
          child: Column(
            children: [
              Divider(
                color: AppColors.colorConsignLeftPanel,
                height: getHeight(SizeConstants.dp0_5),
              ),
              Expanded(
                child: Container(
                  alignment: Alignment.center,
                  color: AppColors.colorWhite,
                  child: Obx(() => Text(
                        loginController.appVersion.value,
                        style: tSw400dp12fontF.copyWith(
                          color: AppColors.colorSubText,
                        ),
                      )),
                ),
              ),
            ],
          ),
        ));
  }

  Widget preferenceRow(int index) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        if (index == 0) ...[
          ProfileView()
        ] else if (index == 1) ...[
          ProfilePreference(
              AppStrings.district,
              loginController.userDetailsList.first.districtId.toString(),
              false,
              AppImages.userdistrict)
        ] else if (index == 2) ...[
          ProfilePreference(
              AppStrings.plant,
              '${loginController.userDetailsList.first.plantId.toString()} | ${loginController.userDetailsList.first.plantDescription.toString()}',
              false,
              AppImages.userplant)
        ] else if (index == 3) ...[
          ProfilePreference(
              AppStrings.truck,
              loginController.userDetailsList.first.storageLocationDescription
                      .toString()
                      .isNotEmpty
                  ? '${loginController.userDetailsList.first.storageLocationId.toString()} | ${loginController.userDetailsList.first.storageLocationDescription.toString()}'
                  : loginController.userDetailsList.first.storageLocationId
                      .toString(),
              false,
              AppImages.usertruck)
        ] else if (index == 4) ...[
          ProfileNormalUI(
            textString: AppStrings.syncNow,
            imageIconPath: AppImages.ic_info,
            onPressCallback: () {
              final InventoryController inventoryController = Get.find();
              if (loginController.connectivityController.isConnected.value) {
                inventoryController.updatePrefsIfMovementHappen();
                inventoryController.hitBitMovementApi(
                    loginController.connectivityController.isConnected.value);
              } else {
                showToastMsg(Get.context, AppStrings.noInternet, ToastStatus.info);
              }
              Get.back();
            },
          )
        ] else if (index == 5) ...[
          ProfileNormalUI(
            textString: AppStrings.signout,
            imageIconPath: AppImages.userlogout,
            onPressCallback: () {
              AADAuthentication.instance.logout();
              Get.toNamed(Routes.LOGIN);
            },
          )
        ] else ...[
          appVersionView()
        ]
      ],
    );
  }

  Widget _buildOverlayContent(BuildContext context) {
    loginController.getAppVersion();

    return SizedBox(
      width: SizeConstants.dp349,
      height: SizeConstants.dp382,
      child: Column(
        children: [
          preferenceRow(0),
          preferenceRow(1),
          preferenceRow(2),
          preferenceRow(3),
          preferenceRow(4),
          preferenceRow(5),
          preferenceRow(6)
        ],
      ),
    );
  }

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    // You can add your own animations for the overlay content
    return FadeTransition(
      opacity: animation,
      child: ScaleTransition(
        scale: animation,
        child: child,
      ),
    );
  }
}
