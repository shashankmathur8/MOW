import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/base/base_widget_mixin.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';

import '../../../core/connectivity_utils/connectivity_controller.dart';
import '../controller/login_controller.dart';

class ProfileImage extends StatelessWidget with BaseWidgetMixin {
  bool isProfileImage;
  bool isOnline;

  ProfileImage(this.isProfileImage, this.isOnline);
  final LoginController loginController = Get.find();
  final ConnectivityController connectivityController = Get.find();

  @override
  Widget body(BuildContext context) {
    return Stack(
      children: [
        CircleAvatar(
          backgroundColor: AppColors.colorDisabled,
          radius: getWidth(SizeConstants.dp40),
          child: isProfileImage
              ? CircleAvatar(
                  backgroundColor: AppColors.colorWhite,
                  radius: getWidth(SizeConstants.dp38),
                  backgroundImage: const AssetImage(AppImages.user),
                )
              : CircleAvatar(
                  backgroundColor: AppColors.colorFilterTag,
                  radius: getWidth(SizeConstants.dp38),
                  child: Container(
                    padding: const EdgeInsets.all(AppValues.margin_6),
                    child: FittedBox(
                        child: Text(
                      loginController.getInitials(loginController.userName),
                      style: tSw400dp14fontF.copyWith(
                        color: AppColors.colorPrimary,
                        fontSize: SizeConstants.dp32,
                      ),
                    )),
                  )),
        ),
        Positioned(
          bottom: AppValues.margin_7,
          right: AppValues.margin_2,
          child: Obx(() => CircleAvatar(
                backgroundColor: AppColors.colorWhite,
                radius: getWidth(SizeConstants.dp9),
                child: CircleAvatar(
                  backgroundColor: connectivityController.isConnected.value
                      ? AppColors.colorGreen
                      : AppColors.colorOffline,
                  radius: getWidth(SizeConstants.dp8),
                ),
              )),
        )
      ],
    );
  }
}
