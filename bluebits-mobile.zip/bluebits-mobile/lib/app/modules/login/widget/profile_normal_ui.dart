import 'package:flutter/material.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';

import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';

class ProfileNormalUI extends StatelessWidget {
  final textString;
  final imageIconPath;
  final VoidCallback onPressCallback;

  const ProfileNormalUI({super.key, this.textString, this.imageIconPath, required this.onPressCallback});

  double get popupWidth => AppValues.profilePopupWidth;

  @override
  Widget build(BuildContext context) {
    return Container(
        width: getWidth(popupWidth),
        margin: EdgeInsets.symmetric(horizontal: getWidth(AppValues.margin_18)),
        height: getHeight(SizeConstants.dp58),
        child: Column(
          children: [
            Divider(
              color: AppColors.colorConsignLeftPanel,
              height: getHeight(SizeConstants.dp0_3),
            ),
            Expanded(
              child: Container(
                color: AppColors.colorWhite,
                padding:
                    const EdgeInsets.symmetric(horizontal: AppValues.margin_18),
                child: InkWell(
                  onTap: () {
                    onPressCallback();
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Image.asset(
                        imageIconPath,
                        fit: BoxFit.fill,
                        width: getWidth(SizeConstants.dp18),
                        height: getWidth(SizeConstants.dp18),
                      ),
                      SizedBox(
                        width: getWidth(SizeConstants.dp18),
                      ),
                      Text(
                        textString,
                        style: tSw700fontF.copyWith(
                          color: AppColors.colorMainText,
                          fontSize: SizeConstants.dp12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ));
  }
}
