import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/app_utils.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';

import 'package:slb_gt_mobile/app/modules/login/widget/profile_image.dart';

import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../controller/login_controller.dart';

class ProfileView extends StatelessWidget {
  ProfileView({super.key});

  final LoginController loginController = Get.find();

  double get popupWidth => AppValues.profilePopupWidth;

  bool isProfileImage = false;
  bool isOnline = true;

  Widget profileInformationView() {
    return Flexible(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            loginController.userName.toString(),
            style: tSw700fontF.copyWith(
              color: AppColors.colorMainText,
              fontSize: SizeConstants.dp15,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          loginController.userDetailsList.first.role.toString().isNotEmpty
              ? SizedBox(
                  height: getHeight(SizeConstants.dp1),
                )
              : Container(),
          loginController.userDetailsList.first.role.toString().isNotEmpty
              ? Text(
                  loginController.userDetailsList.first.role.toString(),
                  style: tSw400dp12fontF.copyWith(
                    color: AppColors.colorSubText,
                  ),
                )
              : Container(),
          loginController.userEmail.isNotEmpty
              ? SizedBox(
                  height: getHeight(SizeConstants.dp3),
                )
              : Container(),
          loginController.userEmail.isNotEmpty
              ? Text(
                  loginController.userEmail,
                  style: tSw400dp12fontF.copyWith(
                    color: AppColors.colorMainText,
                  ),
                )
              : Container(),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.symmetric(horizontal: getWidth(AppValues.margin_18)),
        child: ClipRRect(
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(AppValues.margin_5),
              topRight: Radius.circular(AppValues.margin_5)),
          child: Container(
            color: AppColors.colorBackgroundPanel,
            width: getWidth(popupWidth),
            height: getHeight(SizeConstants.dp109),
            child: Stack(
              children: [
                Container(
                  margin: EdgeInsets.symmetric(
                      vertical: getHeight(SizeConstants.dp20),
                      horizontal: getWidth(SizeConstants.dp20)),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        ProfileImage(isProfileImage, isOnline),
                        SizedBox(
                          width: getWidth(SizeConstants.dp10),
                        ),
                        profileInformationView(),
                      ]),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: Container(
                    width: getWidth(SizeConstants.dp35),
                    height: getWidth(SizeConstants.dp35),
                    margin: EdgeInsets.all(getWidth(SizeConstants.dp8)),
                    child: InkWell(
                      child: Image.asset(
                        AppImages.cancelBlackPng,
                      ),
                      onTap: () {
                        Get.back();
                      },
                    ),
                  ),
                )
              ],
            ),
          ),
        ) // This trailing comma makes auto-formatting nicer for build methods.
        );
  }
}
