import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:slb_gt_mobile/app/core/utils/logger_common.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';
import 'package:slb_gt_mobile/app/modules/login/controller/login_controller.dart';

import '../../../common_binding/realm_initial.dart';
import '../../../core/values/preference_constants.dart';
import '../../../routes/app_pages.dart';
import '../../../utils/msal_login.dart';

class LoginScreen extends GetView<LoginController> {
  final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();

  LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      body: Center(
        child: Container(
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                  colors: [
                    AppColors.topColorPrimaryDark,
                    AppColors.bottomColorPrimaryDark
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  stops: [0.0359, 0.9104]),
            ),
            child: Stack(
              children: [
                Obx(() => controller.isNoInternetUI.value
                    ? noInternetUI(context)
                    : loginUI(context)),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                          margin: EdgeInsets.only(
                              bottom: getHeight(SizeConstants.dp5)),
                          child: Text(
                            controller.appVersion.value,
                            style: tSw400dp14fontF.copyWith(
                                color: AppColors.colorWhite),
                          ),),
                      Container(
                          margin: EdgeInsets.only(
                              bottom: getHeight(SizeConstants.dp15)),
                          width: getWidth(SizeConstants.dp74),
                          height: getHeight(SizeConstants.dp52),
                          alignment: Alignment.bottomCenter,
                          decoration: const BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage(AppImages.brandLogo),
                              fit: BoxFit.cover,
                            ),
                          ),
                          child: null),
                    ],
                  ),
                )
              ],
            )),
      ),
    );
  }

  Future<void> openDashboard() async {
    if (GetPlatform.isAndroid) {
      final SharedPreferences prefs = await _prefs;
      prefs.setString(PreferenceConstants.userEmail, 'SMathur4@slb.com');

      prefs.setString(PreferenceConstants.userName, 'Shashank Mathur');
    }

    await controller.updateUserEmailAndUserName();
    controller.createSyncQueryforWells(controller.userDetailsList.first);
    Get.toNamed(Routes.dashboard, arguments: 0);
    controller.isNoInternetUI.value = false;
  }

  Widget loginUI(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Obx(
        () => Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 0),
              child: Container(
                  height: getHeight(SizeConstants.dp292),
                  width: getWidth(SizeConstants.dp359),
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(AppImages.appLogo),
                      fit: BoxFit.contain,
                    ),
                  ),
                  child: null),
            ),
            const SizedBox(
              height: SizeConstants.dp10,
            ),
            RealmInitial.isSyncDone.value
                ? GestureDetector(
                    onTap: () async {
                      var loginStatus = await controller.fetchIsUserLoggedIn();
                      ApplicationLogger()
                          .printInfo('Login status:- $loginStatus', '');

                      if (loginStatus) {
                        openDashboard();
                      } else if (!controller
                          .connectivityController.isConnected.value) {
                        controller.isNoInternetUI.value = true;
                      } else {
                        AADAuthentication.instance
                            .acquireToken(context)
                            .whenComplete(() async {
                          loginStatus = await controller.fetchIsUserLoggedIn();
                          ApplicationLogger()
                              .printInfo('Login status:- $loginStatus', '');
                          if (loginStatus) {
                            openDashboard();
                          }
                        });
                      }

                      if (GetPlatform.isAndroid) {
                        openDashboard();
                      }
                    },
                    child: Container(
                      width: getWidth(SizeConstants.dp198),
                      height: getHeight(SizeConstants.dp60),
                      alignment: Alignment.center,
                      padding: EdgeInsets.symmetric(
                          horizontal: getWidth(SizeConstants.dp66),
                          vertical: getHeight(SizeConstants.dp12)),
                      decoration: BoxDecoration(
                          border: Border.all(color: AppColors.colorWhite),
                          borderRadius:
                              BorderRadius.circular(SizeConstants.dp5)),
                      child: Text(
                        AppStrings.login,
                        style: tSw400dp14fontF.copyWith(
                            fontSize: SizeConstants.dp24,
                            color: AppColors.colorWhite),
                      ),
                    ),
                  )
                : circleProgressUI(),
          ],
        ),
      ),
    );
  }

  Widget noInternetUI(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Obx(
        () => Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 0),
              child: Container(
                  height: getHeight(SizeConstants.dp128),
                  width: getWidth(SizeConstants.dp128),
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(AppImages.noInternetLogin),
                      fit: BoxFit.contain,
                    ),
                  ),
                  child: null),
            ),
            const SizedBox(
              height: SizeConstants.dp48,
            ),
            Text(
              AppStrings.noInternetConnection,
              textAlign: TextAlign.center,
              style: tSw400dp14fontF.copyWith(
                  fontWeight: FontWeight.w300,
                  color: AppColors.colorWhite,
                  fontSize: SizeConstants.dp40),
            ),
            const SizedBox(
              height: SizeConstants.dp10,
            ),
            Text(AppStrings.noInternetConnectionDes,
                style: tSw400dp18fontF.copyWith(
                  color: AppColors.colorWhite,
                ),
                textAlign: TextAlign.center),
            const SizedBox(
              height: SizeConstants.dp35,
            ),
            RealmInitial.isSyncDone.value
                ? GestureDetector(
                    onTap: () async {
                      var loginStatus = await controller.fetchIsUserLoggedIn();
                      ApplicationLogger()
                          .printInfo('Login status:- $loginStatus', '');

                      if (loginStatus) {
                        openDashboard();
                      } else if (controller
                          .connectivityController.isConnected.value) {
                        AADAuthentication.instance
                            .acquireToken(context)
                            .whenComplete(() async {
                          loginStatus = await controller.fetchIsUserLoggedIn();
                          ApplicationLogger()
                              .printInfo('Login status:- $loginStatus', '');
                          if (loginStatus) {
                            openDashboard();
                          }
                        });
                      }

                      if (GetPlatform.isAndroid) {
                        openDashboard();
                      }
                    },
                    child: Container(
                      width: getWidth(SizeConstants.dp198),
                      height: getHeight(SizeConstants.dp60),
                      alignment: Alignment.center,
                      padding: EdgeInsets.symmetric(
                          vertical: getHeight(SizeConstants.dp12)),
                      decoration: BoxDecoration(
                          border: Border.all(color: AppColors.colorWhite),
                          borderRadius:
                              BorderRadius.circular(SizeConstants.dp5)),
                      child: Text(
                        AppStrings.tryAgain,
                        style: tSw400dp14fontF.copyWith(
                            fontSize: SizeConstants.dp24,
                            color: AppColors.colorWhite),
                      ),
                    ),
                  )
                : circleProgressUI(),
          ],
        ),
      ),
    );
  }

  Widget circleProgressUI() {
    return SizedBox(
      width: getWidth(SizeConstants.dp198),
      height: getHeight(SizeConstants.dp60),
      child: const Center(
        child: CircularProgressIndicator(
          strokeWidth: SizeConstants.dp4,
          backgroundColor: AppColors.transparentColor,
          color: AppColors.colorCircleProgress,
        ),
      ),
    );
  }
}
