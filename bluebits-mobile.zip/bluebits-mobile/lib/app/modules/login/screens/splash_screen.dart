import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/routes/app_pages.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      body: Center(
        child: Container(
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                  colors: [
                    AppColors.topColorPrimaryDark,
                    AppColors.bottomColorPrimaryDark
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  stops: [0.0359, 0.9104]),
            ),
            child: Stack(
              children: [
                Center(
                  child: Container(
                      height: getHeight(SizeConstants.dp292),
                      width: getWidth(SizeConstants.dp359),
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(AppImages.appLogo),
                          fit: BoxFit.contain,
                        ),
                      ),
                      child: null),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                      margin: EdgeInsets.only(
                          bottom: getHeight(SizeConstants.dp15)),
                      width: getWidth(SizeConstants.dp74),
                      height: getHeight(SizeConstants.dp52),
                      alignment: Alignment.bottomCenter,
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(AppImages.brandLogo),
                          fit: BoxFit.cover,
                        ),
                      ),
                      child: null),
                )
              ],
            )),
      ),
    );
  }

  void openLoginScreen() {
    Get.toNamed(Routes.LOGIN);
  }

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
        overlays: [SystemUiOverlay.bottom, SystemUiOverlay.top]);
    Future.delayed(const Duration(seconds: 3), () => openLoginScreen());
  }

  @override
  void dispose() {
    super.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
        overlays: SystemUiOverlay.values); // to re-show bars
  }
}
