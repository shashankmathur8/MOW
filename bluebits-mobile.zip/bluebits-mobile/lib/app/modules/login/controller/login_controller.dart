import 'package:get/get.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:realm/realm.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:slb_gt_mobile/app/core/base/base_controller.dart';
import 'package:slb_gt_mobile/app/core/utils/logger_common.dart';
import 'package:slb_gt_mobile/app/core/values/app_utils.dart';
import 'package:slb_gt_mobile/app/core/values/preference_constants.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/truckUserMapping.dart';

import '../../../common_binding/realm_initial.dart';
import '../../../core/common_widgets/toast_message.dart';
import '../../../core/connectivity_utils/connectivity_controller.dart';
import '../../../core/values/app_strings.dart';
import '../../../data/model/request/bit_movment_param.dart';
import '../../../data/model/response/bit_movement_response.dart';
import '../../../data/repository/inventory_repo.dart';
import '../../../network/exceptions/app_exception.dart';
import '../../../utils/msal_login.dart';
import '../../ticketing_bill_bits/model/wells_schema.dart';

class LoginController extends BaseController {
  final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());
  final ConnectivityController connectivityController = Get.find();

  late RealmResults<TruckUserMapping> userDetailsList;
  final _userEntitlement = <TruckUserMapping>[].obs;
  late SharedPreferences prefs;

  late String userEmail;
  late String userName;

  var appVersion = '1.0.45(46) MOGW DEV'.obs;
  var isNoInternetUI = false.obs;

  get userList => _userEntitlement.value;

  set userList(value) {
    _userEntitlement.value = value;
  }

  Future<void> updateUserEmailAndUserName() async {
    prefs = await _prefs;
    userEmail = prefs.getString(PreferenceConstants.userEmail).toString();
    userName = prefs.getString(PreferenceConstants.userName).toString();
    ApplicationLogger().printInfo('userEmail:- $userEmail, userName:- $userName', 'updateUserEmailAndUserName');
    if (userEmail != null) {
      await fetchUserEntitlements(userEmail);
    }

  }

  Future<void> fetchUserEntitlements(String email) async {
    final RealmInitial realm = Get.find(tag: (RealmInitial).toString());
    userDetailsList = realm.getUserEntitlements(email);
    if (!userDetailsList.isEmpty) {
      ApplicationLogger().printInfo('userEmail:- $userEmail, ${userDetailsList[0].id.toString() ?? ""}', 'fetchUserEntitlements');
      prefs.setString(PreferenceConstants.userTruckMapping,
          userDetailsList[0].id.toString() ?? "");
    }else{
      //TODO show USER missing ERROR and logout
    }
  }

  String getInitials(String userName) => userName.isNotEmpty
      ? userName.trim().split(RegExp(' +')).map((s) => s[0]).take(2).join()
      : '';

  Future<bool> fetchIsUserLoggedIn() async {
    final SharedPreferences prefs = await _prefs;
    if (prefs.getBool(PreferenceConstants.isUserLoggedIn) != null) {
      return prefs.getBool(PreferenceConstants.isUserLoggedIn)!;
    }
    return false;
  }

  getAppVersion() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();

    String appName = packageInfo.appName;
    String packageName = packageInfo.packageName;
    String version = packageInfo.version;
    String buildNumber = packageInfo.buildNumber;

    //appVersion.value = '$version($buildNumber)';
  }
  late List<Well> wellList;
  void createSyncQueryforWells(TruckUserMapping user) {
    ApplicationLogger().printInfo('user:- ${user.mailId}- ${user.country}- ${user.state}', 'createSyncQueryforWells');
    realm.updateRealmSync(user.country.toString(),user.state.toString());
  }

}
