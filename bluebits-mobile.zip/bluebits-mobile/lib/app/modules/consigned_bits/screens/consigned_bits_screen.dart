import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/common_widgets/custom_button_material.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/modules/consigned_bits/controller/consigned_bits_controller.dart';
import 'package:slb_gt_mobile/app/modules/consigned_bits/widget/billBitOverlay.dart';
import 'package:slb_gt_mobile/app/modules/consigned_bits/widget/consignList.dart';
import 'package:slb_gt_mobile/app/modules/consigned_bits/widget/recent_searches.dart';
import 'package:slb_gt_mobile/app/modules/consigned_bits/widget/returnBitOverlay.dart';
import 'package:slb_gt_mobile/app/modules/shared/generic_overlay.dart';

import '../../../core/utils/size_config.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/text_styles.dart';
import '../../shared/bottom_tab_notification_shared.dart';

class ConsignedBitsScreen extends GetView<ConsignedBitController> {
  @override
  final ConsignedBitController controller = Get.put(ConsignedBitController(),
      tag: (ConsignedBitController).toString());
  ScrollController scrollController;
  var visible;

  ConsignedBitsScreen(
      {super.key, required this.scrollController, required this.visible});

  @override
  Widget build(BuildContext context) {
    //Put for close all item expanded on tab move to back
    controller.clearAllSelectedBits();
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        color: AppColors.colorF5F6F5,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              height: getHeight(SizeConstants.dp52),
              padding: EdgeInsets.only(
                  left: getWidth(SizeConstants.dp19),
                  right: getWidth(SizeConstants.dp17),
                  top: getHeight(SizeConstants.dp10),
                  bottom: getHeight(SizeConstants.dp10)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    AppStrings.myConsignments,
                    style: tSw400dp14fontF.copyWith(
                        color: AppColors.colorMainText,
                        fontSize: SizeConstants.dp24),
                  ),
                  const Spacer(),
                  Obx(
                    () => controller.isBitsSelected.value
                        ? bottomButtonWidget(context)
                        : !(controller.isConsignSearchEnabled.value)
                            ? IconButton(
                                onPressed: () {
                                  controller.isConsignSearchEnabled.value =
                                      !controller.isConsignSearchEnabled.value;
                                },
                                splashColor: AppColors.transparentColor,
                                padding:
                                    const EdgeInsets.all(SizeConstants.dp0),
                                icon: Image.asset(AppImages.search))
                            : Padding(
                                padding: const EdgeInsets.only(
                                    right: SizeConstants.dp10),
                                child: SearchConsignBits()),
                  ),
                  refreshButton(),
                ],
              ),
            ),
            const Divider(
              color: AppColors.colorSeparatorLine,
              height: SizeConstants.dp0_5,
            ),
            Expanded(
              child: Stack(
                alignment: AlignmentDirectional.bottomStart,
                children: [
                  Expanded(
                      child: ConsignList(
                          scrollController: scrollController,
                          visible: visible)),
                  Obx(
                    () => Visibility(
                        visible: !visible.value,
                        child: BottomTabNotificationShared(
                            controller, scrollController)),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget refreshButton() {
    // add refresh button
    return InkWell(
      onTap: () {
        controller.fetchData();
        controller.makeAllDropDownClose();
      },
      child: Container(
          padding: EdgeInsets.only(
              right: getWidth(SizeConstants.dp8),
              left: getWidth(SizeConstants.dp8)),
          child: const Icon(
            Icons.refresh,
            color: AppColors.colorBlack,
          )),
    );
  }

  bottomButtonWidget(BuildContext context) {
    return Row(mainAxisAlignment: MainAxisAlignment.end, children: [
      CustomButtonMaterial(
        width: getWidth(SizeConstants.dp102),
        height: getHeight(SizeConstants.dp40),
        backgroundColor: AppColors.transparentColor,
        foregroundColor: AppColors.colorPrimary,
        borderRadius: AppValues.radius_4,
        text: AppStrings.returnBit,
        style: tSw500dp16fontF,
        side: const BorderSide(
          width: SizeConstants.dp1,
          color: AppColors.colorPrimary,
        ),
        onPressCallback: () {
          /*  Navigator.of(context).push(ReturnBitOverlay(controller,
              controller.getSelectedBitsForBilling()));*/
          Navigator.of(context).push(GenericOverlay(
              title: AppStrings.returnBits,
              messageWidget: descriptionTitle(),
              iconPath: AppImages.returnImage,
              negativeButtonText: AppStrings.cancel,
              positiveButtonText: AppStrings.ok,
              onPositivePressCallback: () async {
                controller.addReturn();
                controller.makeAllDropDownClose();
                Get.back();
              }));
        },
      ),
      SizedBox(
        width: getWidth(SizeConstants.dp10),
      ),
      AbsorbPointer(
        absorbing: !controller.isSelectedBitStatusValid.value ||
            controller.multipleBitsAreSelected.value,
        child: CustomButtonMaterial(
          width: getWidth(SizeConstants.dp130),
          height: getHeight(SizeConstants.dp40),
          backgroundColor: controller.isSelectedBitStatusValid.value &&
                  !controller.multipleBitsAreSelected.value
              ? AppColors.colorPrimary
              : AppColors.colorPrimary.withOpacity(0.3),
          foregroundColor: controller.isSelectedBitStatusValid.value &&
                  !controller.multipleBitsAreSelected.value
              ? AppColors.colorWhite
              : AppColors.colorWhite.withOpacity(0.4),
          borderRadius: AppValues.radius_4,
          text: AppStrings.ticket,
          style: tSw500dp16fontF,
          onPressCallback: () {
            Navigator.of(context).push(BillBitOverlay(
              controller,
              controller.getSelectedBitsSerialNbrForBilling(),
              controller.getSelectedBitsForBilling(),
            ));
          },
        ),
      )
    ]);
  }

  Widget descriptionTitle() {
    return SizedBox(
      width: SizeConstants.dp360,
      child: RichText(
        text: TextSpan(
            text: AppStrings.allSelected,
            style: tSw400dp14fontF.copyWith(
              color: AppColors.colorMainText,
              fontSize: SizeConstants.dp18,
            ),
            children: <TextSpan>[
              const TextSpan(
                  text: AppStrings.bits,
                  style: TextStyle(fontWeight: AppValues.fontWeight700)),
              TextSpan(
                text: AppStrings.willBeReturned,
                style: tSw400dp14fontF.copyWith(
                  color: AppColors.colorMainText,
                  fontSize: SizeConstants.dp18,
                ),
              ),
              const TextSpan(
                  text: AppStrings.myTruckInventory,
                  style: TextStyle(fontWeight: AppValues.fontWeight700)),
              const TextSpan(
                  text: '\n\n',
                  style: TextStyle(fontWeight: AppValues.fontWeight700)),
              TextSpan(
                text: AppStrings.doyouwanttoproceed,
                style: tSw400dp14fontF.copyWith(
                  color: AppColors.colorMainText,
                  fontSize: SizeConstants.dp18,
                ),
              )
            ]),
      ),
    );
  }
}
