import 'package:get/get.dart';

class ConsignedBitsBinding extends Bindings {
  @override
  void dependencies() {
    //Get.lazyPut<ConsignController>(() => ConsignController());
  }
}
