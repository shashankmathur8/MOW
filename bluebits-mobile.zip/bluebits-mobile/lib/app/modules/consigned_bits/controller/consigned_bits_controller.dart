import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:realm/src/list.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:slb_gt_mobile/app/core/base/base_controller.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';
import 'package:slb_gt_mobile/app/core/values/app_utils.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/controller/consign_controller.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/model/consignment_model.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/screens/consign_bits_screen.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/consignmentSchema.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../../../common_binding/realm_initial.dart';
import '../../../core/common_widgets/toast_message.dart';
import '../../../core/connectivity_utils/connectivity_controller.dart';
import '../../../core/utils/logger_common.dart';
import '../../../core/values/preference_constants.dart';
import '../../../data/model/request/bit_movment_param.dart';
import '../../../data/model/response/bit_movement_response.dart';
import '../../../data/repository/inventory_repo.dart';
import '../../../network/exceptions/app_exception.dart';
import '../../../utils/msal_login.dart';
import '../../login/controller/login_controller.dart';

class ConsignedBitController extends BaseController {
  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());
  LoginController loginController = Get.find();

  var index = 0.obs;

  List<dynamic> selectedPriceLineItem = [];
  late WebViewController webHtmlViewController;

  var visibilityDropDown = [].obs;
  final _consignedList = <Consignment>[].obs;

  late SharedPreferences prefs;
  var defaultTab = "".obs;
  var ListIndex = 0.obs;
  var listLength = 0;
  final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();

  final InventoryRepo _repository = Get.find(tag: (InventoryRepo).toString());

  final ConnectivityController connectivityController = Get.find();

  var swapList;
  var sortingState;

  int getConsignedBitsLength() {
    return _consignedList.length;
  }

  String getConsignedBitsID(index) {
    return _consignedList[index].consignmentId.toString();
  }

  Consignment getConsignedBit(index) {
    return _consignedList[index];
  }

  var editLineItemIndex = -1;

  final _columnList = [
    ConsignedBitsColumn.consignmentID,
    ConsignedBitsColumn.customer,
    ConsignedBitsColumn.rigNameAndNo,
    ConsignedBitsColumn.dateConsigned,
    ConsignedBitsColumn.noOfBitsConsigned,
    ConsignedBitsColumn.consignmentStatus,
    ConsignedBitsColumn.emptyTitle,
    ConsignedBitsColumn.emptyTitle
  ].obs;

  final innerColumnList = [
    ConsignedBitsColumn.emptyTitle,
    ConsignedBitsColumn.srNbr,
    ConsignedBitsColumn.size,
    ConsignedBitsColumn.type,
    ConsignedBitsColumn.bom,
    ConsignedBitsColumn.noOfRuns,
    ConsignedBitsColumn.daysInStatus,
    ConsignedBitsColumn.status,
    ConsignedBitsColumn.emptyTitle,
  ];

  List<String> get columnList => _columnList.value;

  set columnList(List<String> value) {
    _columnList.value = value;
  }

  var isConsignSearchEnabled = false.obs;
  var multipleBitsAreSelected = false.obs;

  List<Consignment> get allBitList => _consignedList.value;

  set allBitList(List<Consignment> value) {
    _consignedList.value = value;
  }

  var isBitsSelected = false.obs;
  var isSelectedBitStatusValid = false.obs;
  var currentConsignmentForBilling = "";
  var currentConsignment;

  var selectedValueList = [];
  var refreshUi = "".obs;

  @override
  void onInit() {
    super.onInit();
    // TODO: implement onInit
    ApplicationLogger()
        .printInfo('ConsignedBitController Created', 'DashboardBinding');
    makeAllDropDownClose();
    fetchData();
  }

  /*--------------Quote Screen----------------*/
  refreshUI() {
    refreshUi.value = AppStrings.updatedValue;
    refreshUi.refresh();
  }

  clearAllSelectedBits() {
    selectedValueList.clear();
    for (int i = 0; i < getConsignedBitsLength(); i++) {
      selectedValueList
          .add(List.filled(getConsignedBit(i).bits.length.toInt(), false));
    }
    isBitsSelected.value = false;
  }

  void makeAllDropDownCloseExcept(int index) {
    visibilityDropDown.value = List.filled(getConsignedBitsLength(), false);
    visibilityDropDown[index] = true;
    clearAllSelectedBitsExcept(index);
  }

  void makeAllDropDownClose() {
    visibilityDropDown.value = List.filled(getConsignedBitsLength(), false);
    clearAllSelectedBits();
    _consignedList.refresh();
    update();
  }

  clearAllSelectedBitsExcept(int index) {
    var temp = selectedValueList[index];
    selectedValueList.clear();
    for (int i = 0; i < getConsignedBitsLength(); i++) {
      selectedValueList
          .add(List.filled(getConsignedBit(i).bits.length.toInt(), false));
    }
    selectedValueList[index] = temp;
    isBitsSelected.value = false;
  }

  FocusNode focusNode = FocusNode();
  TextEditingController searchController = TextEditingController();

  void fetchData() async {
    allBitList = realm.getConsignedBits(loginController.userEmail).toList();
    fillList();
    _consignedList.refresh();
    update();
  }

  fillList() {
    sortingState = List.filled(columnList.length, false);
    visibilityDropDown.value = List.filled(getConsignedBitsLength(), false);
    selectedValueList.clear();
    for (int i = 0; i < getConsignedBitsLength(); i++) {
      selectedValueList
          .add(List.filled(getConsignedBit(i).bits.length.toInt(), false));
    }
  }

  void sortConsignList(bool aorD, String column) {
    if (column == ConsignedBitsColumn.consignmentID) {
      if (aorD == true) {
        allBitList.sort((a, b) =>
            (a.consignmentId.toString()).compareTo(b.consignmentId.toString()));
      } else {
        allBitList.sort((a, b) =>
            (b.consignmentId.toString()).compareTo(a.consignmentId.toString()));
      }
    } else if (column == ConsignedBitsColumn.customer) {
      if (aorD == true) {
        allBitList.sort((a, b) =>
            (a.customerName.toString()).compareTo(b.customerName.toString()));
      } else {
        allBitList.sort((a, b) =>
            (b.customerName.toString()).compareTo(a.customerName.toString()));
      }
    } else if (column == ConsignedBitsColumn.rigNameAndNo) {
      if (aorD == true) {
        allBitList.sort(
            (a, b) => (a.rigName.toString()).compareTo(b.rigName.toString()));
      } else {
        allBitList.sort(
            (a, b) => (b.rigName.toString()).compareTo(a.rigName.toString()));
      }
    } else if (column == ConsignedBitsColumn.dateConsigned) {
      if (aorD == true) {
        allBitList.sort((a, b) => (a.createdAt
                .toString()!
                .substring(0, 10)
                .toString())
            .compareTo(b.createdAt.toString()!.substring(0, 10).toString()));
      } else {
        allBitList.sort((a, b) => (b.createdAt
                .toString()!
                .substring(0, 10)
                .toString())
            .compareTo(a.createdAt.toString()!.substring(0, 10).toString()));
      }
    } else if (column == ConsignedBitsColumn.noOfBitsConsigned) {
      if (aorD == true) {
        allBitList.sort((a, b) =>
            (a.bits.length.toString()).compareTo(b.bits.length.toString()));
      } else {
        allBitList.sort((a, b) =>
            (b.bits.length.toString()).compareTo(a.bits.length.toString()));
      }
    } else if (column == ConsignedBitsColumn.consignmentStatus) {
      if (aorD == true) {
        allBitList.sort(
            (a, b) => (a.status.toString()).compareTo(b.status.toString()));
      } else {
        allBitList.sort(
            (a, b) => (b.status.toString()).compareTo(a.status.toString()));
      }
    }
    clearAllSelectedBits();
    _consignedList.refresh();
  }

  filterBitListData(String value) {
    List<Consignment> filteredList;
    filteredList =
        realm.getSearchedConsignedBits(value, loginController.userEmail);

    swapList = allBitList;
    allBitList = filteredList;
    _consignedList.refresh();
    makeAllDropDownClose();
    update();
  }

  void backToDefaultList() {
    allBitList = swapList;
  }

  void prepareForDraftEdit(Consignment consignedBit) {
    var cust;
    if (consignedBit.customerId != "") {
      cust = getCustomer(consignedBit.customerId.toString());
    }
    var lineItems = getLineItems(consignedBit.bits);
    List<Bits> bits = getBits(consignedBit.bits);
    List<Bit> selectedBits = [];
    bits.forEach((element) {
      selectedBits.add(element.bit!);
    });
    var rig;
    if (consignedBit.rigId != "") {
      rig = getRig(consignedBit.rigId.toString());
    }
    ConsignmentModel cm = ConsignmentModel(
        customer: cust == null ? null : cust.first,
        consignmentID: consignedBit.consignmentId,
        customerEmail: consignedBit.customerEmail,
        bits: bits,
        rig: rig);

    final ConsignController controller =
        Get.put(ConsignController(), tag: (ConsignController).toString());
// dont remove below lines without disscussion draftConsignmentID
    controller.draftConsignmentID = consignedBit.id.toString();
    controller.consignmentModel = cm;
    controller.selectedValueCustomer = cust == null ? "" : cust.first.name;
    controller.selectedValueRig = rig == null ? "" : rig.name;
    Get.to(ConsignBits(isDraftEdit: true, selectedBits: selectedBits),
        transition: Transition.native,
        duration: const Duration(milliseconds: 300));
  }

  getCustomer(String customerId) {
    return realm.getCustomer(customerId);
  }

  getBits(RealmList<ConsignmentBits> bits) {
    List<LineItems> temp2 = [];
    List<Bits> temp3 = [];
    bits.forEach((element) {
      var details = new Map();
      element.priceBookDetails.forEach((element2) {
        var lineItem = realm.getLineItem(
            element2.priceBookId.toString(),
            element2.pricingId.toString(),
            loginController.userDetailsList.first.country ??
                AppStrings.usCountryCode);
        lineItem.bestPrice = element2.bestPrice;
        lineItem.comments = element2.comments;
        lineItem.discountAmount = element2.discountAmount;
        lineItem.discountPercentage = element2.discountPercentage!.toDouble();
        lineItem.unitDrilled = double.parse(element2.unitDrilled.toString());
        lineItem.pricePerUnit = double.parse(element2.pricePerUnit.toString());
        lineItem.lineCondition = element2.lineCondition;

        temp2.add(lineItem);
      });
      details['srNO'] = element.serialNumber.toString();
      details['lineItems'] = temp2;
      temp3.add(realm.getBitFromMap(details));
      temp2 = [];
    });
    return temp3;
  }

  getRig(String rigId) {
    return realm.getRig(rigId);
  }

  getLineItems(RealmList<ConsignmentBits> bits) {
    bits.forEach((element) {
      element.priceBookDetails.forEach((element2) {
        var lineItem = realm.getLineItem(
            element2.priceBookId.toString(),
            element2.pricingId.toString(),
            loginController.userDetailsList.first.country ??
                AppStrings.usCountryCode);
      });
    });
  }

  String getSelectedBitsSerialNbrForBilling() {
    List<String> stringList = [];
    for (var i = 0; i < selectedValueList.length; i++) {
      for (var j = 0; j < getConsignedBit(i).bits.length; j++) {
        if (selectedValueList[i][j] == true) {
          stringList.add((getConsignedBit(i).bits[j].serialNumber.toString()));
        }
      }
    }
    return stringList.join(' & ');
  }

  List<Bit> getSelectedBitsForBilling() {
    List<Bit> selectedBitList = [];
    List<String> stringList = [];
    for (var i = 0; i < selectedValueList.length; i++) {
      for (var j = 0; j < getConsignedBit(i).bits.length; j++) {
        if (selectedValueList[i][j] == true) {
          stringList
              .add('\'${getConsignedBit(i).bits[j].serialNumber.toString()}\'');
        }
      }
    }

    String query =
        stringList.toString().replaceAll('[', '{').replaceAll(']', '}');

    List<Bit> dbBits = realm.getBitFromSerialNbr(query);
    selectedBitList.addAll(dbBits);

    return selectedBitList;
  }

  void isMultipleBitsSelected(int index) {
    List<bool> bitsSelectedState = selectedValueList[index];
    var count = 0;
    bitsSelectedState.forEach((element) {
      if (element) {
        count++;
      }
    });
    if (count > 1) {
      multipleBitsAreSelected.value = true;
    } else {
      multipleBitsAreSelected.value = false;
    }
  }

  void addReturn() async {
    var selectedBits = getSelectedBitsForBilling();
    var returnTicketID = createReturnID();
    prefs = await _prefs;
    bool result = await realm.insertReturnBitQueue(
        selectedBits, currentConsignment, returnTicketID);
    if (result) {
      updatePrefsIfMovementHappen();
      hitMovementApi(connectivityController.isConnected.value);
      showToastMsg(Get.context!, AppStrings.returnInitiated, ToastStatus.info);
    }
  }

  createReturnID() {
    return "${AppStrings.prefixReturnID}${DateTime.now().toUtc().millisecondsSinceEpoch}";
  }

  updatePrefsIfMovementHappen() {
    prefs.setBool(PreferenceConstants.isMovementHappen, true);
  }

  void hitMovementApi(bool isInternetConnected) {
    ApplicationLogger().printInfo(
        'hitBitMovementApi:- $isInternetConnected', 'hitBitMovementApi()');
    if (isInternetConnected) {
      if (prefs.getBool(PreferenceConstants.isMovementHappen)!) {
        var queryParam = BitMovementParam(
            requestedBy: prefs.getString(PreferenceConstants.userEmail)!,
            truckUserMappingId:
                prefs.getString(PreferenceConstants.userTruckMapping)!);
        var bitMovementService = _repository.bitMovement(queryParam);
        callDataService(bitMovementService,
            onSuccess: _handleProjectListResponseSuccess,
            onError: _handleBitMovmentError);
      }
    } else if (prefs.getBool(PreferenceConstants.isMovementHappen)!) {
      showToastMsg(Get.context!, AppStrings.noInternet, ToastStatus.info);
    }
  }

  void _handleProjectListResponseSuccess(BitMovementResponseModel response) {
    var repoList = response.message;
    prefs.setBool(PreferenceConstants.isMovementHappen, false);
  }

  void _handleBitMovmentError(Exception response) async {
    if (response is AppCustomException) {
      if (response.message.contains("401")) {
        await AADAuthentication.instance.acquireTokenSilently();
        hitMovementApi(true);
      }
    }
    prefs.setBool(PreferenceConstants.isMovementHappen, false);
  }
}
