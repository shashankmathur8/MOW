import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/modules/consigned_bits/controller/consigned_bits_controller.dart';

class SearchConsignBits extends StatefulWidget {
  var localSearches;

  SearchConsignBits({
    super.key,
  });
  @override
  _SearchConsignBitsState createState() => _SearchConsignBitsState();
}

class _SearchConsignBitsState extends State<SearchConsignBits> {
  ConsignedBitController consignBitController =
      Get.find(tag: (ConsignedBitController).toString());

  late OverlayState overlay;

  var entry;

  _SearchConsignBitsState();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    consignBitController.focusNode.addListener(() {
      if (consignBitController.focusNode.hasFocus) {
        var renderBox = context.findRenderObject() as RenderBox;
        final size = renderBox.size;
        final pos = renderBox.localToGlobal(Offset.zero);
        entry = OverlayEntry(
            builder: (context) => Positioned(
                left: pos.dx,
                top: pos.dy + size.height,
                width: size.width,
                child: buildOverlay()));
        ;
        Overlay.of(context).insert(entry);
      } else {
        entry.remove();
      }
    });
  }

  Widget buildOverlay() => Container();
  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(
          maxWidth: SizeConstants.dp420, maxHeight: SizeConstants.dp40),
      child: TextField(
          focusNode: consignBitController.focusNode,
          onChanged: (value) {
            setState(() {});
            //ShowOverlay(context);
            value.length == SizeConstants.dp0 ? () {} : print("");
          },
          onSubmitted: (value) {
            if (value.isNotEmpty) {
              consignBitController.filterBitListData(value);
              consignBitController.focusNode.unfocus();
            }
            //print(value);
          },
          //      consignController.filterBitListData(searchController.text),
          controller: consignBitController.searchController,
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(AppValues.radius_20),
            ),
            fillColor: AppColors.colorBg.withOpacity(0.8),
            labelStyle: const TextStyle(color: AppColors.colorSubText),
            labelText: AppStrings.hintConsignSearch,
            suffixIcon: consignBitController.searchController.text.isNotEmpty
                ? IconButton(
                    onPressed: () {
                      consignBitController.searchController.text = "";
                      setState(() {
                        //hideOverLay();
                        consignBitController.fetchData();
                        consignBitController.focusNode.unfocus();
                      });
                      //
                    },
                    icon: const Icon(
                      Icons.close,
                      color: AppColors.colorBlack,
                    ))
                : IconButton(
                    onPressed: () {},
                    icon: const Icon(
                      Icons.search,
                      color: AppColors.colorBlack,
                    )),
            floatingLabelBehavior: FloatingLabelBehavior.never,
          )),
    );
  }
}
