import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:slb_gt_mobile/app/core/utils/logger_common.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';
import 'package:slb_gt_mobile/app/modules/consigned_bits/controller/consigned_bits_controller.dart';

import 'package:slb_gt_mobile/app/modules/consigned_bits/widget/fileViewerOverlay.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/consignmentSchema.dart';
import '../../../core/common_widgets/no_results_screen.dart';
import '../../../core/values/app_utils.dart';
import '../../../core/values/size_constants.dart';
import 'delete_draft_overlay.dart';

class ConsignList extends StatefulWidget {
  var scrollController;
  var visible;
   ConsignList({super.key, required this.scrollController, required this.visible});

  @override
  State<ConsignList> createState() => _ConsignList();
}

class _ConsignList extends State<ConsignList> {
  final ConsignedBitController consignBitController = Get.find(tag: (ConsignedBitController).toString());

  var selectedValue = false;
  var isSelectedBits = false;

  var curSortIndex = 0;

  @override
  void initState() {
    super.initState();
    consignBitController.fetchData();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Obx(() => consignBitController.allBitList.isNotEmpty
          ? Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: SizeConstants.dp40, right: SizeConstants.dp20, top: SizeConstants.dp4),
                  child: getHeaderUI(),
                ),
                Obx(
                  () => Expanded(
                      child: ListView.builder(
                        controller: widget.scrollController,
                    scrollDirection: Axis.vertical,
                    shrinkWrap: false,
                    physics: const ScrollPhysics(),
                    itemCount: consignBitController.allBitList.length,
                    itemBuilder: (context, index) {
                      return AnimatedContainer(
                        duration: const Duration(seconds: SizeConstants.dp0I),
                        decoration: BoxDecoration(
                            boxShadow: const [
                              BoxShadow(color: AppColors.colorGrey, blurRadius: SizeConstants.dp1, offset: Offset(0.0, 0.75))
                            ],
                            borderRadius: BorderRadius.circular(SizeConstants.dp5),
                            border: Border.all(color: AppColors.colorWhite),
                            color: AppColors.colorWhite),
                        margin: const EdgeInsets.only(
                            left: SizeConstants.dp20, right: SizeConstants.dp20, bottom: SizeConstants.dp10),
                        //Normal UI:- dp62 , Sub header UI:- dp30, Sub item UI:- dp64
                        height: consignBitController.visibilityDropDown[index]
                            ? SizeConstants.dp62 +
                                SizeConstants.dp30 +
                                SizeConstants.dp64 *
                                    consignBitController.getConsignedBit(index).bits.length.toDouble() //height for dropdown
                            : SizeConstants.dp62,
                        // TODO Change height
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          AnimatedContainer(
                            padding: const EdgeInsets.only(left: SizeConstants.dp20),
                            duration: const Duration(seconds: SizeConstants.dp0I),
                            height: SizeConstants.dp60,
                            child: Row(
                              children: [
                                getColumnUI(
                                  consignedBit: consignBitController.getConsignedBit(index),
                                  status: consignBitController.getConsignedBit(index).status.toString(),
                                  textValue: consignBitController.getConsignedBitsID(index),
                                  textStyle: consignScreenTextStyle.copyWith(
                                      color: consignBitController.getConsignedBit(index).status == AppStrings.draft
                                          ? AppColors.colorPrimaryDarkText
                                          : AppColors.colorMainText,
                                      fontWeight: consignBitController.getConsignedBit(index).status == AppStrings.draft
                                          ? AppValues.fontWeight500
                                          : AppValues.fontWeight600),
                                ),
                                getColumnUI(
                                  textValue:
                                      consignBitController.getConsignedBit(index).customerName.useCorrectEllipsis().toString(),
                                  textStyle: consignScreenTextStyle,
                                ),
                                getColumnUI(
                                  textValue:
                                      '${consignBitController.getConsignedBit(index).rigName!}-${consignBitController.getConsignedBit(index).rigId}'
                                          .useCorrectEllipsis()
                                          .toString(),
                                  textStyle: consignScreenTextStyle,
                                ),
                                getColumnUI(
                                  textValue: consignBitController
                                      .getConsignedBit(index)
                                      .createdAt
                                      .toString()
                                      .substring(0, 10)
                                      .toString(),
                                  textStyle: consignScreenTextStyle,
                                ),
                                getColumnUI(
                                    textValue: consignBitController.getConsignedBit(index).bits.length.toString(),
                                    textStyle: consignScreenTextStyle.copyWith(fontWeight: AppValues.fontWeight700),
                                    textAlign: TextAlign.end,
                                    flex: 2),
                                getColumnUI(textValue: '', textStyle: consignScreenTextStyle, flex: 1),
                                Expanded(
                                  flex: 2,
                                  child: Row(
                                    children: [
                                      Container(
                                        width: SizeConstants.dp5,
                                        height: SizeConstants.dp5,
                                        decoration: ShapeDecoration(
                                          color: getColorCodeOfConsignmentStatus(
                                              consignBitController.getConsignedBit(index).status.toString()),
                                          shape: const OvalBorder(),
                                        ),
                                      ),
                                      const SizedBox(
                                        width: SizeConstants.dp5,
                                      ),
                                      Text(
                                        consignBitController.getConsignedBit(index).status.toString(),
                                        style: tSw400dp12fontF.copyWith(
                                          color: getColorCodeOfConsignmentStatus(
                                              consignBitController.getConsignedBit(index).status.toString()),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Expanded(
                                  flex: 1,
                                  child: Container(
                                    padding: const EdgeInsets.all(SizeConstants.dp10),
                                    child: GestureDetector(
                                      onTap: () {
                                        if (consignBitController
                                            .getConsignedBit(index)
                                            .finalPdf
                                            .toString()
                                            .replaceAll('\n', '')
                                            .trim()
                                            .isNotEmpty) {
                                          createFileViewerOverlay(consignBitController.getConsignedBit(index));
                                        }
                                      },
                                      child: Opacity(
                                        opacity: consignBitController
                                                .getConsignedBit(index)
                                                .finalPdf
                                                .toString()
                                                .replaceAll('\n', '')
                                                .trim()
                                                .isNotEmpty
                                            ? 1
                                            : 0.2,
                                        child: Image.asset(
                                          AppImages.attachment,
                                          width: SizeConstants.dp20,
                                          height: SizeConstants.dp20,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  flex: 1,
                                  child: Container(
                                    padding: const EdgeInsets.all(SizeConstants.dp10),
                                    child: GestureDetector(
                                      onTap: () {
                                        if (AppStrings.draft == consignBitController.getConsignedBit(index).status.toString()) {
                                          consignBitController.makeAllDropDownClose();
                                          Navigator.of(context).push(DeleteDraftOverlay(consignBitController,
                                              consignBitController.getConsignedBit(index).consignmentId, index));
                                        }
                                      },
                                      child: Opacity(
                                        opacity: AppStrings.draft == consignBitController.getConsignedBit(index).status.toString()
                                            ? 1
                                            : 0.2,
                                        child: Image.asset(
                                          AppImages.delete,
                                          width: SizeConstants.dp20,
                                          height: SizeConstants.dp20,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Flexible(
                                  fit: FlexFit.loose,
                                  flex: 1,
                                  child: GestureDetector(
                                    onTap: () {
                                      consignBitController.visibilityDropDown[index] =
                                          !consignBitController.visibilityDropDown[index];

                                      if (consignBitController.visibilityDropDown[index] == true) {
                                        consignBitController.makeAllDropDownCloseExcept(index);
                                      } else {
                                        consignBitController.isBitsSelected.value = false;
                                        consignBitController.clearAllSelectedBits();
                                      }
                                      setState(() {});
                                    },
                                    child: Container(
                                      width: SizeConstants.dp30,
                                      height: SizeConstants.dp30,
                                      padding: const EdgeInsets.all(SizeConstants.dp8),
                                      child: ImageIcon(
                                        AssetImage(consignBitController.visibilityDropDown[index]
                                            ? AppImages.arrowDown
                                            : AppImages.arrowRight),
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                          AnimatedContainer( color: Colors.amber,
                            duration: const Duration(milliseconds: SizeConstants.dp0I),
                            height: consignBitController.visibilityDropDown[index]
                                ? SizeConstants.dp30 +
                                    SizeConstants.dp64 *
                                        consignBitController.getConsignedBit(index).bits.length.toDouble() //SizeConstants.dp90
                                : SizeConstants.dp0,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                    height: SizeConstants.dp30,
                                    color: AppColors.colorConsignLeftPanel,
                                    padding: const EdgeInsets.only(left: SizeConstants.dp10, right: SizeConstants.dp10),
                                    child: getSubHeaderUI()),
                                Flexible(
                                  fit: FlexFit.tight,
                                  child: Obx(
                                    () => ListView.builder(
                                      itemCount: consignBitController.getConsignedBit(index).bits.length,
                                      itemBuilder: (context, innerIndex) => SizedBox(
                                        height: SizeConstants.dp64,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Flexible(
                                              fit: FlexFit.tight,
                                              child: Container(
                                                padding:
                                                    const EdgeInsets.only(left: SizeConstants.dp10, right: SizeConstants.dp10),
                                                child: Row(children: [
                                                  //Checkbox 1
                                                  Flexible(
                                                    flex: 1,
                                                    child: consignBitController.getConsignedBit(index).status ==
                                                            AppStrings.completed
                                                        ? Checkbox(
                                                            shape: RoundedRectangleBorder(
                                                              borderRadius: BorderRadius.circular(AppValues.radius_2),
                                                            ),
                                                            //splashRadius: 0,
                                                            side: BorderSide(
                                                                width: SizeConstants.dp1,
                                                                color: checkBitStatusBlock(index, innerIndex)
                                                                    ? AppColors.colorCheckBoxUnselected
                                                                    : AppColors.colorCheckBoxUnselected.withOpacity(0.3),
                                                                style: BorderStyle.solid),
                                                            activeColor: AppColors.colorCheckBoxSelected,
                                                            checkColor: checkBitStatusBlock(index, innerIndex)
                                                                ? AppColors.colorWhite
                                                                : AppColors.colorWhite.withOpacity(0.3),
                                                            //ToDo need to check in between draft item record delete expand new item range error
                                                            value: consignBitController.selectedValueList[index][innerIndex],
                                                            onChanged: checkBitStatusBlock(index, innerIndex)
                                                                ? (value) {
                                                                    consignBitController.selectedValueList[index][innerIndex] =
                                                                        !consignBitController.selectedValueList[index]
                                                                            [innerIndex];
                                                                    isBitsSelected(consignBitController.getConsignedBit(index));
                                                                    consignBitController.isMultipleBitsSelected(index);
                                                                    setState(() {});
                                                                  }
                                                                : null,
                                                          )
                                                        : Container(),
                                                  ),
                                                  //serial number 2
                                                  getSubColumnItemUI(
                                                      flex: 2,
                                                      textValue: consignBitController
                                                          .getConsignedBit(index)
                                                          .bits[innerIndex]
                                                          .serialNumber
                                                          .toString()),
                                                  //size 4
                                                  getSubColumnItemUI(
                                                      flex: 4,
                                                      textValue: consignBitController
                                                          .getConsignedBit(index)
                                                          .bits[innerIndex]
                                                          .size
                                                          .toString()),
                                                  //type 4
                                                  getSubColumnItemUI(
                                                      flex: 4,
                                                      textValue: consignBitController
                                                          .getConsignedBit(index)
                                                          .bits[innerIndex]
                                                          .type
                                                          .toString()),
                                                  //bom 4
                                                  getSubColumnItemUI(
                                                      flex: 4,
                                                      textValue: consignBitController
                                                          .getConsignedBit(index)
                                                          .bits[innerIndex]
                                                          .bom
                                                          .toString()),
                                                  //no of runs 3
                                                  getSubColumnItemUI(
                                                      flex: 3,
                                                      textValue: consignBitController
                                                          .getConsignedBit(index)
                                                          .bits[innerIndex]
                                                          .noOfRuns
                                                          .toString()),
                                                  //iadc 3
                                                  getSubColumnItemUI(
                                                      flex: 3,
                                                      textValue: consignBitController
                                                          .getConsignedBit(index)
                                                          .bits[innerIndex]
                                                          .iadcCode
                                                          .toString()),
                                                  //status 2
                                                  consignBitController
                                                              .getConsignedBit(index)
                                                              .bits[innerIndex]
                                                              .status
                                                              .toString() !=
                                                          "-"
                                                      ? getSubColumnStatusUI(
                                                          flex: 2,
                                                          textValue: consignBitController
                                                              .getConsignedBit(index)
                                                              .bits[innerIndex]
                                                              .status
                                                              .toString())
                                                      : getSubColumnItemUI(flex: 2, textValue: '-'),
                                                  //blank 3
                                                  getSubColumnItemUI(flex: 3, textValue: ''),
                                                ]),
                                              ),
                                            ),
                                            consignBitController.getConsignedBit(index).bits.length - 1 != innerIndex
                                                ? Divider(
                                                    color: AppColors.colorSeparatorLine.withOpacity(0.5),
                                                    height: SizeConstants.dp0_5,
                                                  )
                                                : Container()
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          )
                        ]),
                      );
                    },
                  )),
                ),
              ],
            )
          : Align(
              alignment: Alignment.center,
              child: NoResultsScreen(
                imagePath: AppImages.noResults,
                titleText: AppStrings.noResultsFound,
                descriptionText: AppStrings.noResultsDescription,
                titleStyle: tSw500dp16fontF.copyWith(
                  color: AppColors.colorMainText,
                  fontSize: SizeConstants.dp32,
                ),
                descriptionStyle: tSw400dp14fontF.copyWith(
                  color: AppColors.colorSubText.withOpacity(0.7),
                  fontSize: SizeConstants.dp20,
                ),
                onPressCallback: () {},
              ),
            )),
    );
  }

  Widget getHeaderUI() {
    return Row(children: [
      Expanded(
        flex: 3,
        child: getColumnHeader(0),
      ),
      Expanded(
        flex: 3,
        child: getColumnHeader(1),
      ),
      Expanded(
        flex: 3,
        child: getColumnHeader(2),
      ),
      Expanded(
        flex: 3,
        child: getColumnHeader(3),
      ),
      Expanded(
        flex: 2,
        child: getColumnHeader(4),
      ),
      Expanded(
        flex: 1,
        child: Container(),
      ),
      Expanded(
        flex: 3,
        child: getColumnHeader(5),
      ),
      Expanded(
        flex: 1,
        child: getColumnHeader(6),
      ),
      Expanded(
        flex: 1,
        child: getColumnHeader(7),
      )
    ]);
  }

  Widget getColumnHeader(index) {
    return GestureDetector(
      onTap: () {
        consignBitController.sortingState[index] = !consignBitController.sortingState[index];
        // curSortIndex = index;

        consignBitController.sortConsignList(consignBitController.sortingState[index], consignBitController.columnList[index]);
      },
      child: Container(
        color: AppColors.transparentColor,
        padding: const EdgeInsets.only(
          top: SizeConstants.dp10,
          bottom: SizeConstants.dp10,
        ),
        alignment: Alignment.bottomLeft,
        child: Row(
          children: [
            Text(
              consignBitController.columnList[index],
              style: tSw600dp16fontF.copyWith(fontSize: SizeConstants.dp11, color: AppColors.colorSubText),
            ),
            Visibility(
              /* visible: consignBitController.isSortEnable &&
                  curSortIndex == index,*/
              visible: false,
              child: ImageIcon(
                consignBitController.sortingState[index]
                    ? const AssetImage(AppImages.icArrowUpward)
                    : const AssetImage(AppImages.icArrowDownward),
                color: AppColors.textColorGreyLight,
                size: SizeConstants.dp10,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget getColumnUI(
      {int flex = 3,
      required String textValue,
      TextAlign textAlign = TextAlign.left,
      required TextStyle textStyle,
      String? status,
      var consignedBit}) {
    return Expanded(
      flex: flex,
      child: Container(
        padding: const EdgeInsets.only(right: SizeConstants.dp15),
        child: GestureDetector(
          onTap: status == AppStrings.draft
              ? () {
                  try {
                    consignBitController.prepareForDraftEdit(consignedBit);
                  } catch (e) {
                    ApplicationLogger().printError('$textValue :- ${e.toString()}', "OnConsigned draft click");
                  }
                }
              : () => {},
          child: Text(
            textValue,
            style: textStyle,
            textAlign: textAlign,
          ),
        ),
      ),
    );
  }

  Color getColorCodeOfConsignmentStatus(String statusString) {
    return statusString == AppStrings.draft
        ? AppColors.colorRedError
        : statusString == AppStrings.processing
            ? AppColors.colorOrangeDraft
            : AppColors.colorGreen;
  }

  Widget getSubHeaderUI() {
    return Row(mainAxisAlignment: MainAxisAlignment.start, crossAxisAlignment: CrossAxisAlignment.center, children: [
      getSubColumnHeaderTitle(flex: 1, index: 0), //checkbox
      getSubColumnHeaderTitle(flex: 2, index: 1), //serial number
      getSubColumnHeaderTitle(flex: 4, index: 2), //size
      getSubColumnHeaderTitle(flex: 4, index: 3), //type
      getSubColumnHeaderTitle(flex: 4, index: 4), //bom
      getSubColumnHeaderTitle(flex: 3, index: 5), //no of runs
      getSubColumnHeaderTitle(flex: 3, index: 6), //iadc
      getSubColumnHeaderTitle(flex: 2, index: 7), //status
      getSubColumnHeaderTitle(flex: 3, index: 8), //blank
    ]);
  }

  Widget getSubColumnHeaderTitle({required int flex, required int index}) {
    return Expanded(
      flex: flex,
      child: Text(
        consignBitController.innerColumnList[index],
        style: tSw600dp14fontF.copyWith(
          fontSize: SizeConstants.dp11,
          color: AppColors.colorSubText,
        ),
      ),
    );
  }

  Widget getSubColumnItemUI({required int flex, required String textValue}) {
    return Expanded(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.only(right: SizeConstants.dp5),
        child: Text(
          textValue,
          style: tSw400dp14fontF.copyWith(color: AppColors.colorMainText),
        ),
      ),
    );
  }

  void isBitsSelected(Consignment bit) {
    if (bit.status == AppStrings.completed) {
      consignBitController.isSelectedBitStatusValid.value = true;
      consignBitController.currentConsignmentForBilling = bit.consignmentId.toString();
      consignBitController.currentConsignment = bit;
    } else {
      consignBitController.isSelectedBitStatusValid.value = false;
    }
    for (List element in consignBitController.selectedValueList) {
      for (bool innerElement in element) {
        if (innerElement == true) {
          isSelectedBits = true;
          consignBitController.isBitsSelected.value = true;

          break;
        } else {
          isSelectedBits = false;
          consignBitController.isBitsSelected.value = false;
        }
      }
      if (isSelectedBits == true) {
        break;
      }
    }
  }

  Future<String> createFile(String encodedStr) async {
    Uint8List bytes = base64.decode(encodedStr);
    String dir = (await getApplicationDocumentsDirectory()).path;
    File file = File("$dir/${DateTime.now().millisecondsSinceEpoch}${AppStrings.pdfExtension}");
    await file.writeAsBytes(bytes);
    return file.path;
  }

  void createFileViewerOverlay(Consignment getConsignedBit) async {
    String id = getConsignedBit.consignmentId ?? DateTime.now().toString().replaceAll(" ", "");
    var bytes = base64Decode(getConsignedBit.finalPdf.toString().replaceAll('\n', ''));
    final output = await getTemporaryDirectory();
    final file = File("${output.path}/$id${AppStrings.pdfExtension}");
    await file.writeAsBytes(bytes.buffer.asUint8List());
    Navigator.of(context).push(FileViewerOverlay(file, id, true));
  }

  getSubColumnStatusUI({required int flex, required String textValue}) {
    return Flexible(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.only(right: SizeConstants.dp5),
        child: Container(
          padding: const EdgeInsets.all(SizeConstants.dp5),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              border: Border.all(color: textValue == AppStrings.ticketed ? AppColors.colorGreen : AppColors.colorOrange)),
          child: Text(
            textValue,
            style: tSw500dp12fontF.copyWith(
                color: textValue == AppStrings.ticketed ? AppColors.colorGreen : AppColors.colorOrange, fontSize: 10),
          ),
        ),
      ),
    );
  }

  bool checkBitStatusBlock(int index, int innerIndex) {
    return consignBitController.getConsignedBit(index).bits[innerIndex].isBlocked == false;
  }
}
