import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/common_binding/realm_initial.dart';
import 'package:slb_gt_mobile/app/core/common_widgets/custom_button_material.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';
import 'package:slb_gt_mobile/app/modules/consigned_bits/controller/consigned_bits_controller.dart';
import 'package:slb_gt_mobile/app/modules/inventory/controller/inventory_controller.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/consignmentSchema.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/screens/ticketing_bits_screen.dart';
import 'package:slb_gt_mobile/app/routes/app_pages.dart';

class BillBitOverlay extends ModalRoute<void> {

  String selectedSerialNumber;
  List<Bit> selectedBits;

  ConsignedBitController consinedBitController;

  BillBitOverlay(
    this.consinedBitController,
    this.selectedSerialNumber,
    this.selectedBits,
  );

  @override
  Duration get transitionDuration => const Duration(milliseconds: 0);

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => false;

  @override
  Color get barrierColor => AppColors.colorBlack.withOpacity(0.3);

  @override
  String get barrierLabel => '';

  @override
  bool get maintainState => true;
  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());
  final InventoryController inventoryController = Get.find();

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    // This makes sure that text and other content follows the material style
    return Material(
      type: MaterialType.transparency,
      // make sure that the overlay content is not cut off
      child: SafeArea(
        child: _buildOverlayContent(context),
      ),
    );
  }

  Widget _buildOverlayContent(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: getWidth(SizeConstants.dp570),
            //height: getHeight(SizeConstants.dp331),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(SizeConstants.dp10),
                boxShadow: [
                  BoxShadow(
                      color: AppColors.colorBlack.withOpacity(0.3),
                      blurRadius: SizeConstants.dp7)
                ]),
            child: Container(
              decoration: BoxDecoration(
                color: AppColors.colorWhite,
                borderRadius: BorderRadius.circular(SizeConstants.dp10),
              ),
              child: Padding(
                padding: const EdgeInsets.all(SizeConstants.dp20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: getHeight(SizeConstants.dp64),
                      child: Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: AppColors.colorCircleIcon,
                            radius: SizeConstants.dp32,
                            child: Container(
                                height: getWidth(SizeConstants.dp30),
                                width: getWidth(SizeConstants.dp30),
                                decoration: const BoxDecoration(
                                  image: DecorationImage(
                                    image: AssetImage(AppImages.money),
                                    fit: BoxFit.fill,
                                  ),
                                ),
                                child: null),
                          ),
                          const SizedBox(
                            width: SizeConstants.dp16,
                          ),
                          const Text(
                            AppStrings.ticketBit,
                            style: warehouseTextStyle,
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: getHeight(SizeConstants.dp4),
                    ),
                    Column(
                      children: [
                        Row(
                          children: [
                            SizedBox(
                              width: SizeConstants.dp85,
                            ),
                            Text(
                              AppStrings.billingTicketGen,
                              style: wareHouseStaticTextStyle,
                            ),
                            SizedBox(
                              width: SizeConstants.dp3,
                            ),
                          ],
                        ),
                        SizedBox(
                          height: getHeight(SizeConstants.dp2),
                        ),
                        Row(
                          children: [
                            const SizedBox(
                              width: SizeConstants.dp85,
                            ),
                            Text(
                              selectedSerialNumber,
                              style: wareHouseBitsTextStyle,
                            ),
                            const SizedBox(
                              width: SizeConstants.dp5,
                            ),
                            const Text(
                              AppStrings.forConsign,
                              style: wareHouseStaticTextStyle,
                            ),
                          ],
                        ),
                        SizedBox(
                          height: getHeight(SizeConstants.dp5),
                        ),
                        Row(
                          children: [
                            const SizedBox(
                              width: SizeConstants.dp85,
                            ),
                            Text(
                              consinedBitController.currentConsignmentForBilling,
                              style: wareHouseBitsTextStyle,
                            ),
                          ],
                        ),
                        SizedBox(
                          height: getHeight(SizeConstants.dp15),
                        ),
                        Row(
                          children: [
                            SizedBox(
                              width: SizeConstants.dp85,
                            ),
                            Text(
                              AppStrings.doyouwanttoproceed,
                              style: wareHouseStaticTextStyle,
                            ),
                          ],
                        ),
                        SizedBox(
                          height: getHeight(SizeConstants.dp19),
                        ),
                        bottomButtonWidget(context, consinedBitController)
                      ],
                    )
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget bottomButtonWidget(
      BuildContext context, ConsignedBitController consinedBitController) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        CustomButtonMaterial(
          width: getWidth(SizeConstants.dp102),
          height: getHeight(SizeConstants.dp45),
          backgroundColor: AppColors.colorWhite,
          foregroundColor: AppColors.colorPrimary,
          borderRadius: AppValues.radius_4,
          text: AppStrings.cancel,
          style: tSw500dp16fontF,
          side: const BorderSide(
            width: SizeConstants.dp1,
            color: AppColors.colorPrimary,
          ),
          onPressCallback: () {
            Get.back();
          },
        ),
        SizedBox(
          width: getWidth(SizeConstants.dp10),
        ),
        CustomButtonMaterial(
          width: getWidth(SizeConstants.dp130),
          height: getHeight(SizeConstants.dp45),
          backgroundColor: true
              ? AppColors.colorPrimary
              : AppColors.colorPrimary.withOpacity(0.2),
          foregroundColor: Colors.white,
          borderRadius: AppValues.radius_4,
          text: AppStrings.yes,
          style: tSw500dp16fontF,
          onPressCallback: () async {
            Get.back();
            Get.to(
                    TicketingBits(isDraftEdit: false,
                      selectedBits: selectedBits,
                      currentConsignment: consinedBitController.currentConsignment,

                    ),
                    transition: Transition.native,
                    duration: const Duration(milliseconds: 300))
                ?.then((value) => consinedBitController.makeAllDropDownClose());
          },
        ),
      ],
    );
  }

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    // You can add your own animations for the overlay content
    return FadeTransition(
      opacity: animation,
      child: ScaleTransition(
        scale: animation,
        child: child,
      ),
    );
  }
}

class response {
  String bit;
  String warehouse;

  var success;

  response(this.success, this.bit, this.warehouse);
}
