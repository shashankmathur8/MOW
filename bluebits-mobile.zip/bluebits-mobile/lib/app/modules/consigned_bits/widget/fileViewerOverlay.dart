import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:slb_gt_mobile/app/core/common_widgets/custom_button_material.dart';
import 'package:slb_gt_mobile/app/core/common_widgets/toast_message.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

import '../../../core/common_widgets/common_widget.dart';

class FileViewerOverlay extends ModalRoute<void> {
  dynamic base64File;
  bool isConsignedQuote = false;
  String? fileRecordId = '';

  var list;

  FileViewerOverlay(
    this.base64File,
    this.fileRecordId,
    this.isConsignedQuote,
  );

  @override
  Duration get transitionDuration => const Duration(milliseconds: 0);

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => false;

  @override
  Color get barrierColor => AppColors.colorBlack.withOpacity(0.3);

  @override
  String get barrierLabel => '';

  @override
  bool get maintainState => true;

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    // This makes sure that text and other content follows the material style
    return Material(
      type: MaterialType.transparency,
      // make sure that the overlay content is not cut off
      child: SafeArea(
        child: _buildOverlayContent(context),
      ),
    );
  }

  Widget _buildOverlayContent(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(getWidth(SizeConstants.dp20)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: getWidth(SizeConstants.dp864),
              height: getHeight(SizeConstants.dp568),
              decoration: BoxDecoration(
                  borderRadius:
                      BorderRadius.circular(getWidth(SizeConstants.dp10)),
                  boxShadow: [
                    BoxShadow(
                        color: AppColors.colorBlack.withOpacity(0.3),
                        blurRadius: SizeConstants.dp7)
                  ]),
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.colorWhite,
                  borderRadius:
                      BorderRadius.circular(getWidth(SizeConstants.dp10)),
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: getWidth(SizeConstants.dp20),
                      vertical: getWidth(SizeConstants.dp20)),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          CustomWidgets().roundIconWidget(AppImages.previewColoredBig,
                              iconHeight: SizeConstants.dp64, iconWidth: SizeConstants.dp64),
                          SizedBox(
                            width: getWidth(SizeConstants.dp19),
                          ),
                          CustomWidgets().headerTitle(
                            isConsignedQuote
                                ? AppStrings.prevConsignmentQuote
                                : AppStrings.prevBilledTicket,
                            warehouseTextStyle,
                          )
                        ],
                      ),
                      SizedBox(height: getHeight(SizeConstants.dp16)),
                      Expanded(
                        child: Container(
                          decoration: const BoxDecoration(
                              color: AppColors.colorBg,
                              borderRadius: BorderRadius.only(
                                  bottomLeft:
                                      Radius.circular(AppValues.radius_5),
                                  bottomRight:
                                      Radius.circular(AppValues.radius_5))),
                          width: double.infinity,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: getHeight(SizeConstants.dp15),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                    left: getWidth(SizeConstants.dp51)),
                                child: Text(
                                  '$fileRecordId${AppStrings.quotePDFExt}',
                                  textAlign: TextAlign.center,
                                  style: tSw400dp16fontF,
                                ),
                              ),
                              SizedBox(
                                height: getHeight(SizeConstants.dp11),
                              ),
                              Expanded(
                                child: Container(
                                  height: getHeight(SizeConstants.dp352),
                                  padding: EdgeInsets.only(
                                      left: getWidth(SizeConstants.dp51),
                                      right: getWidth(SizeConstants.dp58),
                                      top: getHeight(SizeConstants.dp6),
                                      bottom: getHeight(SizeConstants.dp1)),
                                  child: SfPdfViewer.file(
                                    base64File,
                                    canShowScrollHead: true,
                                    canShowScrollStatus: true,
                                    enableDoubleTapZooming: false,
                                    enableHyperlinkNavigation: false,
                                    enableDocumentLinkAnnotation: false,
                                    enableTextSelection: false,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: getHeight(SizeConstants.dp15),
                      ),
                      bottomButtonWidget(context, base64File)
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget bottomButtonWidget(BuildContext context, File file) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        CustomButtonMaterial(
          width: getWidth(SizeConstants.dp102),
          height: getHeight(SizeConstants.dp45),
          backgroundColor: AppColors.colorWhite,
          foregroundColor: AppColors.colorPrimary,
          borderRadius: AppValues.radius_4,
          text: AppStrings.close,
          style: tSw500dp16fontF,
          side: const BorderSide(
            width: SizeConstants.dp1,
            color: AppColors.colorPrimary,
          ),
          onPressCallback: () {
            Get.back();
          },
        ),
        SizedBox(
          width: getWidth(SizeConstants.dp10),
        ),
        CustomButtonMaterial(
          width: getWidth(SizeConstants.dp130),
          height: getHeight(SizeConstants.dp45),
          backgroundColor: AppColors.colorPrimary,
          foregroundColor: Colors.white,
          borderRadius: AppValues.radius_4,
          text: AppStrings.download,
          style: tSw500dp16fontF,
          onPressCallback: () async {
            Directory documents = await getApplicationDocumentsDirectory();
            final fileOP = File(
                "${documents.path}/$fileRecordId${AppStrings.pdfExtension}");
            await fileOP.writeAsBytes(file.readAsBytesSync());
            showToastMsg(
                context, AppStrings.downloadComplete, ToastStatus.success);
          },
        ),
      ],
    );
  }

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    // You can add your own animations for the overlay content
    return FadeTransition(
      opacity: animation,
      child: ScaleTransition(
        scale: animation,
        child: child,
      ),
    );
  }
}

void showToastMsg(BuildContext context, String message, ToastStatus status) {
  Timer(const Duration(seconds: AppValues.timeDuration1), () {
    var msg = ToastMessage(
      message: message,
      status: status,
    );
    Navigator.of(context).push(msg);
    Timer(const Duration(seconds: AppValues.timeDuration2), () {
      Navigator.of(context).pop();
    });
  });
}

class response {
  String bit;
  String warehouse;

  var success;

  response(this.success, this.bit, this.warehouse);
}
