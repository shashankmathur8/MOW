import 'package:get/get.dart';

class TicketedBitsBinding extends Bindings {
  @override
  void dependencies() {
    //Get.lazyPut<BilledBitsController>(() => BilledBitsController());
  }
}