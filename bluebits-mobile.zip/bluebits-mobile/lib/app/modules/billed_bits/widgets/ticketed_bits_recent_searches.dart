import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/modules/billed_bits/controller/ticketed_bits_controller.dart';

class SearchTicketedBits extends StatefulWidget {
  SearchTicketedBits({
    super.key,
  });

  @override
  _SearchTicketedBitsState createState() => _SearchTicketedBitsState();
}

class _SearchTicketedBitsState extends State<SearchTicketedBits> {
  TicketedBitsController ticketedBitsController =
      Get.find(tag: (TicketedBitsController).toString());

  var entry;

  _SearchTicketedBitsState();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    ticketedBitsController.focusNode.addListener(() {
      if (ticketedBitsController.focusNode.hasFocus) {
        var renderBox = context.findRenderObject() as RenderBox;
        final size = renderBox.size;
        final pos = renderBox.localToGlobal(Offset.zero);
        entry = OverlayEntry(
            builder: (context) => Positioned(
                left: pos.dx,
                top: pos.dy + size.height,
                width: size.width,
                child: buildOverlay()));
        Overlay.of(context).insert(entry);
      } else {
        if (entry != null) {
          entry?.remove();
          entry = null;
        }
      }
    });
  }

  Widget buildOverlay() => Container();

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(
          maxWidth: SizeConstants.dp420, maxHeight: SizeConstants.dp40),
      child: TextField(
          autocorrect: false,
          enableSuggestions: false,
          focusNode: ticketedBitsController.focusNode,
          onChanged: (value) {
            setState(() {
              if (value.trim().isEmpty) {
                refreshUITabData();
              }
            });
          },
          onSubmitted: (value) {
            if (value.trim().isNotEmpty) {
              if (ticketedBitsController.pageIndex.value == 0) {
                ticketedBitsController.filterBitListData(value.trim());
              } else if (ticketedBitsController.pageIndex.value == 1) {
                ticketedBitsController.filterTicketLaterListData(value.trim());
              }
              ticketedBitsController.focusNode.unfocus();
            }
          },
          controller: ticketedBitsController.searchController,
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(AppValues.radius_20),
            ),
            fillColor: AppColors.colorBg.withOpacity(0.8),
            labelStyle: const TextStyle(color: AppColors.colorSubText),
            labelText: AppStrings.hintBilledBitsSearch,
            suffixIcon: ticketedBitsController.searchController.text.isNotEmpty
                ? IconButton(
                    onPressed: () {
                      setState(() {
                        refreshUITabData();
                      });
                    },
                    icon: const Icon(
                      Icons.close,
                      color: AppColors.colorBlack,
                    ))
                : IconButton(
                    onPressed: () {},
                    icon: const Icon(
                      Icons.search,
                      color: AppColors.colorBlack,
                    )),
            floatingLabelBehavior: FloatingLabelBehavior.never,
          )),
    );
  }

  void refreshUITabData() {
    ticketedBitsController.searchController.text = "";
    ticketedBitsController.pageIndex.value == 0
        ? ticketedBitsController.fetchData()
        : ticketedBitsController.fetchDataTicketLater();
    ticketedBitsController.focusNode.unfocus();
  }
}
