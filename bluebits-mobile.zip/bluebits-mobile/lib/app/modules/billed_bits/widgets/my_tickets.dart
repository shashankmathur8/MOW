import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';
import 'package:slb_gt_mobile/app/modules/consigned_bits/widget/fileViewerOverlay.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/consignmentSchema.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/model/schema/ticketing_schema.dart';

import '../../../core/common_widgets/no_results_screen.dart';
import '../../../core/values/app_utils.dart';
import '../../../core/values/size_constants.dart';
import '../../shared/bottom_tab_notification_shared.dart';
import '../../shared/generic_overlay.dart';
import '../controller/ticketed_bits_controller.dart';

class MyTickets extends StatefulWidget {
  var scrollController;
  var visible;
  MyTickets({super.key, required this.scrollController, required this.visible});

  @override
  State<MyTickets> createState() => _MyTickets();
}

class _MyTickets extends State<MyTickets> {
  final TicketedBitsController ticketedBitsController =
      Get.find(tag: (TicketedBitsController).toString());

  var selectedValue = false;
  var isSelectedBits = false;

  @override
  void initState() {
    super.initState();
    ticketedBitsController.fetchData();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Obx(() => ticketedBitsController.allBilledBitList.isNotEmpty
          ? Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                      left: SizeConstants.dp40,
                      right: SizeConstants.dp20,
                      top: SizeConstants.dp4),
                  child: getHeaderUI(),
                ),
                Flexible(
                    child: Stack(
                  alignment: AlignmentDirectional.bottomStart,
                  children: [
                    Obx(
                      () => Expanded(
                          child: ListView.builder(
                        controller: widget.scrollController,
                        scrollDirection: Axis.vertical,
                        shrinkWrap: false,
                        physics: const ScrollPhysics(),
                        itemCount:
                            ticketedBitsController.allBilledBitList.length,
                        itemBuilder: (context, index) {
                          return AnimatedContainer(
                            duration:
                                const Duration(seconds: SizeConstants.dp0I),
                            decoration: BoxDecoration(
                                boxShadow: const [
                                  BoxShadow(
                                      color: AppColors.colorGrey,
                                      blurRadius: SizeConstants.dp1,
                                      offset: Offset(0.0, 0.75))
                                ],
                                borderRadius:
                                    BorderRadius.circular(SizeConstants.dp5),
                                border: Border.all(color: AppColors.colorWhite),
                                color: AppColors.colorWhite),
                            margin: const EdgeInsets.only(
                                left: SizeConstants.dp20,
                                right: SizeConstants.dp20,
                                bottom: SizeConstants.dp10),
                            //Normal UI:- dp62 , Sub header UI:- dp30, Sub item UI:- dp64
                            height: ticketedBitsController
                                    .visibilityDropDown[index]
                                ? SizeConstants.dp62 +
                                    SizeConstants.dp30 +
                                    SizeConstants.dp64 *
                                        ticketedBitsController
                                            .getBilledBit(index)
                                            .bits
                                            .length
                                            .toDouble() //height for dropdown
                                : SizeConstants.dp62,
                            // TODO Change height
                            child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  AnimatedContainer(
                                    padding: const EdgeInsets.only(
                                        left: SizeConstants.dp20),
                                    duration: const Duration(
                                        seconds: SizeConstants.dp0I),
                                    height: SizeConstants.dp60,
                                    child: Row(
                                      children: [
                                        //billingID
                                        getColumnUI(
                                          columnID: 0,
                                          index: index,
                                          textValue: ticketedBitsController
                                              .getBilledBitsID(index),
                                          textStyle:
                                              consignScreenTextStyle.copyWith(
                                                  color: ticketedBitsController
                                                              .getBilledBit(
                                                                  index)
                                                              .status ==
                                                          AppStrings.draft
                                                      ? AppColors
                                                          .colorPrimaryDarkText
                                                      : AppColors.colorMainText,
                                                  fontWeight:
                                                      ticketedBitsController
                                                                  .getBilledBit(
                                                                      index)
                                                                  .status ==
                                                              AppStrings.draft
                                                          ? AppValues
                                                              .fontWeight500
                                                          : AppValues
                                                              .fontWeight600),
                                        ),

                                        //customer
                                        getColumnUI(
                                          columnID: 1,
                                          index: index,
                                          textValue: ticketedBitsController
                                              .getBilledBit(index)
                                              .customerName
                                              .useCorrectEllipsis()
                                              .toString(),
                                          textStyle: consignScreenTextStyle,
                                        ),
                                        //rigNameAndNo
                                        getColumnUI(
                                          columnID: 1,
                                          index: index,
                                          textValue:
                                              '${ticketedBitsController.getBilledBit(index).rigName!}-${ticketedBitsController.getBilledBit(index).rigId}'
                                                  .useCorrectEllipsis()
                                                  .toString(),
                                          textStyle: consignScreenTextStyle,
                                        ),
                                        //wellNameAndNo
                                        getColumnUI(
                                          columnID: 1,
                                          index: index,
                                          textValue: ticketedBitsController
                                              .getBilledBit(index)
                                              .wellId
                                              .toString(),
                                          textStyle: consignScreenTextStyle,
                                        ),
                                        //dateTicketed
                                        getColumnUI(
                                          columnID: 1,
                                          index: index,
                                          textValue: ticketedBitsController
                                              .getBilledBit(index)
                                              .createdAt
                                              .toString()
                                              .substring(0, 10)
                                              .toString(),
                                          textStyle: consignScreenTextStyle,
                                        ),
                                        //ticketStatus
                                        Expanded(
                                          flex: 2,
                                          child: Row(
                                            children: [
                                              Container(
                                                width: SizeConstants.dp5,
                                                height: SizeConstants.dp5,
                                                decoration: ShapeDecoration(
                                                  color:
                                                      getColorCodeOfConsignmentStatus(
                                                          ticketedBitsController
                                                              .getBilledBit(
                                                                  index)
                                                              .status
                                                              .toString()),
                                                  shape: const OvalBorder(),
                                                ),
                                              ),
                                              const SizedBox(
                                                width: SizeConstants.dp5,
                                              ),
                                              Text(
                                                ticketedBitsController
                                                    .getBilledBit(index)
                                                    .status
                                                    .toString(),
                                                style: tSw400dp12fontF.copyWith(
                                                  color:
                                                      getColorCodeOfConsignmentStatus(
                                                          ticketedBitsController
                                                              .getBilledBit(
                                                                  index)
                                                              .status
                                                              .toString()),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        //emptyTitle attachment
                                        Expanded(
                                          flex: 1,
                                          child: Container(
                                            padding: const EdgeInsets.all(
                                                SizeConstants.dp10),
                                            child: GestureDetector(
                                              onTap: () {
                                                if (ticketedBitsController
                                                    .getBilledBit(index)
                                                    .finalPdf
                                                    .toString()
                                                    .replaceAll('\n', '')
                                                    .trim()
                                                    .isNotEmpty) {
                                                  createFileViewerOverlay(
                                                      ticketedBitsController
                                                          .getBilledBit(index));
                                                }
                                              },
                                              child: Opacity(
                                                opacity: ticketedBitsController
                                                        .getBilledBit(index)
                                                        .finalPdf
                                                        .toString()
                                                        .replaceAll('\n', '')
                                                        .trim()
                                                        .isNotEmpty
                                                    ? 1
                                                    : 0.2,
                                                child: Image.asset(
                                                  AppImages.attachment,
                                                  width: SizeConstants.dp20,
                                                  height: SizeConstants.dp20,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        //emptyTitle delete
                                        Expanded(
                                          flex: 1,
                                          child: Container(
                                            padding: const EdgeInsets.all(
                                                SizeConstants.dp10),
                                            child: GestureDetector(
                                              onTap: () {
                                                if (AppStrings.draft ==
                                                    ticketedBitsController
                                                        .getBilledBit(index)
                                                        .status
                                                        .toString()) {
                                                  ticketedBitsController
                                                      .makeAllDropDownClose();
                                                  Navigator.of(context).push(
                                                      GenericOverlay(
                                                          title: AppStrings
                                                              .deleteDraftTitle,
                                                          message: AppStrings
                                                              .deleteDraftMsg,
                                                          iconPath: AppImages
                                                              .icSignaturePenBackground,
                                                          negativeButtonText:
                                                              AppStrings.cancel,
                                                          positiveButtonText:
                                                              AppStrings.ok,
                                                          onPositivePressCallback:
                                                              () async {
                                                            await ticketedBitsController
                                                                .realm
                                                                .deleteDraftFromTicketedBits(
                                                                    ticketedBitsController
                                                                        .getBilledBit(
                                                                            index)
                                                                        .ticketingId);
                                                            ticketedBitsController
                                                                .fetchData();
                                                            Get.back();
                                                          }));
                                                }
                                              },
                                              child: Opacity(
                                                opacity: AppStrings.draft ==
                                                        ticketedBitsController
                                                            .getBilledBit(index)
                                                            .status
                                                            .toString()
                                                    ? 1
                                                    : 0.2,
                                                child: Image.asset(
                                                  AppImages.delete,
                                                  width: SizeConstants.dp20,
                                                  height: SizeConstants.dp20,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        //emptyTitle arrow
                                        Flexible(
                                          fit: FlexFit.loose,
                                          flex: 1,
                                          child: GestureDetector(
                                            onTap: () {
                                              ticketedBitsController
                                                          .visibilityDropDown[
                                                      index] =
                                                  !ticketedBitsController
                                                          .visibilityDropDown[
                                                      index];

                                              if (ticketedBitsController
                                                          .visibilityDropDown[
                                                      index] ==
                                                  true) {
                                                ticketedBitsController
                                                    .makeAllDropDownCloseExcept(
                                                        index);
                                              } else {
                                                ticketedBitsController
                                                    .isBitsSelected
                                                    .value = false;
                                                ticketedBitsController
                                                    .clearAllSelectedBits();
                                              }
                                              setState(() {});
                                            },
                                            child: Container(
                                              width: SizeConstants.dp30,
                                              height: SizeConstants.dp30,
                                              padding: const EdgeInsets.all(
                                                  SizeConstants.dp8),
                                              child: ImageIcon(
                                                AssetImage(ticketedBitsController
                                                            .visibilityDropDown[
                                                        index]
                                                    ? AppImages.arrowDown
                                                    : AppImages.arrowRight),
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  AnimatedContainer(
                                    duration: const Duration(
                                        milliseconds: SizeConstants.dp0I),
                                    height: ticketedBitsController
                                            .visibilityDropDown[index]
                                        ? SizeConstants.dp30 +
                                            SizeConstants.dp64 *
                                                ticketedBitsController
                                                    .getBilledBit(index)
                                                    .bits
                                                    .length
                                                    .toDouble() //SizeConstants.dp90
                                        : SizeConstants.dp0,
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Container(
                                            height: SizeConstants.dp30,
                                            color:
                                                AppColors.colorConsignLeftPanel,
                                            padding: const EdgeInsets.only(
                                                left: SizeConstants.dp10,
                                                right: SizeConstants.dp10),
                                            child: getSubHeaderUI()),
                                        Flexible(
                                          fit: FlexFit.tight,
                                          child: ListView.builder(
                                            itemCount: ticketedBitsController
                                                .getBilledBit(index)
                                                .bits
                                                .length,
                                            itemBuilder:
                                                (context, innerIndex) =>
                                                    SizedBox(
                                              height: SizeConstants.dp64,
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Flexible(
                                                    fit: FlexFit.tight,
                                                    child: Container(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              left:
                                                                  SizeConstants
                                                                      .dp10,
                                                              right:
                                                                  SizeConstants
                                                                      .dp10),
                                                      child: Row(children: [
                                                        Expanded(
                                                          flex: 1,
                                                          child: Container(),
                                                        ),
                                                        getSubColumnItemUI(
                                                            flex: 2,
                                                            textValue: ticketedBitsController
                                                                .getBilledBit(
                                                                    index)
                                                                .bits[
                                                                    innerIndex]
                                                                .serialNumber
                                                                .toString()),
                                                        getSubColumnItemUI(
                                                            flex: 4,
                                                            textValue:
                                                                ticketedBitsController
                                                                    .getBilledBit(
                                                                        index)
                                                                    .bits[
                                                                        innerIndex]
                                                                    .size
                                                                    .toString()),
                                                        getSubColumnItemUI(
                                                            flex: 4,
                                                            textValue:
                                                                ticketedBitsController
                                                                    .getBilledBit(
                                                                        index)
                                                                    .bits[
                                                                        innerIndex]
                                                                    .type
                                                                    .toString()),
                                                        getSubColumnItemUI(
                                                            flex: 4,
                                                            textValue:
                                                                ticketedBitsController
                                                                    .getBilledBit(
                                                                        index)
                                                                    .bits[
                                                                        innerIndex]
                                                                    .bom
                                                                    .toString()),
                                                        getSubColumnItemUI(
                                                            flex: 3,
                                                            textValue:
                                                                ticketedBitsController
                                                                    .getBilledBit(
                                                                        index)
                                                                    .bits[
                                                                        innerIndex]
                                                                    .noOfRuns
                                                                    .toString()),
                                                        getSubColumnItemUI(
                                                            flex: 3,
                                                            textValue:
                                                                ticketedBitsController
                                                                    .getBilledBit(
                                                                        index)
                                                                    .bits[
                                                                        innerIndex]
                                                                    .iadcCode
                                                                    .toString()),
                                                        getSubColumnItemUI(
                                                            flex: 5,
                                                            textValue: ''),
                                                      ]),
                                                    ),
                                                  ),
                                                  ticketedBitsController
                                                                  .getBilledBit(
                                                                      index)
                                                                  .bits
                                                                  .length -
                                                              1 !=
                                                          innerIndex
                                                      ? Divider(
                                                          color: AppColors
                                                              .colorSeparatorLine
                                                              .withOpacity(0.5),
                                                          height: SizeConstants
                                                              .dp0_5,
                                                        )
                                                      : Container()
                                                ],
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  )
                                ]),
                          );
                        },
                      )),
                    ),
                    Obx(
                      () => Visibility(
                          visible: !widget.visible.value,
                          child: BottomTabNotificationShared(
                              ticketedBitsController, widget.scrollController)),
                    )
                  ],
                ))
              ],
            )
          : Align(
              alignment: Alignment.center,
              child: NoResultsScreen(
                imagePath: AppImages.noResults,
                titleText: AppStrings.noResultsFound,
                descriptionText: AppStrings.noResultsDescription,
                titleStyle: tSw500dp16fontF.copyWith(
                  color: AppColors.colorMainText,
                  fontSize: SizeConstants.dp32,
                ),
                descriptionStyle: tSw400dp14fontF.copyWith(
                  color: AppColors.colorSubText.withOpacity(0.7),
                  fontSize: SizeConstants.dp20,
                ),
                onPressCallback: () {},
              ),
            )),
    );
  }

  Widget getHeaderUI() {
    return Row(children: [
      Expanded(
        flex: 3,
        child: getColumnHeader(0), //billingID
      ),
      Expanded(
        flex: 3,
        child: getColumnHeader(1), //customer
      ),
      Expanded(
        flex: 3,
        child: getColumnHeader(2), //rigNameAndNo
      ),
      Expanded(
        flex: 3,
        child: getColumnHeader(3), //wellNameAndNo
      ),
      Expanded(
        flex: 3,
        child: getColumnHeader(4), //dateTicketed
      ),
      Expanded(
        flex: 2,
        child: getColumnHeader(5), //ticketStatus
      ),
      Expanded(
        flex: 1,
        child: getColumnHeader(6), //emptyTitle attachment
      ),
      Expanded(
        flex: 1,
        child: getColumnHeader(7), //emptyTitle delete
      ),
      Expanded(
        flex: 1,
        child: getColumnHeader(8), //emptyTitle arrow
      )
    ]);
  }

  Widget getColumnHeader(index) {
    return GestureDetector(
      onTap: () {
        ticketedBitsController.sortingState[index] =
            !ticketedBitsController.sortingState[index];
        ticketedBitsController.sortConsignList(
            ticketedBitsController.sortingState[index],
            ticketedBitsController.columnList[index]);
      },
      child: Container(
        color: AppColors.transparentColor,
        padding: const EdgeInsets.only(
          top: SizeConstants.dp10,
          bottom: SizeConstants.dp10,
        ),
        alignment: Alignment.bottomLeft,
        child: Row(
          children: [
            Text(
              ticketedBitsController.columnList[index],
              style: tSw600dp16fontF.copyWith(
                  fontSize: SizeConstants.dp11, color: AppColors.colorSubText),
            ),
            Visibility(
              visible: false,
              child: ImageIcon(
                ticketedBitsController.sortingState[index]
                    ? const AssetImage(AppImages.icArrowUpward)
                    : const AssetImage(AppImages.icArrowDownward),
                color: AppColors.textColorGreyLight,
                size: SizeConstants.dp10,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget getColumnUI(
      {required columnID,
      required int index,
      int flex = 3,
      required String textValue,
      TextAlign textAlign = TextAlign.left,
      required TextStyle textStyle}) {
    return Expanded(
      flex: flex,
      child: Container(
        padding: const EdgeInsets.only(right: SizeConstants.dp15),
        child: columnID != 0
            ? Text(
                textValue,
                style: textStyle,
                textAlign: textAlign,
              )
            : GestureDetector(
                child: Text(
                  textValue,
                  style: textStyle,
                  textAlign: textAlign,
                ),
                onTap: ticketedBitsController.getBilledBit(index).status ==
                        AppStrings.draft
                    ? () {
                        ticketedBitsController.prepareForDraft(
                            ticketedBitsController.getBilledBit(index));
                      }
                    : null,
              ),
      ),
    );
  }

  Color getColorCodeOfConsignmentStatus(String statusString) {
    return statusString == AppStrings.draft
        ? AppColors.colorRedError
        : statusString == AppStrings.processing
            ? AppColors.colorOrangeDraft
            : AppColors.colorGreen;
  }

  Widget getSubHeaderUI() {
    return Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          getSubColumnHeaderTitle(flex: 1, index: 0),
          getSubColumnHeaderTitle(flex: 2, index: 1),
          getSubColumnHeaderTitle(flex: 4, index: 2),
          getSubColumnHeaderTitle(flex: 4, index: 3),
          getSubColumnHeaderTitle(flex: 4, index: 4),
          getSubColumnHeaderTitle(flex: 3, index: 5),
          getSubColumnHeaderTitle(flex: 3, index: 6),
          getSubColumnHeaderTitle(flex: 5, index: 7),
        ]);
  }

  Widget getSubColumnHeaderTitle({required int flex, required int index}) {
    return Expanded(
      flex: flex,
      child: Text(
        ticketedBitsController.innerColumnList[index],
        style: tSw600dp14fontF.copyWith(
          fontSize: SizeConstants.dp11,
          color: AppColors.colorSubText,
        ),
      ),
    );
  }

  Widget getSubColumnItemUI({required int flex, required String textValue}) {
    return Expanded(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.only(right: SizeConstants.dp5),
        child: Text(
          textValue,
          style: tSw400dp14fontF.copyWith(color: AppColors.colorMainText),
        ),
      ),
    );
  }

  void isBitsSelected(Consignment bit) {
    if (bit.status == AppStrings.completed) {
      ticketedBitsController.isSelectedBitStatusValid.value = true;
      ticketedBitsController.currentConsignmentForBilling =
          bit.consignmentId.toString();
    } else {
      ticketedBitsController.isSelectedBitStatusValid.value = false;
    }
    for (List element in ticketedBitsController.selectedValueList) {
      for (bool innerElement in element) {
        if (innerElement == true) {
          isSelectedBits = true;
          ticketedBitsController.isBitsSelected.value = true;

          break;
        } else {
          isSelectedBits = false;
          ticketedBitsController.isBitsSelected.value = false;
        }
      }
      if (isSelectedBits == true) {
        break;
      }
    }
  }

  Future<String> createFile(String encodedStr) async {
    Uint8List bytes = base64.decode(encodedStr);
    String dir = (await getApplicationDocumentsDirectory()).path;
    File file = File(
        "$dir/${DateTime.now().millisecondsSinceEpoch}${AppStrings.pdfExtension}");
    await file.writeAsBytes(bytes);
    return file.path;
  }

  void createFileViewerOverlay(Ticket ticket) async {
    String id =
        ticket.ticketingId ?? DateTime.now().toString().replaceAll(" ", "");
    var bytes = base64Decode(ticket.finalPdf.toString().replaceAll('\n', ''));
    final output = await getTemporaryDirectory();
    final file = File("${output.path}/$id${AppStrings.pdfExtension}");
    await file.writeAsBytes(bytes.buffer.asUint8List());
    Navigator.of(context).push(FileViewerOverlay(file, id, false));
  }
}
