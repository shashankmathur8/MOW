import 'package:flutter/cupertino.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_values.dart';

class AnimatedToggle extends StatefulWidget {
  final ValueChanged onToggleCallback;
  final bool initialPosition;
  final List<String> values = [AppImages.icCross, AppImages.icTick];

  AnimatedToggle(
      {super.key,
      required this.onToggleCallback,
      required this.initialPosition});

  @override
  _AnimatedToggleState createState() => _AnimatedToggleState();
}

class _AnimatedToggleState extends State<AnimatedToggle> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: SizeConstants.dp44,
      height: SizeConstants.dp25,
      margin: EdgeInsets.all(AppValues.margin_5),
      child: Stack(
        children: <Widget>[
          GestureDetector(
            /* onTap: () {
              initialPosition = !initialPosition;
              var index = 0;
              if (!initialPosition) {
                index = 1;
              }
              widget.onToggleCallback(index);
              setState(() {});
            },*/
            child: Container(
              width: SizeConstants.dp44,
              height: SizeConstants.dp25,
              decoration: ShapeDecoration(
                color: widget.initialPosition
                    ? AppColors.color5A7793.withOpacity(0.3)
                    : AppColors.colorGreen.withOpacity(0.3),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(SizeConstants.dp20),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: List.generate(
                  widget.values.length,
                  (index) => Padding(
                    padding: EdgeInsets.symmetric(vertical: 2),
                  ),
                ),
              ),
            ),
          ),
          AnimatedAlign(
            duration: const Duration(milliseconds: 250),
            curve: Curves.decelerate,
            alignment: widget.initialPosition
                ? Alignment.centerLeft
                : Alignment.centerRight,
            child: Container(
              margin: EdgeInsets.all(AppValues.margin_3),
              width: SizeConstants.dp20,
              height: SizeConstants.dp20,
              decoration: ShapeDecoration(
                color: widget.initialPosition
                    ? AppColors.color5A7793
                    : AppColors.colorGreen,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(SizeConstants.dp10),
                ),
              ),
              child: Image.asset(
                widget.initialPosition ? widget.values[0] : widget.values[1],
              ),
              alignment: Alignment.center,
            ),
          ),
        ],
      ),
    );
  }
}
