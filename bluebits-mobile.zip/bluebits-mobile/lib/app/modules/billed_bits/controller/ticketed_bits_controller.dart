import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:realm/realm.dart';
import 'package:slb_gt_mobile/app/core/base/base_controller.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';
import 'package:slb_gt_mobile/app/core/values/app_utils.dart';
import 'package:slb_gt_mobile/app/modules/login/controller/login_controller.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/controller/ticketing_bits_controller.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/model/ticketing_model.dart';
import '../../../common_binding/realm_initial.dart';
import '../../../core/utils/logger_common.dart';
import '../../inventory/models/bitSchema.dart';
import '../../ticketing_bill_bits/model/schema/ticketing_schema.dart';
import '../../ticketing_bill_bits/screens/ticketing_bits_screen.dart';
import '../widgets/my_tickets.dart';
import '../widgets/ticket_later.dart';

class TicketedBitsController extends BaseController {
  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());

  var index = 0.obs;
  LoginController loginController = Get.find();

  var visibilityDropDown = [].obs;
  var visibilityTicketLaterDropDown = [].obs;
  final _billedBitsList = <Ticket>[].obs;
  final _ticketLaterList = <Ticket>[].obs;
  var defaultTab = "".obs;
  var ListIndex = 0.obs;
  var listLength = 0;

  var sortingState;

  var pageIndex = 0.obs;

  FocusNode focusNode = FocusNode();
  TextEditingController searchController = TextEditingController();

  var editLineItemIndex = -1;

  final _columnList = [
    TicketedBitsColumn.billingID,
    TicketedBitsColumn.customer,
    TicketedBitsColumn.rigNameAndNo,
    TicketedBitsColumn.wellNameAndNo,
    TicketedBitsColumn.dateTicketed,
    TicketedBitsColumn.ticketStatus,
    TicketedBitsColumn.emptyTitle,
    TicketedBitsColumn.emptyTitle,
    TicketedBitsColumn.emptyTitle
  ].obs;

  final innerColumnList = [
    TicketedBitsColumn.emptyTitle,
    TicketedBitsColumn.srNbr,
    TicketedBitsColumn.size,
    TicketedBitsColumn.type,
    TicketedBitsColumn.bom,
    TicketedBitsColumn.amountForBits,
    TicketedBitsColumn.status,
    TicketedBitsColumn.emptyTitle,
  ];

  final _ticketLaterColumnList = [
    TicketedBitsColumn.billingID,
    TicketedBitsColumn.customer,
    TicketedBitsColumn.rigNameAndNo,
    TicketedBitsColumn.wellNameAndNo,
    TicketedBitsColumn.datePushed,
    TicketedBitsColumn.ticketingCompleted,
    TicketedBitsColumn.emptyTitle,
  ].obs;

  var isConsignSearchEnabled = false.obs;
  var isBitsSelected = false.obs;
  var isTicketLaterBitsSelected = false.obs;
  var isSelectedBitStatusValid = false.obs;
  var currentConsignmentForBilling = "";
  var selectedValueList = [];
  var selectedTicketLaterList = [];
  var refreshUi = "".obs;

  int getBilledBitsLength() {
    return _billedBitsList.length;
  }

  int getTicketLaterLength() {
    return _ticketLaterList.length;
  }

  String getBilledBitsID(index) {
    return _billedBitsList[index].ticketingId.toString();
  }

  String getTicketLaterBitsID(index) {
    return _ticketLaterList[index].ticketingId.toString();
  }

  Ticket getBilledBit(index) {
    return _billedBitsList[index];
  }

  Ticket getTicketLater(index) {
    return _ticketLaterList[index];
  }

  List<String> get ticketLaterColumnList => _ticketLaterColumnList.value;

  set ticketLaterColumnList(List<String> value) {
    _ticketLaterColumnList.value = value;
  }

  List<String> get columnList => _columnList.value;

  set columnList(List<String> value) {
    _columnList.value = value;
  }

  List<Ticket> get allBilledBitList => _billedBitsList.value;

  List<Ticket> get allTicketedLaterList => _ticketLaterList.value;

  set allBilledBitList(List<Ticket> value) {
    _billedBitsList.value = value;
  }

  set allTicketedLaterList(List<Ticket> value) {
    _ticketLaterList.value = value;
  }

  @override
  void onInit() {
    super.onInit();
    ApplicationLogger()
        .printInfo('BilledBitsController Created', 'DashboardBinding');

    fetchData();
    fetchDataTicketLater();

    makeAllDropDownClose();
    makeTicketLaterAllDropDownClose();
  }

  onTapTab(var tabIndex) {
    searchController.text = '';
    pageIndex.value = tabIndex;
  }

  /*--------------Quote Screen----------------*/
  refreshUI() {
    refreshUi.value = AppStrings.updatedValue;
    refreshUi.refresh();
  }

  clearAllSelectedBits() {
    selectedValueList.clear();
    for (int i = 0; i < getBilledBitsLength(); i++) {
      selectedValueList
          .add(List.filled(getBilledBit(i).bits.length.toInt(), false));
    }
    isBitsSelected.value = false;
  }

  clearAllTicketLaterBits() {
    selectedTicketLaterList.clear();
    for (int i = 0; i < getTicketLaterLength(); i++) {
      selectedTicketLaterList
          .add(List.filled(getTicketLater(i).bits.length.toInt(), false));
    }
    isTicketLaterBitsSelected.value = false;
  }

  void makeAllDropDownCloseExcept(int index) {
    visibilityDropDown.value = List.filled(getBilledBitsLength(), false);
    visibilityDropDown[index] = true;
    clearAllSelectedBitsExcept(index);
  }

  void makeTicketLaterAllDropDownCloseExcept(int index) {
    visibilityTicketLaterDropDown.value =
        List.filled(getTicketLaterLength(), false);
    visibilityTicketLaterDropDown[index] = true;
    clearAllTicketLaterSelectedBitsExcept(index);
  }

  void makeAllDropDownClose() {
    visibilityDropDown.value = List.filled(getBilledBitsLength(), false);
    clearAllSelectedBits();
    _billedBitsList.refresh();
    update();
  }

  void makeTicketLaterAllDropDownClose() {
    visibilityTicketLaterDropDown.value =
        List.filled(getTicketLaterLength(), false);
    clearAllTicketLaterBits();
    _ticketLaterList.refresh();
    update();
  }

  clearAllTicketLaterSelectedBitsExcept(int index) {
    var temp = selectedTicketLaterList[index];
    selectedTicketLaterList.clear();
    for (int i = 0; i < getTicketLaterLength(); i++) {
      selectedTicketLaterList
          .add(List.filled(getTicketLater(index).bits.length.toInt(), false));
    }
    selectedTicketLaterList[index] = temp;
    isTicketLaterBitsSelected.value = false;
  }

  clearAllSelectedBitsExcept(int index) {
    var temp = selectedValueList[index];
    selectedValueList.clear();
    for (int i = 0; i < getBilledBitsLength(); i++) {
      selectedValueList
          .add(List.filled(getBilledBit(i).bits.length.toInt(), false));
    }
    selectedValueList[index] = temp;
    isBitsSelected.value = false;
  }

  void fetchData() async {
    allBilledBitList = realm.getTicketBits(loginController.userEmail).toList();
    fillListMyTicket();
    _billedBitsList.refresh();
    update();
  }

  fillListMyTicket() {
    sortingState = List.filled(columnList.length, false);
    visibilityDropDown.value = List.filled(getBilledBitsLength(), false);
    selectedValueList.clear();
    for (int i = 0; i < getBilledBitsLength(); i++) {
      selectedValueList
          .add(List.filled(getBilledBit(i).bits.length.toInt(), false));
    }
  }

  void fetchDataTicketLater() async {
    allTicketedLaterList =
        realm.getTicketLaterBits(loginController.userEmail).toList();
    fillListTicketLater();
    makeTicketLaterAllDropDownClose();
  }

  fillListTicketLater() {
    sortingState = List.filled(ticketLaterColumnList.length, false);
    visibilityTicketLaterDropDown.value =
        List.filled(getTicketLaterLength(), false);
    selectedTicketLaterList.clear();
    for (int i = 0; i < getTicketLaterLength(); i++) {
      selectedTicketLaterList
          .add(List.filled(getTicketLater(i).bits.length.toInt(), false));
    }
  }

  //Need to connect model key value connection
  void sortConsignList(bool aorD, String column) {
    if (column == TicketedBitsColumn.billingID) {
      if (aorD == true) {
        allBilledBitList.sort((a, b) =>
            (a.ticketingId.toString()).compareTo(b.ticketingId.toString()));
      } else {
        allBilledBitList.sort((a, b) =>
            (b.ticketingId.toString()).compareTo(a.ticketingId.toString()));
      }
    } else if (column == TicketedBitsColumn.customer) {
      if (aorD == true) {
        allBilledBitList.sort((a, b) =>
            (a.customerName.toString()).compareTo(b.customerName.toString()));
      } else {
        allBilledBitList.sort((a, b) =>
            (b.customerName.toString()).compareTo(a.customerName.toString()));
      }
    } else if (column == TicketedBitsColumn.rigNameAndNo) {
      if (aorD == true) {
        allBilledBitList.sort(
            (a, b) => (a.rigName.toString()).compareTo(b.rigName.toString()));
      } else {
        allBilledBitList.sort(
            (a, b) => (b.rigName.toString()).compareTo(a.rigName.toString()));
      }
    } else if (column == TicketedBitsColumn.wellNameAndNo) {
      if (aorD == true) {
        allBilledBitList.sort(
            (a, b) => (a.wellId.toString()).compareTo(b.wellId.toString()));
      } else {
        allBilledBitList.sort(
            (a, b) => (b.wellId.toString()).compareTo(a.wellId.toString()));
      }
    } else if (column == TicketedBitsColumn.dateTicketed) {
      if (aorD == true) {
        allBilledBitList.sort((a, b) =>
            (a.createdAt.toString().substring(0, 10).toString())
                .compareTo(b.createdAt.toString().substring(0, 10).toString()));
      } else {
        allBilledBitList.sort((a, b) =>
            (b.createdAt.toString().substring(0, 10).toString())
                .compareTo(a.createdAt.toString().substring(0, 10).toString()));
      }
    } else if (column == TicketedBitsColumn.ticketStatus) {
      if (aorD == true) {
        allBilledBitList.sort(
            (a, b) => (a.status.toString()).compareTo(b.status.toString()));
      } else {
        allBilledBitList.sort(
            (a, b) => (b.status.toString()).compareTo(a.status.toString()));
      }
    }
    clearAllSelectedBits();
    _billedBitsList.refresh();
  }

  void sortTicketLaterList(bool aorD, String column) {
    if (column == TicketedBitsColumn.billingID) {
      if (aorD == true) {
        allTicketedLaterList.sort((a, b) =>
            (a.ticketingId.toString()).compareTo(b.ticketingId.toString()));
      } else {
        allTicketedLaterList.sort((a, b) =>
            (b.ticketingId.toString()).compareTo(a.ticketingId.toString()));
      }
    } else if (column == TicketedBitsColumn.customer) {
      if (aorD == true) {
        allTicketedLaterList.sort((a, b) =>
            (a.customerName.toString()).compareTo(b.customerName.toString()));
      } else {
        allTicketedLaterList.sort((a, b) =>
            (b.customerName.toString()).compareTo(a.customerName.toString()));
      }
    } else if (column == TicketedBitsColumn.rigNameAndNo) {
      if (aorD == true) {
        allTicketedLaterList.sort(
            (a, b) => (a.rigName.toString()).compareTo(b.rigName.toString()));
      } else {
        allTicketedLaterList.sort(
            (a, b) => (b.rigName.toString()).compareTo(a.rigName.toString()));
      }
    } else if (column == TicketedBitsColumn.wellNameAndNo) {
      if (aorD == true) {
        allTicketedLaterList.sort(
            (a, b) => (a.wellId.toString()).compareTo(b.wellId.toString()));
      } else {
        allTicketedLaterList.sort(
            (a, b) => (b.wellId.toString()).compareTo(a.wellId.toString()));
      }
    } else if (column == TicketedBitsColumn.dateTicketed) {
      if (aorD == true) {
        allTicketedLaterList.sort((a, b) =>
            (a.createdAt.toString().substring(0, 10).toString())
                .compareTo(b.createdAt.toString().substring(0, 10).toString()));
      } else {
        allTicketedLaterList.sort((a, b) =>
            (b.createdAt.toString().substring(0, 10).toString())
                .compareTo(a.createdAt.toString().substring(0, 10).toString()));
      }
    } else if (column == TicketedBitsColumn.ticketStatus) {
      if (aorD == true) {
        allTicketedLaterList.sort(
            (a, b) => (a.status.toString()).compareTo(b.status.toString()));
      } else {
        allTicketedLaterList.sort(
            (a, b) => (b.status.toString()).compareTo(a.status.toString()));
      }
    }
    clearAllTicketLaterBits();
    _ticketLaterList.refresh();
  }

  filterBitListData(String value) {
    List<Ticket> filteredList;
    filteredList =
        realm.getSearchedTicketBits(value, loginController.userEmail);

    allBilledBitList = filteredList;
    _billedBitsList.refresh();
    makeAllDropDownClose();
    update();
  }

  filterTicketLaterListData(String value) {
    List<Ticket> filteredTicketLaterList;
    filteredTicketLaterList =
        realm.getSearchedTicketLaterBits(value, loginController.userEmail);

    allTicketedLaterList = filteredTicketLaterList;
    _ticketLaterList.refresh();
    makeTicketLaterAllDropDownClose();
    update();
  }

  getCustomer(String customerId) {
    return realm.getCustomer(customerId).first;
  }

  getRig(String rigId) {
    return realm.getRig(rigId);
  }

  getCEC(String cec) {
    return realm.getTicketCEC(cec);
  }

  getDE(String de) {
    return realm.getDE(de);
  }

  getBits(RealmList<TicketBits> bits) {
    List<TicketingLineItems> temp2 = [];
    List<TicketingBit> temp3 = [];
    bits.forEach((element) {
      var details = new Map();
      element.priceBookDetails.forEach((element2) {
        var lineItem = realm.getTicketingLineItem(
            element2.priceBookId.toString(),
            element2.pricingId.toString(),
            loginController.userDetailsList.first.country ??
                AppStrings.usCountryCode);
        lineItem.bestPrice = element2.bestPrice;
        lineItem.comments = element2.comments;
        lineItem.discountAmount = element2.discountAmount;
        lineItem.discountPercentage = element2.discountPercentage!.toDouble();
        lineItem.unitDrilled = double.parse(element2.unitDrilled.toString());
        lineItem.pricePerUnit = double.parse(element2.pricePerUnit.toString());

        temp2.add(lineItem);
      });
      details['srNO'] = element.serialNumber.toString();
      details['lineItems'] = temp2;
      temp3.add(realm.getTicketBitFromMap(details));
      temp2 = [];
    });
    return temp3;
  }

  void prepareForDraft(Ticket ticket) {
    var cust;
    var billToCustomer;
    var shipToCustomer;
    List<TicketingBit> bits;
    if (ticket.customerId != "") {
      cust = getCustomer(ticket.customerId.toString());
    }
    if (ticket.bits.isNotEmpty) {}
    if (ticket.billToCustomerId != "") {
      billToCustomer = getAddress(ticket.billToCustomerId.toString());
    }
    if (ticket.shipToCustomerId != "") {
      shipToCustomer = getAddress(ticket.shipToCustomerId.toString());
    }
    var rig;
    if (ticket.rigId != "") {
      rig = getRig(ticket.rigId.toString());
    }
    var cec;
    if (ticket.cEC != "") {
      cec = getCEC(ticket.cEC.toString());
    }

    var designEngineer;
    if (ticket.designEngineer != "") {
      designEngineer = getDE(ticket.designEngineer.toString());
    }
    var well;
    print("${ticket.bits.first.priceBookDetails}=tag123");
    bits = getBits(ticket.bits);
    if (ticket.wellId != "" && ticket.wellNumber != "") {
      well = realm.getSingleWell(ticket.wellId, ticket.wellNumber);
    }
    var currentConsignment;
    if (ticket.consignmentGuid != "") {
      currentConsignment =
          realm.getConsignment(ticket.consignmentId.toString());
    }

    List<Bit> selectedBits = [];
    bits.forEach((element) {
      selectedBits.add(element.bit!);
    });

    TicketingModel ticketingModel = TicketingModel(
        bits: bits,
        lat: ticket.lat,
        long: ticket.long,
        consignmentID: ticket.consignmentId,
        startDate: ticket.startDate,
        //TODO
        endDate: ticket.endDate,
        //TODO
        consumptionType: ticket.consumptionType,
        billTo: billToCustomer,
        cec: cec,
        consignmentGUID: ticket.consignmentGuid,
        customer: cust,
        customerEmail: ticket.customerEmail,
        designEngineer: designEngineer,
        isTicketLater: ticket.ticketLater,
        quoteID: ticket.gTQuoteId,
        rig: rig,
        shipTo: shipToCustomer,
        ticketingID: ticket.ticketingId,
        well: well);

    final TicketingBitsController controller = Get.put(
        TicketingBitsController(),
        tag: (TicketingBitsController).toString());
// dont remove below lines without disscussion draftConsignmentID
    controller.draftTicketingID = ticket.id.toString();
    controller.ticketingModel = ticketingModel;
    controller.selectedValueCustomer = cust == null ? "" : cust.name;
    controller.selectedValueRig = rig == null ? "" : rig.name;
    Get.to(
        TicketingBits(
            isDraftEdit: true,
            currentConsignment: currentConsignment,
            selectedBits: selectedBits),
        transition: Transition.native,
        duration: const Duration(milliseconds: 300));
  }

  getAddress(String customerID) {
    return realm.getAddressCustomer(customerID);
  }
}
