import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/modules/billed_bits/widgets/ticketed_bits_recent_searches.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/text_styles.dart';
import '../controller/ticketed_bits_controller.dart';
import '../widgets/my_tickets.dart';
import '../widgets/ticket_later.dart';

class TicketedBitsScreen extends GetView<TicketedBitsController> {
  @override
  final TicketedBitsController controller = Get.put(TicketedBitsController(),
      tag: (TicketedBitsController).toString());
  ScrollController scrollController;
  var visible;
  TicketedBitsScreen({super.key, required this.scrollController, required this.visible});

  @override
  Widget build(BuildContext context) {
    final pages = [MyTickets(scrollController: scrollController,visible:visible), TicketLaterScreen(scrollController: scrollController,visible:visible)];
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        color: AppColors.colorF5F6F5,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              height: getHeight(SizeConstants.dp52),
              padding: EdgeInsets.only(
                  left: getWidth(SizeConstants.dp19),
                  right: getWidth(SizeConstants.dp17),
                  top: getHeight(SizeConstants.dp10),
                  bottom: getHeight(SizeConstants.dp10)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Obx(
                    () => Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            controller.onTapTab(0);
                          },
                          child: Container(
                            padding: const EdgeInsets.all(SizeConstants.dp2),
                            alignment: Alignment.center,
                            width: getHeight(SizeConstants.dp102),
                            height: getHeight(SizeConstants.dp34),
                            decoration: BoxDecoration(
                              color: controller.pageIndex.value == 0
                                  ? AppColors.bgColorTabSelected
                                  : AppColors.transparentColor,
                              borderRadius:
                                  BorderRadius.circular(SizeConstants.dp20),
                            ),
                            child: Text(
                              AppStrings.myBilledBits,
                              style: controller.pageIndex.value == 0
                                  ? tSw500dp15fontF.copyWith(
                                      fontSize: SizeConstants.dp15,
                                      color: AppColors.colorLightWhite,
                                    )
                                  : tSw400dp14fontF.copyWith(
                                      fontSize: SizeConstants.dp15,
                                      color: AppColors.colorMainText,
                                    ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: SizeConstants.dp10,
                        ),
                        GestureDetector(
                          onTap: () {
                            controller.onTapTab(1);
                          },
                          child: Container(
                            padding: const EdgeInsets.all(SizeConstants.dp2),
                            alignment: Alignment.center,
                            width: getHeight(SizeConstants.dp102),
                            height: getHeight(SizeConstants.dp34),
                            decoration: BoxDecoration(
                              color: controller.pageIndex.value != 0
                                  ? AppColors.bgColorTabSelected
                                  : AppColors.transparentColor,
                              borderRadius:
                                  BorderRadius.circular(SizeConstants.dp20),
                            ),
                            child: Text(
                              AppStrings.ticketLater,
                              style: controller.pageIndex.value != 0
                                  ? tSw500dp15fontF.copyWith(
                                      fontSize: SizeConstants.dp15,
                                      color: AppColors.colorLightWhite)
                                  : tSw400dp14fontF.copyWith(
                                      fontSize: SizeConstants.dp15,
                                      color: AppColors.colorMainText,
                                    ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  Obx(
                    () => !(controller.isConsignSearchEnabled.value)
                        ? IconButton(
                            onPressed: () {
                              controller.isConsignSearchEnabled.value =
                                  !controller.isConsignSearchEnabled.value;
                            },
                            splashColor: AppColors.transparentColor,
                            padding: const EdgeInsets.all(SizeConstants.dp0),
                            icon: Image.asset(AppImages.search))
                        : Padding(
                            padding: const EdgeInsets.only(
                                right: SizeConstants.dp10),
                            child: SearchTicketedBits()),
                  ),
                ],
              ),
            ),
            const Divider(
              color: AppColors.colorSeparatorLine,
              height: SizeConstants.dp0_5,
            ),
            Obx(
              () => Expanded(
                child: pages[controller.pageIndex.value],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
