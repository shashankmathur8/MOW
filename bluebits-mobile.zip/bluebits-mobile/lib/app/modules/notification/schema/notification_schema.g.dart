// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'notification_schema.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class Notification extends _Notification
    with RealmEntity, RealmObjectBase, RealmObject {
  Notification(
    ObjectId? id, {
    String? body,
    String? category,
    DateTime? createdAt,
    String? title,
    String? truckUserMappingId,
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'body', body);
    RealmObjectBase.set(this, 'category', category);
    RealmObjectBase.set(this, 'createdAt', createdAt);
    RealmObjectBase.set(this, 'title', title);
    RealmObjectBase.set(this, 'truckUserMappingId', truckUserMappingId);
  }

  Notification._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get body => RealmObjectBase.get<String>(this, 'body') as String?;
  @override
  set body(String? value) => RealmObjectBase.set(this, 'body', value);

  @override
  String? get category =>
      RealmObjectBase.get<String>(this, 'category') as String?;
  @override
  set category(String? value) => RealmObjectBase.set(this, 'category', value);

  @override
  DateTime? get createdAt =>
      RealmObjectBase.get<DateTime>(this, 'createdAt') as DateTime?;
  @override
  set createdAt(DateTime? value) =>
      RealmObjectBase.set(this, 'createdAt', value);

  @override
  String? get title => RealmObjectBase.get<String>(this, 'title') as String?;
  @override
  set title(String? value) => RealmObjectBase.set(this, 'title', value);

  @override
  String? get truckUserMappingId =>
      RealmObjectBase.get<String>(this, 'truckUserMappingId') as String?;
  @override
  set truckUserMappingId(String? value) =>
      RealmObjectBase.set(this, 'truckUserMappingId', value);

  @override
  Stream<RealmObjectChanges<Notification>> get changes =>
      RealmObjectBase.getChanges<Notification>(this);

  @override
  Notification freeze() => RealmObjectBase.freezeObject<Notification>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(Notification._);
    return const SchemaObject(
        ObjectType.realmObject, Notification, 'Notification', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('body', RealmPropertyType.string, optional: true),
      SchemaProperty('category', RealmPropertyType.string, optional: true),
      SchemaProperty('createdAt', RealmPropertyType.timestamp, optional: true),
      SchemaProperty('title', RealmPropertyType.string, optional: true),
      SchemaProperty('truckUserMappingId', RealmPropertyType.string,
          optional: true),
    ]);
  }
}
