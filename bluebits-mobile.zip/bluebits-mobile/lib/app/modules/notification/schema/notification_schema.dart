import 'package:realm/realm.dart';
part 'notification_schema.g.dart';

@RealmModel()
class _Notification {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;

  String? body;

  String? category;

  DateTime? createdAt;

  String? title;

  String? truckUserMappingId;
}