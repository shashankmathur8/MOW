import 'package:get/get.dart';
import 'package:realm/realm.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:slb_gt_mobile/app/core/base/base_controller.dart';
import 'package:slb_gt_mobile/app/modules/notification/schema/notification_schema.dart';

import '../../../common_binding/realm_initial.dart';
import '../../../core/values/preference_constants.dart';

class NotificationController extends BaseController {
  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());

  late RealmResults<Notification> notificationList;

  void fetchNotificationList() async {
    notificationList = realm.getNotifications();
    update();
  }
}
