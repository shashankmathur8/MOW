import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/modules/notification/controller/notification_controller.dart';

class NotificationBinding extends Bindings{
  @override
  void dependencies() {
   // Get.put<NotificationController>(NotificationController());
  }

}