import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';

import '../../core/common_widgets/no_overscroll_behavior.dart';
import '../../core/utils/time_utils.dart';
import '../../core/values/app_colors.dart';
import '../../core/values/app_images.dart';
import '../../core/values/app_values.dart';
import '../../core/values/common_widget.dart';
import '../../core/values/size_constants.dart';
import '../notification/controller/notification_controller.dart';

class NotificationView extends StatefulWidget {
  const NotificationView({super.key});

  @override
  State<NotificationView> createState() => _NotificationViewState();
}

class _NotificationViewState extends State<NotificationView> {
  final NotificationController notificationController =
      Get.find(tag: (NotificationController).toString());
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    notificationController.fetchNotificationList();
  }

  @override
  Widget build(BuildContext context) {
    return IntrinsicHeight(
      child: Container(
          width: SizeConstants.dp200,
          height: SizeConstants.dp200,
          margin: EdgeInsets.only(right: getWidth(SizeConstants.dp68)),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              ClipRRect(
                  borderRadius: const BorderRadius.all(
                      Radius.circular(AppValues.radius_5)),
                  child: Container(
                    width: getWidth(SizeConstants.dp349),
                    height: getHeight(SizeConstants.dp522),
                    color: AppColors.colorWhite,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          margin: EdgeInsets.only(
                              right: getWidth(SizeConstants.dp19),
                              left: getWidth(SizeConstants.dp23),
                              top: getHeight(SizeConstants.dp15),
                              bottom: getHeight(SizeConstants.dp5)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                AppStrings.notification,
                                style: tSw700fontF.copyWith(
                                    fontSize: SizeConstants.dp22,
                                    color: AppColors.colorMainText),
                              ),
                              GestureDetector(
                                child: Container(
                                    color: AppColors.transparentColor,
                                    width: getWidth(SizeConstants.dp34),
                                    height: getWidth(SizeConstants.dp34),
                                    padding: EdgeInsets.only(
                                        left: getWidth(SizeConstants.dp23),
                                        bottom: getWidth(SizeConstants.dp23)),
                                    child: Image.asset(
                                      AppImages.cancelBlackPng,
                                      color: AppColors.colorMainText,
                                      fit: BoxFit.fill,
                                      width: getWidth(SizeConstants.dp14),
                                      height: getWidth(SizeConstants.dp14),
                                    )),
                                onTap: () {
                                  Get.back();
                                },
                              )
                            ],
                          ),
                        ),
                        Expanded(
                            child: StreamBuilder(
                                stream: notificationController
                                    .notificationList.changes,
                                builder: (context, snapshot) {
                                  if (snapshot.hasData) {
                                    return Container(
                                      margin: EdgeInsets.only(
                                          right: getWidth(SizeConstants.dp5),
                                          left: getWidth(SizeConstants.dp21),
                                          bottom: getHeight(SizeConstants.dp5)),
                                      child: ScrollConfiguration(
                                        behavior: NoOverscrollBehavior(),
                                        child: notificationController
                                                .notificationList.isNotEmpty
                                            ? Scrollbar(
                                                thumbVisibility: true,
                                                thickness:
                                                    getWidth(SizeConstants.dp4),
                                                radius: Radius.circular(
                                                    getWidth(
                                                        SizeConstants.dp8)),
                                                controller: _scrollController,
                                                child: ListView.separated(
                                                  controller: _scrollController,
                                                  scrollDirection:
                                                      Axis.vertical,
                                                  shrinkWrap: true,
                                                  physics:
                                                      const ScrollPhysics(),
                                                  padding: EdgeInsets.only(
                                                      right: getWidth(
                                                          SizeConstants.dp16)),
                                                  itemCount:
                                                      notificationController
                                                          .notificationList
                                                          .length,
                                                  itemBuilder: (ctx, index) {
                                                    return Container(
                                                      margin: EdgeInsets.symmetric(
                                                          horizontal: getWidth(
                                                              SizeConstants
                                                                  .dp2)),
                                                      //height: getHeight(SizeConstants.dp90),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.only(
                                                                top: getHeight(
                                                                    SizeConstants
                                                                        .dp11),
                                                                right: getWidth(
                                                                    SizeConstants
                                                                        .dp14)),
                                                            child:
                                                                setNotificationIcon(
                                                                    index),
                                                          ),
                                                          Expanded(
                                                              child: Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                SizedBox(
                                                                  height: getHeight(
                                                                      SizeConstants
                                                                          .dp17),
                                                                ),
                                                                Text(
                                                                  notificationController
                                                                      .notificationList[
                                                                          index]
                                                                      .body
                                                                      .toString()
                                                                      .trim(),
                                                                  style: tSw400dp14fontF
                                                                      .copyWith(
                                                                          color:
                                                                              AppColors.colorMainText),
                                                                ),
                                                                SizedBox(
                                                                  height: getHeight(
                                                                      SizeConstants
                                                                          .dp9),
                                                                ),
                                                                Text(
                                                                  TimeUtils().pickDateTime(notificationController
                                                                      .notificationList[
                                                                          index]
                                                                      .createdAt
                                                                      .toString()),
                                                                  style: tSw400dp12fontF
                                                                      .copyWith(
                                                                          color:
                                                                              AppColors.colorSubText),
                                                                ),
                                                                SizedBox(
                                                                  height: getHeight(
                                                                      SizeConstants
                                                                          .dp17),
                                                                ),
                                                              ]))
                                                        ],
                                                      ),
                                                    );
                                                  },
                                                  separatorBuilder:
                                                      (context, index) {
                                                    return const Divider(
                                                      height: SizeConstants.dp1,
                                                      color: AppColors
                                                          .colorSeparatorLine,
                                                      thickness:
                                                          SizeConstants.dp0_5,
                                                    );
                                                  },
                                                ),
                                              )
                                            : noDataWidget(
                                                AppStrings.noDataFound),
                                      ),
                                    );
                                  } else {
                                    return Align(
                                      alignment: Alignment.center,
                                      child:
                                          noDataWidget(AppStrings.noDataFound),
                                    );
                                  }
                                }))
                      ],
                    ),
                  )),
            ],
          )),
    );
  }

  Widget setNotificationIcon(int index) {
    return Image.asset(
      notificationController.notificationList[index].title
              .toString()
              .contains(AppStrings.containsSuccess)
          ? AppImages.notiSuccess
          : notificationController.notificationList[index].title
                  .toString()
                  .contains(AppStrings.containsFailed)
              ? AppImages.notiFail
              : AppImages.notiInfo,
      width: getWidth(SizeConstants.dp30),
      height: getHeight(SizeConstants.dp30),
    );
  }
}
