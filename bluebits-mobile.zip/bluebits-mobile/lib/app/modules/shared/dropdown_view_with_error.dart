import 'package:flutter/material.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:slb_gt_mobile/app/core/values/app_utils.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/model/schema/pricebook_schema.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/model/sales_representative_schema.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/model/wells_schema.dart';
import '../../core/values/app_colors.dart';
import '../../core/values/app_strings.dart';
import '../../core/values/size_constants.dart';
import '../../core/values/text_styles.dart';
import 'dart:async';

import '../inventory/models/customerSchema.dart';

class DropDownViewWithError extends StatefulWidget {
  final String strImage;
  final String strTitle;
  final String strHint;
  final String selectedValue;
  final List<dynamic> arrList;
  final double widthInput;
  final double heightInput;
  final Decoration inputDecoration;
  final Decoration overlayDecoration;
  final TextStyle textStyle;
  final Color hintTextColor;
  final Color textColor;
  final bool showError;
  final Function onClickAction;
  final String errorText;

  DropDownViewWithError({
    super.key,
    this.strImage = '',
    this.strTitle = '',
    this.strHint = '',
    this.selectedValue = '',
    this.arrList = const [],
    this.widthInput = 0,
    this.heightInput = SizeConstants.dp50,
    required this.onClickAction,
    required this.inputDecoration,
    required this.overlayDecoration,
    this.textStyle = smartSearchFontStyle,
    this.hintTextColor = AppColors.colorSubText,
    this.textColor = AppColors.colorMainText,
    this.showError = false,
    this.errorText = '',
  });

  @override
  State<DropDownViewWithError> createState() => _DropDownViewWithErrorState();
}

class _DropDownViewWithErrorState extends State<DropDownViewWithError> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.widthInput,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          widget.strTitle.trim().isEmpty
              ? Container()
              : Text(
                  widget.strTitle,
                  style: smartSearchInputStyle,
                ),
          widget.strTitle.trim().isEmpty
              ? Container()
              : const SizedBox(
                  height: SizeConstants.dp7,
                ),
          Container(
              child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: widget.widthInput,
                    padding: const EdgeInsets.symmetric(
                        horizontal: SizeConstants.dp15,
                        vertical: SizeConstants.dp2),
                    decoration: widget.inputDecoration,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                            width: widget.widthInput - SizeConstants.dp49,
                            height: widget.heightInput,
                            child: Container(
                              alignment: Alignment.centerLeft,
                              child: DropDownField(
                                inputWidth: widget.widthInput,
                                arrList: widget.arrList,
                                hintText: widget.strHint,
                                selectedValue: widget.selectedValue,
                                onClickAction: widget.onClickAction,
                                overlayDecoration: widget.overlayDecoration,
                                textStyle: widget.textStyle,
                                hintTextColor: widget.hintTextColor,
                                textColor: widget.textColor,
                              ),
                            )),
                        Container(
                            height: SizeConstants.dp9,
                            width: SizeConstants.dp16,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage(widget.strImage),
                                fit: BoxFit.fill,
                              ),
                            ),
                            child: null)
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: SizeConstants.dp7,
              ),
              SizedBox(
                height: SizeConstants.dp17,
                child: Visibility(
                    visible: widget.showError ? true : false,
                    child: Column(
                      children: [
                        Text(
                          widget.errorText,
                          style: tSw400dp14fontF.copyWith(
                            color: AppColors.colorRedError,
                          ),
                        ),
                      ],
                    )),
              )
            ],
          )),
        ],
      ),
    );
  }
}

class DropDownField extends StatefulWidget {
  double inputWidth;
  final List<dynamic> arrList;
  final String hintText;
  String selectedValue;
  final Function onClickAction;
  final Decoration overlayDecoration;
  final TextStyle textStyle;
  final Color hintTextColor;
  final Color textColor;

  DropDownField({
    super.key,
    required this.inputWidth,
    required this.arrList,
    required this.hintText,
    required this.selectedValue,
    required this.onClickAction,
    required this.overlayDecoration,
    required this.textStyle,
    required this.hintTextColor,
    required this.textColor,
  });

  @override
  _DropDownFieldState createState() => _DropDownFieldState();
}

class _DropDownFieldState extends State<DropDownField> {
  OverlayEntry? _overlayEntry;
  bool isInserted = false;
  late StreamSubscription<bool> keyboardSubscription;
  final LayerLink _layerLink = LayerLink();

  @override
  void dispose() {
    keyboardSubscription.cancel();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: SizeConstants.dp500I), () {
      _overlayEntry = _createOverlayEntry();
    });

    var keyboardVisibilityController = KeyboardVisibilityController();

    // Subscribe
    keyboardSubscription =
        keyboardVisibilityController.onChange.listen((bool visible) {
      if (visible == true && _overlayEntry != null && isInserted) {
        isInserted = false;
        _overlayEntry?.remove();
      }
    });
  }

  OverlayEntry _createOverlayEntry() {
    RenderBox renderBox = context.findRenderObject() as RenderBox;
    var size = renderBox.size;
    var offset = renderBox.localToGlobal(Offset.zero);

    return OverlayEntry(
        builder: (context) => Positioned(
              //left: offset.dx - 16,
              //top: offset.dy + size.height + 5.0,
              width: widget.inputWidth,
              child: CompositedTransformFollower(
                link: _layerLink,
                showWhenUnlinked: false,
                offset: Offset(
                    SizeConstants.dp_16, size.height + SizeConstants.dp5),
                child: Material(
                  child: Container(
                    height: SizeConstants.dp250,
                    color: AppColors.colorWhite.withAlpha(SizeConstants.dp0I),
                    child: Container(
                      padding: overLayPadding,
                      decoration: widget.overlayDecoration,
                      child: SizedBox(
                        width: SizeConstants.dp310,
                        child: MediaQuery.removePadding(
                          context: context,
                          removeTop: true,
                          child: widget.arrList.isNotEmpty
                              ? ListView.builder(
                                  itemBuilder: (ctx, index) {
                                    return InkWell(
                                      onTap: () => {
                                        setState(() {
                                          widget.selectedValue =
                                              getValue(index);
                                          widget.onClickAction(
                                              widget.arrList[index]);
                                          isInserted = false;
                                          _overlayEntry!.remove();
                                        })
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                            vertical: SizeConstants.dp8),
                                        child: Text(
                                          getValue(index),
                                          style: widget.textStyle,
                                        ),
                                      ),
                                    );
                                  },
                                  itemCount: widget.arrList.length,
                                )
                              : Center(
                                  child: Text(
                                    AppStrings.noResultsFound,
                                    style: widget.textStyle,
                                  ),
                                ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ));
  }

  String getValue(int index) {
    if (widget.arrList[index] is PriceBook) {
      return (widget.arrList[index] as PriceBook).priceBookName as String;
    } else if (widget.arrList[index] is Customer) {
      return (widget.arrList[index] as Customer).addressLine1 as String;
    } else if (widget.arrList[index] is SalesRepresentative) {
      return (widget.arrList[index] as SalesRepresentative).fullName as String;
    } else if (widget.arrList[index] is Well) {
      return (widget.arrList[index] as Well).name as String;
    } else {
      return widget.arrList[index];
    }
  }

  onShowDropDownChange() {
    if (isInserted == false) {
      isInserted = true;
      FocusManager.instance.primaryFocus?.unfocus();
      Overlay.of(context).insert(_overlayEntry!);
    } else {
      isInserted = false;
      _overlayEntry!.remove();
    }
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
        link: _layerLink,
        child: InkWell(
          onTap: () {
            onShowDropDownChange();
          },
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: SizeConstants.dp14),
            child: Text(
              widget.selectedValue == ''
                  ? widget.hintText
                  : widget.selectedValue.useCorrectEllipsis().toString(),
              style: widget.textStyle.copyWith(
                color: widget.selectedValue == ''
                    ? widget.hintTextColor
                    : widget.textColor,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.left,
            ),
          ),
        ));
  }
}
