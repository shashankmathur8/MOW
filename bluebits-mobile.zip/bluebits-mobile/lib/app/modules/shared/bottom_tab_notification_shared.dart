import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';
import 'package:slb_gt_mobile/app/modules/inventory/controller/inventory_controller.dart';

class BottomTabNotificationShared extends StatelessWidget {
  var controller;
  ScrollController scrollController;

  BottomTabNotificationShared(this.controller, this.scrollController,
      {super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      height: getHeight(SizeConstants.dp200),
      width: getScreenWidth(),
      alignment: Alignment.bottomCenter,
      child: GestureDetector(
        onTap: () {
          scrollController.animateTo(
              //go to top of scroll
              0.0, //scroll offset to go
              duration: const Duration(milliseconds: 1), //duration of scroll
              curve: Curves.bounceIn //scroll type
              );
        },
        child: Container(
          alignment: Alignment.center,
          constraints: const BoxConstraints(
            maxWidth: SizeConstants.dp190,
            minWidth: SizeConstants.dp160,
          ),
          margin: const EdgeInsets.only(bottom: SizeConstants.dp22),
          height: getHeight(SizeConstants.dp30),
          decoration: BoxDecoration(
              color: Color.fromRGBO(39, 44, 57, 1)
                  .withOpacity(0.70), //AppColors.bottomTabNotificationColor,
              borderRadius:
                  BorderRadius.all(Radius.circular(SizeConstants.dp20))),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const ImageIcon(
                AssetImage(AppImages.upArrow),
                color: AppColors.colorWhite,
              ),
              Obx(() => Text(
                  style: bottomTabNotificationStyle,
                  "${controller.defaultTab.value} ${controller.ListIndex.value}/${controller.listLength}"))
            ],
          ),
        ),
      ),
    );
  }
}
