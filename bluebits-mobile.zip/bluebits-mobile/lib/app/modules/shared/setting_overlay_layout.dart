import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/modules/inventory/controller/inventory_controller.dart';

import '../../core/values/app_colors.dart';
import '../../core/values/app_values.dart';
import 'setting_overlay_menu.dart';

import '../../modules/login/widget/profile_overlay.dart';

/// This is the stateful widget that the main application instantiates.
class MyStatefulWidget extends StatefulWidget {
  InventoryController inventoryController = Get.find();

  Function selectedValue;

  MyStatefulWidget({Key? key, required this.selectedValue}) : super(key: key);

  @override
  State<MyStatefulWidget> createState() => _SettingOverlayMenu(selectedValue);
}

/// This is the private State class that goes with MyStatefulWidget.
class _SettingOverlayMenu extends State<MyStatefulWidget> {
  Function selectedValues;

  _SettingOverlayMenu(this.selectedValues);

  @override
  Widget build(BuildContext context) {
    final ColorScheme colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: AppColors.colorWhite,
      body: Obx(
        () => ReorderableListView(
          padding: const EdgeInsets.only(bottom: SizeConstants.dp10),
          buildDefaultDragHandles: true, //Remove default drag handles
          proxyDecorator: proxyDecorator,
          children: <Widget>[
            for (int index = 0;
                index < widget.inventoryController.columnList.length;
                index++)
              cardDraggabelTile(index: index)
          ],
          onReorder: (int oldIndex, int newIndex) {
            setState(() {
              if (oldIndex < newIndex) {
                newIndex -= 1;
              }
              final item =
                  widget.inventoryController.columnList.removeAt(oldIndex);
              widget.inventoryController.columnList.insert(newIndex, item);
            });
            print(this.widget.inventoryController.columnList[0].title);
          },
        ),
      ),
    );
  }

  Widget proxyDecorator(Widget child, int index, Animation<double> animation) {
    return AnimatedBuilder(
      animation: animation,
      builder: (BuildContext context, Widget? child) {
        return Material(
          elevation: 0,
          color: Colors.transparent,
          child: child,
        );
      },
      child: child,
    );
  }

  bool? check1 = false; //true for checked checkbox, false for unchecked one
  Widget cardDraggabelTile({required int index}) {
    return Container(
      key: Key('$index'),
      margin: const EdgeInsets.only(
        right: SizeConstants.dp20,
        left: SizeConstants.dp20,
      ),
      child: Card(
          child: Container(
        decoration: BoxDecoration(
          color: AppColors.colorWhite,
          border: Border.all(
            width: 1,
            color: AppColors.colorSeparatorLine,
          ),
          borderRadius: BorderRadius.all(Radius.circular(SizeConstants.dp4)),
        ),
        height: AppValues.height_60,
        width: AppValues.width_365,
        child: Container(
          margin: const EdgeInsets.only(left: SizeConstants.dp5),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Checkbox(
                  //only check box
                  value: widget.inventoryController.columnList[index]
                      .isEnable, //unchecked
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppValues.radius_2),
                  ),
                  side: const BorderSide(
                      width: SizeConstants.dp1,
                      color: AppColors.colorCheckBoxUnselected,
                      style: BorderStyle.solid),
                  activeColor: AppColors.colorCheckBoxSelected,
                  checkColor: AppColors.colorWhite,
                  onChanged: (bool? value) {
                    //value returned when checkbox is clicked
                    setState(() {
                      widget.inventoryController.columnList[index].isEnable =
                          value!;
                      this.selectedValues(
                          widget.inventoryController.columnList);
                    });
                  }),
              Container(
                margin: const EdgeInsets.only(right: AppValues.margin_13),
                child: Text(
                    '${widget.inventoryController.columnList[index].title}',
                    style: const TextStyle(
                        color: AppColors.colorMainText,
                        fontWeight: FontWeight.w400,
                        fontSize: 14)),
              ),
              const Spacer(),
              ReorderableDragStartListener(
                index: index,
                child: Container(
                  width: getWidth(SizeConstants.dp65),
                  height: getHeight(SizeConstants.dp45),
                  color: AppColors.transparentColor,
                  alignment: Alignment.center,
                  child: Image.asset(AppImages.ic_drag),
                ),
              ),
            ],
          ),
        ),
      )),
    );
  }
}
