import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/controller/consign_controller.dart';

import '../../core/common_widgets/custom_button_material.dart';
import '../../core/common_widgets/toast_message.dart';
import '../../core/values/app_colors.dart';
import '../../core/values/app_images.dart';
import '../../core/values/app_strings.dart';
import '../../core/values/app_utils.dart';
import '../../core/values/app_values.dart';
import '../../core/values/size_constants.dart';
import '../../core/values/text_styles.dart';

class SignatureConfirmationOverlay extends ModalRoute<void> {
  final ConsignController consignController;

  SignatureConfirmationOverlay(this.consignController);

  @override
  Duration get transitionDuration => const Duration(milliseconds: 0);

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => false;

  @override
  Color get barrierColor => AppColors.colorBlack.withOpacity(0.3);

  @override
  String get barrierLabel => '';

  @override
  bool get maintainState => true;

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    // This makes sure that text and other content follows the material style
    return Material(
      type: MaterialType.transparency,
      // make sure that the overlay content is not cut off
      child: SafeArea(
        child: _buildOverlayContent(context),
      ),
    );
  }

  Widget _buildOverlayContent(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppValues.padding_20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: SizeConstants.dp570,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(AppValues.radius_10),
                  boxShadow: [
                    BoxShadow(
                        color: AppColors.colorBlack.withOpacity(0.3),
                        blurRadius: AppValues.radius_7)
                  ]),
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.colorWhite,
                  borderRadius: BorderRadius.circular(AppValues.radius_10),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: AppValues.padding_30,
                      vertical: AppValues.padding_20),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: AppColors.colorCircleIcon,
                            radius: AppValues.radius_30,
                            child: Container(
                                height: SizeConstants.dp30,
                                width: SizeConstants.dp30,
                                decoration: const BoxDecoration(
                                  image: DecorationImage(
                                    image: AssetImage(AppImages.icSignaturePen),
                                    fit: BoxFit.fill,
                                  ),
                                ),
                                child: null),
                          ),
                          const SizedBox(
                            width: SizeConstants.dp16,
                          ),
                          Flexible(
                            child: Text(
                              AppStrings.signatureConfirmation,
                              style: tSw700fontF.copyWith(
                                color: AppColors.colorBlack,
                                fontSize: SizeConstants.dp26,
                              ),
                            ),
                          )
                        ],
                      ),
                      Column(
                        children: [
                          const SizedBox(
                            height: SizeConstants.dp10,
                          ),
                          Row(
                            children: [
                              const SizedBox(
                                width: SizeConstants.dp75,
                              ),
                              Flexible(
                                child: Text(
                                  AppStrings.signatureConfirmationMsg,
                                  style: tSw400dp14fontF.copyWith(
                                    color: AppColors.colorBlack,
                                    fontSize: SizeConstants.dp18,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: getHeight(SizeConstants.dp40),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Align(
                                alignment: Alignment.bottomRight,
                                child: CustomButtonMaterial(
                                  width: getWidth(SizeConstants.dp102),
                                  height: getHeight(SizeConstants.dp45),
                                  backgroundColor: AppColors.colorWhite,
                                  foregroundColor: AppColors.colorPrimary,
                                  borderRadius: AppValues.radius_4,
                                  text: AppStrings.cancel,
                                  style: tSw500dp16fontF,
                                  side: const BorderSide(
                                    width: SizeConstants.dp1,
                                    color: AppColors.colorPrimary,
                                  ),
                                  onPressCallback: () {
                                    Get.back();
                                  },
                                ),
                              ),
                              const SizedBox(
                                width: SizeConstants.dp10,
                              ),
                              Align(
                                alignment: Alignment.bottomRight,
                                child: CustomButtonMaterial(
                                  width: getWidth(SizeConstants.dp130),
                                  height: getHeight(SizeConstants.dp45),
                                  backgroundColor: AppColors.colorPrimary,
                                  foregroundColor: AppColors.colorWhite,
                                  borderRadius: AppValues.radius_4,
                                  text: AppStrings.ok,
                                  style: tSw500dp16fontF,
                                  onPressCallback: () {
                                    consignController.isConfirmationScreen = true;

                                    int index = consignController.index.value + 1;
                                    consignController.updateStepItemStatus(currentIndex: index);

                                    consignController.addConsignment(AppStrings.processing);
                                    Get.back();
                                  },
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    // You can add your own animations for the overlay content
    return FadeTransition(
      opacity: animation,
      child: ScaleTransition(
        scale: animation,
        child: child,
      ),
    );
  }
}
