import 'package:flutter/material.dart';
import '../../core/values/app_colors.dart';

import '../../core/values/app_values.dart';
import '../../core/values/common_widget.dart';
import '../../core/values/size_constants.dart';
import '../../core/values/text_styles.dart';

class MultiLineInputView extends StatefulWidget {
  final String strTitle;
  final String strHint;
  final double widthInput;
  final Function onClickAction;

  MultiLineInputView(
      {this.strTitle = "",
      this.strHint = "",
      this.widthInput = 0,
      required this.onClickAction});

  @override
  State<MultiLineInputView> createState() => _MultiLineInputViewState();
}

class _MultiLineInputViewState extends State<MultiLineInputView> {
  @override
  void initState() {
    //print(widget.widthInput);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.widthInput,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.strTitle,
            style: tSw400dp14fontF.copyWith(
              color: AppColors.colorMainText,
            ),
          ),
          const SizedBox(
            height: SizeConstants.dp7,
          ),
          Row(
            children: [
              SizedBox(
                width: widget.widthInput,
                child: SizedBox(
                    width: widget.widthInput - SizeConstants.dp49,
                    child: MultiLineField(widget.widthInput, widget.strHint,
                        widget.onClickAction)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class MultiLineField extends StatefulWidget {
  double inputWidth;
  final String hintText;
  final Function onClickAction;

  MultiLineField(this.inputWidth, this.hintText, this.onClickAction,
      {super.key});

  @override
  _MultiLineFieldState createState() => _MultiLineFieldState();
}

class _MultiLineFieldState extends State<MultiLineField> {
  @override
  void dispose() {
    //this._overlayEntry!.remove();
    super.dispose();
  }

  @override
  void initState() {}

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      maxLength: SizeConstants.maxLengthLimitText,
      keyboardType: TextInputType.multiline,
      maxLines: 4,
      minLines: 4,
      cursorColor: AppColors.colorBlack,
      onChanged: (text) {
        widget.onClickAction(text);
      },
      inputFormatters: [
        filteringTextInputFormatter,
      ],
      textAlign: TextAlign.start,
      style: smartSearchFontStyle,
      decoration: InputDecoration(
        fillColor: AppColors.colorBg,
        filled: true,
        hintText: widget.hintText,
        border: outlineBorderMultiLine,
        focusedBorder: outlineBorderMultiLine,
        enabledBorder: outlineBorderMultiLine,
        errorBorder: outlineBorderMultiLine,
        disabledBorder: outlineBorderMultiLine,
        contentPadding: const EdgeInsets.only(
            right: SizeConstants.dp18,
            left: SizeConstants.dp10,
            top: SizeConstants.dp12,
            bottom: SizeConstants.dp5),
      ),
      onTapOutside: (event) {
        FocusManager.instance.primaryFocus?.unfocus();
      },
    );
  }
}
