import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';

import '../../core/values/app_colors.dart';
import '../../core/values/app_images.dart';
import '../../core/values/app_values.dart';
import '../../core/values/size_constants.dart';
import '../inventory/controller/inventory_controller.dart';

class RecentSearches extends StatefulWidget {
  var localSearches;

  RecentSearches({super.key, required this.localSearches});
  @override
  _RecentSearchesState createState() => _RecentSearchesState();
}

class _RecentSearchesState extends State<RecentSearches> {
  InventoryController inventoryController = Get.find();


  _RecentSearchesState();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    inventoryController.focusNode.addListener(() {
      if (inventoryController.focusNode.hasFocus) {
        inventoryController.isSearchEnabled = true;
        var renderBox = context.findRenderObject() as RenderBox;
        final size = renderBox.size;
        final pos = renderBox.localToGlobal(Offset.zero);
        inventoryController.entry = OverlayEntry(
            builder: (context) => Positioned(
                left: pos.dx,
                top: pos.dy + size.height,
                width: size.width,
                child: buildOverlay()));
        Overlay.of(context).insert(this.inventoryController.entry);
      } else {
        this.inventoryController.entry.remove();
      }
    });
  }

  Widget buildOverlay() => Container(
      constraints: BoxConstraints(maxWidth: SizeConstants.dp400),
      child: Material(
        child: Container(
            decoration: const BoxDecoration(
                color: AppColors.colorWhite,
                borderRadius: BorderRadius.all(Radius.circular(4)),
                boxShadow: [
                  BoxShadow(
                      color: Colors.grey,
                      blurRadius: 1.0,
                      offset: Offset(0.0, 0.75))
                ]),
            child: SizedBox(
              child: Column(
                children: [
                  SizedBox(
                    height: SizeConstants.dp40,
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const SizedBox(
                            width: 20,
                          ),
                          const Text(
                            AppStrings.recentSearches,
                            style: TextStyle(
                                color: AppColors.colorSubText,
                                fontWeight: FontWeight.w400,
                                fontSize: 12),
                          ),
                          Spacer(),
                          GestureDetector(
                            onTap: () {
                              inventoryController.clearSearchData();
                              inventoryController.searchController.text = "";
                              inventoryController.getAllBitsListBasedOnTab();
                              inventoryController.focusNode.unfocus();
                            },
                            child: const Text(
                              AppStrings.clear,
                              style: TextStyle(
                                  fontSize: 12,
                                  color: AppColors.colorPrimary,
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                          const SizedBox(
                            width: SizeConstants.dp20,
                          )
                        ]),
                  ),
                  ListView.builder(
                    padding: EdgeInsets.zero,
                    shrinkWrap: true,
                    itemCount: inventoryController.localSearches.length,
                    itemBuilder: (context, index) => GestureDetector(
                      onTap: () {
                        inventoryController.searchController.text =
                            inventoryController.localSearches[
                                inventoryController.localSearches.length -
                                    1 -
                                    index];
                        inventoryController.focusNode.unfocus();
                        if (inventoryController.searchController.text.length >
                            0) {
                          setState(() {
                            //hideOverLay();
                            if (!inventoryController.localSearches.contains(
                                inventoryController.searchController.text)) {
                              inventoryController.localSearches.add(
                                  inventoryController.searchController.text);
                              inventoryController.addSearchData(
                                  inventoryController.localSearches);
                            }
                            inventoryController.filterBitListData(
                                inventoryController.searchController.text,
                                inventoryController.userSloc.value,
                                inventoryController.plantID.toString());
                          });
                        }
                      },
                      child: Container(
                        padding: EdgeInsets.only(bottom: 10),
                        child: Row(
                          children: [
                            const SizedBox(
                              width: 20,
                            ),
                            const ImageIcon(
                              AssetImage(AppImages.tickingClock),
                              size: 15,
                            ),
                            const SizedBox(
                              width: 15,
                            ),
                            Text(
                              inventoryController.localSearches[
                                  inventoryController.localSearches.length -
                                      1 -
                                      index],
                              style: TextStyle(
                                  color: AppColors.colorMainText,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w400),
                            ),
                            Spacer()
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            )),
      ));

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(maxWidth: 420, maxHeight: 40),
      child: TextField(
          focusNode: inventoryController.focusNode,
          onChanged: (value) {
            setState(() {});
            //ShowOverlay(context);
            value.length == 0
                ? () {
                    inventoryController.getAllBitsListBasedOnTab();
                    ;
                    //hideOverLay();
                  }
                : print("");
          },
          onSubmitted: (value) {
            if (inventoryController.searchController.text.length > 0) {
              setState(() {
                if (!inventoryController.localSearches
                    .contains(inventoryController.searchController.text)) {
                  inventoryController.localSearches
                      .add(inventoryController.searchController.text);
                  inventoryController
                      .addSearchData(inventoryController.localSearches);
                }
                inventoryController.filterBitListData(
                    inventoryController.searchController.text,
                    inventoryController.userSloc.value,
                    inventoryController.plantID.toString());
              });
            }
          },
          //      inventoryController.filterBitListData(searchController.text),
          controller: inventoryController.searchController,
          decoration: InputDecoration(
            contentPadding: EdgeInsets.all(10.0),
            border: OutlineInputBorder(
              borderRadius:
                  BorderRadius.all(Radius.circular(SizeConstants.dp20)),
            ),
            fillColor: AppColors.colorBg.withOpacity(0.8),
            labelStyle:
                TextStyle(color: AppColors.colorSubText.withOpacity(0.80)),
            labelText: AppStrings.searchHintText,
            suffixIcon: inventoryController.searchController.text.length != 0
                ? IconButton(
                    onPressed: () {
                      inventoryController.searchController.text = "";
                      setState(() {
                        inventoryController.getAllBitsListBasedOnTab();
                        inventoryController.isSearchEnabled = false;
                        //hideOverLay();
                        inventoryController.focusNode.unfocus();
                      });
                      //
                    },
                    icon: const Icon(
                      Icons.close,
                      color: AppColors.colorBlack,
                    ))
                : IconButton(
                    onPressed: () {
                      if (inventoryController.searchController.text.length >
                          0) {
                        if (!inventoryController.localSearches.contains(
                            inventoryController.searchController.text)) {
                          inventoryController.localSearches
                              .add(inventoryController.searchController.text);
                          inventoryController
                              .addSearchData(inventoryController.localSearches);
                        }
                        inventoryController.filterBitListData(
                            inventoryController.searchController.text,
                            inventoryController.userSloc.value,
                            inventoryController.plantID.toString());
                      }
                    },
                    icon: Image.asset(AppImages.search),
                  ),
            floatingLabelBehavior: FloatingLabelBehavior.never,
          )),
    );
  }
}
