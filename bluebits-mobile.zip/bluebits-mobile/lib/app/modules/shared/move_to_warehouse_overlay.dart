import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/values/app_utils.dart';

import '../../common_binding/realm_initial.dart';
import '../../core/connectivity_utils/connectivity_controller.dart';
import '../../core/utils/size_config.dart';
import '../../core/values/app_colors.dart';
import '../../core/values/app_images.dart';
import '../../core/values/app_strings.dart';
import '../../core/values/app_values.dart';
import '../../core/values/size_constants.dart';
import '../../core/values/text_styles.dart';
import '../inventory/controller/inventory_controller.dart';
import '../inventory/models/bitSchema.dart';
import '../login/controller/login_controller.dart';

class MoveToWarehouseOverlay extends ModalRoute<void> {
  bool isTruckPopup;
  late List<Bit>? bitsList;

  Function bitSubmittedCallBak;

  MoveToWarehouseOverlay(this.isTruckPopup,
      {this.bitsList, required this.bitSubmittedCallBak});

  final ConnectivityController connectivityController = Get.find();

  final LoginController loginController = Get.find();

  @override
  Duration get transitionDuration => const Duration(milliseconds: 0);

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => false;

  @override
  Color get barrierColor => AppColors.colorBlack.withOpacity(0.3);

  @override
  String get barrierLabel => '';

  @override
  bool get maintainState => true;
  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());
  final InventoryController inventoryController = Get.find();

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    // This makes sure that text and other content follows the material style
    return Material(
      type: MaterialType.transparency,
      // make sure that the overlay content is not cut off
      child: SafeArea(
        child: _buildOverlayContent(context),
      ),
    );
  }

  Widget _buildOverlayContent(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(SizeConstants.dp20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: getWidth(SizeConstants.dp570),
              height: getHeight(SizeConstants.dp295),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(SizeConstants.dp10),
                  boxShadow: [
                    BoxShadow(
                        color: AppColors.colorBlack.withOpacity(0.3),
                        blurRadius: SizeConstants.dp7)
                  ]),
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.colorWhite,
                  borderRadius: BorderRadius.circular(SizeConstants.dp10),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: SizeConstants.dp35,
                      vertical: SizeConstants.dp25),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: getHeight(SizeConstants.dp64),
                        child: Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: AppColors.colorCircleIcon,
                              radius: SizeConstants.dp32,
                              child: Container(
                                  height: getWidth(SizeConstants.dp30),
                                  width: getWidth(SizeConstants.dp30),
                                  decoration: BoxDecoration(
                                    image: DecorationImage(
                                      image: AssetImage(isTruckPopup
                                          ? AppImages.truck
                                          : AppImages.warehouse),
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  child: null),
                            ),
                            const SizedBox(
                              width: SizeConstants.dp16,
                            ),
                            Text(
                              isTruckPopup
                                  ? AppStrings.movebitToMyTruck
                                  : AppStrings.moveBitToWarehouse,
                              style: warehouseTextStyle,
                            )
                          ],
                        ),
                      ),
                      SizedBox(
                        height: getHeight(SizeConstants.dp4),
                      ),
                      Column(
                        children: [
                          Row(
                            children: [
                              const SizedBox(
                                width: SizeConstants.dp85,
                              ),
                              const Text(
                                AppStrings.alltheselected,
                                style: wareHouseStaticTextStyle,
                              ),
                              const SizedBox(
                                width: SizeConstants.dp3,
                              ),
                              const Text(
                                AppStrings.bits,
                                style: wareHouseBitsTextStyle,
                              ),
                              const SizedBox(
                                width: SizeConstants.dp3,
                              ),
                              Text(
                                isTruckPopup
                                    ? AppStrings.willbemoved
                                    : AppStrings.willbemovestoproceed,
                                style: wareHouseStaticTextStyle,
                              )
                            ],
                          ),
                          SizedBox(
                            height: getHeight(SizeConstants.dp2),
                          ),
                          Row(
                            children: [
                              const SizedBox(
                                width: SizeConstants.dp85,
                              ),
                              Text(
                                isTruckPopup
                                    ? loginController.userDetailsList.first.storageLocationId.toString() //dynamic
                                    : '${AppStrings.warehouse} ${loginController.userDetailsList.first.baseLocationId.toString()}',
                                style: wareHouseBitsTextStyle,
                              ),
                            ],
                          ),
                          SizedBox(
                            height: getHeight(SizeConstants.dp25),
                          ),
                          Row(
                            children: const [
                              SizedBox(
                                width: SizeConstants.dp85,
                              ),
                              Text(
                                AppStrings.doyouwanttoproceed,
                                style: wareHouseStaticTextStyle,
                              ),
                            ],
                          ),
                          SizedBox(
                            height: getHeight(SizeConstants.dp40),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              SizedBox(
                                width: getWidth(SizeConstants.dp110),
                                height: getHeight(SizeConstants.dp42),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    primary: AppColors.colorWhite,
                                    onPrimary: AppColors.colorPrimary,
                                    elevation: 0,
                                    side: const BorderSide(
                                      width: 1.0,
                                      color: AppColors.colorPrimary,
                                    ),
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(
                                            SizeConstants.dp3)),
                                  ),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: const Text(
                                    AppStrings.cancel,
                                    style: TextStyle(
                                        fontSize: SizeConstants.dp16,
                                        fontWeight: AppValues.fontWeight500,
                                        fontFamily: AppValues.fontFamily),
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: getWidth(SizeConstants.dp10),
                              ),
                              SizedBox(
                                width: getWidth(SizeConstants.dp110),
                                height: getHeight(SizeConstants.dp42),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    primary: AppColors.colorPrimary,
                                    onPrimary: AppColors.colorWhite,
                                    elevation: 0,
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(
                                            SizeConstants.dp3)),
                                  ),
                                  onPressed: isTruckPopup
                                      ? () async {
                                          inventoryController
                                              .updatePrefsIfMovementHappen();
                                          var result = await realm
                                              .insertBitMovementRequest(
                                                  bitsList!,
                                                  loginController.userEmail,
                                                  loginController.userName,
                                                  true,
                                                  loginController,
                                                  AppStrings.moveToWarehouse,
                                                  false,
                                                  null).then((value) {
                                            inventoryController.hitBitMovementApi(
                                                connectivityController
                                                    .isConnected.value);
                                          });

                                          inventoryController
                                              .updateSyncedBitsList(bitsList!);

                                          String serialNumbers =
                                              inventoryController
                                                  .joinSerialNumber(bitsList);

                                          if (result == true) {
                                            bitSubmittedCallBak(response(
                                                true,
                                                serialNumbers,
                                                isTruckPopup
                                                    ? loginController
                                                        .userDetailsList
                                                        .first
                                                        .storageLocationId
                                                        .toString() //dynamic
                                                    : loginController
                                                        .userDetailsList
                                                        .first
                                                        .baseLocationId
                                                        .toString()));
                                          } else {
                                            bitSubmittedCallBak(response(
                                                true,
                                                serialNumbers,
                                                isTruckPopup
                                                    ? loginController
                                                        .userDetailsList
                                                        .first
                                                        .storageLocationId
                                                        .toString() //dynamic
                                                    : loginController
                                                        .userDetailsList
                                                        .first
                                                        .baseLocationId
                                                        .toString()));
                                          }
                                          Get.back();
                                        }
                                      : () async {
                                          inventoryController
                                              .updatePrefsIfMovementHappen();
                                          var result = await realm
                                              .insertBitMovementRequest(
                                                  bitsList!,
                                                  loginController.userEmail,
                                                  loginController.userName,
                                                  false,
                                                  loginController,
                                                  AppStrings.moveToWarehouse,
                                                  false,
                                                  null).then((value) {
                                            inventoryController.hitBitMovementApi(
                                                connectivityController
                                                    .isConnected.value);
                                          });

                                          inventoryController
                                              .updateSyncedBitsList(bitsList!);

                                          String serialNumbers =
                                              inventoryController
                                                  .joinSerialNumber(bitsList);

                                          if (result == true) {
                                            bitSubmittedCallBak(response(
                                                true,
                                                serialNumbers,
                                                isTruckPopup
                                                    ? loginController
                                                        .userDetailsList
                                                        .first
                                                        .storageLocationId
                                                        .toString() //dynamic
                                                    : loginController
                                                        .userDetailsList
                                                        .first
                                                        .baseLocationId
                                                        .toString()));
                                          } else {
                                            bitSubmittedCallBak(response(
                                                true,
                                                serialNumbers,
                                                isTruckPopup
                                                    ? loginController
                                                        .userDetailsList
                                                        .first
                                                        .storageLocationId
                                                        .toString() //dynamic
                                                    : loginController
                                                        .userDetailsList
                                                        .first
                                                        .baseLocationId
                                                        .toString()));
                                          }
                                          Get.back();
                                        },
                                  child: const Text(
                                    AppStrings.confirm,
                                    style: TextStyle(
                                        fontSize: SizeConstants.dp16,
                                        fontWeight: AppValues.fontWeight500,
                                        fontFamily: AppValues.fontFamily),
                                  ),
                                ),
                              )
                            ],
                          )
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    // You can add your own animations for the overlay content
    return FadeTransition(
      opacity: animation,
      child: ScaleTransition(
        scale: animation,
        child: child,
      ),
    );
  }
}

class response {
  String bit;
  String warehouse;

  var success;

  response(this.success, this.bit, this.warehouse);
}
