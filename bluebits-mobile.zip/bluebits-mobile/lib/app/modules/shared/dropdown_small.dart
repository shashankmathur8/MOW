import 'package:flutter/material.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_utils.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/model/schema/pricebook_schema.dart';
import '../../core/values/app_colors.dart';
import '../../core/values/app_strings.dart';
import '../../core/values/size_constants.dart';
import '../../core/values/text_styles.dart';
import 'dart:async';

class DropDownViewSmall extends StatefulWidget {
  final String strImage;
  final String strHint;
  final String selectedValue;
  final List<dynamic> arrList;
  final double widthInput;
  final double heightInput;
  final Decoration inputDecoration;
  final Decoration overlayDecoration;
  final TextStyle textStyle;
  final Color hintTextColor;
  final Color textColor;
  final Function onClickAction;

  DropDownViewSmall({
    super.key,
    this.strImage = '',
    this.strHint = '',
    this.selectedValue = '',
    this.arrList = const [],
    this.widthInput = 0,
    this.heightInput = SizeConstants.dp50,
    required this.onClickAction,
    required this.inputDecoration,
    required this.overlayDecoration,
    this.textStyle = smartSearchFontStyle,
    this.hintTextColor = AppColors.colorSubText,
    this.textColor = AppColors.colorMainText,
  });

  @override
  State<DropDownViewSmall> createState() => _DropDownViewState();
}

class _DropDownViewState extends State<DropDownViewSmall> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.widthInput,
      padding: const EdgeInsets.symmetric(horizontal: SizeConstants.dp15, vertical: SizeConstants.dp2),
      decoration: widget.inputDecoration,
      child: SizedBox(
          width: widget.widthInput - getWidth(SizeConstants.dp35),
          height: widget.heightInput,
          child: Container(
            alignment: Alignment.centerLeft,
            child: DropDownField(
              inputWidth: widget.widthInput,
              strImage: widget.strImage,
              arrList: widget.arrList,
              hintText: widget.strHint,
              selectedValue: widget.selectedValue,
              onClickAction: widget.onClickAction,
              overlayDecoration: widget.overlayDecoration,
              textStyle: widget.textStyle,
              hintTextColor: widget.hintTextColor,
              textColor: widget.textColor,
            ),
          )),
    );
  }
}

class DropDownField extends StatefulWidget {
  double inputWidth;
  final String strImage;
  final List<dynamic> arrList;
  final String hintText;
  String selectedValue;
  final Function onClickAction;
  final Decoration overlayDecoration;
  final TextStyle textStyle;
  final Color hintTextColor;
  final Color textColor;

  DropDownField(
      {super.key,
      required this.inputWidth,
      required this.arrList,
      required this.hintText,
      required this.selectedValue,
      required this.onClickAction,
      required this.overlayDecoration,
      required this.textStyle,
      required this.hintTextColor,
      required this.textColor,
      required this.strImage});

  @override
  _DropDownFieldState createState() => _DropDownFieldState();
}

class _DropDownFieldState extends State<DropDownField> {
  OverlayEntry? _overlayEntry;
  bool isInserted = false;
  late StreamSubscription<bool> keyboardSubscription;
  final LayerLink _layerLink = LayerLink();

  @override
  void dispose() {
    //this._overlayEntry!.remove();
    keyboardSubscription.cancel();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: SizeConstants.dp500I), () {
      _overlayEntry = _createOverlayEntry();
    });

    var keyboardVisibilityController = KeyboardVisibilityController();

    // Subscribe
    keyboardSubscription = keyboardVisibilityController.onChange.listen((bool visible) {
      if (visible == true && _overlayEntry != null && isInserted) {
        isInserted = false;
        _overlayEntry?.remove();
      }
    });
  }

  OverlayEntry _createOverlayEntry() {
    RenderBox renderBox = context.findRenderObject() as RenderBox;
    var size = renderBox.size;
    var offset = renderBox.localToGlobal(Offset.zero);

    return OverlayEntry(
        builder: (context) => Positioned(
              //left: offset.dx - 16,
              //top: offset.dy + size.height + 5.0,
              width: widget.inputWidth,
              child: CompositedTransformFollower(
                link: _layerLink,
                showWhenUnlinked: false,
                offset: Offset(SizeConstants.dp_16, size.height + SizeConstants.dp15),
                child: Material(
                  child: Container(
                    height: SizeConstants.dp216,
                    color: AppColors.colorWhite.withAlpha(SizeConstants.dp0I),
                    child: Container(
                      padding: overLayPadding,
                      decoration: widget.overlayDecoration,
                      child: SizedBox(
                        width: SizeConstants.dp310,
                        child: MediaQuery.removePadding(
                          context: context,
                          removeTop: true,
                          child: widget.arrList.isNotEmpty
                              ? ListView.builder(
                                  itemBuilder: (ctx, index) {
                                    return InkWell(
                                      onTap: () => {
                                        setState(() {
                                          widget.selectedValue = getValue(index);
                                          widget.onClickAction(widget.arrList[index]);
                                          isInserted = false;
                                          _overlayEntry!.remove();
                                        })
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(vertical: SizeConstants.dp8),
                                        child: Text(
                                          getValue(index),
                                          style: widget.textStyle,
                                        ),
                                      ),
                                    );
                                  },
                                  itemCount: widget.arrList.length,
                                )
                              : Center(
                                  child: Text(
                                    AppStrings.noResultsFound,
                                    style: widget.textStyle,
                                  ),
                                ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ));
  }

  String getValue(int index) {
    if (widget.arrList[index] is PriceBook) {
      return (widget.arrList[index] as PriceBook).priceBookName as String;
    } else {
      return widget.arrList[index];
    }
  }

  onShowDropDownChange() {
    if (isInserted == false) {
      isInserted = true;
      FocusManager.instance.primaryFocus?.unfocus();
      Overlay.of(context).insert(_overlayEntry!);
    } else {
      isInserted = false;
      _overlayEntry!.remove();
    }
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
        link: _layerLink,
        child: InkWell(
          onTap: () {
            onShowDropDownChange();
          },
          child: SizedBox(
            width: double.infinity,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  widget.selectedValue == '' ? widget.hintText : widget.selectedValue.useCorrectEllipsis().toString(),
                  style: tSw500dp12fontF.copyWith(
                    color: widget.textColor,
                    fontSize: SizeConstants.dp14,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.left,
                ),
                Image.asset(
                  widget.strImage,
                  height: SizeConstants.dp6,
                  width: SizeConstants.dp12,
                  fit: BoxFit.fill,
                )
              ],
            ),
          ),
        ));
  }
}
