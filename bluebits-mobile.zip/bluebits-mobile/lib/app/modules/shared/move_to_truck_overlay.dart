import 'package:flutter/material.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';

import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';
import 'package:slb_gt_mobile/app/modules/shared/move_to_truck_view.dart';

class MoveToTruckOverlay extends ModalRoute<void> {
  late List<Bit> bitsList;
  Function bitSubmittedCallBak;
  MoveToTruckOverlay(
      {required this.bitsList, required this.bitSubmittedCallBak});

  @override
  Duration get transitionDuration => const Duration(milliseconds: 0);

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => false;

  @override
  Color get barrierColor => AppColors.colorBlack.withOpacity(0.3);

  @override
  String get barrierLabel => '';

  @override
  bool get maintainState => true;

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    // This makes sure that text and other content follows the material style
    return Material(
      type: MaterialType.transparency,
      // make sure that the overlay content is not cut off
      child: SafeArea(
        child: _buildOverlayContent(context),
      ),
    );
  }

  Widget _buildOverlayContent(BuildContext context) {
    return SelectTruckToMove(
      bitsList: bitsList,
      bitSubmittedCallBak: (value) {
        bitSubmittedCallBak(value);
      },
    );
  }

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    // You can add your own animations for the overlay content
    return FadeTransition(
      opacity: animation,
      child: ScaleTransition(
        scale: animation,
        child: child,
      ),
    );
  }
}

class response {
  String bit;
  String warehouse;

  var success;

  response(this.success, this.bit, this.warehouse);
}
