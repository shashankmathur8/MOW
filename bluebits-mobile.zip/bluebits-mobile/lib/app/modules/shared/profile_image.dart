import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';

import '../../core/connectivity_utils/connectivity_controller.dart';
import '../login/controller/login_controller.dart';

class ProfileImage extends StatelessWidget {
  bool isProfileImage;
  bool isOnline;
  final LoginController loginController = Get.find();
  final ConnectivityController connectivityController = Get.find();

  ProfileImage(this.isProfileImage, this.isOnline);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: getWidth(SizeConstants.dp33),
      height: getWidth(SizeConstants.dp33),
      margin: EdgeInsets.only(right: getWidth(SizeConstants.dp12)),
      child: Stack(
        children: [
          Align(
            alignment: Alignment.center,
            child: SizedBox(
              width: getWidth(SizeConstants.dp32),
              height: getWidth(SizeConstants.dp32),
              child: CircleAvatar(
                backgroundColor: AppColors.colorProfileRadius,
                radius: getWidth(SizeConstants.dp16),
                child: isProfileImage
                    ? CircleAvatar(
                        backgroundColor: AppColors.colorGreyTransparent,
                        radius: getWidth(SizeConstants.dp16),
                        backgroundImage: const AssetImage(AppImages.user_small),
                      )
                    : CircleAvatar(
                        backgroundColor: AppColors.colorFilterTag,
                        radius: getWidth(SizeConstants.dp16),
                        child: Container(
                          padding: EdgeInsets.all(getWidth(AppValues.margin_6)),
                          child: FittedBox(
                              child: Text(
                            loginController.getInitials(
                                loginController.userName), //On Inventory Screen
                            style: tSw400dp14fontF.copyWith(
                              color: AppColors.colorPrimary,
                            ),
                          )),
                        )),
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomRight,
            child: Obx(() => Container(
                  width: getWidth(SizeConstants.dp14),
                  height: getWidth(SizeConstants.dp14),
                  decoration: BoxDecoration(
                      border: Border.all(
                          width: getWidth(SizeConstants.dp1_5),
                          color: AppColors.colorWhite),
                      borderRadius:
                          BorderRadius.circular(getWidth(SizeConstants.dp10)),
                      color: connectivityController.isConnected.value
                          ? AppColors.colorGreen
                          : AppColors.colorOffline),
                  child: null,
                )),
          )
        ],
      ),
    );
  }
}
