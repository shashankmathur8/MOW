import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/common_widgets/common_widget.dart';
import '../../core/common_widgets/custom_button_material.dart';
import '../../core/utils/size_config.dart';
import '../../core/values/app_colors.dart';
import '../../core/values/app_values.dart';
import '../../core/values/size_constants.dart';
import '../../core/values/text_styles.dart';

class GenericOverlay extends ModalRoute<void> {
  final String title;
  final String? message;
  final Widget? messageWidget;
  final String? negativeButtonText;
  final String positiveButtonText;
  final String iconPath;
  final VoidCallback onPositivePressCallback;

  GenericOverlay({
    required this.iconPath,
    required this.title,
    this.message,
    this.messageWidget,
    this.negativeButtonText,
    required this.positiveButtonText,
    required this.onPositivePressCallback,
  }) : super();

  @override
  Duration get transitionDuration => const Duration(milliseconds: 0);

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => false;

  @override
  Color get barrierColor => AppColors.colorBlack.withOpacity(0.3);

  @override
  String get barrierLabel => '';

  @override
  bool get maintainState => true;

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    // This makes sure that text and other content follows the material style
    return Material(
      type: MaterialType.transparency,
      // make sure that the overlay content is not cut off
      child: SafeArea(
        child: _buildOverlayContent(context),
      ),
    );
  }

  Widget _buildOverlayContent(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppValues.padding_20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: SizeConstants.dp570,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(AppValues.radius_10),
                  boxShadow: [
                    BoxShadow(
                        color: AppColors.colorBlack.withOpacity(0.3),
                        blurRadius: AppValues.radius_7)
                  ]),
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.colorWhite,
                  borderRadius: BorderRadius.circular(AppValues.radius_10),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: AppValues.padding_30,
                      vertical: AppValues.padding_20),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          CustomWidgets().roundIconWidget(iconPath),
                         // Image(image: AssetImage(iconPath) ,),
                          const SizedBox(
                            width: SizeConstants.dp16,
                          ),
                          CustomWidgets().headerTitle(
                              title,
                              tSw700fontF.copyWith(
                                color: AppColors.colorBlack,
                                fontSize: SizeConstants.dp26,
                              ))
                        ],
                      ),
                      Column(
                        children: [
                          const SizedBox(
                            height: SizeConstants.dp10,
                          ),
                          Row(
                            children: [
                              const SizedBox(
                                width: SizeConstants.dp75,
                              ),
                              Flexible(
                                child: message != null
                                    ? Text(
                                        message!,
                                        style: tSw400dp14fontF.copyWith(
                                          color: AppColors.colorMainText,
                                          fontSize: SizeConstants.dp18,
                                        ),
                                      )
                                    : messageWidget != null
                                        ? messageWidget!
                                        : Container(),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: getHeight(SizeConstants.dp40),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              negativeButtonText != null ? Align(
                                alignment: Alignment.bottomRight,
                                child: CustomButtonMaterial(
                                  width: getWidth(SizeConstants.dp102),
                                  height: getHeight(SizeConstants.dp45),
                                  backgroundColor: AppColors.colorWhite,
                                  foregroundColor: AppColors.colorPrimary,
                                  borderRadius: AppValues.radius_4,
                                  text: negativeButtonText!,
                                  style: tSw500dp16fontF,
                                  side: const BorderSide(
                                    width: SizeConstants.dp1,
                                    color: AppColors.colorPrimary,
                                  ),
                                  onPressCallback: () {
                                    Get.back();
                                  },
                                ),
                              ) : Container(),
                              SizedBox(
                                width: getWidth(SizeConstants.dp10),
                              ),
                              Align(
                                alignment: Alignment.bottomRight,
                                child: CustomButtonMaterial(
                                  width: getWidth(SizeConstants.dp130),
                                  height: getHeight(SizeConstants.dp45),
                                  backgroundColor: AppColors.colorPrimary,
                                  foregroundColor: AppColors.colorWhite,
                                  borderRadius: AppValues.radius_4,
                                  text: positiveButtonText,
                                  style: tSw500dp16fontF,
                                  onPressCallback: () {
                                    onPositivePressCallback();
                                  },
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    // You can add your own animations for the overlay content
    return FadeTransition(
      opacity: animation,
      child: ScaleTransition(
        scale: animation,
        child: child,
      ),
    );
  }
}
