import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:realm/realm.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:slb_gt_mobile/app/core/connectivity_utils/connectivity_controller.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_utils.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/modules/inventory/controller/inventory_controller.dart';

import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';
import '../../common_binding/realm_initial.dart';
import '../../core/values/app_images.dart';
import '../../core/values/app_strings.dart';
import '../../core/values/app_values.dart';
import '../inventory/models/storagelocSchema.dart';
import '../login/controller/login_controller.dart';

class SelectTruckToMove extends StatefulWidget {
  late List<Bit>? bitsList;
  Function bitSubmittedCallBak;
  SelectTruckToMove({this.bitsList, required this.bitSubmittedCallBak});
  final LoginController loginController = Get.find();

  final InventoryController inventoryController = Get.find();
  final ConnectivityController connectivityController = Get.find();

  @override
  State<SelectTruckToMove> createState() => _SelectTruckToMoveState();
}

class _SelectTruckToMoveState extends State<SelectTruckToMove> {
  late List<StorageLocation> trucks;
  @override
  initState() {
    print("initState Called");
    trucks = widget.inventoryController.storageLocations;
  }

  bool showDropDown = false;
  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());
  late StorageLocation selectedTruck = StorageLocation(ObjectId());

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Center(
          child: Padding(
            padding: const EdgeInsets.all(SizeConstants.dp20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: getWidth(SizeConstants.dp570),
                  height: getHeight(SizeConstants.dp260),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                            color: AppColors.colorBlack.withOpacity(0.3),
                            blurRadius: SizeConstants.dp7)
                      ]),
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppColors.colorWhite,
                      borderRadius: BorderRadius.circular(SizeConstants.dp10),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: SizeConstants.dp35,
                          vertical: SizeConstants.dp22),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            height: getHeight(SizeConstants.dp64),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  backgroundColor: AppColors.colorCircleIcon,
                                  radius: SizeConstants.dp32,
                                  child: Container(
                                      height: getWidth(SizeConstants.dp30),
                                      width: getWidth(SizeConstants.dp30),
                                      decoration: const BoxDecoration(
                                        image: DecorationImage(
                                          image: AssetImage(AppImages.truck),
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                      child: null),
                                ),
                                const SizedBox(
                                  width: SizeConstants.dp19,
                                ),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text(
                                      'Move Bit(s) to Truck',
                                      style: TextStyle(
                                          color: AppColors.colorBlack,
                                          fontSize: SizeConstants.dp26,
                                          fontWeight: FontWeight.w700,
                                          fontFamily: AppValues.fontFamily),
                                    ),
                                    SizedBox(
                                      height: getHeight(SizeConstants.dp2),
                                    ),
                                    Text(
                                      widget.loginController.userDetailsList
                                          .first.storageLocationId
                                          .toString(),
                                      style: const TextStyle(
                                          color: AppColors.colorMainText,
                                          fontSize: SizeConstants.dp20,
                                          fontWeight: FontWeight.w400,
                                          fontFamily: AppValues.fontFamily),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                          SizedBox(
                            height: getHeight(SizeConstants.dp20),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const SizedBox(
                                    width: SizeConstants.dp85,
                                  ),
                                  Expanded(
                                    child: Container(
                                      padding: EdgeInsets.only(
                                          top: getHeight(SizeConstants.dp16),
                                          bottom: getHeight(SizeConstants.dp16),
                                          left: getWidth(SizeConstants.dp16),
                                          right: getWidth(SizeConstants.dp16)),
                                      decoration: BoxDecoration(
                                        color: AppColors.colorBg,
                                        border: Border.all(
                                            width: getWidth(SizeConstants.dp1),
                                            color:
                                                AppColors.colorSeparatorLine),
                                        borderRadius: const BorderRadius.all(
                                            Radius.circular(
                                                SizeConstants.dp10)),
                                      ),
                                      child: InkWell(
                                        onTap: () => setState(() {
                                          showDropDown = !showDropDown;
                                        }),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              selectedTruck.plantId == null
                                                  ? AppStrings.selecttruck
                                                  : selectedTruck
                                                      .storageLocationId
                                                      .toString(),
                                              style: TextStyle(
                                                  color: selectedTruck == ''
                                                      ? AppColors.colorSubText
                                                      : AppColors.colorMainText,
                                                  fontSize: SizeConstants.dp20,
                                                  fontWeight: FontWeight.w400,
                                                  fontFamily:
                                                      AppValues.fontFamily),
                                            ),
                                            InkWell(
                                              child: Container(
                                                  height: SizeConstants.dp9,
                                                  width: SizeConstants.dp16,
                                                  decoration:
                                                      const BoxDecoration(
                                                    image: DecorationImage(
                                                      image: AssetImage(
                                                          AppImages.down_arrow),
                                                      fit: BoxFit.fill,
                                                    ),
                                                  ),
                                                  child: null),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: getWidth(SizeConstants.dp70),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: getHeight(SizeConstants.dp30),
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  SizedBox(
                                    width: getWidth(SizeConstants.dp110),
                                    height: getHeight(SizeConstants.dp42),
                                    child: ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        primary: AppColors.colorWhite,
                                        onPrimary: AppColors.colorPrimary,
                                        elevation: 0,
                                        side: const BorderSide(
                                          width: 1.0,
                                          color: AppColors.colorPrimary,
                                        ),
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                                SizeConstants.dp3)),
                                      ),
                                      onPressed: () {
                                        Get.back();
                                      },
                                      child: const Text(
                                        AppStrings.cancel,
                                        style: TextStyle(
                                            fontSize: SizeConstants.dp16,
                                            fontWeight: AppValues.fontWeight500,
                                            fontFamily: AppValues.fontFamily),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: getWidth(SizeConstants.dp10),
                                  ),
                                  SizedBox(
                                    width: getWidth(SizeConstants.dp110),
                                    height: getHeight(SizeConstants.dp42),
                                    child: ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        foregroundColor: _isTruckSelected() ? AppColors.colorWhite : AppColors.colorWhite.withOpacity(0.4),
                                        backgroundColor: _isTruckSelected() ? AppColors.colorPrimary : AppColors.colorPrimary.withOpacity(0.3),
                                        elevation: 0,
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                                SizeConstants.dp3)),
                                      ),
                                      onPressed: () async {
                                        if (_isTruckSelected()) {
                                          widget.inventoryController
                                              .updatePrefsIfMovementHappen();
                                          var result = await realm
                                              .insertBitMovementRequest(
                                                  widget.bitsList!,
                                                  widget.loginController
                                                      .userEmail,
                                                  widget
                                                      .loginController.userName,
                                                  false,
                                                  widget.loginController,
                                                  AppStrings.moveToTruck,
                                                  true,
                                                  selectedTruck).then((value) {
                                            widget.inventoryController
                                                .hitBitMovementApi(widget
                                                .connectivityController
                                                .isConnected
                                                .value);
                                          });

                                          widget.inventoryController
                                              .updateSyncedBitsList(
                                                  widget.bitsList!);

                                          String serialNumbers = widget
                                              .inventoryController
                                              .joinSerialNumber(
                                                  widget.bitsList);
                                          if (result == true) {
                                            widget.bitSubmittedCallBak(
                                                serialNumbers);
                                          } else {
                                            widget.bitSubmittedCallBak(
                                                serialNumbers);
                                          }
                                          Get.back();
                                        }
                                      },
                                      child: const Text(
                                        AppStrings.confirm,
                                        style: TextStyle(
                                            fontSize: SizeConstants.dp16,
                                            fontWeight: AppValues.fontWeight500,
                                            fontFamily: AppValues.fontFamily),
                                      ),
                                    ),
                                  )
                                ],
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        Positioned.fromRect(
            rect: Rect.fromCenter(
                center: Offset(getScreenWidth() / 2,
                    getScreenHeight() / 2 + getHeight(SizeConstants.dp133)),
                width: getWidth(SizeConstants.dp500),
                height: getHeight(SizeConstants.dp235)),
            child: Visibility(
              visible: showDropDown,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const SizedBox(
                    width: SizeConstants.dp85,
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: SizeConstants.dp10,
                        horizontal: SizeConstants.dp16),
                    decoration: BoxDecoration(
                      color: AppColors.colorBg,
                      border: Border.all(
                          width: SizeConstants.dp1,
                          color: AppColors.colorSeparatorLine),
                      borderRadius: const BorderRadius.all(
                          Radius.circular(SizeConstants.dp10)),
                    ),
                    child: Container(
                      width: getWidth(SizeConstants.dp310),
                      child: ListView.builder(
                        itemBuilder: (ctx, index) {
                          return InkWell(
                            onTap: () => {
                              setState(() {
                                selectedTruck = trucks[index];
                                showDropDown = false;
                              })
                            },
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: SizeConstants.dp15),
                              child: Text(
                                trucks[index].storageLocationId.toString(),
                                style: const TextStyle(
                                    color: AppColors.colorMainText,
                                    fontSize: SizeConstants.dp20,
                                    fontWeight: AppValues.fontWeight400,
                                    fontFamily: AppValues.fontFamily),
                              ),
                            ),
                          );
                        },
                        itemCount: trucks.length,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: getWidth(SizeConstants.dp60),
                  ),
                ],
              ),
            ))
      ],
    );
  }

  bool _isTruckSelected() {
    return selectedTruck.storageLocationId !=
        null &&
        selectedTruck.storageLocationId
            .toString() !=
            'null' &&
        selectedTruck.storageLocationId
            .toString() !=
            '';
  }
}
