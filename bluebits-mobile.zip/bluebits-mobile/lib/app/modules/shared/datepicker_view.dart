import 'package:flutter/material.dart';

import 'package:intl/intl.dart';
import '../../core/utils/size_config.dart';
import '../../core/values/app_colors.dart';
import '../../core/values/app_images.dart';
import '../../core/values/app_strings.dart';
import '../../core/values/app_values.dart';
import '../../core/values/size_constants.dart';
import '../../core/values/text_styles.dart';

class DatePickerView extends StatefulWidget {
  final String strImage;
  final String strTitle;
  final String strHint;
  final List<String> arrList;
  final double widthInput;
  final Function onClickAction;
  final Decoration inputDecoration;
  final DateTime firstDate;
  final DateTime selectedDate;
  final bool showError;
  final String errorText;

  DatePickerView({
    this.strImage = "",
    this.strTitle = "",
    this.strHint = "",
    this.arrList = const [],
    this.widthInput = 0,
    required this.inputDecoration,
    required this.onClickAction,
    required this.firstDate,
    this.showError = false,
    this.errorText = '',
    required this.selectedDate,
  });

  @override
  State<DatePickerView> createState() => _DatePickerViewState();
}

class _DatePickerViewState extends State<DatePickerView> {
  @override
  void initState() {
    //print(widget.widthInput);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.widthInput,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.strTitle,
            style: smartSearchInputStyle,
          ),
          const SizedBox(
            height: SizeConstants.dp7,
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: widget.widthInput,
                    padding: const EdgeInsets.symmetric(
                        horizontal: SizeConstants.dp15,
                        vertical: SizeConstants.dp2),
                    decoration: widget.inputDecoration,
                    child: InkWell(
                      onTap: () => setState(() {
                        // showDropDown = !showDropDown;
                      }),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                              width: widget.widthInput - SizeConstants.dp49,
                              height: SizeConstants.dp50,
                              child: DatePickerField(
                                  widget.widthInput,
                                  widget.arrList,
                                  widget.strHint,
                                  widget.onClickAction,
                                  widget.firstDate,
                                  widget.selectedDate)),
                          InkWell(
                            child: Container(
                                height: SizeConstants.dp16,
                                width: SizeConstants.dp16,
                                decoration: BoxDecoration(
                                  image: DecorationImage(
                                    image: AssetImage(widget.strImage),
                                    fit: BoxFit.fill,
                                  ),
                                ),
                                child: null),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              Visibility(
                  visible: widget.showError ? true : false,
                  child: Column(
                    children: [
                      const SizedBox(
                        height: SizeConstants.dp7,
                      ),
                      Text(
                        widget.errorText,
                        style: tSw400dp14fontF.copyWith(
                          color: AppColors.colorRedError,
                        ),
                      ),
                    ],
                  ))
            ],
          ),
        ],
      ),
    );
  }
}

class DatePickerField extends StatefulWidget {
  double inputWidth;
  final List<String> arrList;
  final Function onClickAction;
  final String hintText;
  final DateTime firstDate;
  final DateTime selectedDate;

  DatePickerField(this.inputWidth, this.arrList, this.hintText,
      this.onClickAction, this.firstDate, this.selectedDate);

  @override
  _DatePickerFieldState createState() =>
      _DatePickerFieldState(this.selectedDate);
}

class _DatePickerFieldState extends State<DatePickerField> {
  DateTime? _selectedDate;

  _DatePickerFieldState(DateTime selectedDate) {
    if (selectedDate != null) {
      _selectedDate = selectedDate;
    }
  }

  void _presentDatePicker() {
    showDatePicker(
            context: context,
            initialDate: DateTime.now(),
            firstDate: widget.firstDate,
            builder: (context, child) {
              return Theme(
                data: ThemeData.light().copyWith(
                  primaryColor: AppColors.colorPrimaryLight,
                  colorScheme: const ColorScheme.light(
                      primary: AppColors.colorPrimaryLight),
                  buttonTheme:
                      const ButtonThemeData(textTheme: ButtonTextTheme.primary),
                ),
                child: child!,
              );
            },
            lastDate: DateTime(SizeConstants.dp2025))
        .then((date) {
      if (date == null) {
        return;
      }
      setState(() {
        _selectedDate = date;
        widget.onClickAction(date);
      });
    });
  }

  @override
  void dispose() {
    //this._overlayEntry!.remove();
    super.dispose();
  }

  @override
  void initState() {}

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        FocusManager.instance.primaryFocus?.unfocus();
        _presentDatePicker();
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Text(
          _selectedDate == null
              ? AppStrings.dateformat
              : DateFormat('dd-MM-yyyy').format(_selectedDate!),
          style: TextStyle(
              color: _selectedDate == null
                  ? AppColors.colorSubText
                  : AppColors.colorMainText,
              fontSize: SizeConstants.dp16,
              fontWeight: FontWeight.w400,
              fontFamily: AppValues.fontFamily),
        ),
      ),
    );
  }
}
