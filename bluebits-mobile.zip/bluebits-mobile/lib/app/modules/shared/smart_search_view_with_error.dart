import 'package:flutter/material.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';

import 'package:slb_gt_mobile/app/modules/inventory/models/customerSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/rigsSchema.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/model/sales_representative_schema.dart';

import '../../core/values/app_colors.dart';
import '../../core/values/app_strings.dart';
import '../../core/values/size_constants.dart';
import '../../core/values/text_styles.dart';
import '../ticketing_bill_bits/controller/ticketing_bits_controller.dart';
import '../ticketing_bill_bits/model/wells_schema.dart';

class UserInputViewWithError extends StatefulWidget {
  late var isInserted; //. = false.obs;
  late var overlayEntry;

  final String strImage;
  final String strTitle;
  final String strHint;
  final List<dynamic> arrList;
  final double widthInput;
  late int? inputThreshold;
  final TextStyle? headerTextStyle;
  final TextStyle? hintTextStyle;
  final TextStyle? labelTextStyle;
  final BoxDecoration? smartSearchBoxDecoration;
  final Decoration inputDecoration;
  final Decoration overlayDecoration;
  final Function onClickAction;
  final Function onRemoveText;
  final String initValue;
  final bool showError;
  final String errorText;
  final String fieldType;
  late String customerNumber;
  var controller;

  UserInputViewWithError({
    this.strImage = "",
    this.strTitle = "",
    this.strHint = "",
    this.arrList = const [],
    this.widthInput = 0,
    this.inputThreshold = 3,
    this.headerTextStyle = smartSearchInputStyle,
    this.smartSearchBoxDecoration,
    required this.inputDecoration,
    required this.overlayDecoration,
    this.hintTextStyle,
    this.labelTextStyle,
    required this.onClickAction,
    required this.onRemoveText,
    required this.initValue,
    this.showError = false,
    this.errorText = '',
    this.customerNumber = "",
    required this.fieldType,
    required this.isInserted,
    required this.overlayEntry,
    this.controller,
  });

  @override
  State<UserInputViewWithError> createState() => _UserInputViewWithErrorState();
}

class _UserInputViewWithErrorState extends State<UserInputViewWithError> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.widthInput,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.strTitle,
            style: widget.headerTextStyle,
          ),
          SizedBox(
            height: getHeight(SizeConstants.dp7),
          ),
          Row(
            children: [
              Container(
                width: widget.widthInput,
                padding: const EdgeInsets.symmetric(horizontal: SizeConstants.dp15, vertical: SizeConstants.dp2), //16.0
                decoration: widget.inputDecoration,
                child: InkWell(
                  onTap: () => setState(() {}),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                          width: widget.widthInput - SizeConstants.dp49,
                          height: SizeConstants.dp50,
                          padding: const EdgeInsets.only(right: AppValues.padding_7),
                          child: CountriesField(
                              widget.widthInput,
                              widget.arrList,
                              widget.strHint,
                              widget.arrList,
                              widget.inputThreshold,
                              widget.labelTextStyle,
                              widget.hintTextStyle,
                              widget.onClickAction,
                              widget.onRemoveText,
                              widget.initValue,
                              widget.fieldType,
                              widget.isInserted,
                              widget.overlayEntry,
                              widget.customerNumber,
                              widget.controller)),
                      InkWell(
                        child: GestureDetector(
                          onTap: () {
                            if (widget.isInserted.value) {
                              widget.overlayEntry!.value.remove();
                              widget.isInserted.value = false;
                              widget.isInserted.refresh();
                              FocusManager.instance.primaryFocus?.unfocus();
                              widget.overlayEntry.refresh();
                            }
                          },
                          child: Container(
                              height: SizeConstants.dp9,
                              width: SizeConstants.dp16,
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: AssetImage(widget.strImage),
                                  fit: BoxFit.fill,
                                ),
                              ),
                              child: null),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
          SizedBox(
            height: SizeConstants.dp7,
          ),
          SizedBox(
            height: SizeConstants.dp17,
            child: Visibility(
                visible: widget.showError ? true : false,
                child: Column(
                  children: [
                    Text(
                      widget.errorText,
                      style: tSw400dp14fontF.copyWith(
                        color: AppColors.colorRedError,
                      ),
                    ),
                  ],
                )),
          )
        ],
      ),
    );
  }
}

class CountriesField extends StatefulWidget {
  double inputWidth;
  List<dynamic> arrList;
  List<dynamic> arrOriginal;
  final String hintText;
  final Function onClickAction;
  final Function onRemoveText;
  int? inputThreshold;
  TextStyle? labelTextStyle;
  TextStyle? hintTextStyle;
  String initvalue;
  String customerNumber;
  final fieldType;
  var isInserted;
  var _overlayEntry;
  var controller;

  CountriesField(
      this.inputWidth,
      this.arrList,
      this.hintText,
      this.arrOriginal,
      this.inputThreshold,
      this.labelTextStyle,
      this.hintTextStyle,
      this.onClickAction,
      this.onRemoveText,
      this.initvalue,
      this.fieldType,
      this.isInserted,
      this._overlayEntry,
      this.customerNumber,
      this.controller);

  @override
  _CountriesFieldState createState() => _CountriesFieldState();
}

class _CountriesFieldState extends State<CountriesField> {
  final FocusNode _focusNode = FocusNode();
  var ticketingBitsController = TicketingBitsController();
  final LayerLink _layerLink = LayerLink();
  String selectedValue = '';
  TextEditingController textEditingController = TextEditingController();

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  @override
  void initState() {
    // Subscribe
    if (widget.initvalue != "") {
      selectedValue = widget.initvalue;
      textEditingController.text = selectedValue;
    }
  }

  OverlayEntry _createOverlayEntry(var isInserted, var _overlayEntry) {
    RenderBox renderBox = context.findRenderObject() as RenderBox;
    var size = renderBox.size;
    var offset = renderBox.localToGlobal(Offset.zero);
    var list = widget.arrList;
    return OverlayEntry(
        builder: (context) => Positioned(
              width: widget.inputWidth,
              child: CompositedTransformFollower(
                link: _layerLink,
                showWhenUnlinked: false,
                offset: Offset(SizeConstants.dp_16, size.height + SizeConstants.dp5),
                child: Material(
                  child: Container(
                    height: SizeConstants.dp250,
                    color: AppColors.colorWhite.withAlpha(SizeConstants.dp0I),
                    child: Container(
                      padding: overLayPadding,
                      decoration: overlayDecoration,
                      child: SizedBox(
                        width: SizeConstants.dp310,
                        child: MediaQuery.removePadding(
                          context: context,
                          removeTop: true,
                          child: list.isNotEmpty
                              ? ListView.builder(
                                  itemBuilder: (ctx, index) {
                                    return InkWell(
                                      onTap: () => {
                                        setState(() {
                                          isInserted.value = false;
                                          isInserted.refresh();
                                          _overlayEntry.value.remove();
                                          _overlayEntry.refresh();
                                          FocusManager.instance.primaryFocus?.unfocus();
                                          selectedValue = getValue(index, list);
                                          textEditingController.text = selectedValue;
                                          widget.onClickAction(widget.arrList[index]);
                                        })
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(vertical: SizeConstants.dp8),
                                        child: Text(
                                          getValue(index, list),
                                          style: dropDownListStyle,
                                        ),
                                      ),
                                    );
                                  },
                                  itemCount: list.length,
                                )
                              : const Center(
                                  child: Text(
                                    AppStrings.noResultsFound,
                                    style: dropDownListStyle,
                                  ),
                                ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ));
  }

  String getValue(int index, arrList) {
    if (arrList[index] is Rig) {
      return (arrList[index] as Rig).name as String;
    } else if (arrList[index] is Customer) {
      return (arrList[index] as Customer).addressLine1 as String;
    } else if (arrList[index] is Well) {
      return (arrList[index] as Well).name as String;
    } else if (arrList[index] is SalesRepresentative) {
      return (arrList[index] as SalesRepresentative).fullName as String;
    } else {
      return arrList[index];
    }
    return "";
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
      link: _layerLink,
      child: TextFormField(
        key: Key(selectedValue),
        controller: textEditingController,
        autocorrect: false,
        enableSuggestions: false,
        keyboardType: TextInputType.visiblePassword,
        cursorColor: AppColors.colorBlack,
        onTap: () async {
          var obj = widget.arrOriginal.first;
          if (obj is Well) {
            widget.arrList = TicketingBitsController().searchWell(textEditingController.text, 10);
          } else if (obj is Customer) {
            List<dynamic> customerList = [];
            if (widget.fieldType == AppStrings.billToType) {
              await TicketingBitsController()
                  .searchBillTo(textEditingController.text, widget.customerNumber.toString(), 10)
                  .then((value) => customerList = value);
            } else {
              await TicketingBitsController()
                  .searchShipTo(textEditingController.text, widget.customerNumber.toString(), 10)
                  .then((value) => customerList = value);
            }
            widget.arrList = customerList;
          } else if (obj is SalesRepresentative) {
            widget.arrList = widget.fieldType == AppStrings.cecType
                ? TicketingBitsController().searchCEC(textEditingController.text, 10)
                : TicketingBitsController().searchDesignEngineer(textEditingController.text, 10);
          }

          if (widget.isInserted.value) {
            widget._overlayEntry.value.remove();
          }
          widget._overlayEntry.value = _createOverlayEntry(widget.isInserted, widget._overlayEntry);
          widget._overlayEntry.refresh();
          widget.isInserted.value = true;
          widget.isInserted.refresh();
          Overlay.of(context).insert(widget._overlayEntry.value);

          if (textEditingController.text == '' || textEditingController.text != selectedValue || selectedValue == null) {
            widget.onRemoveText();
          }
        },
        onChanged: (text) async {
          if (text.length >= (widget.inputThreshold ?? 3)) {
            var obj = widget.arrOriginal.first;
            if (obj is Well) {
              widget.arrList = TicketingBitsController().searchWell(text, 10);
            } else if (obj is SalesRepresentative) {
              widget.arrList = widget.fieldType == AppStrings.cecType
                  ? TicketingBitsController().searchCEC(text, 10)
                  : TicketingBitsController().searchDesignEngineer(text, 5);
            } else if (obj is Customer) {
              List<dynamic> customerList = [];
              if (widget.fieldType == AppStrings.billToType) {
                await TicketingBitsController()
                    .searchBillTo(text, widget.customerNumber.toString(), 10)
                    .then((value) => customerList = value);
              } else {
                await TicketingBitsController()
                    .searchShipTo(text, widget.customerNumber.toString(), 10)
                    .then((value) => customerList = value);
              }
              widget.arrList = customerList;
            }

            if (widget.isInserted.value) {
              widget._overlayEntry.value.remove();
            }

            widget._overlayEntry.value = _createOverlayEntry(widget.isInserted, widget._overlayEntry);
            widget._overlayEntry.refresh();
            widget.isInserted.value = true;
            widget.isInserted.refresh();
            Overlay.of(context).insert(widget._overlayEntry.value);
          } else {
            if (text.length < 3) {
              if (widget.isInserted.value) {
                widget._overlayEntry.value.remove();
              }
              widget._overlayEntry.value = _createOverlayEntry(widget.isInserted, widget._overlayEntry);
              widget._overlayEntry.refresh();
              widget.isInserted.value = true;
              widget.isInserted.refresh();
              Overlay.of(context).insert(widget._overlayEntry.value);
            }
          }
          if (text == '' || text != selectedValue || selectedValue == null) {
            widget.onRemoveText();
          }
        },
        focusNode: _focusNode,
        style: smartSearchFontStyle,
        decoration: InputDecoration(
          filled: false,
          labelText: widget.hintText,
          labelStyle: widget.labelTextStyle,
          hintStyle: widget.hintTextStyle,
          floatingLabelBehavior: FloatingLabelBehavior.never,
          hintText: widget.hintText,
          border: InputBorder.none,
          focusedBorder: InputBorder.none,
          enabledBorder: InputBorder.none,
          errorBorder: InputBorder.none,
          disabledBorder: InputBorder.none,
          contentPadding: const EdgeInsets.only(
              left: SizeConstants.dp0, bottom: SizeConstants.dp17, top: SizeConstants.dp0, right: SizeConstants.dp0),
        ),
      ),
    );
  }
}
