import 'dart:async';

import 'package:flutter/material.dart';

import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';

import 'package:slb_gt_mobile/app/modules/inventory/models/customerSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/rigsSchema.dart';

import '../../core/values/app_colors.dart';
import '../../core/values/app_strings.dart';
import '../../core/values/size_constants.dart';
import '../../core/values/text_styles.dart';

class UserInputView extends StatefulWidget {
  final String strImage;
  final String strTitle;
  final String strHint;
  final List<dynamic> arrList;
  final double widthInput;
  late int? inputThreshold;
  final TextStyle? headerTextStyle;
  final TextStyle? hintTextStyle;
  final TextStyle? labelTextStyle;
  final BoxDecoration? smartSearchBoxDecoration;
  final Function onClickAction;
  final Function onRemoveText;
  final String initValue;

  UserInputView(
      {this.strImage = "",
      this.strTitle = "",
      this.strHint = "",
      this.arrList = const [],
      this.widthInput = 0,
      this.inputThreshold = 4,
      this.headerTextStyle = smartSearchInputStyle,
      this.smartSearchBoxDecoration,
      this.hintTextStyle,
      this.labelTextStyle,
      required this.onClickAction,
      required this.onRemoveText,
      required this.initValue});

  @override
  State<UserInputView> createState() => _UserInputViewState();
}

class _UserInputViewState extends State<UserInputView> {
  @override
  void initState() {
    //print(widget.widthInput);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.widthInput,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.strTitle,
            style: widget.headerTextStyle,
          ),
          SizedBox(
            height: getHeight(SizeConstants.dp7),
          ),
          Row(
            children: [
              Container(
                width: widget.widthInput,
                padding: const EdgeInsets.symmetric(
                    horizontal: SizeConstants.dp15,
                    vertical: SizeConstants.dp2), //16.0
                decoration: widget.smartSearchBoxDecoration,
                child: InkWell(
                  onTap: () => setState(() {
                    // showDropDown = !showDropDown;
                  }),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                          width: widget.widthInput - SizeConstants.dp49,
                          height: SizeConstants.dp50,
                          padding: const EdgeInsets.only(right: AppValues.padding_7),
                          child: CountriesField(
                              widget.widthInput,
                              widget.arrList,
                              widget.strHint,
                              widget.arrList,
                              widget.inputThreshold,
                              widget.labelTextStyle,
                              widget.hintTextStyle,
                              widget.onClickAction,
                              widget.onRemoveText,
                              widget.initValue)),
                      InkWell(
                        child: Container(
                            height: SizeConstants.dp16,
                            width: SizeConstants.dp16,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage(widget.strImage),
                                fit: BoxFit.fill,
                              ),
                            ),
                            child: null),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class CountriesField extends StatefulWidget {
  double inputWidth;
  List<dynamic> arrList;
  List<dynamic> arrOriginal;
  final String hintText;
  final Function onClickAction;
  final Function onRemoveText;
  int? inputThreshold;
  TextStyle? labelTextStyle;
  TextStyle? hintTextStyle;
  String initvalue;

  CountriesField(
      this.inputWidth,
      this.arrList,
      this.hintText,
      this.arrOriginal,
      this.inputThreshold,
      this.labelTextStyle,
      this.hintTextStyle,
      this.onClickAction,
      this.onRemoveText,
      this.initvalue);

  @override
  _CountriesFieldState createState() => _CountriesFieldState();
}

class _CountriesFieldState extends State<CountriesField> {
  final FocusNode _focusNode = FocusNode();
  bool isInserted = false;
  OverlayEntry? _overlayEntry;
  //late StreamSubscription<bool> keyboardSubscription;
  final LayerLink _layerLink = LayerLink();
  String selectedValue = '';
  TextEditingController textEditingController = TextEditingController();

  @override
  void dispose() {
    // TODO: implement dispose
    //this._overlayEntry!.remove();
    super.dispose();
  }

  @override
  void initState() {
    var keyboardVisibilityController = KeyboardVisibilityController();
    // Query
    //print(
    //'Keyboard visibility direct query: ${keyboardVisibilityController.isVisible}');

    // Subscribe
    if (widget.initvalue != "") {
      selectedValue = widget.initvalue;
      textEditingController.text = selectedValue;
    }

    /*keyboardSubscription =
        keyboardVisibilityController.onChange.listen((bool visible) {
      if (visible == false) {
        if (_overlayEntry != null) {
          if (isInserted == true) {
            isInserted = false;
            _overlayEntry!.remove();
          }
        }
        isInserted = false;
      }
    });*/
  }

  OverlayEntry _createOverlayEntry() {
    RenderBox renderBox = context.findRenderObject() as RenderBox;
    var size = renderBox.size;
    var offset = renderBox.localToGlobal(Offset.zero);

    return OverlayEntry(
        builder: (context) => Positioned(
              //left: offset.dx - 16,
              //top: offset.dy + size.height + 5.0,
              width: widget.inputWidth,
              child: CompositedTransformFollower(
                link: _layerLink,
                showWhenUnlinked: false,
                offset: Offset(
                    SizeConstants.dp_16, size.height + SizeConstants.dp5),
                child: Material(
                  child: Container(
                    height: SizeConstants.dp250,
                    color: AppColors.colorWhite.withAlpha(SizeConstants.dp0I),
                    child: Container(
                      padding: overLayPadding,
                      decoration: overlayDecoration,
                      child: SizedBox(
                        width: SizeConstants.dp310,
                        child: MediaQuery.removePadding(
                          context: context,
                          removeTop: true,
                          child: widget.arrList.isNotEmpty
                              ? ListView.builder(
                                  itemBuilder: (ctx, index) {
                                    return InkWell(
                                      onTap: () => {
                                        setState(() {
                                          isInserted = false;
                                          _overlayEntry!.remove();
                                          FocusManager.instance.primaryFocus
                                              ?.unfocus();
                                          selectedValue = getValue(index);
                                          textEditingController.text = selectedValue;
                                          widget.onClickAction(
                                              widget.arrList[index]);
                                        })
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                            vertical: SizeConstants.dp8),
                                        child: Text(
                                          getValue(index),
                                          style: dropDownListStyle,
                                        ),
                                      ),
                                    );
                                  },
                                  itemCount: widget.arrList.length,
                                )
                              : const Center(
                                  child: Text(
                                    AppStrings.noResultsFound,
                                    style: dropDownListStyle,
                                  ),
                                ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ));
  }

  String getValue(int index) {
    if (widget.arrList[index] is Rig) {
      return (widget.arrList[index] as Rig).name as String;
    } else if (widget.arrList[index] is Customer) {
      return (widget.arrList[index] as Customer).name as String;
    }
    return "";
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
      link: _layerLink,
      child: TextFormField(
        key: Key(selectedValue),
        controller: textEditingController,
        autocorrect: false,
        enableSuggestions: false,
        keyboardType: TextInputType.visiblePassword,
        cursorColor: AppColors.colorBlack,
        onChanged: (text) {
          if (text.length >= (widget.inputThreshold ?? 4)) {
            setState(() {
              var temp = [];
              widget.arrOriginal.forEach((obj) {
                if (obj is Rig) {
                  if ((obj.name as String)
                          .toLowerCase()
                          .contains(text.toLowerCase()) ==
                      true) {
                    temp.add(obj);
                  }
                } else if (obj is Customer) {
                  if ((obj.name as String)
                          .toLowerCase()
                          .contains(text.toLowerCase()) ==
                      true) {
                    temp.add(obj);
                  }
                } else {}
              });
              widget.arrList = temp;
              if (isInserted == true) {
                _overlayEntry!.remove();
              }
              _overlayEntry = _createOverlayEntry();

              isInserted = true;
              Overlay.of(context).insert(_overlayEntry!);
            });
          } else {
            if (_overlayEntry != null) {
              if (isInserted == true) {
                isInserted = false;
                _overlayEntry!.remove();
              }
            }
          }
          if (text == '' || text != selectedValue) {
            widget.onRemoveText();
          }
        },
        focusNode: _focusNode,
        style: smartSearchFontStyle,
        decoration: InputDecoration(
          filled: false,
          labelText: widget.hintText,
          labelStyle: widget.labelTextStyle,
          hintStyle: widget.hintTextStyle,
          floatingLabelBehavior: FloatingLabelBehavior.never,
          hintText: widget.hintText,
          border: InputBorder.none,
          focusedBorder: InputBorder.none,
          enabledBorder: InputBorder.none,
          errorBorder: InputBorder.none,
          disabledBorder: InputBorder.none,
          contentPadding: const EdgeInsets.only(
              left: SizeConstants.dp0,
              bottom: SizeConstants.dp17,
              top: SizeConstants.dp0,
              right: SizeConstants.dp0),
        ),
      ),
    );
  }
}
