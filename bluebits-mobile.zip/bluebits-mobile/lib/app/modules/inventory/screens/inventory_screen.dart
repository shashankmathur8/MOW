import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:slb_gt_mobile/app/modules/inventory/controller/inventory_controller.dart';
import '../../../core/common_widgets/no_results_screen.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../widget/bits_list.dart';
import '../widget/bottom_tab_notification.dart';
import '../widget/combined_action_inventory_tab.dart';
import '../widget/inventory_tab.dart';

class InventoryScreen extends GetView<InventoryController> {
  ScrollController scrollController;
  var visible;
  InventoryScreen({super.key,required this.scrollController, required this.visible});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: true,
        body: Obx(() => controller.swapList.isNotEmpty == false
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : Container(
                color: AppColors.colorWhite,
                child: Column(
                  children: [
                    Visibility(
                      visible: controller.noOfSelectedBits.value == 0
                          ? visible.value
                          : true,
                      child: Flexible(
                          flex: 0,
                          child: AnimatedSwitcher(
                            duration: const Duration(milliseconds: 300),
                            reverseDuration: const Duration(milliseconds: 300),
                            switchInCurve: Curves.easeIn,
                            child: controller.noOfSelectedBits.value == 0
                                ? InventoryTabView(controller)
                                : CombinedActionInventoryTab(controller),
                          )),
                    ),
                    Flexible(
                      flex: 2,
                      child: Stack(
                        alignment: AlignmentDirectional.bottomStart,
                        children: [
                          Container(
                            color: AppColors.colorBg,
                            child: Obx(() => controller.allBitList.length == 0
                                ? Align(
                                    alignment: Alignment.center,
                                    child: SizedBox(
                                      width: double.infinity,
                                      child: NoResultsScreen(
                                        imagePath: AppImages.noResults,
                                        titleText: AppStrings.noResultsFound,
                                        descriptionText:
                                            AppStrings.noResultsDescription,
                                        titleStyle: tSw500dp16fontF.copyWith(
                                          color: AppColors.colorMainText,
                                          fontSize: SizeConstants.dp32,
                                        ),
                                        descriptionStyle:
                                            tSw400dp14fontF.copyWith(
                                          color: AppColors.colorSubText
                                              .withOpacity(0.7),
                                          fontSize: SizeConstants.dp20,
                                        ),
                                        onPressCallback: () {},
                                      ),
                                    ),
                                  )
                                : SingleChildScrollView(
                                    scrollDirection: Axis.vertical,
                                    child: BitsList(
                                        inventoryController: controller,scrollController: scrollController,visible:visible),
                                  )),
                          ),
                          Obx(
                            () => Visibility(
                                visible: !visible.value,
                                child: BottomTabNotification(controller,scrollController)),
                          )
                        ],
                      ),
                    )
                  ],
                ))));
  }
}
