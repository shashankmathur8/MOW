import 'package:realm/realm.dart';
part 'deviceTokenStorage.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.
@RealmModel()
class _DeviceTokenStorage {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;
  String? userName;
  String? truckUserMappingId;
  String? deviceID;
  String? deviceToken;
}
