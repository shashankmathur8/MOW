import 'package:realm/realm.dart';
part 'consignmentQueueSchema.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.

@RealmModel()
class _ConsignmentQueue {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;

  late List<_ConsignmentQueueBits> bits;

  String? consignmentId;

  DateTime? createdAt;

  String? createdBy;

  String? createdByFullName;

  String? destinationPlant;

  String? destinationStorageLocation;

  String? lat;

  String? long;

  DateTime? modifiedAt;

  String? modifiedBy;

  String? modifiedByFullName;

  String? sourcePlant;

  String? sourceStorageLocation;

  String? truckUserMappingId;
}

@RealmModel(ObjectType.embeddedObject)
@MapTo('ConsignmentQueue_bits')
class _ConsignmentQueueBits {
  String? materialId;

  String? serialNumber;

  String? uom;

  String? valuationType;
}
