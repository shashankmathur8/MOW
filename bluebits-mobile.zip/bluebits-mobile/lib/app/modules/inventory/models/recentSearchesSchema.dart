import 'package:realm/realm.dart';
part 'recentSearchesSchema.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.
@RealmModel()
class _RecentSearchesData {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;
  String? userName;
  late List<String> recentSearches;
}
