// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fields_name.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class FieldsName extends _FieldsName
    with RealmEntity, RealmObjectBase, RealmObject {
  FieldsName(
    ObjectId? id, {
    String? fields,
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'fields', fields);
  }

  FieldsName._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get fields => RealmObjectBase.get<String>(this, 'fields') as String?;
  @override
  set fields(String? value) => RealmObjectBase.set(this, 'fields', value);

  @override
  Stream<RealmObjectChanges<FieldsName>> get changes =>
      RealmObjectBase.getChanges<FieldsName>(this);

  @override
  FieldsName freeze() => RealmObjectBase.freezeObject<FieldsName>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(FieldsName._);
    return const SchemaObject(
        ObjectType.realmObject, FieldsName, 'FieldsName', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('fields', RealmPropertyType.string, optional: true),
    ]);
  }
}
