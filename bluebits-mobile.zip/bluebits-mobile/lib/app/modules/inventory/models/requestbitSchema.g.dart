// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'requestbitSchema.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class RequestBit extends _RequestBit
    with RealmEntity, RealmObjectBase, RealmObject {
  RequestBit(
    ObjectId? id, {
    String? bitType,
    String? comments,
    String? customerName,
    bool? isEmailSent,
    String? jobType,
    String? probability,
    DateTime? requestBitByDate,
    String? requestedBy,
    String? rigName,
    String? size,
    String? truckUserMappingId,
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'bitType', bitType);
    RealmObjectBase.set(this, 'comments', comments);
    RealmObjectBase.set(this, 'customerName', customerName);
    RealmObjectBase.set(this, 'isEmailSent', isEmailSent);
    RealmObjectBase.set(this, 'jobType', jobType);
    RealmObjectBase.set(this, 'probability', probability);
    RealmObjectBase.set(this, 'requestBitByDate', requestBitByDate);
    RealmObjectBase.set(this, 'requestedBy', requestedBy);
    RealmObjectBase.set(this, 'rigName', rigName);
    RealmObjectBase.set(this, 'size', size);
    RealmObjectBase.set(this, 'truckUserMappingId', truckUserMappingId);
  }

  RequestBit._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get bitType =>
      RealmObjectBase.get<String>(this, 'bitType') as String?;
  @override
  set bitType(String? value) => RealmObjectBase.set(this, 'bitType', value);

  @override
  String? get comments =>
      RealmObjectBase.get<String>(this, 'comments') as String?;
  @override
  set comments(String? value) => RealmObjectBase.set(this, 'comments', value);

  @override
  String? get customerName =>
      RealmObjectBase.get<String>(this, 'customerName') as String?;
  @override
  set customerName(String? value) =>
      RealmObjectBase.set(this, 'customerName', value);

  @override
  bool? get isEmailSent =>
      RealmObjectBase.get<bool>(this, 'isEmailSent') as bool?;
  @override
  set isEmailSent(bool? value) =>
      RealmObjectBase.set(this, 'isEmailSent', value);

  @override
  String? get jobType =>
      RealmObjectBase.get<String>(this, 'jobType') as String?;
  @override
  set jobType(String? value) => RealmObjectBase.set(this, 'jobType', value);

  @override
  String? get probability =>
      RealmObjectBase.get<String>(this, 'probability') as String?;
  @override
  set probability(String? value) =>
      RealmObjectBase.set(this, 'probability', value);

  @override
  DateTime? get requestBitByDate =>
      RealmObjectBase.get<DateTime>(this, 'requestBitByDate') as DateTime?;
  @override
  set requestBitByDate(DateTime? value) =>
      RealmObjectBase.set(this, 'requestBitByDate', value);

  @override
  String? get requestedBy =>
      RealmObjectBase.get<String>(this, 'requestedBy') as String?;
  @override
  set requestedBy(String? value) =>
      RealmObjectBase.set(this, 'requestedBy', value);

  @override
  String? get rigName =>
      RealmObjectBase.get<String>(this, 'rigName') as String?;
  @override
  set rigName(String? value) => RealmObjectBase.set(this, 'rigName', value);

  @override
  String? get size => RealmObjectBase.get<String>(this, 'size') as String?;
  @override
  set size(String? value) => RealmObjectBase.set(this, 'size', value);

  @override
  String? get truckUserMappingId =>
      RealmObjectBase.get<String>(this, 'truckUserMappingId') as String?;
  @override
  set truckUserMappingId(String? value) =>
      RealmObjectBase.set(this, 'truckUserMappingId', value);

  @override
  Stream<RealmObjectChanges<RequestBit>> get changes =>
      RealmObjectBase.getChanges<RequestBit>(this);

  @override
  RequestBit freeze() => RealmObjectBase.freezeObject<RequestBit>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(RequestBit._);
    return const SchemaObject(
        ObjectType.realmObject, RequestBit, 'RequestBit', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('bitType', RealmPropertyType.string, optional: true),
      SchemaProperty('comments', RealmPropertyType.string, optional: true),
      SchemaProperty('customerName', RealmPropertyType.string, optional: true),
      SchemaProperty('isEmailSent', RealmPropertyType.bool, optional: true),
      SchemaProperty('jobType', RealmPropertyType.string, optional: true),
      SchemaProperty('probability', RealmPropertyType.string, optional: true),
      SchemaProperty('requestBitByDate', RealmPropertyType.timestamp,
          optional: true),
      SchemaProperty('requestedBy', RealmPropertyType.string, optional: true),
      SchemaProperty('rigName', RealmPropertyType.string, optional: true),
      SchemaProperty('size', RealmPropertyType.string, optional: true),
      SchemaProperty('truckUserMappingId', RealmPropertyType.string,
          optional: true),
    ]);
  }
}
