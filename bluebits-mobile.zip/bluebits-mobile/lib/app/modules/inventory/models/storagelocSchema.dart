import 'package:realm/realm.dart';
part 'storagelocSchema.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.

@RealmModel()
class _StorageLocation {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;

  String? interfaceDate;

  int? isActive;

  String? plantId;

  String? sourceSystem;

  String? storageLocationDescription;

  String? storageLocationId;

  String? storageLocationType;
}
