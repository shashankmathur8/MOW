import 'package:realm/realm.dart';
part 'bitState.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.
@RealmModel()
class _BitState {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;
  String? bitSerialNumber;
  bool? isBlocked;
  String? reasonForBlock;
}
