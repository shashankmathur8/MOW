import 'package:realm/realm.dart';
part 'customerSchema.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.
@RealmModel()
class _Customer {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;
  String? addressLine1;
  String? addressLine2;
  String? addressLine3;
  String? addressType;
  String? category;
  String? city;
  String? country;
  String? countryCode;
  String? county;
  DateTime? createdDate;
  String? customerReferenceId;
  bool? isActive;
  DateTime? lastUpdatedDate;
  String? name;
  String? number;
  String? parentId;
  String? postalCode;
  String? sourceSystem;
  String? state;
  String? stateCode;
}
