import 'package:realm/realm.dart';
part 'movementQueue.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.

@RealmModel()
class _MovementQueue {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;

  late List<_MovementQueueBits> bits;

  DateTime? createdAt;

  String? createdBy;

  String? createdByFullName;

  String? destinationPlant;

  String? destinationStorageLocation;

  String? lat;

  String? long;

  DateTime? modifiedAt;

  String? modifiedBy;

  String? modifiedByFullName;

  String? sourcePlant;

  String? sourceStorageLocation;

  String? truckUserMappingId;
}

@RealmModel(ObjectType.embeddedObject)
@MapTo('MovementQueue_bits')
class _MovementQueueBits {
  String? materialId;

  String? serialNumber;

  String? uom;

  String? valuationType;
}
