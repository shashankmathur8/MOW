// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'bitState.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class BitState extends _BitState
    with RealmEntity, RealmObjectBase, RealmObject {
  BitState(
    ObjectId? id, {
    String? bitSerialNumber,
    bool? isBlocked,
    String? reasonForBlock,
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'bitSerialNumber', bitSerialNumber);
    RealmObjectBase.set(this, 'isBlocked', isBlocked);
    RealmObjectBase.set(this, 'reasonForBlock', reasonForBlock);
  }

  BitState._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get bitSerialNumber =>
      RealmObjectBase.get<String>(this, 'bitSerialNumber') as String?;
  @override
  set bitSerialNumber(String? value) =>
      RealmObjectBase.set(this, 'bitSerialNumber', value);

  @override
  bool? get isBlocked => RealmObjectBase.get<bool>(this, 'isBlocked') as bool?;
  @override
  set isBlocked(bool? value) => RealmObjectBase.set(this, 'isBlocked', value);

  @override
  String? get reasonForBlock =>
      RealmObjectBase.get<String>(this, 'reasonForBlock') as String?;
  @override
  set reasonForBlock(String? value) =>
      RealmObjectBase.set(this, 'reasonForBlock', value);

  @override
  Stream<RealmObjectChanges<BitState>> get changes =>
      RealmObjectBase.getChanges<BitState>(this);

  @override
  BitState freeze() => RealmObjectBase.freezeObject<BitState>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(BitState._);
    return const SchemaObject(ObjectType.realmObject, BitState, 'BitState', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('bitSerialNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('isBlocked', RealmPropertyType.bool, optional: true),
      SchemaProperty('reasonForBlock', RealmPropertyType.string,
          optional: true),
    ]);
  }
}
