import 'package:realm/realm.dart';
part 'rigsSchema.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.
@RealmModel()
class _Rig {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;
  String? buildDate;
  String? country;
  String? drillingContractor;
  bool? isActive;
  String? name;
  String? number;
  String? operatingEnvironment;
  String? rigType;
  String? sourceSystem;
}
