import 'package:slb_gt_mobile/app/core/utils/logger_common.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';

class FilterCheckboxItem {
  final String key;
  final String title;
  late bool isActive;
  late Map<String, bool> categoryItem;
  late Map<String, bool> categoryItemTemp;
  late Map<String, String>? mmToInch;

  FilterCheckboxItem(this.key, this.title, this.isActive, this.categoryItem, this.categoryItemTemp, {this.mmToInch});

  String selectedFilterCount() {
    var length = categoryItem.values.where((item) => item == true).length;
    return length == 0 ? '' : length.toString();
  }

  List<String> getAllSelectedFilter() {
    List<String> selectedFilterItem = [];
    categoryItem.forEach((key, value) {
      if(value) {
        selectedFilterItem.add('\'$key\'');
      }
    });
    return selectedFilterItem;
  }

  void applyTempToCategoryItem() {
    categoryItem = <String, bool>{};
    categoryItem = categoryItemTemp.map((key, value) => MapEntry(key, value));
  }

  void applyCategoryItemToTemp() {
    categoryItemTemp = <String, bool>{};
    categoryItemTemp = categoryItem.map((key, value) => MapEntry(key, value));
  }
}