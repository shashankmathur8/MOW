// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'bitSchema.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class Bit extends _Bit with RealmEntity, RealmObjectBase, RealmObject {
  Bit(
    ObjectId? id, {
    String? batchNumber,
    String? bitId,
    String? bitSize,
    String? bitType,
    String? businessLine,
    DateTime? dateOfLastGoodsMovement,
    String? equipmentNumber,
    String? features,
    String? geoMarket,
    String? iadcCode,
    String? inch,
    DateTime? interfaceDate,
    String? invOrgId,
    String? materialDescription,
    String? materialNumber,
    String? milim,
    String? numberOfRuns,
    String? pinSize,
    String? plant,
    String? plantName,
    String? profitCenter,
    String? serialNumber,
    String? snStockType,
    String? specialStockIndicator,
    String? status1,
    String? storageLoc,
    String? storageLocationDescription,
    String? subSegment,
    String? uom,
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'batchNumber', batchNumber);
    RealmObjectBase.set(this, 'bitId', bitId);
    RealmObjectBase.set(this, 'bitSize', bitSize);
    RealmObjectBase.set(this, 'bitType', bitType);
    RealmObjectBase.set(this, 'businessLine', businessLine);
    RealmObjectBase.set(
        this, 'dateOfLastGoodsMovement', dateOfLastGoodsMovement);
    RealmObjectBase.set(this, 'equipmentNumber', equipmentNumber);
    RealmObjectBase.set(this, 'features', features);
    RealmObjectBase.set(this, 'geoMarket', geoMarket);
    RealmObjectBase.set(this, 'iadcCode', iadcCode);
    RealmObjectBase.set(this, 'inch', inch);
    RealmObjectBase.set(this, 'interfaceDate', interfaceDate);
    RealmObjectBase.set(this, 'invOrgId', invOrgId);
    RealmObjectBase.set(this, 'materialDescription', materialDescription);
    RealmObjectBase.set(this, 'materialNumber', materialNumber);
    RealmObjectBase.set(this, 'milim', milim);
    RealmObjectBase.set(this, 'numberOfRuns', numberOfRuns);
    RealmObjectBase.set(this, 'pinSize', pinSize);
    RealmObjectBase.set(this, 'plant', plant);
    RealmObjectBase.set(this, 'plantName', plantName);
    RealmObjectBase.set(this, 'profitCenter', profitCenter);
    RealmObjectBase.set(this, 'serialNumber', serialNumber);
    RealmObjectBase.set(this, 'snStockType', snStockType);
    RealmObjectBase.set(this, 'specialStockIndicator', specialStockIndicator);
    RealmObjectBase.set(this, 'status1', status1);
    RealmObjectBase.set(this, 'storageLoc', storageLoc);
    RealmObjectBase.set(
        this, 'storageLocationDescription', storageLocationDescription);
    RealmObjectBase.set(this, 'subSegment', subSegment);
    RealmObjectBase.set(this, 'uom', uom);
  }

  Bit._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get batchNumber =>
      RealmObjectBase.get<String>(this, 'batchNumber') as String?;
  @override
  set batchNumber(String? value) =>
      RealmObjectBase.set(this, 'batchNumber', value);

  @override
  String? get bitId => RealmObjectBase.get<String>(this, 'bitId') as String?;
  @override
  set bitId(String? value) => RealmObjectBase.set(this, 'bitId', value);

  @override
  String? get bitSize =>
      RealmObjectBase.get<String>(this, 'bitSize') as String?;
  @override
  set bitSize(String? value) => RealmObjectBase.set(this, 'bitSize', value);

  @override
  String? get bitType =>
      RealmObjectBase.get<String>(this, 'bitType') as String?;
  @override
  set bitType(String? value) => RealmObjectBase.set(this, 'bitType', value);

  @override
  String? get businessLine =>
      RealmObjectBase.get<String>(this, 'businessLine') as String?;
  @override
  set businessLine(String? value) =>
      RealmObjectBase.set(this, 'businessLine', value);

  @override
  DateTime? get dateOfLastGoodsMovement =>
      RealmObjectBase.get<DateTime>(this, 'dateOfLastGoodsMovement')
          as DateTime?;
  @override
  set dateOfLastGoodsMovement(DateTime? value) =>
      RealmObjectBase.set(this, 'dateOfLastGoodsMovement', value);

  @override
  String? get equipmentNumber =>
      RealmObjectBase.get<String>(this, 'equipmentNumber') as String?;
  @override
  set equipmentNumber(String? value) =>
      RealmObjectBase.set(this, 'equipmentNumber', value);

  @override
  String? get features =>
      RealmObjectBase.get<String>(this, 'features') as String?;
  @override
  set features(String? value) => RealmObjectBase.set(this, 'features', value);

  @override
  String? get geoMarket =>
      RealmObjectBase.get<String>(this, 'geoMarket') as String?;
  @override
  set geoMarket(String? value) => RealmObjectBase.set(this, 'geoMarket', value);

  @override
  String? get iadcCode =>
      RealmObjectBase.get<String>(this, 'iadcCode') as String?;
  @override
  set iadcCode(String? value) => RealmObjectBase.set(this, 'iadcCode', value);

  @override
  String? get inch => RealmObjectBase.get<String>(this, 'inch') as String?;
  @override
  set inch(String? value) => RealmObjectBase.set(this, 'inch', value);

  @override
  DateTime? get interfaceDate =>
      RealmObjectBase.get<DateTime>(this, 'interfaceDate') as DateTime?;
  @override
  set interfaceDate(DateTime? value) =>
      RealmObjectBase.set(this, 'interfaceDate', value);

  @override
  String? get invOrgId =>
      RealmObjectBase.get<String>(this, 'invOrgId') as String?;
  @override
  set invOrgId(String? value) => RealmObjectBase.set(this, 'invOrgId', value);

  @override
  String? get materialDescription =>
      RealmObjectBase.get<String>(this, 'materialDescription') as String?;
  @override
  set materialDescription(String? value) =>
      RealmObjectBase.set(this, 'materialDescription', value);

  @override
  String? get materialNumber =>
      RealmObjectBase.get<String>(this, 'materialNumber') as String?;
  @override
  set materialNumber(String? value) =>
      RealmObjectBase.set(this, 'materialNumber', value);

  @override
  String? get milim => RealmObjectBase.get<String>(this, 'milim') as String?;
  @override
  set milim(String? value) => RealmObjectBase.set(this, 'milim', value);

  @override
  String? get numberOfRuns =>
      RealmObjectBase.get<String>(this, 'numberOfRuns') as String?;
  @override
  set numberOfRuns(String? value) =>
      RealmObjectBase.set(this, 'numberOfRuns', value);

  @override
  String? get pinSize =>
      RealmObjectBase.get<String>(this, 'pinSize') as String?;
  @override
  set pinSize(String? value) => RealmObjectBase.set(this, 'pinSize', value);

  @override
  String? get plant => RealmObjectBase.get<String>(this, 'plant') as String?;
  @override
  set plant(String? value) => RealmObjectBase.set(this, 'plant', value);

  @override
  String? get plantName =>
      RealmObjectBase.get<String>(this, 'plantName') as String?;
  @override
  set plantName(String? value) => RealmObjectBase.set(this, 'plantName', value);

  @override
  String? get profitCenter =>
      RealmObjectBase.get<String>(this, 'profitCenter') as String?;
  @override
  set profitCenter(String? value) =>
      RealmObjectBase.set(this, 'profitCenter', value);

  @override
  String? get serialNumber =>
      RealmObjectBase.get<String>(this, 'serialNumber') as String?;
  @override
  set serialNumber(String? value) =>
      RealmObjectBase.set(this, 'serialNumber', value);

  @override
  String? get snStockType =>
      RealmObjectBase.get<String>(this, 'snStockType') as String?;
  @override
  set snStockType(String? value) =>
      RealmObjectBase.set(this, 'snStockType', value);

  @override
  String? get specialStockIndicator =>
      RealmObjectBase.get<String>(this, 'specialStockIndicator') as String?;
  @override
  set specialStockIndicator(String? value) =>
      RealmObjectBase.set(this, 'specialStockIndicator', value);

  @override
  String? get status1 =>
      RealmObjectBase.get<String>(this, 'status1') as String?;
  @override
  set status1(String? value) => RealmObjectBase.set(this, 'status1', value);

  @override
  String? get storageLoc =>
      RealmObjectBase.get<String>(this, 'storageLoc') as String?;
  @override
  set storageLoc(String? value) =>
      RealmObjectBase.set(this, 'storageLoc', value);

  @override
  String? get storageLocationDescription =>
      RealmObjectBase.get<String>(this, 'storageLocationDescription')
          as String?;
  @override
  set storageLocationDescription(String? value) =>
      RealmObjectBase.set(this, 'storageLocationDescription', value);

  @override
  String? get subSegment =>
      RealmObjectBase.get<String>(this, 'subSegment') as String?;
  @override
  set subSegment(String? value) =>
      RealmObjectBase.set(this, 'subSegment', value);

  @override
  String? get uom => RealmObjectBase.get<String>(this, 'uom') as String?;
  @override
  set uom(String? value) => RealmObjectBase.set(this, 'uom', value);

  @override
  Stream<RealmObjectChanges<Bit>> get changes =>
      RealmObjectBase.getChanges<Bit>(this);

  @override
  Bit freeze() => RealmObjectBase.freezeObject<Bit>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(Bit._);
    return const SchemaObject(ObjectType.realmObject, Bit, 'Bit', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('batchNumber', RealmPropertyType.string, optional: true),
      SchemaProperty('bitId', RealmPropertyType.string, optional: true),
      SchemaProperty('bitSize', RealmPropertyType.string, optional: true),
      SchemaProperty('bitType', RealmPropertyType.string, optional: true),
      SchemaProperty('businessLine', RealmPropertyType.string, optional: true),
      SchemaProperty('dateOfLastGoodsMovement', RealmPropertyType.timestamp,
          optional: true),
      SchemaProperty('equipmentNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('features', RealmPropertyType.string, optional: true),
      SchemaProperty('geoMarket', RealmPropertyType.string, optional: true),
      SchemaProperty('iadcCode', RealmPropertyType.string, optional: true),
      SchemaProperty('inch', RealmPropertyType.string, optional: true),
      SchemaProperty('interfaceDate', RealmPropertyType.timestamp,
          optional: true),
      SchemaProperty('invOrgId', RealmPropertyType.string, optional: true),
      SchemaProperty('materialDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('materialNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('milim', RealmPropertyType.string, optional: true),
      SchemaProperty('numberOfRuns', RealmPropertyType.string, optional: true),
      SchemaProperty('pinSize', RealmPropertyType.string, optional: true),
      SchemaProperty('plant', RealmPropertyType.string, optional: true),
      SchemaProperty('plantName', RealmPropertyType.string, optional: true),
      SchemaProperty('profitCenter', RealmPropertyType.string, optional: true),
      SchemaProperty('serialNumber', RealmPropertyType.string, optional: true),
      SchemaProperty('snStockType', RealmPropertyType.string, optional: true),
      SchemaProperty('specialStockIndicator', RealmPropertyType.string,
          optional: true),
      SchemaProperty('status1', RealmPropertyType.string, optional: true),
      SchemaProperty('storageLoc', RealmPropertyType.string, optional: true),
      SchemaProperty('storageLocationDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('subSegment', RealmPropertyType.string, optional: true),
      SchemaProperty('uom', RealmPropertyType.string, optional: true),
    ]);
  }
}
