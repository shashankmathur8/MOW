import 'package:realm/realm.dart';
part 'truckUserMapping.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.
@RealmModel()
class _TruckUserMapping {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;

  String? baseLocationId;

  String? country;

  String? districtDescription;

  String? districtId;

  String? finOrgId;

  String? mailId;

  String? plantDescription;

  String? plantId;

  String? role;

  String? state;

  String? storageLocationDescription;

  String? storageLocationId;
}
