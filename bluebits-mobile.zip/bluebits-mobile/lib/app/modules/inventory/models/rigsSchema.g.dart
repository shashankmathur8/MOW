// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'rigsSchema.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class Rig extends _Rig with RealmEntity, RealmObjectBase, RealmObject {
  Rig(
    ObjectId? id, {
    String? buildDate,
    String? country,
    String? drillingContractor,
    bool? isActive,
    String? name,
    String? number,
    String? operatingEnvironment,
    String? rigType,
    String? sourceSystem,
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'buildDate', buildDate);
    RealmObjectBase.set(this, 'country', country);
    RealmObjectBase.set(this, 'drillingContractor', drillingContractor);
    RealmObjectBase.set(this, 'isActive', isActive);
    RealmObjectBase.set(this, 'name', name);
    RealmObjectBase.set(this, 'number', number);
    RealmObjectBase.set(this, 'operatingEnvironment', operatingEnvironment);
    RealmObjectBase.set(this, 'rigType', rigType);
    RealmObjectBase.set(this, 'sourceSystem', sourceSystem);
  }

  Rig._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get buildDate =>
      RealmObjectBase.get<String>(this, 'buildDate') as String?;
  @override
  set buildDate(String? value) => RealmObjectBase.set(this, 'buildDate', value);

  @override
  String? get country =>
      RealmObjectBase.get<String>(this, 'country') as String?;
  @override
  set country(String? value) => RealmObjectBase.set(this, 'country', value);

  @override
  String? get drillingContractor =>
      RealmObjectBase.get<String>(this, 'drillingContractor') as String?;
  @override
  set drillingContractor(String? value) =>
      RealmObjectBase.set(this, 'drillingContractor', value);

  @override
  bool? get isActive => RealmObjectBase.get<bool>(this, 'isActive') as bool?;
  @override
  set isActive(bool? value) => RealmObjectBase.set(this, 'isActive', value);

  @override
  String? get name => RealmObjectBase.get<String>(this, 'name') as String?;
  @override
  set name(String? value) => RealmObjectBase.set(this, 'name', value);

  @override
  String? get number => RealmObjectBase.get<String>(this, 'number') as String?;
  @override
  set number(String? value) => RealmObjectBase.set(this, 'number', value);

  @override
  String? get operatingEnvironment =>
      RealmObjectBase.get<String>(this, 'operatingEnvironment') as String?;
  @override
  set operatingEnvironment(String? value) =>
      RealmObjectBase.set(this, 'operatingEnvironment', value);

  @override
  String? get rigType =>
      RealmObjectBase.get<String>(this, 'rigType') as String?;
  @override
  set rigType(String? value) => RealmObjectBase.set(this, 'rigType', value);

  @override
  String? get sourceSystem =>
      RealmObjectBase.get<String>(this, 'sourceSystem') as String?;
  @override
  set sourceSystem(String? value) =>
      RealmObjectBase.set(this, 'sourceSystem', value);

  @override
  Stream<RealmObjectChanges<Rig>> get changes =>
      RealmObjectBase.getChanges<Rig>(this);

  @override
  Rig freeze() => RealmObjectBase.freezeObject<Rig>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(Rig._);
    return const SchemaObject(ObjectType.realmObject, Rig, 'Rig', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('buildDate', RealmPropertyType.string, optional: true),
      SchemaProperty('country', RealmPropertyType.string, optional: true),
      SchemaProperty('drillingContractor', RealmPropertyType.string,
          optional: true),
      SchemaProperty('isActive', RealmPropertyType.bool, optional: true),
      SchemaProperty('name', RealmPropertyType.string, optional: true),
      SchemaProperty('number', RealmPropertyType.string, optional: true),
      SchemaProperty('operatingEnvironment', RealmPropertyType.string,
          optional: true),
      SchemaProperty('rigType', RealmPropertyType.string, optional: true),
      SchemaProperty('sourceSystem', RealmPropertyType.string, optional: true),
    ]);
  }
}
