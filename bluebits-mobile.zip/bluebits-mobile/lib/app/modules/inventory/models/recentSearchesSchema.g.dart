// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'recentSearchesSchema.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class RecentSearchesData extends _RecentSearchesData
    with RealmEntity, RealmObjectBase, RealmObject {
  RecentSearchesData(
    ObjectId? id, {
    String? userName,
    Iterable<String> recentSearches = const [],
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'userName', userName);
    RealmObjectBase.set<RealmList<String>>(
        this, 'recentSearches', RealmList<String>(recentSearches));
  }

  RecentSearchesData._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get userName =>
      RealmObjectBase.get<String>(this, 'userName') as String?;
  @override
  set userName(String? value) => RealmObjectBase.set(this, 'userName', value);

  @override
  RealmList<String> get recentSearches =>
      RealmObjectBase.get<String>(this, 'recentSearches') as RealmList<String>;
  @override
  set recentSearches(covariant RealmList<String> value) =>
      throw RealmUnsupportedSetError();

  @override
  Stream<RealmObjectChanges<RecentSearchesData>> get changes =>
      RealmObjectBase.getChanges<RecentSearchesData>(this);

  @override
  RecentSearchesData freeze() =>
      RealmObjectBase.freezeObject<RecentSearchesData>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(RecentSearchesData._);
    return const SchemaObject(
        ObjectType.realmObject, RecentSearchesData, 'RecentSearchesData', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('userName', RealmPropertyType.string, optional: true),
      SchemaProperty('recentSearches', RealmPropertyType.string,
          collectionType: RealmCollectionType.list),
    ]);
  }
}
