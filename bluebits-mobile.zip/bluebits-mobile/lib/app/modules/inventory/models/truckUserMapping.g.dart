// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'truckUserMapping.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class TruckUserMapping extends _TruckUserMapping
    with RealmEntity, RealmObjectBase, RealmObject {
  TruckUserMapping(
    ObjectId? id, {
    String? baseLocationId,
    String? country,
    String? districtDescription,
    String? districtId,
    String? finOrgId,
    String? mailId,
    String? plantDescription,
    String? plantId,
    String? role,
    String? state,
    String? storageLocationDescription,
    String? storageLocationId,
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'baseLocationId', baseLocationId);
    RealmObjectBase.set(this, 'country', country);
    RealmObjectBase.set(this, 'districtDescription', districtDescription);
    RealmObjectBase.set(this, 'districtId', districtId);
    RealmObjectBase.set(this, 'finOrgId', finOrgId);
    RealmObjectBase.set(this, 'mailId', mailId);
    RealmObjectBase.set(this, 'plantDescription', plantDescription);
    RealmObjectBase.set(this, 'plantId', plantId);
    RealmObjectBase.set(this, 'role', role);
    RealmObjectBase.set(this, 'state', state);
    RealmObjectBase.set(
        this, 'storageLocationDescription', storageLocationDescription);
    RealmObjectBase.set(this, 'storageLocationId', storageLocationId);
  }

  TruckUserMapping._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get baseLocationId =>
      RealmObjectBase.get<String>(this, 'baseLocationId') as String?;
  @override
  set baseLocationId(String? value) =>
      RealmObjectBase.set(this, 'baseLocationId', value);

  @override
  String? get country =>
      RealmObjectBase.get<String>(this, 'country') as String?;
  @override
  set country(String? value) => RealmObjectBase.set(this, 'country', value);

  @override
  String? get districtDescription =>
      RealmObjectBase.get<String>(this, 'districtDescription') as String?;
  @override
  set districtDescription(String? value) =>
      RealmObjectBase.set(this, 'districtDescription', value);

  @override
  String? get districtId =>
      RealmObjectBase.get<String>(this, 'districtId') as String?;
  @override
  set districtId(String? value) =>
      RealmObjectBase.set(this, 'districtId', value);

  @override
  String? get finOrgId =>
      RealmObjectBase.get<String>(this, 'finOrgId') as String?;
  @override
  set finOrgId(String? value) => RealmObjectBase.set(this, 'finOrgId', value);

  @override
  String? get mailId => RealmObjectBase.get<String>(this, 'mailId') as String?;
  @override
  set mailId(String? value) => RealmObjectBase.set(this, 'mailId', value);

  @override
  String? get plantDescription =>
      RealmObjectBase.get<String>(this, 'plantDescription') as String?;
  @override
  set plantDescription(String? value) =>
      RealmObjectBase.set(this, 'plantDescription', value);

  @override
  String? get plantId =>
      RealmObjectBase.get<String>(this, 'plantId') as String?;
  @override
  set plantId(String? value) => RealmObjectBase.set(this, 'plantId', value);

  @override
  String? get role => RealmObjectBase.get<String>(this, 'role') as String?;
  @override
  set role(String? value) => RealmObjectBase.set(this, 'role', value);

  @override
  String? get state => RealmObjectBase.get<String>(this, 'state') as String?;
  @override
  set state(String? value) => RealmObjectBase.set(this, 'state', value);

  @override
  String? get storageLocationDescription =>
      RealmObjectBase.get<String>(this, 'storageLocationDescription')
          as String?;
  @override
  set storageLocationDescription(String? value) =>
      RealmObjectBase.set(this, 'storageLocationDescription', value);

  @override
  String? get storageLocationId =>
      RealmObjectBase.get<String>(this, 'storageLocationId') as String?;
  @override
  set storageLocationId(String? value) =>
      RealmObjectBase.set(this, 'storageLocationId', value);

  @override
  Stream<RealmObjectChanges<TruckUserMapping>> get changes =>
      RealmObjectBase.getChanges<TruckUserMapping>(this);

  @override
  TruckUserMapping freeze() =>
      RealmObjectBase.freezeObject<TruckUserMapping>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(TruckUserMapping._);
    return const SchemaObject(
        ObjectType.realmObject, TruckUserMapping, 'TruckUserMapping', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('baseLocationId', RealmPropertyType.string,
          optional: true),
      SchemaProperty('country', RealmPropertyType.string, optional: true),
      SchemaProperty('districtDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('districtId', RealmPropertyType.string, optional: true),
      SchemaProperty('finOrgId', RealmPropertyType.string, optional: true),
      SchemaProperty('mailId', RealmPropertyType.string, optional: true),
      SchemaProperty('plantDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('plantId', RealmPropertyType.string, optional: true),
      SchemaProperty('role', RealmPropertyType.string, optional: true),
      SchemaProperty('state', RealmPropertyType.string, optional: true),
      SchemaProperty('storageLocationDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('storageLocationId', RealmPropertyType.string,
          optional: true),
    ]);
  }
}
