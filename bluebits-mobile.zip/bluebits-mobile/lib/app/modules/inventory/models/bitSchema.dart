import 'package:realm/realm.dart';
part 'bitSchema.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.
@RealmModel()
class _Bit {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;
  String? batchNumber;
  String? bitId;
  String? bitSize;
  String? bitType;
  String? businessLine;
  DateTime? dateOfLastGoodsMovement;
  String? equipmentNumber;
  String? features;
  String? geoMarket;
  String? iadcCode;
  String? inch;
  DateTime? interfaceDate;
  String? invOrgId;
  String? materialDescription;
  String? materialNumber;
  String? milim;
  String? numberOfRuns;
  String? pinSize;
  String? plant;
  String? plantName;
  String? profitCenter;
  String? serialNumber;
  String? snStockType;
  String? specialStockIndicator;
  String? status1;
  String? storageLoc;
  String? storageLocationDescription;
  String? subSegment;
  String? uom;

  Map<String, dynamic> toMap() {
    return {
      "id": id,
      "batchNumber": batchNumber,
      "bitId": bitId,
      "bitSize": inch,
      "bitType": bitType,
      "businessLine": businessLine,
      //"dateOfLastGoodsMovement": dateOfLastGoodsMovement.toIso8601String(),
      "equipmentNumber": equipmentNumber,
      "features": features,
      "geoMarket": geoMarket,
      "iadcCode": iadcCode,
      //"interfaceDate": interfaceDate.toIso8601String(),
      "invOrgId": invOrgId,
      "materialDescription": materialDescription,
      "materialNumber": materialNumber,
      "numberOfRuns": numberOfRuns,
      "pinSize": pinSize,
      "plant": plant,
      "plantName": plantName,
      "profitCenter": profitCenter,
      "serialNumber": serialNumber,
      "snStockType": snStockType,
      "specialStockIndicator": specialStockIndicator,
      "status1": status1,
      "storageLoc": storageLoc,
      "storageLocationDescription": storageLocationDescription,
      "subSegment": subSegment,
      "uom": uom,
    };
  }
}
