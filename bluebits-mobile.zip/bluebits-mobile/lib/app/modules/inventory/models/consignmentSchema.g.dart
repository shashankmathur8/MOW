// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'consignmentSchema.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class Consignment extends _Consignment
    with RealmEntity, RealmObjectBase, RealmObject {
  Consignment(
    ObjectId? id, {
    String? activityId,
    String? cEC,
    String? consignmentId,
    DateTime? createdAt,
    String? createdBy,
    String? createdByFullName,
    String? customerEmail,
    String? customerId,
    String? customerName,
    String? designEngineer,
    String? finalPdf,
    String? gTQuoteId,
    bool? isEmailSent,
    DateTime? modifiedAt,
    String? modifiedBy,
    String? modifiedByFullName,
    String? operationId,
    String? projectId,
    String? rigContractor,
    String? rigId,
    String? rigName,
    String? status,
    String? truckUserMappingId,
    String? wBSNumber,
    Iterable<ConsignmentBits> bits = const [],
    Iterable<ConsignmentDigitalAttachments> digitalAttachments = const [],
    Iterable<ConsignmentManualAttachments> manualAttachments = const [],
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'activityId', activityId);
    RealmObjectBase.set(this, 'cEC', cEC);
    RealmObjectBase.set(this, 'consignmentId', consignmentId);
    RealmObjectBase.set(this, 'createdAt', createdAt);
    RealmObjectBase.set(this, 'createdBy', createdBy);
    RealmObjectBase.set(this, 'createdByFullName', createdByFullName);
    RealmObjectBase.set(this, 'customerEmail', customerEmail);
    RealmObjectBase.set(this, 'customerId', customerId);
    RealmObjectBase.set(this, 'customerName', customerName);
    RealmObjectBase.set(this, 'designEngineer', designEngineer);
    RealmObjectBase.set(this, 'finalPdf', finalPdf);
    RealmObjectBase.set(this, 'gTQuoteId', gTQuoteId);
    RealmObjectBase.set(this, 'isEmailSent', isEmailSent);
    RealmObjectBase.set(this, 'modifiedAt', modifiedAt);
    RealmObjectBase.set(this, 'modifiedBy', modifiedBy);
    RealmObjectBase.set(this, 'modifiedByFullName', modifiedByFullName);
    RealmObjectBase.set(this, 'operationId', operationId);
    RealmObjectBase.set(this, 'projectId', projectId);
    RealmObjectBase.set(this, 'rigContractor', rigContractor);
    RealmObjectBase.set(this, 'rigId', rigId);
    RealmObjectBase.set(this, 'rigName', rigName);
    RealmObjectBase.set(this, 'status', status);
    RealmObjectBase.set(this, 'truckUserMappingId', truckUserMappingId);
    RealmObjectBase.set(this, 'wBSNumber', wBSNumber);
    RealmObjectBase.set<RealmList<ConsignmentBits>>(
        this, 'bits', RealmList<ConsignmentBits>(bits));
    RealmObjectBase.set<RealmList<ConsignmentDigitalAttachments>>(
        this,
        'digitalAttachments',
        RealmList<ConsignmentDigitalAttachments>(digitalAttachments));
    RealmObjectBase.set<RealmList<ConsignmentManualAttachments>>(
        this,
        'manualAttachments',
        RealmList<ConsignmentManualAttachments>(manualAttachments));
  }

  Consignment._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get activityId =>
      RealmObjectBase.get<String>(this, 'activityId') as String?;
  @override
  set activityId(String? value) =>
      RealmObjectBase.set(this, 'activityId', value);

  @override
  RealmList<ConsignmentBits> get bits =>
      RealmObjectBase.get<ConsignmentBits>(this, 'bits')
          as RealmList<ConsignmentBits>;
  @override
  set bits(covariant RealmList<ConsignmentBits> value) =>
      throw RealmUnsupportedSetError();

  @override
  String? get cEC => RealmObjectBase.get<String>(this, 'cEC') as String?;
  @override
  set cEC(String? value) => RealmObjectBase.set(this, 'cEC', value);

  @override
  String? get consignmentId =>
      RealmObjectBase.get<String>(this, 'consignmentId') as String?;
  @override
  set consignmentId(String? value) =>
      RealmObjectBase.set(this, 'consignmentId', value);

  @override
  DateTime? get createdAt =>
      RealmObjectBase.get<DateTime>(this, 'createdAt') as DateTime?;
  @override
  set createdAt(DateTime? value) =>
      RealmObjectBase.set(this, 'createdAt', value);

  @override
  String? get createdBy =>
      RealmObjectBase.get<String>(this, 'createdBy') as String?;
  @override
  set createdBy(String? value) => RealmObjectBase.set(this, 'createdBy', value);

  @override
  String? get createdByFullName =>
      RealmObjectBase.get<String>(this, 'createdByFullName') as String?;
  @override
  set createdByFullName(String? value) =>
      RealmObjectBase.set(this, 'createdByFullName', value);

  @override
  String? get customerEmail =>
      RealmObjectBase.get<String>(this, 'customerEmail') as String?;
  @override
  set customerEmail(String? value) =>
      RealmObjectBase.set(this, 'customerEmail', value);

  @override
  String? get customerId =>
      RealmObjectBase.get<String>(this, 'customerId') as String?;
  @override
  set customerId(String? value) =>
      RealmObjectBase.set(this, 'customerId', value);

  @override
  String? get customerName =>
      RealmObjectBase.get<String>(this, 'customerName') as String?;
  @override
  set customerName(String? value) =>
      RealmObjectBase.set(this, 'customerName', value);

  @override
  String? get designEngineer =>
      RealmObjectBase.get<String>(this, 'designEngineer') as String?;
  @override
  set designEngineer(String? value) =>
      RealmObjectBase.set(this, 'designEngineer', value);

  @override
  RealmList<ConsignmentDigitalAttachments> get digitalAttachments =>
      RealmObjectBase.get<ConsignmentDigitalAttachments>(
              this, 'digitalAttachments')
          as RealmList<ConsignmentDigitalAttachments>;
  @override
  set digitalAttachments(
          covariant RealmList<ConsignmentDigitalAttachments> value) =>
      throw RealmUnsupportedSetError();

  @override
  String? get finalPdf =>
      RealmObjectBase.get<String>(this, 'finalPdf') as String?;
  @override
  set finalPdf(String? value) => RealmObjectBase.set(this, 'finalPdf', value);

  @override
  String? get gTQuoteId =>
      RealmObjectBase.get<String>(this, 'gTQuoteId') as String?;
  @override
  set gTQuoteId(String? value) => RealmObjectBase.set(this, 'gTQuoteId', value);

  @override
  bool? get isEmailSent =>
      RealmObjectBase.get<bool>(this, 'isEmailSent') as bool?;
  @override
  set isEmailSent(bool? value) =>
      RealmObjectBase.set(this, 'isEmailSent', value);

  @override
  RealmList<ConsignmentManualAttachments> get manualAttachments =>
      RealmObjectBase.get<ConsignmentManualAttachments>(
          this, 'manualAttachments') as RealmList<ConsignmentManualAttachments>;
  @override
  set manualAttachments(
          covariant RealmList<ConsignmentManualAttachments> value) =>
      throw RealmUnsupportedSetError();

  @override
  DateTime? get modifiedAt =>
      RealmObjectBase.get<DateTime>(this, 'modifiedAt') as DateTime?;
  @override
  set modifiedAt(DateTime? value) =>
      RealmObjectBase.set(this, 'modifiedAt', value);

  @override
  String? get modifiedBy =>
      RealmObjectBase.get<String>(this, 'modifiedBy') as String?;
  @override
  set modifiedBy(String? value) =>
      RealmObjectBase.set(this, 'modifiedBy', value);

  @override
  String? get modifiedByFullName =>
      RealmObjectBase.get<String>(this, 'modifiedByFullName') as String?;
  @override
  set modifiedByFullName(String? value) =>
      RealmObjectBase.set(this, 'modifiedByFullName', value);

  @override
  String? get operationId =>
      RealmObjectBase.get<String>(this, 'operationId') as String?;
  @override
  set operationId(String? value) =>
      RealmObjectBase.set(this, 'operationId', value);

  @override
  String? get projectId =>
      RealmObjectBase.get<String>(this, 'projectId') as String?;
  @override
  set projectId(String? value) => RealmObjectBase.set(this, 'projectId', value);

  @override
  String? get rigContractor =>
      RealmObjectBase.get<String>(this, 'rigContractor') as String?;
  @override
  set rigContractor(String? value) =>
      RealmObjectBase.set(this, 'rigContractor', value);

  @override
  String? get rigId => RealmObjectBase.get<String>(this, 'rigId') as String?;
  @override
  set rigId(String? value) => RealmObjectBase.set(this, 'rigId', value);

  @override
  String? get rigName =>
      RealmObjectBase.get<String>(this, 'rigName') as String?;
  @override
  set rigName(String? value) => RealmObjectBase.set(this, 'rigName', value);

  @override
  String? get status => RealmObjectBase.get<String>(this, 'status') as String?;
  @override
  set status(String? value) => RealmObjectBase.set(this, 'status', value);

  @override
  String? get truckUserMappingId =>
      RealmObjectBase.get<String>(this, 'truckUserMappingId') as String?;
  @override
  set truckUserMappingId(String? value) =>
      RealmObjectBase.set(this, 'truckUserMappingId', value);

  @override
  String? get wBSNumber =>
      RealmObjectBase.get<String>(this, 'wBSNumber') as String?;
  @override
  set wBSNumber(String? value) => RealmObjectBase.set(this, 'wBSNumber', value);

  @override
  Stream<RealmObjectChanges<Consignment>> get changes =>
      RealmObjectBase.getChanges<Consignment>(this);

  @override
  Consignment freeze() => RealmObjectBase.freezeObject<Consignment>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(Consignment._);
    return const SchemaObject(
        ObjectType.realmObject, Consignment, 'Consignment', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('activityId', RealmPropertyType.string, optional: true),
      SchemaProperty('bits', RealmPropertyType.object,
          linkTarget: 'Consignment_bits',
          collectionType: RealmCollectionType.list),
      SchemaProperty('cEC', RealmPropertyType.string, optional: true),
      SchemaProperty('consignmentId', RealmPropertyType.string, optional: true),
      SchemaProperty('createdAt', RealmPropertyType.timestamp, optional: true),
      SchemaProperty('createdBy', RealmPropertyType.string, optional: true),
      SchemaProperty('createdByFullName', RealmPropertyType.string,
          optional: true),
      SchemaProperty('customerEmail', RealmPropertyType.string, optional: true),
      SchemaProperty('customerId', RealmPropertyType.string, optional: true),
      SchemaProperty('customerName', RealmPropertyType.string, optional: true),
      SchemaProperty('designEngineer', RealmPropertyType.string,
          optional: true),
      SchemaProperty('digitalAttachments', RealmPropertyType.object,
          linkTarget: 'Consignment_digitalAttachments',
          collectionType: RealmCollectionType.list),
      SchemaProperty('finalPdf', RealmPropertyType.string, optional: true),
      SchemaProperty('gTQuoteId', RealmPropertyType.string, optional: true),
      SchemaProperty('isEmailSent', RealmPropertyType.bool, optional: true),
      SchemaProperty('manualAttachments', RealmPropertyType.object,
          linkTarget: 'Consignment_manualAttachments',
          collectionType: RealmCollectionType.list),
      SchemaProperty('modifiedAt', RealmPropertyType.timestamp, optional: true),
      SchemaProperty('modifiedBy', RealmPropertyType.string, optional: true),
      SchemaProperty('modifiedByFullName', RealmPropertyType.string,
          optional: true),
      SchemaProperty('operationId', RealmPropertyType.string, optional: true),
      SchemaProperty('projectId', RealmPropertyType.string, optional: true),
      SchemaProperty('rigContractor', RealmPropertyType.string, optional: true),
      SchemaProperty('rigId', RealmPropertyType.string, optional: true),
      SchemaProperty('rigName', RealmPropertyType.string, optional: true),
      SchemaProperty('status', RealmPropertyType.string, optional: true),
      SchemaProperty('truckUserMappingId', RealmPropertyType.string,
          optional: true),
      SchemaProperty('wBSNumber', RealmPropertyType.string, optional: true),
    ]);
  }
}

class ConsignmentBits extends _ConsignmentBits
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  ConsignmentBits({
    String? bom,
    String? iadcCode,
    bool? isBlocked,
    String? materialId,
    String? noOfRuns,
    String? pinConnection,
    String? serialNumber,
    String? size,
    String? status,
    String? transactionMessage,
    String? type,
    Iterable<ConsignmentBitsPriceBookDetails> priceBookDetails = const [],
  }) {
    RealmObjectBase.set(this, 'bom', bom);
    RealmObjectBase.set(this, 'iadcCode', iadcCode);
    RealmObjectBase.set(this, 'isBlocked', isBlocked);
    RealmObjectBase.set(this, 'materialId', materialId);
    RealmObjectBase.set(this, 'noOfRuns', noOfRuns);
    RealmObjectBase.set(this, 'pinConnection', pinConnection);
    RealmObjectBase.set(this, 'serialNumber', serialNumber);
    RealmObjectBase.set(this, 'size', size);
    RealmObjectBase.set(this, 'status', status);
    RealmObjectBase.set(this, 'transactionMessage', transactionMessage);
    RealmObjectBase.set(this, 'type', type);
    RealmObjectBase.set<RealmList<ConsignmentBitsPriceBookDetails>>(
        this,
        'priceBookDetails',
        RealmList<ConsignmentBitsPriceBookDetails>(priceBookDetails));
  }

  ConsignmentBits._();

  @override
  String? get bom => RealmObjectBase.get<String>(this, 'bom') as String?;
  @override
  set bom(String? value) => RealmObjectBase.set(this, 'bom', value);

  @override
  String? get iadcCode =>
      RealmObjectBase.get<String>(this, 'iadcCode') as String?;
  @override
  set iadcCode(String? value) => RealmObjectBase.set(this, 'iadcCode', value);

  @override
  bool? get isBlocked => RealmObjectBase.get<bool>(this, 'isBlocked') as bool?;
  @override
  set isBlocked(bool? value) => RealmObjectBase.set(this, 'isBlocked', value);

  @override
  String? get materialId =>
      RealmObjectBase.get<String>(this, 'materialId') as String?;
  @override
  set materialId(String? value) =>
      RealmObjectBase.set(this, 'materialId', value);

  @override
  String? get noOfRuns =>
      RealmObjectBase.get<String>(this, 'noOfRuns') as String?;
  @override
  set noOfRuns(String? value) => RealmObjectBase.set(this, 'noOfRuns', value);

  @override
  String? get pinConnection =>
      RealmObjectBase.get<String>(this, 'pinConnection') as String?;
  @override
  set pinConnection(String? value) =>
      RealmObjectBase.set(this, 'pinConnection', value);

  @override
  RealmList<ConsignmentBitsPriceBookDetails> get priceBookDetails =>
      RealmObjectBase.get<ConsignmentBitsPriceBookDetails>(
              this, 'priceBookDetails')
          as RealmList<ConsignmentBitsPriceBookDetails>;
  @override
  set priceBookDetails(
          covariant RealmList<ConsignmentBitsPriceBookDetails> value) =>
      throw RealmUnsupportedSetError();

  @override
  String? get serialNumber =>
      RealmObjectBase.get<String>(this, 'serialNumber') as String?;
  @override
  set serialNumber(String? value) =>
      RealmObjectBase.set(this, 'serialNumber', value);

  @override
  String? get size => RealmObjectBase.get<String>(this, 'size') as String?;
  @override
  set size(String? value) => RealmObjectBase.set(this, 'size', value);

  @override
  String? get status => RealmObjectBase.get<String>(this, 'status') as String?;
  @override
  set status(String? value) => RealmObjectBase.set(this, 'status', value);

  @override
  String? get transactionMessage =>
      RealmObjectBase.get<String>(this, 'transactionMessage') as String?;
  @override
  set transactionMessage(String? value) =>
      RealmObjectBase.set(this, 'transactionMessage', value);

  @override
  String? get type => RealmObjectBase.get<String>(this, 'type') as String?;
  @override
  set type(String? value) => RealmObjectBase.set(this, 'type', value);

  @override
  Stream<RealmObjectChanges<ConsignmentBits>> get changes =>
      RealmObjectBase.getChanges<ConsignmentBits>(this);

  @override
  ConsignmentBits freeze() =>
      RealmObjectBase.freezeObject<ConsignmentBits>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(ConsignmentBits._);
    return const SchemaObject(
        ObjectType.embeddedObject, ConsignmentBits, 'Consignment_bits', [
      SchemaProperty('bom', RealmPropertyType.string, optional: true),
      SchemaProperty('iadcCode', RealmPropertyType.string, optional: true),
      SchemaProperty('isBlocked', RealmPropertyType.bool, optional: true),
      SchemaProperty('materialId', RealmPropertyType.string, optional: true),
      SchemaProperty('noOfRuns', RealmPropertyType.string, optional: true),
      SchemaProperty('pinConnection', RealmPropertyType.string, optional: true),
      SchemaProperty('priceBookDetails', RealmPropertyType.object,
          linkTarget: 'Consignment_bits_priceBookDetails',
          collectionType: RealmCollectionType.list),
      SchemaProperty('serialNumber', RealmPropertyType.string, optional: true),
      SchemaProperty('size', RealmPropertyType.string, optional: true),
      SchemaProperty('status', RealmPropertyType.string, optional: true),
      SchemaProperty('transactionMessage', RealmPropertyType.string,
          optional: true),
      SchemaProperty('type', RealmPropertyType.string, optional: true),
    ]);
  }
}

class ConsignmentManualAttachments extends _ConsignmentManualAttachments
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  ConsignmentManualAttachments({
    Iterable<String> draftQuote = const [],
  }) {
    RealmObjectBase.set<RealmList<String>>(
        this, 'draftQuote', RealmList<String>(draftQuote));
  }

  ConsignmentManualAttachments._();

  @override
  RealmList<String> get draftQuote =>
      RealmObjectBase.get<String>(this, 'draftQuote') as RealmList<String>;
  @override
  set draftQuote(covariant RealmList<String> value) =>
      throw RealmUnsupportedSetError();

  @override
  Stream<RealmObjectChanges<ConsignmentManualAttachments>> get changes =>
      RealmObjectBase.getChanges<ConsignmentManualAttachments>(this);

  @override
  ConsignmentManualAttachments freeze() =>
      RealmObjectBase.freezeObject<ConsignmentManualAttachments>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(ConsignmentManualAttachments._);
    return const SchemaObject(ObjectType.embeddedObject,
        ConsignmentManualAttachments, 'Consignment_manualAttachments', [
      SchemaProperty('draftQuote', RealmPropertyType.string,
          collectionType: RealmCollectionType.list),
    ]);
  }
}

class ConsignmentDigitalAttachments extends _ConsignmentDigitalAttachments
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  ConsignmentDigitalAttachments({
    Iterable<String> draftQuote = const [],
  }) {
    RealmObjectBase.set<RealmList<String>>(
        this, 'draftQuote', RealmList<String>(draftQuote));
  }

  ConsignmentDigitalAttachments._();

  @override
  RealmList<String> get draftQuote =>
      RealmObjectBase.get<String>(this, 'draftQuote') as RealmList<String>;
  @override
  set draftQuote(covariant RealmList<String> value) =>
      throw RealmUnsupportedSetError();

  @override
  Stream<RealmObjectChanges<ConsignmentDigitalAttachments>> get changes =>
      RealmObjectBase.getChanges<ConsignmentDigitalAttachments>(this);

  @override
  ConsignmentDigitalAttachments freeze() =>
      RealmObjectBase.freezeObject<ConsignmentDigitalAttachments>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(ConsignmentDigitalAttachments._);
    return const SchemaObject(ObjectType.embeddedObject,
        ConsignmentDigitalAttachments, 'Consignment_digitalAttachments', [
      SchemaProperty('draftQuote', RealmPropertyType.string,
          collectionType: RealmCollectionType.list),
    ]);
  }
}

class ConsignmentBitsPriceBookDetails extends _ConsignmentBitsPriceBookDetails
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  ConsignmentBitsPriceBookDetails({
    double? bestPrice,
    String? comments,
    String? commercialAgreementId,
    String? currency,
    String? customerContactName,
    double? discountAmount,
    int? discountPercentage,
    String? hlMaterialNumber,
    String? llMaterialNumber,
    String? priceBookId,
    String? pricePerUnit,
    String? pricingId,
    String? unitDrilled,
    String? unitPrice,
    String? uom,
    String? lineCondition,
  }) {
    RealmObjectBase.set(this, 'bestPrice', bestPrice);
    RealmObjectBase.set(this, 'comments', comments);
    RealmObjectBase.set(this, 'commercialAgreementId', commercialAgreementId);
    RealmObjectBase.set(this, 'currency', currency);
    RealmObjectBase.set(this, 'customerContactName', customerContactName);
    RealmObjectBase.set(this, 'discountAmount', discountAmount);
    RealmObjectBase.set(this, 'discountPercentage', discountPercentage);
    RealmObjectBase.set(this, 'hlMaterialNumber', hlMaterialNumber);
    RealmObjectBase.set(this, 'llMaterialNumber', llMaterialNumber);
    RealmObjectBase.set(this, 'priceBookId', priceBookId);
    RealmObjectBase.set(this, 'pricePerUnit', pricePerUnit);
    RealmObjectBase.set(this, 'pricingId', pricingId);
    RealmObjectBase.set(this, 'unitDrilled', unitDrilled);
    RealmObjectBase.set(this, 'unitPrice', unitPrice);
    RealmObjectBase.set(this, 'uom', uom);
    RealmObjectBase.set(this, 'lineCondition', lineCondition);
  }

  ConsignmentBitsPriceBookDetails._();

  @override
  double? get bestPrice =>
      RealmObjectBase.get<double>(this, 'bestPrice') as double?;
  @override
  set bestPrice(double? value) => RealmObjectBase.set(this, 'bestPrice', value);

  @override
  String? get comments =>
      RealmObjectBase.get<String>(this, 'comments') as String?;
  @override
  set comments(String? value) => RealmObjectBase.set(this, 'comments', value);

  @override
  String? get commercialAgreementId =>
      RealmObjectBase.get<String>(this, 'commercialAgreementId') as String?;
  @override
  set commercialAgreementId(String? value) =>
      RealmObjectBase.set(this, 'commercialAgreementId', value);

  @override
  String? get currency =>
      RealmObjectBase.get<String>(this, 'currency') as String?;
  @override
  set currency(String? value) => RealmObjectBase.set(this, 'currency', value);

  @override
  String? get customerContactName =>
      RealmObjectBase.get<String>(this, 'customerContactName') as String?;
  @override
  set customerContactName(String? value) =>
      RealmObjectBase.set(this, 'customerContactName', value);

  @override
  double? get discountAmount =>
      RealmObjectBase.get<double>(this, 'discountAmount') as double?;
  @override
  set discountAmount(double? value) =>
      RealmObjectBase.set(this, 'discountAmount', value);

  @override
  int? get discountPercentage =>
      RealmObjectBase.get<int>(this, 'discountPercentage') as int?;
  @override
  set discountPercentage(int? value) =>
      RealmObjectBase.set(this, 'discountPercentage', value);

  @override
  String? get hlMaterialNumber =>
      RealmObjectBase.get<String>(this, 'hlMaterialNumber') as String?;
  @override
  set hlMaterialNumber(String? value) =>
      RealmObjectBase.set(this, 'hlMaterialNumber', value);

  @override
  String? get llMaterialNumber =>
      RealmObjectBase.get<String>(this, 'llMaterialNumber') as String?;
  @override
  set llMaterialNumber(String? value) =>
      RealmObjectBase.set(this, 'llMaterialNumber', value);

  @override
  String? get priceBookId =>
      RealmObjectBase.get<String>(this, 'priceBookId') as String?;
  @override
  set priceBookId(String? value) =>
      RealmObjectBase.set(this, 'priceBookId', value);

  @override
  String? get pricePerUnit =>
      RealmObjectBase.get<String>(this, 'pricePerUnit') as String?;
  @override
  set pricePerUnit(String? value) =>
      RealmObjectBase.set(this, 'pricePerUnit', value);

  @override
  String? get pricingId =>
      RealmObjectBase.get<String>(this, 'pricingId') as String?;
  @override
  set pricingId(String? value) => RealmObjectBase.set(this, 'pricingId', value);

  @override
  String? get unitDrilled =>
      RealmObjectBase.get<String>(this, 'unitDrilled') as String?;
  @override
  set unitDrilled(String? value) =>
      RealmObjectBase.set(this, 'unitDrilled', value);

  @override
  String? get unitPrice =>
      RealmObjectBase.get<String>(this, 'unitPrice') as String?;
  @override
  set unitPrice(String? value) => RealmObjectBase.set(this, 'unitPrice', value);

  @override
  String? get uom => RealmObjectBase.get<String>(this, 'uom') as String?;
  @override
  set uom(String? value) => RealmObjectBase.set(this, 'uom', value);

  @override
  String? get lineCondition =>
      RealmObjectBase.get<String>(this, 'lineCondition') as String?;
  @override
  set lineCondition(String? value) =>
      RealmObjectBase.set(this, 'lineCondition', value);

  @override
  Stream<RealmObjectChanges<ConsignmentBitsPriceBookDetails>> get changes =>
      RealmObjectBase.getChanges<ConsignmentBitsPriceBookDetails>(this);

  @override
  ConsignmentBitsPriceBookDetails freeze() =>
      RealmObjectBase.freezeObject<ConsignmentBitsPriceBookDetails>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(ConsignmentBitsPriceBookDetails._);
    return const SchemaObject(ObjectType.embeddedObject,
        ConsignmentBitsPriceBookDetails, 'Consignment_bits_priceBookDetails', [
      SchemaProperty('bestPrice', RealmPropertyType.double, optional: true),
      SchemaProperty('comments', RealmPropertyType.string, optional: true),
      SchemaProperty('commercialAgreementId', RealmPropertyType.string,
          optional: true),
      SchemaProperty('currency', RealmPropertyType.string, optional: true),
      SchemaProperty('customerContactName', RealmPropertyType.string,
          optional: true),
      SchemaProperty('discountAmount', RealmPropertyType.double,
          optional: true),
      SchemaProperty('discountPercentage', RealmPropertyType.int,
          optional: true),
      SchemaProperty('hlMaterialNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('llMaterialNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('priceBookId', RealmPropertyType.string, optional: true),
      SchemaProperty('pricePerUnit', RealmPropertyType.string, optional: true),
      SchemaProperty('pricingId', RealmPropertyType.string, optional: true),
      SchemaProperty('unitDrilled', RealmPropertyType.string, optional: true),
      SchemaProperty('unitPrice', RealmPropertyType.string, optional: true),
      SchemaProperty('uom', RealmPropertyType.string, optional: true),
      SchemaProperty('lineCondition', RealmPropertyType.string, optional: true),
    ]);
  }
}
