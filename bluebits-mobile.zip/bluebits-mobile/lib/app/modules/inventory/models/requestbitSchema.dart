import 'package:realm/realm.dart';
part 'requestbitSchema.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.
@RealmModel()
class _RequestBit {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;
  String? bitType;
  String? comments;
  String? customerName;
  bool? isEmailSent;
  String? jobType;
  String? probability;
  DateTime? requestBitByDate;
  String? requestedBy;
  String? rigName;
  String? size;
  String? truckUserMappingId;
}
