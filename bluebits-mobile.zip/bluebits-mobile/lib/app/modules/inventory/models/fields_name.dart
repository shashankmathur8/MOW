import 'package:realm/realm.dart';
part 'fields_name.g.dart';


// NOTE: These Realm models are private and therefore should be copied into the same .dart file.

@RealmModel()
class _FieldsName {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;

  String? fields;
}
