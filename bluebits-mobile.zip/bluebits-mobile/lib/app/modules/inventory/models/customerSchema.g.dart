// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'customerSchema.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class Customer extends _Customer
    with RealmEntity, RealmObjectBase, RealmObject {
  Customer(
    ObjectId? id, {
    String? addressLine1,
    String? addressLine2,
    String? addressLine3,
    String? addressType,
    String? category,
    String? city,
    String? country,
    String? countryCode,
    String? county,
    DateTime? createdDate,
    String? customerReferenceId,
    bool? isActive,
    DateTime? lastUpdatedDate,
    String? name,
    String? number,
    String? parentId,
    String? postalCode,
    String? sourceSystem,
    String? state,
    String? stateCode,
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'addressLine1', addressLine1);
    RealmObjectBase.set(this, 'addressLine2', addressLine2);
    RealmObjectBase.set(this, 'addressLine3', addressLine3);
    RealmObjectBase.set(this, 'addressType', addressType);
    RealmObjectBase.set(this, 'category', category);
    RealmObjectBase.set(this, 'city', city);
    RealmObjectBase.set(this, 'country', country);
    RealmObjectBase.set(this, 'countryCode', countryCode);
    RealmObjectBase.set(this, 'county', county);
    RealmObjectBase.set(this, 'createdDate', createdDate);
    RealmObjectBase.set(this, 'customerReferenceId', customerReferenceId);
    RealmObjectBase.set(this, 'isActive', isActive);
    RealmObjectBase.set(this, 'lastUpdatedDate', lastUpdatedDate);
    RealmObjectBase.set(this, 'name', name);
    RealmObjectBase.set(this, 'number', number);
    RealmObjectBase.set(this, 'parentId', parentId);
    RealmObjectBase.set(this, 'postalCode', postalCode);
    RealmObjectBase.set(this, 'sourceSystem', sourceSystem);
    RealmObjectBase.set(this, 'state', state);
    RealmObjectBase.set(this, 'stateCode', stateCode);
  }

  Customer._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get addressLine1 =>
      RealmObjectBase.get<String>(this, 'addressLine1') as String?;
  @override
  set addressLine1(String? value) =>
      RealmObjectBase.set(this, 'addressLine1', value);

  @override
  String? get addressLine2 =>
      RealmObjectBase.get<String>(this, 'addressLine2') as String?;
  @override
  set addressLine2(String? value) =>
      RealmObjectBase.set(this, 'addressLine2', value);

  @override
  String? get addressLine3 =>
      RealmObjectBase.get<String>(this, 'addressLine3') as String?;
  @override
  set addressLine3(String? value) =>
      RealmObjectBase.set(this, 'addressLine3', value);

  @override
  String? get addressType =>
      RealmObjectBase.get<String>(this, 'addressType') as String?;
  @override
  set addressType(String? value) =>
      RealmObjectBase.set(this, 'addressType', value);

  @override
  String? get category =>
      RealmObjectBase.get<String>(this, 'category') as String?;
  @override
  set category(String? value) => RealmObjectBase.set(this, 'category', value);

  @override
  String? get city => RealmObjectBase.get<String>(this, 'city') as String?;
  @override
  set city(String? value) => RealmObjectBase.set(this, 'city', value);

  @override
  String? get country =>
      RealmObjectBase.get<String>(this, 'country') as String?;
  @override
  set country(String? value) => RealmObjectBase.set(this, 'country', value);

  @override
  String? get countryCode =>
      RealmObjectBase.get<String>(this, 'countryCode') as String?;
  @override
  set countryCode(String? value) =>
      RealmObjectBase.set(this, 'countryCode', value);

  @override
  String? get county => RealmObjectBase.get<String>(this, 'county') as String?;
  @override
  set county(String? value) => RealmObjectBase.set(this, 'county', value);

  @override
  DateTime? get createdDate =>
      RealmObjectBase.get<DateTime>(this, 'createdDate') as DateTime?;
  @override
  set createdDate(DateTime? value) =>
      RealmObjectBase.set(this, 'createdDate', value);

  @override
  String? get customerReferenceId =>
      RealmObjectBase.get<String>(this, 'customerReferenceId') as String?;
  @override
  set customerReferenceId(String? value) =>
      RealmObjectBase.set(this, 'customerReferenceId', value);

  @override
  bool? get isActive => RealmObjectBase.get<bool>(this, 'isActive') as bool?;
  @override
  set isActive(bool? value) => RealmObjectBase.set(this, 'isActive', value);

  @override
  DateTime? get lastUpdatedDate =>
      RealmObjectBase.get<DateTime>(this, 'lastUpdatedDate') as DateTime?;
  @override
  set lastUpdatedDate(DateTime? value) =>
      RealmObjectBase.set(this, 'lastUpdatedDate', value);

  @override
  String? get name => RealmObjectBase.get<String>(this, 'name') as String?;
  @override
  set name(String? value) => RealmObjectBase.set(this, 'name', value);

  @override
  String? get number => RealmObjectBase.get<String>(this, 'number') as String?;
  @override
  set number(String? value) => RealmObjectBase.set(this, 'number', value);

  @override
  String? get parentId =>
      RealmObjectBase.get<String>(this, 'parentId') as String?;
  @override
  set parentId(String? value) => RealmObjectBase.set(this, 'parentId', value);

  @override
  String? get postalCode =>
      RealmObjectBase.get<String>(this, 'postalCode') as String?;
  @override
  set postalCode(String? value) =>
      RealmObjectBase.set(this, 'postalCode', value);

  @override
  String? get sourceSystem =>
      RealmObjectBase.get<String>(this, 'sourceSystem') as String?;
  @override
  set sourceSystem(String? value) =>
      RealmObjectBase.set(this, 'sourceSystem', value);

  @override
  String? get state => RealmObjectBase.get<String>(this, 'state') as String?;
  @override
  set state(String? value) => RealmObjectBase.set(this, 'state', value);

  @override
  String? get stateCode =>
      RealmObjectBase.get<String>(this, 'stateCode') as String?;
  @override
  set stateCode(String? value) => RealmObjectBase.set(this, 'stateCode', value);

  @override
  Stream<RealmObjectChanges<Customer>> get changes =>
      RealmObjectBase.getChanges<Customer>(this);

  @override
  Customer freeze() => RealmObjectBase.freezeObject<Customer>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(Customer._);
    return const SchemaObject(ObjectType.realmObject, Customer, 'Customer', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('addressLine1', RealmPropertyType.string, optional: true),
      SchemaProperty('addressLine2', RealmPropertyType.string, optional: true),
      SchemaProperty('addressLine3', RealmPropertyType.string, optional: true),
      SchemaProperty('addressType', RealmPropertyType.string, optional: true),
      SchemaProperty('category', RealmPropertyType.string, optional: true),
      SchemaProperty('city', RealmPropertyType.string, optional: true),
      SchemaProperty('country', RealmPropertyType.string, optional: true),
      SchemaProperty('countryCode', RealmPropertyType.string, optional: true),
      SchemaProperty('county', RealmPropertyType.string, optional: true),
      SchemaProperty('createdDate', RealmPropertyType.timestamp,
          optional: true),
      SchemaProperty('customerReferenceId', RealmPropertyType.string,
          optional: true),
      SchemaProperty('isActive', RealmPropertyType.bool, optional: true),
      SchemaProperty('lastUpdatedDate', RealmPropertyType.timestamp,
          optional: true),
      SchemaProperty('name', RealmPropertyType.string, optional: true),
      SchemaProperty('number', RealmPropertyType.string, optional: true),
      SchemaProperty('parentId', RealmPropertyType.string, optional: true),
      SchemaProperty('postalCode', RealmPropertyType.string, optional: true),
      SchemaProperty('sourceSystem', RealmPropertyType.string, optional: true),
      SchemaProperty('state', RealmPropertyType.string, optional: true),
      SchemaProperty('stateCode', RealmPropertyType.string, optional: true),
    ]);
  }
}
