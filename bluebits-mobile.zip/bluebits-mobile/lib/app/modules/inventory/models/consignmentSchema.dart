import 'package:realm/realm.dart';
part 'consignmentSchema.g.dart';
@RealmModel()
class _Consignment {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;

  String? activityId;

  late List<_ConsignmentBits> bits;

  String? cEC;

  String? consignmentId;

  DateTime? createdAt;

  String? createdBy;

  String? createdByFullName;

  String? customerEmail;

  String? customerId;

  String? customerName;

  String? designEngineer;

  late List<_ConsignmentDigitalAttachments> digitalAttachments;

  String? finalPdf;

  String? gTQuoteId;

  bool? isEmailSent;

  late List<_ConsignmentManualAttachments> manualAttachments;

  DateTime? modifiedAt;

  String? modifiedBy;

  String? modifiedByFullName;

  String? operationId;

  String? projectId;

  String? rigContractor;

  String? rigId;

  String? rigName;

  String? status;

  String? truckUserMappingId;

  String? wBSNumber;
}


@RealmModel(ObjectType.embeddedObject)
@MapTo('Consignment_bits')
class _ConsignmentBits {
  String? bom;

  String? iadcCode;

  bool? isBlocked;

  String? materialId;

  String? noOfRuns;

  String? pinConnection;

  late List<_ConsignmentBitsPriceBookDetails> priceBookDetails;

  String? serialNumber;

  String? size;

  String? status;

  String? transactionMessage;

  String? type;
}
// NOTE: These Realm models are private and therefore should be copied into the same .dart file.

@RealmModel(ObjectType.embeddedObject)
@MapTo('Consignment_manualAttachments')
class _ConsignmentManualAttachments {
  late List<String> draftQuote;
}


@RealmModel(ObjectType.embeddedObject)
@MapTo('Consignment_digitalAttachments')
class _ConsignmentDigitalAttachments {
  late List<String> draftQuote;
}


@RealmModel(ObjectType.embeddedObject)
@MapTo('Consignment_bits_priceBookDetails')
class _ConsignmentBitsPriceBookDetails {
  double? bestPrice;

  String? comments;

  String? commercialAgreementId;

  String? currency;

  String? customerContactName;

  double? discountAmount;

  int? discountPercentage;

  String? hlMaterialNumber;

  String? llMaterialNumber;

  String? priceBookId;

  String? pricePerUnit;

  String? pricingId;

  String? unitDrilled;

  String? unitPrice;

  String? uom;

  String? lineCondition;
}



