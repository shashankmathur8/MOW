// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'storagelocSchema.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class StorageLocation extends _StorageLocation
    with RealmEntity, RealmObjectBase, RealmObject {
  StorageLocation(
    ObjectId? id, {
    String? interfaceDate,
    int? isActive,
    String? plantId,
    String? sourceSystem,
    String? storageLocationDescription,
    String? storageLocationId,
    String? storageLocationType,
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'interfaceDate', interfaceDate);
    RealmObjectBase.set(this, 'isActive', isActive);
    RealmObjectBase.set(this, 'plantId', plantId);
    RealmObjectBase.set(this, 'sourceSystem', sourceSystem);
    RealmObjectBase.set(
        this, 'storageLocationDescription', storageLocationDescription);
    RealmObjectBase.set(this, 'storageLocationId', storageLocationId);
    RealmObjectBase.set(this, 'storageLocationType', storageLocationType);
  }

  StorageLocation._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get interfaceDate =>
      RealmObjectBase.get<String>(this, 'interfaceDate') as String?;
  @override
  set interfaceDate(String? value) =>
      RealmObjectBase.set(this, 'interfaceDate', value);

  @override
  int? get isActive => RealmObjectBase.get<int>(this, 'isActive') as int?;
  @override
  set isActive(int? value) => RealmObjectBase.set(this, 'isActive', value);

  @override
  String? get plantId =>
      RealmObjectBase.get<String>(this, 'plantId') as String?;
  @override
  set plantId(String? value) => RealmObjectBase.set(this, 'plantId', value);

  @override
  String? get sourceSystem =>
      RealmObjectBase.get<String>(this, 'sourceSystem') as String?;
  @override
  set sourceSystem(String? value) =>
      RealmObjectBase.set(this, 'sourceSystem', value);

  @override
  String? get storageLocationDescription =>
      RealmObjectBase.get<String>(this, 'storageLocationDescription')
          as String?;
  @override
  set storageLocationDescription(String? value) =>
      RealmObjectBase.set(this, 'storageLocationDescription', value);

  @override
  String? get storageLocationId =>
      RealmObjectBase.get<String>(this, 'storageLocationId') as String?;
  @override
  set storageLocationId(String? value) =>
      RealmObjectBase.set(this, 'storageLocationId', value);

  @override
  String? get storageLocationType =>
      RealmObjectBase.get<String>(this, 'storageLocationType') as String?;
  @override
  set storageLocationType(String? value) =>
      RealmObjectBase.set(this, 'storageLocationType', value);

  @override
  Stream<RealmObjectChanges<StorageLocation>> get changes =>
      RealmObjectBase.getChanges<StorageLocation>(this);

  @override
  StorageLocation freeze() =>
      RealmObjectBase.freezeObject<StorageLocation>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(StorageLocation._);
    return const SchemaObject(
        ObjectType.realmObject, StorageLocation, 'StorageLocation', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('interfaceDate', RealmPropertyType.string, optional: true),
      SchemaProperty('isActive', RealmPropertyType.int, optional: true),
      SchemaProperty('plantId', RealmPropertyType.string, optional: true),
      SchemaProperty('sourceSystem', RealmPropertyType.string, optional: true),
      SchemaProperty('storageLocationDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('storageLocationId', RealmPropertyType.string,
          optional: true),
      SchemaProperty('storageLocationType', RealmPropertyType.string,
          optional: true),
    ]);
  }
}
