// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'deviceTokenStorage.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class DeviceTokenStorage extends _DeviceTokenStorage
    with RealmEntity, RealmObjectBase, RealmObject {
  DeviceTokenStorage(
    ObjectId? id, {
    String? userName,
    String? truckUserMappingId,
    String? deviceID,
    String? deviceToken,
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'userName', userName);
    RealmObjectBase.set(this, 'truckUserMappingId', truckUserMappingId);
    RealmObjectBase.set(this, 'deviceID', deviceID);
    RealmObjectBase.set(this, 'deviceToken', deviceToken);
  }

  DeviceTokenStorage._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get userName =>
      RealmObjectBase.get<String>(this, 'userName') as String?;
  @override
  set userName(String? value) => RealmObjectBase.set(this, 'userName', value);

  @override
  String? get truckUserMappingId =>
      RealmObjectBase.get<String>(this, 'truckUserMappingId') as String?;
  @override
  set truckUserMappingId(String? value) =>
      RealmObjectBase.set(this, 'truckUserMappingId', value);

  @override
  String? get deviceID =>
      RealmObjectBase.get<String>(this, 'deviceID') as String?;
  @override
  set deviceID(String? value) => RealmObjectBase.set(this, 'deviceID', value);

  @override
  String? get deviceToken =>
      RealmObjectBase.get<String>(this, 'deviceToken') as String?;
  @override
  set deviceToken(String? value) =>
      RealmObjectBase.set(this, 'deviceToken', value);

  @override
  Stream<RealmObjectChanges<DeviceTokenStorage>> get changes =>
      RealmObjectBase.getChanges<DeviceTokenStorage>(this);

  @override
  DeviceTokenStorage freeze() =>
      RealmObjectBase.freezeObject<DeviceTokenStorage>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(DeviceTokenStorage._);
    return const SchemaObject(
        ObjectType.realmObject, DeviceTokenStorage, 'DeviceTokenStorage', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('userName', RealmPropertyType.string, optional: true),
      SchemaProperty('truckUserMappingId', RealmPropertyType.string,
          optional: true),
      SchemaProperty('deviceID', RealmPropertyType.string, optional: true),
      SchemaProperty('deviceToken', RealmPropertyType.string, optional: true),
    ]);
  }
}
