import 'dart:convert';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:get/get.dart';
import 'package:realm/realm.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:slb_gt_mobile/app/core/common_widgets/toast_message.dart';
import 'package:slb_gt_mobile/app/core/utils/logger_common.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';
import 'package:slb_gt_mobile/app/core/base/base_controller.dart';
import 'package:slb_gt_mobile/app/core/values/app_utils.dart';
import 'package:slb_gt_mobile/app/data/model/request/bit_movment_param.dart';
import 'package:slb_gt_mobile/app/data/model/response/bit_movement_response.dart';
import 'package:slb_gt_mobile/app/data/repository/inventory_repo.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/bitState.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/filter_checkbox_item.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/recentSearchesSchema.dart';
import 'package:slb_gt_mobile/app/network/exceptions/app_exception.dart';

import '../../../common_binding/realm_initial.dart';
import '../../../core/connectivity_utils/connectivity_controller.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/preference_constants.dart';
import '../../../data/model/supporting_model/draggablecards_model.dart';
import '../../../utils/msal_login.dart';
import '../../login/controller/login_controller.dart';
import '../models/truckUserMapping.dart';

class InventoryController extends BaseController {
  final InventoryRepo _repository = Get.find(tag: (InventoryRepo).toString());
  final LoginController loginController = Get.find();
  final ConnectivityController connectivityController = Get.find();

  var entry;
  late FirebaseMessaging _messaging;
  late bool isSortEnable = true;
  late String userEmail;
  late String userName;
  FocusNode focusNode = FocusNode();

  var noBits;

  var userSloc = "4041".obs;
  var numberOfBits = "4041".obs;
  var plantID = "".obs;
  var selectedList;
  late var x;
  var dynamicOpacity = 1.0.obs;
  var checkColumnLength = 0.obs;

  var dynamicOpacity2 = 1.0.obs;
  var noOfSelectedBits = 0.obs;
  var defaultTab = AppValues.myTruckTabStr.obs;
  var sloc = "".obs;

  late RealmResults<TruckUserMapping> userDetailsList;

  late RealmResults<RecentSearchesData> recentSearch;

  late PushNotification _notificationInfo;

  var totalNotifications = 0;

  late List<Bit> myDistrictList;

  late List<Bit> myTruckList;

  late List<Bit> otherDistrictList;

  late Map<String, dynamic> fieldsName;

  TextEditingController searchController = TextEditingController();
  final _columnList = [].obs;

  int bottomTabNotificationIndex = 0;

  get columnList => _columnList.value;

  set columnList(value) {
    _columnList.value = value;
  }

  getCheckedColumLength(InventoryController inventoryController) {
    for (int i = 0; i < inventoryController.columnList.length; i++) {
      if (inventoryController.columnList[i].isEnable) {
        inventoryController.checkColumnLength.value =
            inventoryController.checkColumnLength.value + 1;
      }
    }
  }

  resetColumnList(InventoryController inventoryController, bool isSet0) {
    inventoryController.fetchFiledName();
    inventoryController.refreshUI();
    inventoryController.resetSelectedColumn();
    inventoryController.getCheckedColumLength(inventoryController);
    /* if(!isSet0) {
      inventoryController.checkColumnLength.value = 0;
    }*/
    Get.back();
    //Get.back();
  }

  List<Bit> syncedbits = [];
  final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
  late SharedPreferences prefs;
  var isLoading = false;
  var _isRefresh = false;
  var ListIndex = 0.obs;
  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());

  bool tab = false;

  late RealmResults<Bit> bitsList;
  late List<BitState> bitsState;
  final _bitsList = <Bit>[].obs;

  List<Bit> get allBitList => _bitsList.value;

  set allBitList(value) {
    _bitsList.value = value;
  }

  var storageLocations;

  void setMyTruckBitList() {
    LoginController loginController = Get.find();
    myTruckList = bitsList.query('storageLoc == \$0', [
      loginController.userDetailsList.first.storageLocationId.toString()
    ]).toList();
    allBitList = myTruckList;
    numberOfBits.value = myTruckList.length.toString();
    userSloc.value =
        loginController.userDetailsList.first.storageLocationId.toString();
    getCategory();
  }

  void updateSyncedBitsList(List<Bit> bits) {
    print("dta before removing ${_bitsList.length}");
    late List<BitState> tempbitsState;
    bits.forEach((element) {
      bitsState.add(BitState(ObjectId(),
          bitSerialNumber: element.serialNumber,
          isBlocked: true,
          reasonForBlock: "Migration"));
    });

    print("dta after removing ${_bitsList.length}");
    unSelectBits();
    numberOfBits.value = allBitList.length.toString();
    syncedbits = syncedbits + bits;
  }

  List<Bit> getSyncedBitsList() {
    return syncedbits;
  }

  var swapList = [].obs;

  void _showToast(BuildContext context, String notification) {
    final scaffold = ScaffoldMessenger.of(context);
    scaffold.showSnackBar(
      SnackBar(
        content: Text('${notification}'),
        action: SnackBarAction(
            label: 'UNDO', onPressed: scaffold.hideCurrentSnackBar),
      ),
    );
  }

  void insertDeviceToken(String fcmToken, String email, ObjectId? id) {
    realm.insertDeviceID(fcmToken, email, id);
  }

  checkForInitialMessage() async {
    await Firebase.initializeApp();
    RemoteMessage? initialMessage =
        await FirebaseMessaging.instance.getInitialMessage();

    if (initialMessage != null) {
      PushNotification notification = PushNotification(
        title: initialMessage.notification?.title,
        body: initialMessage.notification?.body,
      );
      _notificationInfo = notification;
      totalNotifications++;
    }
  }

  registerNotification(String email, ObjectId? id) async {
    // 1. Initialize the Firebase app
    await Firebase.initializeApp();

    // 2. Instantiate Firebase Messaging
    Future.delayed(Duration(seconds: 5));
    _messaging = await FirebaseMessaging.instance;
    await _messaging.setForegroundNotificationPresentationOptions(badge: true, alert: true, sound: true);
    final fcmToken = await _messaging.getToken();

    // 3. On iOS, this helps to take the user permissions
    NotificationSettings settings = await _messaging.requestPermission(
      alert: true,
      badge: true,
      provisional: false,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      print('${fcmToken}');

      insertDeviceToken(fcmToken.toString(), email, id);
      FirebaseMessaging.onMessage.listen((RemoteMessage message) {
        // Parse the message received
        PushNotification notification = PushNotification(
          title: message.notification?.title,
          body: message.notification?.body,
          dataTitle: message.data['title'],
          dataBody: message.data['body'],
        );

        _notificationInfo = notification;
        totalNotifications++;
        print(notification.title);
      });
    } else {
      print('User declined or has not accepted permission');
    }
  }

  void hitBitMovementApi(bool isInternetConnected) {
    ApplicationLogger().printInfo(
        'hitBitMovementApi:- $isInternetConnected', 'hitBitMovementApi()');

    printLog('hitBitMovementApi() Start:- ${DateTime.now()}');
    if (isInternetConnected) {
      printLog('hitBitMovementApi() Start:- true');
      if (prefs.getBool(PreferenceConstants.isMovementHappen)!) {
        var queryParam = BitMovementParam(
            requestedBy: prefs.getString(PreferenceConstants.userEmail)!,
            truckUserMappingId:
                prefs.getString(PreferenceConstants.userTruckMapping)!);
        var bitMovementService = _repository.bitMovement(queryParam);
        callDataService(bitMovementService,
            onSuccess: _handleProjectListResponseSuccess,
            onError: _handleBitMovmentError);
      }
    } else if (prefs.getBool(PreferenceConstants.isMovementHappen)!) {
      printLog('hitBitMovementApi() Start:- false');
      showToastMsg(Get.context, AppStrings.noInternet, ToastStatus.info);
    }
    printLog('hitBitMovementApi() End:- ${DateTime.now()}');
  }

  String joinSerialNumber(List<Bit>? bitsList) {
    List<String> joinSerialNumber = [];
    bitsList?.forEach((element) {
      joinSerialNumber.add(element.serialNumber ?? '');
    });
    String serialNumbers = joinSerialNumber.isNotEmpty && joinSerialNumber.length > 3 ? '${joinSerialNumber.length}' : joinSerialNumber.join(', ');
    printLog('joinSerialNumber:- $serialNumbers');

    return serialNumbers;
  }

  void _handleProjectListResponseSuccess(BitMovementResponseModel response) {
    var repoList = response.message;
    prefs.setBool(PreferenceConstants.isMovementHappen, false);
  }

  void _handleBitMovmentError(Exception response) async {
    if (response is AppCustomException) {
      if (response.message.contains("401")) {
        await AADAuthentication.instance.acquireTokenSilently();
        hitBitMovementApi(true);
      }
    }
    prefs.setBool(PreferenceConstants.isMovementHappen, false);
  }

  var isSelectionEnabled = false;

  var numberOfSelectedBits = 0;
  var maxBitSelectionAllowed = 10;

  var consignButtonHeight = 34.0;
  var isSearchEnabled = false;

  var consignButtonWidth = 98.0;

  var moveToTruckButtonHeight = 34.0;

  var moveToTruckButtonWidth = 125.0;

  var dotsWidth = 20.0;

  var dotsHeight = 20.0;
  List<String> localSearches = [];

  Map<String, dynamic> columnSettingsList = <String, dynamic>{};

  void init() {
    fetchData();
    fetchFiledName();

  }



  fetchData() async {
    bitsList = realm.getBits();
    fetchBitStateCollection();
    prefs = await _prefs;

    bitsList = realm.getBits();
    recentSearch = realm.getRecentSearches();
    var deviceToken = realm.getDeviceToken();
    numberOfBits.value = allBitList.length.toString();
    swapList.value = bitsList.toList();
    // allBitList = swapList.value;
    getAllBitsListBasedOnTab(query: "");
    storageLocations = realm.getOtherTrucksinSamePlant(
        loginController.userDetailsList.first.plantId.toString(),loginController.userDetailsList.first.storageLocationId.toString()).toList();

    unSelectBits();

    checkForInitialMessage();

    updateLocalSearcher();
  }

  fetchBitStateCollection() {
    bitsState = realm.getBitsState().toList();
  }

  fetchFiledName() async {
    var fieldsJson = realm.getFields();
    var rawJson = fieldsJson.toList()[0].fields ?? '';
    fieldsName = jsonDecode(rawJson) as Map<String, dynamic>;
    var count = 0;
    columnList.clear();
    fieldsName.forEach((key, value) {
      columnList.add(DraggableCardsModel(
          isEnable: ++count <= 8 ? true : false, key: key, title: value));
    });

    createColumnSettingsList();
  }

  createColumnSettingsList() {
    columnSettingsList.clear();
    for (var i = 0; i < columnList.length; i++) {
      if (columnList[i].isEnable) {
        //bitSize: Bit Size
        columnSettingsList[columnList[i].key] = fieldsName[columnList[i].key];
      }
    }
    print('columnSettingsList :- $columnSettingsList');
  }

  updateLocalSearcher() {
    try {
      LoginController loginController = Get.find();
      if (recentSearch.query("userName == \$0",
          [loginController.userEmail.toString()]).isNotEmpty) {
        {
          localSearches = recentSearch
              .query("userName == \$0", [loginController.userEmail.toString()])
              .first
              .recentSearches
              .toList();
        }
      } else {
        localSearches = [];
      }

      registerNotification(loginController.userEmail.toString(),
          loginController.userDetailsList.first.id);
    } catch (e) {
      print(e.toString());
    }
  }

  addToLocalSearch(List<String> sublist) {
    localSearches = sublist;
  }

  addSearchData(List<String> searchValues) {
    realm.insertRecentSearches(searchValues);
    if (searchValues.length > 5) {
      addToLocalSearch(searchValues.sublist(searchValues.length - 5));
    } else {
      addToLocalSearch(searchValues);
    }
  }

  clearSearchData() {
    List<String> emptySearchList = [];
    realm.insertRecentSearches(emptySearchList);
    addToLocalSearch(emptySearchList);
  }

  filterBitListData(String value, String storageLoc,String plant) {
    var filteredList;
    filteredList = realm.getSearchedBits(value, storageLoc,plant);
    allBitList = filteredList;
    numberOfBits.value = allBitList.length.toString();
  }

  void unSelectBits() {
    isSortEnable = true;
    selectedList = List<bool>.filled(allBitList.length, false);
    noOfSelectedBits.value = 0;
    selectDeselectAction(-1);
    noOfSelectedBits.refresh();
    print('noOfSelectedBits $noOfSelectedBits');
  }

  @override
  void onInit() {
    super.onInit();
    init();
  }

  Future<bool> isDeviceOnline() async {
    return true;
  }

  void refreshUI() {
    _columnList.refresh();
    createColumnSettingsList();
    createColumnSortList();
    getAllBitsListBasedOnTab();
    unSelectBits();
  }

  void resetSelectedColumn() {
    checkColumnLength.value = 0;
  }



  void sortColumn(bool aorD, String column) {
    if (aorD == true) {
      allBitList.sort((a, b) => (mapBit(a)[column].toString())
          .compareTo(mapBit(b)[column].toString()));
    } else {
      allBitList.sort((a, b) => (mapBit(b)[column].toString())
          .compareTo(mapBit(a)[column].toString()));
    }
    //update();
    this._bitsList.refresh();
  }

  void changeInList(bool isListChanged, int selectedBits) {
    isSortEnable = selectedBits == 0;
    noOfSelectedBits.value = selectedBits;
    noOfSelectedBits.refresh();
  }

  void updateTab(String currentTab) {
    var shift;

    if (currentTab == "My Truck") {
      tab = false;
      defaultTab.value = AppValues.myTruckTabStr;
      getAllBitsListBasedOnTab();
    } else if (currentTab == "My District") {
      defaultTab.value = AppValues.myDistrictTabStr;
      tab = true;
      getAllBitsListBasedOnTab();
    } else if (currentTab == AppStrings.otherDistrict) {
      defaultTab.value = AppValues.otherDistrictTabStr;
      getAllBitsListBasedOnTab();
    }

    _columnList.refresh();
    update();
  }



  void getAllBitsListBasedOnTab({String query = ''}) {
    searchController.text = "";
    allBitList = tabInventoryData(query);
    /*print(
        "getAllBitsListBasedOnTab allBitList size:- ${allBitList.length.toString()}");*/
    numberOfBits.value = allBitList.length.toString();
    selectedList = List<bool>.filled(allBitList.length, false);
    fetchBitStateCollection();
    if (query.isEmpty) {
      getCategory();
    }
  }

  List<Bit> tabInventoryData(String query) {
    //add comments
    LoginController loginController = Get.find();
    try {
      List<String> parseList = <String>[];
      plantID.value = loginController.userDetailsList.first.plantId.toString();
      if (defaultTab.value == AppStrings.myTruck) {
        userSloc.value =
            loginController.userDetailsList.first.storageLocationId.toString();
        parseList.add(userSloc.value);
        parseList.add(plantID.value);

        return realm.fetchMyTruckBitsFilter(parseList, query: query);
      } else if (defaultTab.value == AppStrings.myDistrict) {
        userSloc.value =
            loginController.userDetailsList.first.baseLocationId.toString();

        parseList.add(userSloc.value);
        parseList.add(plantID.value);

        return realm.fetchMyDistrictBitsFilter(parseList, query: query);
      } else {
        userSloc.value = AppStrings.otherDistrictValue;

        parseList.add(plantID.value);

        /* parseList.add(
            loginController.userDetailsList.first.storageLocationId.toString()); */

        return realm.fetchOtherDistrictFilter(parseList, query: query);
      }
    } catch (e) {
      print(e);
    }
    return [];
  }

  List<Bit> getSelectedBits() {
    List<Bit> bitsSelected = [];
    for (int i = 0; i < allBitList.length; i++) {
      if (selectedList[i] == true) {
        bitsSelected.add(allBitList[i]);
      }
    }

    return bitsSelected;
  }

  void selectDeselectAction(int index) {

    if (defaultTab != AppStrings.otherDistrict) {
      if (numberOfSelectedBits >= maxBitSelectionAllowed && index != -1) {
        if (!selectedList[index] == true) {
        } else {
          selectedList[index] = (!selectedList[index]);
          numberOfSelectedBits =
              (allBitList.where((bit) => bit == true).length);
          numberOfSelectedBits =
              (selectedList.where((bit) => bit == true).length);
          isSelectionEnabled = numberOfSelectedBits != 0;
          changeInList(true, numberOfSelectedBits);
        }
        // We can show popup that maximum 5 bits can be selected.
      } else {
        if (index != -1) {
          selectedList[index] = (!selectedList[index] == true);
        }

        numberOfSelectedBits = (allBitList.where((bit) => bit == true).length);
        numberOfSelectedBits =
            (selectedList.where((bit) => bit == true).length);
        isSelectionEnabled = numberOfSelectedBits != 0;
        changeInList(true, numberOfSelectedBits);

        consignButtonHeight = numberOfSelectedBits != 0 ? 0.0 : 34.0;
        consignButtonWidth = numberOfSelectedBits != 0 ? 0.0 : 98.0;
        dynamicOpacity.value = numberOfSelectedBits != 0 ? 0.80 : 1;
        dynamicOpacity2.value = numberOfSelectedBits != 0 ? 0.30 : 1;

        moveToTruckButtonHeight = numberOfSelectedBits != 0 ? 0.0 : 34.0;

        moveToTruckButtonWidth = numberOfSelectedBits != 0 ? 0.0 : 125.0;
        dotsHeight = numberOfSelectedBits != 0 ? 0.0 : 25.0;
        dotsWidth = numberOfSelectedBits != 0 ? 0.0 : 25.0;
      }
    }
    //  print("Long press clicked: ${widget.inventoryController.selectedList[index]} AtLeast_One_Selected: $isSelectionEnabled numberOfSelctedBits: $numberOfSelectedBits")
  }

  TextEditingController filterSearchController = TextEditingController();
  List<String> selectedFilterCheckBox = [];
  final _selectedFilterTileList = <String>[].obs;
  final _filterDiscardPopupToShow = false.obs;
  final isPopupToShow = false.obs;
  final _filterCheckBoxItemList = <FilterCheckboxItem>[].obs;
  final _filterSearchMap = <String, bool>{}.obs;

  List<String> get selectedFilterTileList => _selectedFilterTileList;

  set selectedFilterTileList(List<String> value) {
    _selectedFilterTileList.value = value;
  }

  get filterDiscardPopupToShow => _filterDiscardPopupToShow.value;

  set filterDiscardPopupToShow(value) {
    _filterDiscardPopupToShow.value = value;
  }

  List<FilterCheckboxItem> get filterCheckBoxItemList =>
      _filterCheckBoxItemList.value;

  set filterCheckBoxItemList(List<FilterCheckboxItem> value) {
    _filterCheckBoxItemList.value = value;
  }

  Map<String, bool> get filterSearchMap => _filterSearchMap;

  set filterSearchMap(Map<String, bool> value) {
    _filterSearchMap.value = value;
  }

  List<Bit> getTabInventoryData(
      String categoryKey, LoginController loginController) {
    try {
      List<String> parseList = <String>[];
      if (defaultTab.value == AppStrings.myTruck) {
        parseList.add(
            loginController.userDetailsList.first.storageLocationId.toString());
        parseList.add(loginController.userDetailsList.first.plantId.toString());

        // add my plantID from truck user mapping
        return realm.fetchMyTruckBitsFilter(parseList,
            value: 'DISTINCT($categoryKey)');
      } else if (defaultTab.value == AppStrings.myDistrict) {
        parseList.add(
            loginController.userDetailsList.first.baseLocationId.toString());
        parseList.add(loginController.userDetailsList.first.plantId.toString());
        return realm.fetchMyDistrictBitsFilter(parseList,
            value: 'DISTINCT($categoryKey)');
      } else {
        parseList.add(loginController.userDetailsList.first.plantId.toString());
        /*  parseList.add(
            loginController.userDetailsList.first.storageLocationId.toString()); */

        return realm.fetchOtherDistrictFilter(parseList,
            value: 'DISTINCT($categoryKey)');
      }
    } catch (e) {
      print(e);
    }
    return [];
  }

  mapBit(Bit bit) {
    Map<String, String> bitMapping = <String, String>{};
    bitMapping["Type"] = bit.bitType.formatStringIfNull();
    bitMapping["BOM"] = bit.materialNumber.formatStringIfNull();
    bitMapping["Size"] = bit.bitSize.formatStringIfNull();
    bitMapping["Business Line"] = bit.businessLine.formatStringIfNull();
    bitMapping["Equipment Number"] = bit.equipmentNumber.formatStringIfNull();
    bitMapping["Features"] = bit.features.formatStringIfNull();
    bitMapping["GeoMarket"] = bit.geoMarket.formatStringIfNull();
    bitMapping["IADC Code"] = bit.iadcCode.formatStringIfNull();
    bitMapping["INV OrgId"] = bit.invOrgId.formatStringIfNull();
    bitMapping["Material Description"] =
        bit.materialDescription.formatStringIfNull();
    bitMapping["No. of Runs"] = bit.numberOfRuns.formatStringIfNull();
    bitMapping["Pin Size"] = bit.pinSize.formatStringIfNull();
    bitMapping["Plant"] = bit.plant.formatStringIfNull();
    bitMapping["Plant Name"] = bit.plantName.formatStringIfNull();
    bitMapping["Profit Center"] = bit.profitCenter.formatStringIfNull();
    bitMapping["Serial Nbr"] = bit.serialNumber.formatStringIfNull();
    bitMapping["SN Stock Type"] = bit.snStockType.formatStringIfNull();
    bitMapping["Special Stock Indicator"] =
        bit.specialStockIndicator.formatStringIfNull();
    bitMapping["Status"] = bit.status1.formatStringIfNull();
    bitMapping["SLOC/Description"] = bit.storageLoc.formatStringIfNull();
    bitMapping["Description"] =
        bit.storageLocationDescription.formatStringIfNull();
    bitMapping["Sub Segment"] = bit.subSegment.formatStringIfNull();
    bitMapping["UOM"] = bit.uom.formatStringIfNull();
    bitMapping["Batch Number"] = bit.batchNumber.formatStringIfNull();

    return bitMapping;
  }

  /*
  * Gathering dynamic data based on Inventory tab selection with respective collection
  * */
  void getCategory({String query = ''}) async {
    LoginController loginController = Get.find();
    var listCheckBoxLocal = <FilterCheckboxItem>[];

    if (fieldsName != null) {
      for (var categoryKey in columnSettingsList.keys) {
        List<Bit> bitList = getTabInventoryData(categoryKey, loginController);

        Map<String, bool> categoryItem = <String, bool>{};
        Map<String, String> mmToInch = <String, String>{};
        for (var bit in bitList) {
          String value = bit.toMap()[categoryKey] ?? '';
          if (value.isNotEmpty) {
            String valueUpdate = value;
            /*if (categoryKey == AppStrings.bitSize) {
              try {
                valueUpdate = convertToInchWithString(valueUpdate);
              } catch (e) {
                ApplicationLogger().printError(
                    'categoryKey:- $categoryKey - $e',
                    'InventoryController.getCategory()');
              }
              mmToInch[valueUpdate] = value;
            }*/

            categoryItem[valueUpdate] = false;
          }
        }
        listCheckBoxLocal.add(FilterCheckboxItem(
            categoryKey == "bitSize" ? 'inch' : categoryKey,
            fieldsName[categoryKey],
            false,
            categoryItem,
            categoryItem));
      }
      clearAllFilter();
      filterCheckBoxItemList = listCheckBoxLocal;
      updateActiveStatus(0);
      _filterCheckBoxItemList.refresh();
    }
  }

  /*
  * Search operation on selected category filter options
  * */
  void filterSearchValue(String search) {
    Map<String, bool>? filterSearchMapLocal = <String, bool>{};

    if (search.isEmpty) {
      // if the search field is empty or only contains white-space, we'll display all results
      filterSearchMapLocal = getActiveCategory()?.categoryItem;
    } else {
      for (String itemKey in getActiveCategory()!.categoryItem.keys) {
        if (itemKey.toLowerCase().contains(search.toLowerCase())) {
          filterSearchMapLocal[itemKey] =
              getActiveCategory()!.categoryItem[itemKey]!;
        }
      }
      // we use the toLowerCase() method to make it case-insensitive
    }
    filterSearchMap = filterSearchMapLocal as Map<String, bool>;
    _filterSearchMap.refresh();
  }

  /*
  * On Apply button click showing filter tile on Inventory page and
  * filtering that data
  * */
  void updateInventorySelectedFilterTile() {
    realmQueryApply();
    // Clear selected value collection
    selectedFilterCheckBox.clear();
    for (var value in filterCheckBoxItemList) {
      //Copy category map to tempMap
      value.applyCategoryItemToTemp();
      for (MapEntry<String, bool> item in value.categoryItem.entries) {
        //Selected value of category adding in collection
        if (item.value) {
          selectedFilterCheckBox.add(item.key);
        }
      }
    }
    _filterCheckBoxItemList.refresh();
    selectedFilterTileList = selectedFilterCheckBox;
    _selectedFilterTileList.refresh();
  }

  void realmQueryApply() {
    String query = '';
    List<String> listOfQuerySelected = [];
    for (var index = 0; index < filterCheckBoxItemList.length; index++) {
      //ApplicationLogger().printDebug('Element key:- ${filterCheckBoxItemList[index].key} - ${filterCheckBoxItemList[index].getAllSelectedFilter()}', 'updateInventorySelectedFilterTile()');
      if (filterCheckBoxItemList[index].getAllSelectedFilter().isNotEmpty) {
        listOfQuerySelected.add(
            '${filterCheckBoxItemList[index].key} IN ${filterCheckBoxItemList[index].getAllSelectedFilter()}');
      }
    }
    query = listOfQuerySelected
        .join(' AND ')
        .replaceAll('[', '{')
        .replaceAll(']', '}');
    if (query.isNotEmpty) {
      query = 'AND $query';
    }
    print('Query:- $query');
    getAllBitsListBasedOnTab(query: query);
  }

  /*
  * On item check/uncheck UI operation
  * */
  void categoryFilterItemCheckChange(String selectedKey, bool isChecked) {
    filterDiscardPopupToShow = true;
    getActiveCategory()?.categoryItem.update(selectedKey, (value) => isChecked);
    filterSearchMap.update(selectedKey, (value) => isChecked);
    _filterSearchMap.refresh();
    _filterCheckBoxItemList.refresh();
  }

  /*
  * On click of filter tile on Inventory page, Removing that tile and unchecked that
  * category selection whichever removed.
  * */
  void removeFilterTile(String tileText) {
    selectedFilterTileList.remove(tileText);
    selectedFilterCheckBox.remove(tileText);
    for (var index = 0; index < filterCheckBoxItemList.length; index++) {
      if (filterCheckBoxItemList[index].categoryItem.containsKey(tileText)) {
        //On tile remove on inventory page, changing checkbox status to false
        filterCheckBoxItemList[index]
            .categoryItem
            .update(tileText, (value) => false);
        filterCheckBoxItemList[index]
            .categoryItemTemp
            .update(tileText, (value) => false);
      }
    }
    realmQueryApply();
    _selectedFilterTileList.refresh();
    _filterCheckBoxItemList.refresh();
  }

  /*
  * Clearing list tile on inventory tab UI and reset all values.
  * */
  void clearAllFilter() {
    selectedFilterTileList = [];
    resetFilter();
    _selectedFilterTileList.refresh();
  }

  /*
  * On click of reset, cleaning all selection and filter search
  * cancel button we keep disable till user not click Apply or any filter check/uncheck
  * */
  void resetFilter({bool isCancelButtonEnable = true}) {
    //Commented if in future we need to uncomment then
    //selectedFilterCheckBox.clear();

    for (var index = 0; index < filterCheckBoxItemList.length; index++) {
      filterCheckBoxItemList[index]
          .categoryItem
          .updateAll((name, value) => value = false);
      if (index == 0) {
        filterCheckBoxItemList[index].isActive = true;
      } else {
        filterCheckBoxItemList[index].isActive = false;
      }
    }
    filterSearchMap = getActiveCategory()?.categoryItem ?? <String, bool>{};
    _filterSearchMap.refresh();
    _filterCheckBoxItemList.refresh();
  }

  /*
  * On click of category we are updating active tile flag to that position
  * */
  void onCategoryChange({int index = 0}) {
    updateActiveStatus(index);
    _filterCheckBoxItemList.refresh();
  }

  void updateActiveStatus(int clickIndex) {
    for (var index = 0; index < filterCheckBoxItemList.length; index++) {
      if (index == clickIndex) {
        filterCheckBoxItemList[index].isActive = true;
        filterSearchMap = filterCheckBoxItemList[index].categoryItem;
        _filterSearchMap.refresh();
      } else {
        filterCheckBoxItemList[index].isActive = false;
      }
    }
  }

  updatePrefsIfMovementHappen() {
    prefs.setBool(PreferenceConstants.isMovementHappen, true);
  }

  /*
  * We are getting selected category name
  * */
  String getActiveSelectedCategoryName() {
    for (var value in filterCheckBoxItemList) {
      if (value.isActive) {
        return value.title;
      }
    }
    return '';
  }

  /*
  * Used for getting current selected category position data
  * */
  FilterCheckboxItem? getActiveCategory() {
    for (var value in filterCheckBoxItemList) {
      if (value.isActive) {
        return value;
      }
    }
    return null;
  }

  void createColumnSortList() {
    var tempList = [];
    var remList = [];
    for (var i = 0; i < columnList.length; i++) {
      if (columnList[i].isEnable) {
        tempList.add(columnList[i]);
      } else {
        remList.add(columnList[i]);
      }
    }

    columnList.clear();
    columnList.addAll(tempList);
    columnList.addAll(remList);
  }

  //When filter popup open we assigned all filtered
  // selected value to popup category item
  void applySelectedFilterValueToPopup() {
    for (var value in filterCheckBoxItemList) {
      value.applyTempToCategoryItem();
    }

    filterSearchMap = getActiveCategory()?.categoryItem ?? <String, bool>{};
    _filterSearchMap.refresh();
    _filterCheckBoxItemList.refresh();
  }

  void clearFilterValueToPopup() {
    for (var value in filterCheckBoxItemList) {
      value.categoryItem.updateAll((name, value) => value = false);
    }
    _filterCheckBoxItemList.refresh();
  }

  void movementInitiateToast({required String serialNumbers}) {
    String message = serialNumbers.length > 3 ? 'The movement for the Bit $serialNumbers has been initiated.' : 'The movement for the $serialNumbers Bit has been initiated.';

    ApplicationLogger().printInfo(message, 'InventoryController.movementInitiateToast()');

    if (connectivityController.isConnected.value) {
      showToastMsg(Get.context, message, ToastStatus.info);
    }
  }
}

class PushNotification {
  PushNotification({
    this.title,
    this.body,
    this.dataTitle,
    this.dataBody,
  });

  String? title;
  String? body;
  String? dataTitle;
  String? dataBody;
}
