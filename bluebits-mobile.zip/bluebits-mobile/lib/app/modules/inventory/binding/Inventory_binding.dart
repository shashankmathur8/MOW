import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/modules/inventory/controller/inventory_controller.dart';

class InventoryBinding implements Bindings {
  @override
  void dependencies() {
    //Get.put<InventoryController>(InventoryController());
    //InventoryController().init();
  }
}
