import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../common_binding/realm_initial.dart';
import '../../../core/common_widgets/custom_button_material.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../controller/inventory_controller.dart';

class ResetColumnSettingOverlay extends ModalRoute<void> {
  final InventoryController consignController;
  Function refresh;

  ResetColumnSettingOverlay(this.consignController, this.refresh);

  @override
  Duration get transitionDuration => const Duration(milliseconds: 0);

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => false;

  @override
  Color get barrierColor => AppColors.colorBlack.withOpacity(0.3);

  @override
  String get barrierLabel => '';

  @override
  bool get maintainState => true;

  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());
  final InventoryController inventoryController = Get.find();

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    // This makes sure that text and other content follows the material style
    return Material(
      type: MaterialType.transparency,
      // make sure that the overlay content is not cut off
      child: SafeArea(
        child: _buildOverlayContent(context),
      ),
    );
  }

  Widget _buildOverlayContent(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: getWidth(SizeConstants.dp570),
            // height: getHeight(SizeConstants.dp220),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(SizeConstants.dp10),
                boxShadow: [
                  BoxShadow(
                      color: AppColors.colorBlack.withOpacity(0.3),
                      blurRadius: SizeConstants.dp7)
                ]),
            child: Container(
              decoration: BoxDecoration(
                color: AppColors.colorWhite,
                borderRadius: BorderRadius.circular(SizeConstants.dp10),
              ),
              child: Padding(
                padding: const EdgeInsets.all(SizeConstants.dp20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: getHeight(SizeConstants.dp64),
                      child: Row(
                        children: [
                          Image.asset(
                            AppImages.warning,
                          ),
                          const SizedBox(
                            width: SizeConstants.dp16,
                          ),
                          const Text(
                            AppStrings.resetTitle,
                            style: warehouseTextStyle,
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: getHeight(SizeConstants.dp4),
                    ),
                    Column(
                      children: [
                        Row(
                          children: [
                            SizedBox(
                              width: SizeConstants.dp85,
                            ),
                            Text(
                              AppStrings.resetMsg1,
                              style: wareHouseStaticTextStyle,
                            ),
                          ],
                        ),
                        SizedBox(
                          height: getHeight(SizeConstants.dp3),
                        ),
                        Row(
                          children: [
                            SizedBox(
                              width: SizeConstants.dp85,
                            ),
                            SizedBox(
                              width: SizeConstants.dp3,
                            ),
                            Text(
                              AppStrings.resetMsg2,
                              style: wareHouseStaticTextStyle,
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            SizedBox(
                              width: SizeConstants.dp85,
                            ),
                            SizedBox(
                              width: SizeConstants.dp3,
                            ),
                            Text(
                              AppStrings.resetMsg3,
                              style: wareHouseStaticTextStyle,
                            ),
                          ],
                        ),
                        SizedBox(
                          height: getHeight(SizeConstants.dp19),
                        ),
                        bottomButtonWidget(context)
                      ],
                    )
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget bottomButtonWidget(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        CustomButtonMaterial(
          width: getWidth(SizeConstants.dp102),
          height: getHeight(SizeConstants.dp45),
          backgroundColor: AppColors.colorWhite,
          foregroundColor: AppColors.colorPrimary,
          borderRadius: AppValues.radius_4,
          text: AppStrings.no,
          style: tSw500dp16fontF,
          side: const BorderSide(
            width: SizeConstants.dp1,
            color: AppColors.colorPrimary,
          ),
          onPressCallback: () {
            Get.back();
          },
        ),
        SizedBox(
          width: getWidth(SizeConstants.dp10),
        ),
        CustomButtonMaterial(
          width: getWidth(SizeConstants.dp130),
          height: getHeight(SizeConstants.dp45),
          backgroundColor: AppColors.colorPrimary,
          foregroundColor: Colors.white,
          borderRadius: AppValues.radius_4,
          text: AppStrings.yes,
          style: tSw500dp16fontF,
          onPressCallback: () async {
            inventoryController.resetColumnList(inventoryController, false);
            /* inventoryController.fetchFiledName();
            refresh();
            inventoryController.refreshUI();
            inventoryController.resetSelectedColumn();
            inventoryController.getCheckedColumLength(inventoryController);
            Get.back();*/
            // Navigator.pop(context);
          },
        ),
      ],
    );
  }

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    // You can add your own animations for the overlay content
    return FadeTransition(
      opacity: animation,
      child: ScaleTransition(
        scale: animation,
        child: child,
      ),
    );
  }
}
