import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';
import 'package:slb_gt_mobile/app/modules/inventory/widget/reset_column_setting_overlay.dart';

import '../../../core/common_widgets/custom_button_material.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';

import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../../shared/setting_overlay_layout.dart';
import '../controller/inventory_controller.dart';

class SettingList extends StatefulWidget {
  var list;

  Function refresh;
  final InventoryController inventoryController = Get.find();

  SettingList({super.key, required this.list, required this.refresh});

  @override
  State<SettingList> createState() => _SettingListState();
}

class _SettingListState extends State<SettingList> {
  @override
  void initState() {
    super.initState();
    widget.inventoryController.checkColumnLength.value = 0;
    widget.inventoryController
        .getCheckedColumLength(widget.inventoryController);
  }

  void getSelectedValue(List<dynamic> items) {
    int selectedItems = 0;
    items.forEach((element) {
      if (element.isEnable == true) {
        selectedItems++;
      }
      widget.inventoryController.checkColumnLength.value = selectedItems;
    });
    print("--->>>${selectedItems}");
  }

  Widget bottomButtonsWidget(bool isEnable) {
    return Container(
      width: SizeConstants.dp430,
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
            bottomLeft: Radius.circular(5), bottomRight: Radius.circular(5)),
        child: Container(
          color: AppColors.colorWhite,
          child: Column(
            children: [
              Container(
                color: AppColors.colorSeparatorLine,
                height: SizeConstants.dp1,
              ),
              Container(
                padding: const EdgeInsets.only(
                    left: SizeConstants.dp30,
                    top: AppValues.padding_15,
                    bottom: AppValues.padding_15,
                    right: AppValues.padding_20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Obx(
                      () => RichText(
                        text: TextSpan(
                          style: tSw400dp14fontF.copyWith(
                            fontSize: SizeConstants.dp16,
                            color: AppColors.colorMainText,
                          ),
                          children: <TextSpan>[
                            TextSpan(
                              text:
                                  '${widget.inventoryController.checkColumnLength.value}',
                              style: tSw700fontF.copyWith(
                                fontSize: SizeConstants.dp14,
                                fontWeight: FontWeight.w700,
                                color: AppColors.colorMainText,
                              ),
                            ),
                            const TextSpan(text: ' '),
                            TextSpan(
                                text: AppStrings.selected,
                                style: tSw700fontF.copyWith(
                                  fontSize: SizeConstants.dp14,
                                  fontWeight: FontWeight.w400,
                                  color: AppColors.colorMainText,
                                )),
                          ],
                        ),
                      ),
                    ),
                    Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          Container(
                            height: AppValues.cancelButtonHeight,
                            width: AppValues.cancelButtonWidth,
                            child: OutlinedButton(
                              onPressed: () {
                                widget.inventoryController.fetchFiledName();

                                Navigator.pop(context);
                                widget.inventoryController
                                    .resetSelectedColumn();

                                print("Cancel");
                              },
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(
                                  width: SizeConstants.dp1,
                                  color: AppColors.colorPrimary,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius:
                                      BorderRadius.circular(AppValues.radius_4),
                                ),
                                backgroundColor: AppColors.colorWhite,
                              ),
                              child: const Text(
                                AppStrings.cancel,
                                style: TextStyle(
                                  color: AppColors.colorPrimary,
                                  fontSize: SizeConstants.dp16,
                                  fontFamily: AppValues.fontFamily,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                          Obx(
                            () => Container(
                              margin: const EdgeInsets.only(
                                left: AppValues.margin_10,
                              ),
                              height: AppValues.saveButtonHeight,
                              width: AppValues.saveButtonWidth,
                              child: CustomButtonMaterial(
                                width: getWidth(SizeConstants.dp130),
                                height: getHeight(SizeConstants.dp45),
                                backgroundColor: widget.inventoryController
                                            .checkColumnLength.value ==
                                        8
                                    ? AppColors.colorPrimary
                                    : AppColors.colorPrimary.withOpacity(widget
                                                .inventoryController
                                                .checkColumnLength
                                                .value ==
                                            8
                                        ? 1
                                        : 0.3),
                                foregroundColor: AppColors.colorWhite
                                    .withOpacity(widget.inventoryController
                                                .checkColumnLength.value ==
                                            8
                                        ? 1
                                        : 0.4),
                                borderRadius: AppValues.radius_4,
                                text: AppStrings.save,
                                style: tSw500dp16fontF,
                                onPressCallback: () {
                                  if (widget.inventoryController
                                          .checkColumnLength.value ==
                                      8) {
                                    widget.refresh();
                                    widget.inventoryController.refreshUI();
                                    widget.inventoryController
                                        .resetSelectedColumn();
                                    Navigator.pop(context);
                                  }
                                },
                              ),
                            ),
                          ),
                        ]),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget headerInformationView() {
    return Container(
      width: SizeConstants.dp430,
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(5), topRight: Radius.circular(5)),
        child: Container(
          color: AppColors.colorWhite,
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    margin: const EdgeInsets.only(
                        left: AppValues.margin_24,
                        top: AppValues.margin_14,
                        bottom: AppValues.margin_15),
                    child: const Text(
                      AppStrings.columnSettings,
                      style: TextStyle(
                          color: AppColors.colorBlack,
                          fontSize: SizeConstants.dp24,
                          fontWeight: FontWeight.w700,
                          fontFamily: AppValues.fontFamily),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      Get.back();
                      Navigator.of(context).push(ResetColumnSettingOverlay(
                          widget.inventoryController, widget.refresh));
                    },
                    child: Container(
                      color: AppColors.colorWhite,
                      padding: const EdgeInsets.only(
                          left: AppValues.margin_40,
                          right: AppValues.margin_24,
                          top: AppValues.margin_24,
                          bottom: AppValues.margin_24),
                      child: const Text(
                        AppStrings.reset,
                        style: TextStyle(
                          color: AppColors.colorPrimary,
                          fontSize: SizeConstants.dp12,
                          fontFamily: AppValues.fontFamily,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  )
                ],
              ),
              Container(
                color: AppColors.colorSeparatorLine,
                height: SizeConstants.dp1,
              ),
              Container(
                margin: const EdgeInsets.only(
                    left: AppValues.margin_24,
                    top: AppValues.margin_14,
                    bottom: AppValues.margin_12,
                    right: AppValues.margin_24),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    // Wrap(
                    // children: [
                    Image.asset(AppImages.ic_info),
                    Container(
                      margin: const EdgeInsets.only(
                        left: AppValues.margin_5,
                      ),
                      child: const Text(
                        AppStrings.only8ColumnsSelectMessage,
                        style: TextStyle(
                            color: AppColors.colorMainText,
                            fontSize: SizeConstants.dp12,
                            fontWeight: FontWeight.w400,
                            fontFamily: AppValues.fontFamily),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return IntrinsicHeight(
      child: Container(
        height: SizeConstants.dp130,
        width: SizeConstants.dp130,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            headerInformationView(),
            Expanded(
                child: Container(
                    width: SizeConstants.dp430,
                    child: MyStatefulWidget(
                      selectedValue: getSelectedValue,
                    ))),
            bottomButtonsWidget(true)
          ],
        ),
      ),
    );
  }
}
