import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/modules/inventory/controller/inventory_controller.dart';

import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';

class FilterCategoryCollection extends StatelessWidget {
  final InventoryController inventoryController;

  const FilterCategoryCollection(this.inventoryController, {Key? key})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemBuilder: (context, index) {
        return GestureDetector(
          onTap: () {
            inventoryController.filterSearchController.clear();
            inventoryController.onCategoryChange(index: index);
          },
          child: Obx(() => Container(
                height: getHeight(SizeConstants.dp57),
                decoration: BoxDecoration(
                  color:
                      inventoryController.filterCheckBoxItemList[index].isActive
                          ? AppColors.colorBackgroundPanel
                          : AppColors.colorWhite,
                  border:
                      inventoryController.filterCheckBoxItemList[index].isActive
                          ? null
                          : Border(
                              right: BorderSide(
                                  color: AppColors.colorSeparatorLine
                                      .withOpacity(0.4)),
                            ),
                ),
                child: Column(
                  children: [
                    Container(
                      height: getHeight(SizeConstants.dp56),
                      padding: EdgeInsets.only(
                          left: getWidth(SizeConstants.dp28),
                          right: getWidth(SizeConstants.dp12)),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Flexible(
                              child: Text(
                                inventoryController
                                    .filterCheckBoxItemList[index].title,
                                style: inventoryController
                                        .filterCheckBoxItemList[index].isActive
                                    ? tSw600dp16fontF.copyWith(
                                        fontSize: SizeConstants.dp14,
                                        color: AppColors.colorMainText)
                                    : tSw400dp14fontF.copyWith(
                                        color: AppColors.colorMainText),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                softWrap: true,
                                textAlign: TextAlign.start,
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(
                                  left: getWidth(SizeConstants.dp5)),
                              child: Text(
                                inventoryController
                                    .filterCheckBoxItemList[index]
                                    .selectedFilterCount(),
                                style: inventoryController
                                        .filterCheckBoxItemList[index].isActive
                                    ? tSw600dp16fontF.copyWith(
                                        fontSize: SizeConstants.dp14,
                                        color: AppColors.colorMainText)
                                    : tSw400dp14fontF.copyWith(
                                        color: AppColors.colorMainText),
                              ),
                            ),
                          ]),
                    ),
                    Divider(
                      color: AppColors.colorSeparatorLine.withOpacity(0.4),
                      height: getHeight(SizeConstants.dp1),
                    )
                  ],
                ),
              )),
        );
      },
      itemCount: inventoryController.filterCheckBoxItemList.length > 8
          ? 8
          : inventoryController.filterCheckBoxItemList.length,
      physics: const ScrollPhysics(),
    );
  }
}
