import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:slb_gt_mobile/app/common_binding/realm_initial.dart';
import 'package:slb_gt_mobile/app/modules/shared/datepicker_view.dart';
import 'package:slb_gt_mobile/app/modules/shared/dropdown_view.dart';
import 'package:slb_gt_mobile/app/modules/shared/multiline_input_view.dart';
import 'package:slb_gt_mobile/app/modules/shared/smart_search_view.dart';
import 'package:realm/realm.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/customerSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/rigsSchema.dart';

import '../../../core/common_widgets/common_widget.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../../login/controller/login_controller.dart';

class RequestBitView extends StatefulWidget {
  Function bitSubmittedCallBak;

  RequestBitView({required this.bitSubmittedCallBak});

  @override
  State<RequestBitView> createState() => _RequestBitViewState();
}

class _RequestBitViewState extends State<RequestBitView> {
  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());
  final LoginController loginController = Get.find();

  bool showDropDown = false;
  String selectedTruck = '';

  late RealmResults<Rig> _rigsList;
  late RealmResults<Customer> _customerList;
  late RealmResults<Bit> _bitsList;

  final _customers = <dynamic>[].obs;
  final _rigs = <dynamic>[].obs;
  final _bitType = <dynamic>[].obs;
  final _bitSize = <dynamic>[].obs;

  final dictValues = {
    'customer': '',
    'rig': '',
    'size': '',
    'probability': '',
    'bitType': '',
    'requestBitBy': DateTime.now(),
    'jobType': '',
    'comments': ''
  }.obs;

  List<dynamic> get customers => _customers;

  set customers(List<dynamic> value) {
    _customers.value = value;
  }

  List<dynamic> get rigs => _rigs;

  set rigs(List<dynamic> value) {
    _rigs.value = value;
  }

  List<dynamic> get bitType => _bitType;

  set bitType(List<dynamic> value) {
    _bitType.value = value;
  }

  List<dynamic> get bitSize => _bitSize;

  set bitSize(List<dynamic> value) {
    _bitSize.value = value;
  }

  bool checkStateToSubmit() {
    if (dictValues['customer'] != '' && dictValues['rig'] != '') {
      return true;
    } else {
      return false;
    }
  }

  void fetchData() async {
    _rigsList = realm.getRigs();
    print('Rigs : ${_rigsList.length}');

    _bitsList = realm.getBits();
    print('Bits : ${_bitsList.length}');

    _customerList = realm.getCustomers(
        loginController.userDetailsList.first.country ??
            AppStrings.usCountryCode);
    print('Customer : ${_customerList.length}');

    List<dynamic> customer = [];
    _customerList.forEach((c) {
      customer.add(c);
    });

    List<dynamic> rig = [];
    _rigsList.forEach((r) {
      rig.add(r);
    });

    List<dynamic> type = [];
    List<dynamic> size = [];
    _bitsList.forEach((b) {
      if (b.bitType != null && b.bitType != '') {
        type.add(b.bitType ?? '');
      }

      if (b.inch != null && b.inch != '') {
        size.add(b.inch ?? '');
      }
    });

    var uniqueType = <dynamic>{};
    var uniqueSize = <dynamic>{};

    customers = customer;
    rigs = rig;
    bitType = type.where((t) => uniqueType.add(t)).toList();
    bitSize = size.where((s) => uniqueSize.add(s)).toList();

    //print('_bitType are ${_bitType.length}');
  }

  @override
  void initState() {
    super.initState();

    Future.delayed(const Duration(milliseconds: 500), () {
      fetchData();
    });
  }

  Future<bool> isDeviceOnline() async {
    return true;
  }

  @override
  Widget build(BuildContext context) {
    double containerWidth =
        getScreenWidth() / 2 + getHeight(SizeConstants.dp150);

    double horizontalSpaceBothSide = SizeConstants.dp30;
    double inBetweenSpace = SizeConstants.dp30;
    double leftSideSpace = SizeConstants.dp85;
    double rightSideSpace = leftSideSpace;
    double widthInput = (containerWidth -
            horizontalSpaceBothSide -
            leftSideSpace -
            inBetweenSpace -
            rightSideSpace) /
        2;

    return Scaffold(
      backgroundColor: AppColors.colorBlack.withAlpha(SizeConstants.dp100I),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(AppValues.margin_2),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: containerWidth,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(SizeConstants.dp10),
                      boxShadow: [
                        BoxShadow(
                            color: AppColors.colorBlack
                                .withOpacity(SizeConstants.dp0_3),
                            blurRadius: AppValues.radius_7)
                      ]),
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppColors.colorWhite,
                      borderRadius: BorderRadius.circular(SizeConstants.dp10),
                    ),
                    padding: const EdgeInsets.symmetric(
                        horizontal: AppValues.margin_15,
                        vertical: AppValues.margin_22),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            CustomWidgets().roundIconWidget(
                                AppImages.requestBit,
                                iconHeight: SizeConstants.dp64,
                                iconWidth: SizeConstants.dp64),
                            SizedBox(
                              width: getWidth(SizeConstants.dp19),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text(
                                  AppStrings.requestbit,
                                  style: TextStyle(
                                      color: AppColors.colorBlack,
                                      fontSize: SizeConstants.dp26,
                                      fontWeight: FontWeight.w700,
                                      fontFamily: AppValues.fontFamily),
                                ),
                              ],
                            )
                          ],
                        ),
                        SizedBox(
                          height: getHeight(SizeConstants.dp20),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: leftSideSpace,
                            ),
                            UserInputView(
                              initValue: "",
                              strImage: AppImages.search,
                              strHint: AppStrings.customername,
                              strTitle: AppStrings.customer,
                              arrList: customers,
                              widthInput: widthInput,
                              onClickAction: (value) => {
                                dictValues['customer'] = value,
                                dictValues.refresh()
                              },
                              onRemoveText: () => {
                                dictValues['customer'] = '',
                                dictValues.refresh()
                              },
                              //85 initial and 30 padding 40 end space
                              smartSearchBoxDecoration: inputDecoration,
                            ),
                            const SizedBox(
                              width: SizeConstants.dp30,
                            ),
                            UserInputView(
                              initValue: "",
                              strImage: AppImages.search,
                              strHint: AppStrings.rigname,
                              strTitle: AppStrings.rig,
                              arrList: rigs,
                              widthInput: widthInput,
                              onClickAction: (value) => {
                                dictValues['rig'] = value,
                                dictValues.refresh()
                              },
                              onRemoveText: () => {
                                dictValues['rig'] = '',
                                dictValues.refresh()
                              },
                              //85 initial and 30 padding 40 end space
                              smartSearchBoxDecoration: inputDecoration, //
                            )
                          ],
                        ),
                        const SizedBox(
                          height: SizeConstants.dp20,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: leftSideSpace,
                            ),
                            DropDownView(
                              strImage: AppImages.down_arrow,
                              strHint: AppStrings.selectsize,
                              strTitle: AppStrings.size,
                              arrList: bitSize,
                              widthInput: widthInput,
                              inputDecoration: inputDecoration,
                              overlayDecoration: overlayDecoration,
                              onClickAction: (value) => {
                                dictValues['size'] = value
                              }, //85 initial and 30 padding 40 end space
                            ),
                            const SizedBox(
                              width: SizeConstants.dp30,
                            ),
                            //DropdownButton(items: items, onChanged: onChanged)
                            DropDownView(
                                strImage: AppImages.down_arrow,
                                strHint: AppStrings.selectprobability,
                                strTitle: AppStrings.probability,
                                arrList: AppStrings.listProbability,
                                widthInput: widthInput,
                                inputDecoration: inputDecoration,
                                overlayDecoration: overlayDecoration,
                                onClickAction: (value) => {
                                      dictValues['probability'] = value
                                    } //85 initial and 30 padding 40 end space
                                )
                          ],
                        ),
                        const SizedBox(
                          height: SizeConstants.dp20,
                        ),
                        /*Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: leftSideSpace,
                            ),
                            SizedBox(
                              width: widthInput,
                              child: EasyAutocomplete(
                                  suggestions: ['Afeganistan', 'Albania', 'Algeria', 'Australia', 'Brazil', 'German', 'Madagascar', 'Mozambique', 'Portugal', 'Zambia'],
                                  onChanged: (value) => print('onChanged1 value: $value'),
                                  onSubmitted: (value) => print('onSubmitted1 value: $value')
                              ),
                            ),
                            const SizedBox(
                              width: SizeConstants.dp30,
                            ),
                            SizedBox(
                              width: widthInput,
                              child: EasyAutocomplete(
                                  suggestions: ['Afeganistan', 'Albania', 'Algeria', 'Australia', 'Brazil', 'German', 'Madagascar', 'Mozambique', 'Portugal', 'Zambia'],
                                  onChanged: (value) => print('onChanged2 value: $value'),
                                  onSubmitted: (value) => print('onSubmitted2 value: $value')
                              ),
                            )
                          ],
                        ),*/
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: leftSideSpace,
                            ),
                            DropDownView(
                                strImage: AppImages.down_arrow,
                                strHint: AppStrings.selectbit,
                                strTitle: AppStrings.bittype,
                                arrList: bitType,
                                widthInput: widthInput,
                                inputDecoration: inputDecoration,
                                overlayDecoration: overlayDecoration,
                                onClickAction: (value) =>
                                    {dictValues["bitType"] = value}),
                            const SizedBox(
                              width: SizeConstants.dp30,
                            ),
                            DatePickerView(
                                selectedDate: DateTime.now(),
                                strImage: AppImages.calendar,
                                strHint: AppStrings.dateformat,
                                strTitle: AppStrings.requestbitby,
                                arrList: [],
                                firstDate: DateTime.now(),
                                inputDecoration: inputDecoration,
                                widthInput: widthInput,
                                onClickAction: (value) =>
                                    {dictValues['requestBitBy'] = value})
                          ],
                        ),
                        const SizedBox(
                          height: SizeConstants.dp20,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: leftSideSpace,
                            ),
                            DropDownView(
                              strImage: AppImages.down_arrow,
                              strHint: AppStrings.selectjobtype,
                              strTitle: AppStrings.jobtype,
                              arrList: const [
                                AppStrings.followrunup,
                                AppStrings.keycustomer,
                                AppStrings.targetgrowthcustomer
                              ],
                              widthInput: widthInput,
                              inputDecoration: inputDecoration,
                              overlayDecoration: overlayDecoration,
                              onClickAction: (value) =>
                                  {dictValues["jobType"] = value},
                            ),
                            const SizedBox(
                              width: SizeConstants.dp30,
                            ),
                            MultiLineInputView(
                                strTitle: AppStrings.comments,
                                strHint: AppStrings.writecomments,
                                widthInput: widthInput,
                                onClickAction: (value) =>
                                    {dictValues["comments"] = value})
                          ],
                        ),
                        const SizedBox(
                          height: SizeConstants.dp30,
                        ),
                        Row(
                          children: [
                            SizedBox(
                              width: leftSideSpace,
                            ),
                            Container(
                              width: containerWidth -
                                  horizontalSpaceBothSide -
                                  leftSideSpace -
                                  rightSideSpace,
                              height: SizeConstants.dp50,
                              decoration: BoxDecoration(
                                borderRadius: const BorderRadius.all(
                                    Radius.circular(SizeConstants.dp3)),
                                border: Border.all(
                                    width: SizeConstants.dp1,
                                    color: AppColors.colorSubText),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: SizeConstants.dp20,
                                    vertical: SizeConstants.dp5),
                                child: Row(
                                  children: [
                                    ImageIcon(
                                      const AssetImage(AppImages.info),
                                      color: AppColors.color5A7793,
                                      size: getWidth(SizeConstants.dp24),
                                    ),
                                    SizedBox(
                                      width: getWidth(SizeConstants.dp10),
                                    ),
                                    const Text(
                                      AppStrings.bitrequest,
                                      style: TextStyle(
                                          color: AppColors.colorMainText,
                                          fontSize: SizeConstants.dp16,
                                          fontWeight: AppValues.fontWeight400,
                                          fontFamily: AppValues.fontFamily),
                                    )
                                  ],
                                ),
                              ),
                            )
                          ],
                        ),
                        SizedBox(
                          height: getHeight(SizeConstants.dp40),
                        ),
                        Padding(
                          padding: EdgeInsets.only(right: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              SizedBox(
                                width: getWidth(SizeConstants.dp130),
                                height: getHeight(SizeConstants.dp45),
                                child: GestureDetector(
                                  onTap: () {
                                    FocusManager.instance.primaryFocus
                                        ?.unfocus();

                                    Get.back();
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(SizeConstants.dp5)),
                                        color: AppColors.colorWhite,
                                        border: Border.all(
                                            color: AppColors.colorPrimary,
                                            width: SizeConstants.dp1)),
                                    child: const Text(
                                      AppStrings.cancel,
                                      style: TextStyle(
                                          color: AppColors.colorPrimary,
                                          fontSize: SizeConstants.dp16,
                                          fontWeight: AppValues.fontWeight500,
                                          fontFamily: AppValues.fontFamily),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: getWidth(SizeConstants.dp10),
                              ),
                              SizedBox(
                                width: getWidth(SizeConstants.dp130),
                                height: getHeight(SizeConstants.dp45),
                                child: Obx(() => GestureDetector(
                                      onTap: checkStateToSubmit() == true
                                          ? () async {
                                              FocusManager.instance.primaryFocus
                                                  ?.unfocus();

                                              var result =
                                                  await realm.insertBitRequest(
                                                      dictValues.value);

                                              if (result == true) {
                                                widget
                                                    .bitSubmittedCallBak(true);
                                                Get.back();
                                              } else {
                                                widget
                                                    .bitSubmittedCallBak(false);
                                              }
                                            }
                                          : null,
                                      child: Container(
                                        alignment: Alignment.center,
                                        decoration: BoxDecoration(
                                            color: checkStateToSubmit() == true
                                                ? AppColors.colorPrimary
                                                : AppColors.colorPrimary
                                                    .withOpacity(0.3),
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(
                                                    SizeConstants.dp5))),
                                        child: Text(
                                          AppStrings.submit,
                                          style: TextStyle(
                                              fontSize: SizeConstants.dp16,
                                              color:
                                                  checkStateToSubmit() == true
                                                      ? AppColors.colorWhite
                                                      : AppColors.colorWhite
                                                          .withOpacity(0.4),
                                              fontWeight:
                                                  AppValues.fontWeight500,
                                              fontFamily: AppValues.fontFamily),
                                        ),
                                      ),
                                    )),
                              ),
                              const SizedBox(
                                width: SizeConstants.dp60,
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
