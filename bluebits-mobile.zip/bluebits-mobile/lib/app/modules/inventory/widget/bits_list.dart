import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/common_binding/realm_initial.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/screens/consign_bits_screen.dart';
import 'package:slb_gt_mobile/app/modules/inventory/controller/inventory_controller.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';
import 'package:slb_gt_mobile/app/modules/shared/move_to_truck_overlay.dart';
import 'package:slb_gt_mobile/app/modules/shared/move_to_warehouse_overlay.dart';
import 'package:slb_gt_mobile/app/modules/shared/setting_overlay_menu.dart';

import '../../../core/common_widgets/common_widget.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_utils.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';

class BitsList extends StatefulWidget {
  InventoryController inventoryController;
  var scrollController;
  var visible;
  BitsList(
      {required this.inventoryController,
      required this.scrollController,
      required this.visible});

  @override
  State<BitsList> createState() => _BitsListState();
}

class _BitsListState extends State<BitsList> {
  var loginController;
  List<bool> sortingState = List.filled(8, false, growable: true);

  var currentSort = 0;

  var sizeList;

  var curSortIndex = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Add Your Code here.
      //widget.inventoryController.setMyTruckBitList();
    });
  }

  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());

  void _showPopupMenu(Offset globalPosition, int selectedBitIndex) async {
    print(selectedBitIndex);
    double left = globalPosition.dx;
    double top = globalPosition.dy;
    List<PopupMenuEntry<dynamic>> itemList = [];
    itemList.add(PopupMenuItem<String>(
        value: 'Val1',
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: () {
            Navigator.pop(context);
            var _bitsList = widget.inventoryController.allBitList;
            List<Bit> bits = [];
            _bitsList.forEach((b) {
              bits.add(b);
            });
            print('move to wherehouse on single click my turck');

            Navigator.of(context).push(MoveToWarehouseOverlay(false,
                bitsList: [bits[selectedBitIndex]],
                bitSubmittedCallBak: (value) {
              widget.inventoryController
                  .movementInitiateToast(serialNumbers: value.bit);
            }));
          },
          child: Row(children: [
            ImageIcon(
              size: SizeConstants.dp14,
              const AssetImage(
                AppImages.warehouseIcon,
              ),
            ),
            SizedBox(
              width: 17,
            ),
            Text(
              AppStrings.moveToWarehouse,
              style:
                  TextStyle(fontWeight: AppValues.fontWeight400, fontSize: 15),
            )
          ]),
        )));

    itemList.add(PopupMenuItem<String>(
        value: 'Val2',
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: () {
            Navigator.pop(context);
            var _bitsList = realm.getBits();
            List<Bit> bits = [];
            _bitsList.forEach((b) {
              bits.add(b);
            });
            print(
                'move to truck single on my truck ${bits[selectedBitIndex].bitId}');
            print('Bits : ${bits.length}');
            print(
                'move to truck single on my truck all ${widget.inventoryController.allBitList[selectedBitIndex].bitId}');
            Navigator.of(context).push(MoveToTruckOverlay(
                bitsList: [
                  widget.inventoryController.allBitList[selectedBitIndex]
                ],
                bitSubmittedCallBak: (value) => {
                      widget.inventoryController
                          .movementInitiateToast(serialNumbers: value)
                    }));
          },
          child: Row(children: [
            ImageIcon(
              size: SizeConstants.dp14,
              const AssetImage(AppImages.myTruck),
            ),
            SizedBox(
              width: 17,
            ),
            Text(
              AppStrings.moveToTruck,
              style:
                  TextStyle(fontWeight: AppValues.fontWeight400, fontSize: 15),
            )
          ]),
        )));

    await showMenu(
      context: context,
      position: RelativeRect.fromLTRB(left + 100, top, 0, 0),
      items: itemList,
      elevation: 8.0,
    );
  }

  final CustomWidgets cw = CustomWidgets();

  _BitsListState() {
    // [0, 0, 0]
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: EdgeInsets.only(
            left: getWidth(SizeConstants.dp40),
            top: getHeight(SizeConstants.dp12)),
        child: Obx(
          () => Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                flex: 0,
                child: Visibility(
                  visible: !widget.inventoryController.isSortEnable,
                  child: Padding(
                    // We need to move top column titles by 'right padding (25)' + 'checkBoxWidth(20)' i.e 45, so as to adjust with the below data columns.
                    padding: const EdgeInsets.fromLTRB(0, 0, 25, 0),
                    child: SizedBox(
                      height: getHeight(SizeConstants.dp34),
                      width: getWidth(SizeConstants.dp20),
                      child: Visibility(
                          visible:
                              !widget.inventoryController.isSortEnable == true,
                          child: Container(
                            child: Align(
                              alignment: Alignment.center,
                            ),
                          )),
                    ),
                  ),
                ),
              ),
              Expanded(
                flex: 1,
                child: getColumnHeader(
                    widget.inventoryController.columnList[0].title, 0),
              ),
              Expanded(
                flex: 1,
                child: getColumnHeader(
                    widget.inventoryController.columnList[1].title, 1),
              ),
              Expanded(
                flex: 1,
                child: getColumnHeader(
                    widget.inventoryController.columnList[2].title, 2),
              ),
              Expanded(
                flex: 1,
                child: getColumnHeader(
                    widget.inventoryController.columnList[3].title, 3),
              ),
              Expanded(
                flex: 1,
                child: getColumnHeader(
                    widget.inventoryController.columnList[4].title, 4),
              ),
              Expanded(
                flex: 1,
                child: getColumnHeader(
                    widget.inventoryController.columnList[5].title, 5),
              ),
              Expanded(
                flex: 1,
                child: getColumnHeader(
                    widget.inventoryController.columnList[6].title, 6),
              ),
              Expanded(
                flex: 1,
                child: getColumnHeader(
                    widget.inventoryController.columnList[7].title, 7),
              ),
              Expanded(
                flex: 1,
                child: GestureDetector(
                  onTap: () => {
                    Navigator.of(context).push(SettingOverlayMenu(
                        widget.inventoryController.columnList,
                        widget.inventoryController.refreshUI))
                  },
                  child: Container(
                    margin: const EdgeInsets.only(
                        bottom: SizeConstants.dp8, right: SizeConstants.dp10),
                    alignment: Alignment.centerRight,
                    child: const ImageIcon(
                      AssetImage(AppImages.settings),
                      //size: SizeConstants.dp16,
                    ),
                  ),
                ),
              ),
              const SizedBox(
                width: SizeConstants.dp20,
              )
            ],
          ),
        ),
      ),
      Container(
          margin: EdgeInsets.only(right: 10),
          height: widget.visible.value
              ? getScreenHeight() - 194
              : widget.inventoryController.isSelectionEnabled
                  ? getScreenHeight() - 170
                  : getScreenHeight() - 120,
          child: Obx(
            () => //widget.inventoryController.allBitList.length > 0?
                ListView.builder(
              controller: widget.scrollController,
              itemCount: widget.inventoryController.allBitList.length,
              //list== ListFinal
              itemBuilder: (context, index) {
                //TODO make use of KEY to get proper key
                widget.inventoryController.bottomTabNotificationIndex =
                    index + 13 > widget.inventoryController.allBitList.length
                        ? widget.inventoryController.allBitList.length
                        : index + 13;
                var rng = index % 2;

                return GestureDetector(
                  onLongPress: () => widget
                                  .inventoryController
                                  .allBitList[index]
                                  .storageLocationDescription ==
                              AppStrings.warehouseShort ||
                          widget.inventoryController.defaultTab ==
                              AppStrings.myTruck
                      ? !(widget.inventoryController.bitsState.any((element) =>
                              element.bitSerialNumber ==
                                  widget.inventoryController.allBitList[index]
                                      .serialNumber &&
                              element.isBlocked == true))
                          ? widget.inventoryController
                              .selectDeselectAction(index)
                          : {}
                      : {},
                  onTap: () => widget.inventoryController.allBitList[index]
                                  .storageLocationDescription ==
                              AppStrings.warehouseShort ||
                          widget.inventoryController.defaultTab ==
                              AppStrings.myTruck
                      ? !(widget.inventoryController.bitsState.any((element) =>
                              element.bitSerialNumber ==
                                  widget.inventoryController.allBitList[index]
                                      .serialNumber &&
                              element.isBlocked == true))
                          ? {
                              if (widget.inventoryController.isSelectionEnabled)
                                {
                                  widget.inventoryController
                                      .selectDeselectAction(index)
                                }
                            }
                          : {}
                      : {},
                  child: AbsorbPointer(
                    absorbing: widget.inventoryController.bitsState.any(
                        (element) =>
                            element.bitSerialNumber ==
                                widget.inventoryController.allBitList[index]
                                    .serialNumber &&
                            element.isBlocked == true),
                    child: Opacity(
                      opacity: widget.inventoryController.bitsState.any(
                              (element) =>
                                  element.bitSerialNumber ==
                                      widget.inventoryController
                                          .allBitList[index].serialNumber &&
                                  element.isBlocked == true)
                          ? 0.3
                          : 1,
                      child: Opacity(
                        opacity: (widget.inventoryController.allBitList[index]
                                        .storageLocationDescription ==
                                    AppStrings.warehouseShort) ||
                                (widget.inventoryController.defaultTab ==
                                    AppStrings.myTruck)
                            ? 1
                            : widget.inventoryController.dynamicOpacity.value,
                        child: Container(
                          height: getHeight(SizeConstants.dp60),
                          width: getScreenWidth(),
                          decoration: BoxDecoration(
                              boxShadow: const [
                                BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 1.0,
                                    offset: Offset(0.0, 0.75))
                              ],
                              borderRadius: BorderRadius.circular(5),
                              border: widget.inventoryController
                                          .selectedList?[index] ==
                                      true
                                  ? Border.all(
                                      color: AppColors.borderSelectedColor)
                                  : Border.all(color: AppColors.colorWhite),
                              color: AppColors.colorWhite),
                          margin: const EdgeInsets.only(
                              top: 5, left: 20, right: 10, bottom: 5),
                          padding: const EdgeInsets.only(top: 0, left: 20),
                          child: IntrinsicHeight(
                            child: Obx(
                              () => Opacity(
                                opacity: widget
                                                .inventoryController
                                                .allBitList[index]
                                                .storageLocationDescription ==
                                            AppStrings.warehouseShort ||
                                        widget.inventoryController.defaultTab ==
                                            AppStrings.myTruck
                                    ? 1
                                    : widget.inventoryController.dynamicOpacity2
                                        .value,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(
                                      flex: 0,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Visibility(
                                            visible: widget.inventoryController
                                                .isSelectionEnabled,
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      0, 0, 25, 0),
                                              child: Container(
                                                alignment: Alignment.center,
                                                height: getHeight(34),
                                                width: getWidth(20),
                                                child: Visibility(
                                                    visible: widget
                                                            .inventoryController
                                                            .selectedList[index] ==
                                                        true,
                                                    child: const Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: ImageIcon(
                                                        AssetImage(AppImages
                                                            .selectedCheck),
                                                        color: AppColors
                                                            .colorCheckBoxSelected,
                                                        size:
                                                            SizeConstants.dp20,
                                                      ),
                                                    )),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: getColumn(
                                          widget.inventoryController
                                              .columnList[0].title,
                                          index),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: getColumn(
                                          widget.inventoryController
                                              .columnList[1].title,
                                          index),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: getColumn(
                                          widget.inventoryController
                                              .columnList[2].title,
                                          index),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: getColumn(
                                          widget.inventoryController
                                              .columnList[3].title,
                                          index),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: getColumn(
                                          widget.inventoryController
                                              .columnList[4].title,
                                          index),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: getColumn(
                                          widget.inventoryController
                                              .columnList[5].title,
                                          index),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: getColumn(
                                          widget.inventoryController
                                              .columnList[6].title,
                                          index),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: getColumn(
                                          widget.inventoryController
                                              .columnList[7].title,
                                          index),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: AnimatedContainer(
                                        alignment: Alignment.centerRight,
                                        duration: const Duration(seconds: 0),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: [
                                            Expanded(
                                              child: Visibility(
                                                visible: widget
                                                        .inventoryController
                                                        .defaultTab !=
                                                    AppStrings.otherDistrict,
                                                child: AnimatedContainer(
                                                    duration: const Duration(
                                                        milliseconds: 0),
                                                    width: widget
                                                            .inventoryController
                                                            .tab
                                                        ? widget
                                                            .inventoryController
                                                            .moveToTruckButtonWidth
                                                        : widget
                                                            .inventoryController
                                                            .consignButtonWidth,
                                                    height: widget
                                                            .inventoryController
                                                            .tab
                                                        ? widget
                                                            .inventoryController
                                                            .moveToTruckButtonHeight
                                                        : widget
                                                            .inventoryController
                                                            .consignButtonHeight,
                                                    child: widget
                                                            .inventoryController
                                                            .tab
                                                        ? GestureDetector(
                                                            onTap: () {
                                                              var value = widget
                                                                  .inventoryController
                                                                  .allBitList[
                                                                      index]
                                                                  .storageLocationDescription;
                                                              if (value ==
                                                                  AppStrings
                                                                      .warehouseShort) {
                                                                var _bitsList =
                                                                    realm
                                                                        .getBits();
                                                                List<Bit> bits =
                                                                    [];
                                                                _bitsList
                                                                    .forEach(
                                                                        (b) {
                                                                  bits.add(b);
                                                                });
                                                                print(
                                                                    'Bits : ${bits.length}');
                                                                print(
                                                                    'move to truck single on my disrict');

                                                                Navigator.of(
                                                                        context)
                                                                    .push(MoveToWarehouseOverlay(
                                                                        true,
                                                                        bitsList: [
                                                                          widget
                                                                              .inventoryController
                                                                              .allBitList[index]
                                                                        ],
                                                                        bitSubmittedCallBak: (value) =>
                                                                            {
                                                                              widget.inventoryController.movementInitiateToast(serialNumbers: value.bit)
                                                                            }));
                                                              }
                                                            },
                                                            child: Container(
                                                              constraints: const BoxConstraints(
                                                                  minWidth:
                                                                      SizeConstants
                                                                          .dp130,
                                                                  maxWidth:
                                                                      SizeConstants
                                                                          .dp130),
                                                              decoration:
                                                                  BoxDecoration(
                                                                border: Border.all(
                                                                    color: widget.inventoryController.allBitList[index].storageLocationDescription ==
                                                                            AppStrings
                                                                                .warehouseShort
                                                                        ? AppColors
                                                                            .colorPrimary
                                                                        : AppColors
                                                                            .colorPrimary
                                                                            .withOpacity(0.3)),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            5),
                                                              ),
                                                              child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  ImageIcon(
                                                                    const AssetImage(
                                                                        AppImages
                                                                            .myTruck),
                                                                    color: widget.inventoryController.allBitList[index].storageLocationDescription ==
                                                                            AppStrings
                                                                                .warehouseShort
                                                                        ? AppColors
                                                                            .colorPrimary
                                                                        : AppColors
                                                                            .colorPrimary
                                                                            .withOpacity(0.3),
                                                                    size: SizeConstants
                                                                        .dp14,
                                                                  ),
                                                                  const SizedBox(
                                                                    width:
                                                                        SizeConstants
                                                                            .dp5,
                                                                  ),
                                                                  Text(
                                                                    AppStrings
                                                                        .moveToTruck,
                                                                    style: TextStyle(
                                                                        color: widget.inventoryController.allBitList[index].storageLocationDescription == AppStrings.warehouseShort
                                                                            ? AppColors
                                                                                .colorPrimary
                                                                            : AppColors.colorPrimary.withOpacity(
                                                                                0.3),
                                                                        fontSize:
                                                                            15),
                                                                  )
                                                                ],
                                                              ),
                                                            ),
                                                          )
                                                        : GestureDetector(
                                                            onTap: () {
                                                              List<Bit>
                                                                  bitsSelected =
                                                                  [];
                                                              bitsSelected.add(widget
                                                                  .inventoryController
                                                                  .allBitList[index]);

                                                              Get.to(
                                                                  ConsignBits(
                                                                    isDraftEdit:
                                                                        false,
                                                                    selectedBits:
                                                                        bitsSelected,
                                                                  ),
                                                                  transition:
                                                                      Transition
                                                                          .native,
                                                                  duration: const Duration(
                                                                      milliseconds:
                                                                          300));
                                                            },
                                                            child: Container(
                                                              constraints: const BoxConstraints(
                                                                  minWidth:
                                                                      SizeConstants
                                                                          .dp98,
                                                                  maxWidth:
                                                                      SizeConstants
                                                                          .dp98),
                                                              decoration:
                                                                  BoxDecoration(
                                                                border: Border.all(
                                                                    color: AppColors
                                                                        .colorPrimary),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            5),
                                                              ),
                                                              child: Row(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .center,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  ImageIcon(
                                                                    AssetImage(
                                                                        AppImages
                                                                            .rig),
                                                                    color: AppColors
                                                                        .colorPrimary,
                                                                    size: SizeConstants
                                                                        .dp14,
                                                                  ),
                                                                  SizedBox(
                                                                    width:
                                                                        SizeConstants
                                                                            .dp5,
                                                                  ),
                                                                  Text(
                                                                    AppStrings
                                                                        .consign,
                                                                    style: TextStyle(
                                                                        color: AppColors
                                                                            .colorPrimary,
                                                                        fontSize:
                                                                            15),
                                                                  )
                                                                ],
                                                              ),
                                                            ),
                                                          )),
                                              ),
                                            ),
                                            SizedBox(
                                              width: SizeConstants.dp10,
                                            ),
                                            Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                children: [
                                                  Visibility(
                                                    visible: !widget
                                                            .inventoryController
                                                            .isSelectionEnabled &&
                                                        !widget
                                                            .inventoryController
                                                            .tab &&
                                                        widget.inventoryController
                                                                .defaultTab !=
                                                            AppStrings
                                                                .otherDistrict,
                                                    child: GestureDetector(
                                                      onTapDown: (TapDownDetails
                                                          details) {
                                                        _showPopupMenu(
                                                            details
                                                                .globalPosition,
                                                            index);
                                                      },
                                                      child: const Icon(
                                                        Icons.more_vert,
                                                        size:
                                                            SizeConstants.dp20,
                                                      ),
                                                    ),
                                                  ),
                                                ]),
                                          ],
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: SizeConstants.dp10,
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            )
            /*: Expanded(
                    child: SizedBox(
                      width: double.infinity,
                      child: NoResultsScreen(
                        imagePath: AppImages.noResults,
                        titleText: AppStrings.noResultsFound,
                        descriptionText: AppStrings.noResultsDescription,
                        titleStyle: tSw500dp16fontF.copyWith(
                          color: AppColors.colorMainText,
                          fontSize: SizeConstants.dp32,
                        ),
                        descriptionStyle: tSw400dp14fontF.copyWith(
                          color: AppColors.colorSubText.withOpacity(0.7),
                          fontSize: SizeConstants.dp20,
                        ),
                        onPressCallback: () {},
                        buttonText: '',
                      ),
                    ),
                  )*/
            ,
          )),
    ]);
  }

  Widget getColumn(columnName, index) {
    //var mappedBit = mapBit(bit);
    // var bitSize = int.parse(widget.inventoryController.allBitList[index].bitSize);
    // var bitSizeInches = bitSize / 25.4;
    if (columnName == AppStrings.size) {
      return Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
                widget.inventoryController.allBitList[index].inch
                    .formatStringIfNull(),
                style: const TextStyle(
                    fontWeight: AppValues.fontWeight600,
                    color: AppColors.colorBlack,
                    fontSize: 15)),
            Text(
                widget.inventoryController.allBitList[index].milim
                    .formatStringIfNull(),
                style: const TextStyle(
                    fontWeight: AppValues.fontWeight400,
                    color: AppColors.colorSubText,
                    // color: AppColors.lightGreyColor,
                    fontSize: 12))
          ],
        ),
      );
    } else if (columnName == AppStrings.noOfRuns) {
      int runs;
      if (widget.inventoryController.allBitList[index].numberOfRuns == null) {
        runs = 0;
      } else {
        runs = int.parse(widget
            .inventoryController.allBitList[index].numberOfRuns
            .toString());
        if (runs < 0) {
          runs = 0;
        }
      }
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            // crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                  child: Text(
                "$runs",
                style: runs == 0
                    ? const TextStyle(
                        color: AppColors.colorGreen,
                        fontSize: SizeConstants.dp15)
                    : const TextStyle(
                        color: AppColors.colorOrange,
                        fontSize: SizeConstants.dp15),
              )),
              Container(
                alignment: Alignment.center,
                height: getHeight(18),
                width: getWidth(37),
                decoration: BoxDecoration(
                    color: AppColors.colorWhite,
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(
                        width: 1,
                        color: runs == 0
                            ? AppColors.colorGreen.withOpacity(0.7)
                            : AppColors.colorOrange.withOpacity(0.7))),
                margin: EdgeInsets.only(left: 10),
                child: Text(
                  runs == 0 ? AppStrings.newChar : AppStrings.used,
                  style: TextStyle(
                      fontSize: 10,
                      color: runs == 0
                          ? AppColors.colorGreen
                          : AppColors.colorOrange),
                ), // <-- Text
              ),
            ],
          )
        ],
      );
    } else if (columnName == AppStrings.currentLocation) {
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Flexible(
            child: Text("${widget.inventoryController.allBitList[index].plant}",
                style: const TextStyle(
                    fontWeight: AppValues.fontWeight600,
                    color: AppColors.colorBlack,
                    fontSize: 15)),
          ),
          Text("${widget.inventoryController.allBitList[index].plantName}",
              style: const TextStyle(
                  fontWeight: AppValues.fontWeight400,
                  color: AppColors.colorSubText,
                  fontSize: 12))
        ],
      );
    } else if (columnName == AppStrings.slocDesc) {
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Flexible(
            child: Text(
                "${widget.inventoryController.allBitList[index].storageLoc}",
                style: const TextStyle(
                    fontWeight: AppValues.fontWeight600,
                    color: AppColors.colorBlack,
                    fontSize: 15)),
          ),
          Text(
              "${widget.inventoryController.allBitList[index].storageLocationDescription}",
              style: const TextStyle(
                  fontWeight: AppValues.fontWeight400,
                  color: AppColors.colorSubText,
                  fontSize: 12))
        ],
      );
    } else if (columnName == AppStrings.status) {
      var value = widget
          .inventoryController.allBitList[index].storageLocationDescription;
      var icon;
      if (value == AppStrings.truckShort) {
        icon = AppImages.truck;
      } else if (value == AppStrings.warehouseShort) {
        icon = AppImages.warehouse;
      } else {
        icon = AppImages.drill;
      }
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
              height: getWidth(SizeConstants.dp20),
              width: getWidth(SizeConstants.dp20),
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(icon),
                  fit: BoxFit.fill,
                ),
              ),
              child: null)
        ],
      );
    } else if (columnName == AppStrings.materialDesc) {
      return GestureDetector(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Tooltip(
              message:
                  "${getColumnValue(widget.inventoryController.allBitList[index], columnName)}",
              child: Text(
                  maxLines: 2,
                  "${getColumnValue(widget.inventoryController.allBitList[index], columnName)}",
                  style: const TextStyle(
                      overflow: TextOverflow.ellipsis,
                      fontWeight: AppValues.fontWeight400,
                      color: AppColors.colorBlack,
                      fontSize: 15)),
            )
          ],
        ),
      );
    } else {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
              maxLines: 2,
              "${getColumnValue(widget.inventoryController.allBitList[index], columnName)}",
              style: const TextStyle(
                  overflow: TextOverflow.ellipsis,
                  fontWeight: AppValues.fontWeight400,
                  color: AppColors.colorBlack,
                  fontSize: 15))
        ],
      );
    }
  }

  Widget getColumnHeader(columnName, index) {
    return GestureDetector(
      onTap: () {
        sortingState[index] = !sortingState[index];
        curSortIndex = index;

        if (widget.inventoryController.isSortEnable) {
          widget.inventoryController.sortColumn(sortingState[index],
              widget.inventoryController.columnList[index].title);
        }
        setState(() {
          currentSort = 0;
        });
      },
      child: Container(
        padding: const EdgeInsets.only(
          bottom: SizeConstants.dp8,
        ),
        alignment: Alignment.centerLeft,
        child: Wrap(
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            Text(
              "${columnName}",
              style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: SizeConstants.dp11,
                  color: AppColors.colorSubText),
            ),
            Visibility(
              visible: widget.inventoryController.isSortEnable &&
                  curSortIndex == index,
              child: Icon(
                  color: AppColors.colorSubText,
                  size: 9,
                  sortingState[index]
                      ? Icons.arrow_upward
                      : Icons.arrow_downward),
            )
          ],
        ),
      ),
    );
  }

  getColumnValue(Bit bit, String ColumnName) {
    var mappedBit = widget.inventoryController.mapBit(bit);
    return mappedBit[ColumnName];
  }
}
