import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/common_binding/realm_initial.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/screens/consign_bits_screen.dart';
import 'package:slb_gt_mobile/app/modules/inventory/controller/inventory_controller.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';
import 'package:slb_gt_mobile/app/modules/shared/move_to_truck_overlay.dart';
import 'package:slb_gt_mobile/app/modules/shared/move_to_warehouse_overlay.dart';

import '../../../core/common_widgets/common_widget.dart';
import '../../../core/common_widgets/pop_menu_item.dart';
import '../../../core/common_widgets/toast_message.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_utils.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';

class CombinedActionInventoryTab extends StatefulWidget {
  InventoryController inventoryController;
  late int numberOfSelectedBits;
  var maxBitSelectionAllowed = 10;
  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());
  var tab;

  CombinedActionInventoryTab(this.inventoryController) {
    numberOfSelectedBits = inventoryController.noOfSelectedBits.value;
    tab = inventoryController.tab;
  }

  @override
  State<CombinedActionInventoryTab> createState() =>
      _CombinedActionInventoryTabState();
}

class _CombinedActionInventoryTabState
    extends State<CombinedActionInventoryTab> {
  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());

  List<PopMenuItems> lst = [
    PopMenuItems(
        icon: const ImageIcon(
          size: SizeConstants.dp14,
          AssetImage(
            AppImages.warehouseIcon,
          ),
        ),
        title: AppStrings.moveToWarehouse,
        type: filterOptions.Warehouse),
    PopMenuItems(
        icon: const ImageIcon(
          size: SizeConstants.dp14,
          AssetImage(
            AppImages.myTruck,
          ),
        ),
        title: AppStrings.moveToTruck,
        type: filterOptions.Truck),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          color: AppColors.colorTopPanel,
          height: getHeight(SizeConstants.dp50),
          child: Row(
            children: [
              SizedBox(
                width: getWidth(SizeConstants.dp30),
              ),
              GestureDetector(
                  onTap: () => widget.inventoryController.unSelectBits(),
                  child: Image.asset(AppImages.backArrow)),
              SizedBox(
                width: getWidth(SizeConstants.dp16),
              ),
              Text(
                "${widget.numberOfSelectedBits}",
                style: const TextStyle(
                    fontSize: SizeConstants.dp16,
                    fontFamily: AppValues.fontFamily,
                    color: AppColors.colorPrimary,
                    fontWeight: FontWeight.w700),
              ),
              const SizedBox(
                width: SizeConstants.dp5,
              ),
              const Text(
                AppStrings.selected,
                style: TextStyle(
                    fontSize: SizeConstants.dp16,
                    fontFamily: AppValues.fontFamily,
                    color: AppColors.colorPrimary,
                    fontWeight: FontWeight.w400),
              ),
              SizedBox(
                width: getWidth(SizeConstants.dp30),
              ),
              Visibility(
                visible:
                    widget.numberOfSelectedBits >= widget.maxBitSelectionAllowed,
                child: Text(
                  "(At max only ${widget.maxBitSelectionAllowed} bits can be selected at a time)",
                  style: const TextStyle(
                  fontStyle: FontStyle.italic,
                  fontSize: SizeConstants.dp13,
                  fontFamily: AppValues.fontFamily,
                  color: AppColors.colorPrimary,
                  fontWeight: FontWeight.w400),
                ),
              ),
              const Spacer(),
              Container(
                child: !widget.tab
                    ? GestureDetector(
                        onTap: () {
                          List<Bit> bitsSelected =
                              widget.inventoryController.getSelectedBits();

                          widget.inventoryController.unSelectBits();

                          print('Bits list selected count:- $bitsSelected');
                          if (bitsSelected.isNotEmpty) {
                            Get.to(
                                ConsignBits(
                                  isDraftEdit: false,
                                  selectedBits: bitsSelected,
                                ),
                                transition: Transition.native,
                                duration: const Duration(milliseconds: 300));
                          }
                        },
                        child: Container(
                          width: getWidth(98),
                          height: getHeight(34),
                          decoration: BoxDecoration(
                            border: Border.all(color: AppColors.colorPrimary),
                            borderRadius: BorderRadius.circular(5),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ImageIcon(
                                AssetImage(AppImages.rig),
                                color: AppColors.colorPrimary,
                                size: SizeConstants.dp14,
                              ),
                              SizedBox(
                                width: SizeConstants.dp5,
                              ),
                              Text(
                                AppStrings.consign,
                                style: TextStyle(
                                    color: AppColors.colorPrimary, fontSize: 15),
                              )
                            ],
                          ),
                        ),
                      )
                    : GestureDetector(
                        onTap: () {
                          var _bitsList = widget.realm.getBits();
                          List<Bit> bits = [];
                          _bitsList.forEach((b) {
                            bits.add(b);
                          });

                          print("move to truck multi selecet on my district");
                          print('Bits : ${bits.length}');
                          Navigator.of(context).push(
                            MoveToWarehouseOverlay(true,
                                bitsList:
                                    widget.inventoryController.getSelectedBits(),
                                bitSubmittedCallBak: (value) => {
                                          /*showToastMsg(
                                              AppStrings.truckMoveSuccessMsg,
                                              ToastStatus.success)*/
                                  widget.inventoryController.movementInitiateToast(serialNumbers: value.bit)
                                    }),
                          );
                        },
                        child: Container(
                          width: getWidth(131),
                          height: getHeight(34),
                          decoration: BoxDecoration(
                            border: Border.all(color: AppColors.colorPrimary),
                            borderRadius: BorderRadius.circular(5),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ImageIcon(
                                AssetImage(AppImages.myTruck),
                                color: AppColors.colorPrimary,
                                size: 14,
                              ),
                              SizedBox(
                                width: SizeConstants.dp5,
                              ),
                              Text(
                               AppStrings.moveToTruck,
                                style: TextStyle(
                                    color: AppColors.colorPrimary, fontSize: 15),
                              )
                            ],
                          ),
                        ),
                      ),
              ),
              SizedBox(
                width: getWidth(20),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Visibility(
                    visible: widget.inventoryController.defaultTab !=
                        AppStrings.myDistrict,
                    child: PopupMenuButton(
                      onSelected: (selectedValue) {
                        if (selectedValue == filterOptions.Warehouse) {
                          var _bitsList = widget.realm.getBits();
                          List<Bit> bits = [];
                          _bitsList.forEach((b) {
                            bits.add(b);
                          });
                          print('Move to whare house multi select on my truck');
                          Navigator.of(context).push(MoveToWarehouseOverlay(false,
                              bitsList: widget.inventoryController
                                  .getSelectedBits(), bitSubmittedCallBak: (value) {

                              /*showToastMsg(
                                  "Bit ${value.bit} is successfully moved to Warehouse ${value.warehouse}",
                                  ToastStatus.success);*/
                                widget.inventoryController.movementInitiateToast(serialNumbers: value.bit);

                          }));
                        } else {
                          //Navigator.of(context).push((true));
                          var _bitsList = widget.realm.getBits();
                          List<Bit> bits = [];
                          _bitsList.forEach((b) {
                            bits.add(b);
                          });
                          print('Move to truck Multi bit select on my truck ');
                          Navigator.of(context).push(MoveToTruckOverlay(
                              bitsList:
                                  widget.inventoryController.getSelectedBits(),
                              bitSubmittedCallBak: (value) => {
                                widget.inventoryController.movementInitiateToast(serialNumbers: value)
                                  }));
                        }
                      },
                      icon: const Icon(Icons.more_vert),
                      itemBuilder: (_) => CustomWidgets().buildPopupMenu(lst),
                      offset: const Offset(-30, 0),
                    ),
                  )
                ],
              ),
              SizedBox(
                width: getWidth(SizeConstants.dp20),
              ),
            ],
          ),
        ),
        const Divider(
          height: SizeConstants.dp1,
          color: AppColors.colorSeparatorLine, //.withOpacity(0.30),
        ),
      ],
    );
  }
}
