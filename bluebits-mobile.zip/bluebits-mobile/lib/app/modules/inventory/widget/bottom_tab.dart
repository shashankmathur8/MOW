import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:slb_gt_mobile/app/core/common_widgets/toast_message.dart';

import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';

class BottomTab extends StatefulWidget {
  const BottomTab({super.key});

  @override
  State<BottomTab> createState() => _BottomTabState();

}

class _BottomTabState extends State<BottomTab> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: getHeight(SizeConstants.dp68),
      width: double.maxFinite,
      color: AppColors.colorWhite,
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          width: getWidth(SizeConstants.dp90),
          child:
          Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
            const ImageIcon(
              AssetImage(AppImages.inventory),
              size: SizeConstants.dp40,
              color: AppColors.colorPrimary,
            ),
            Text(AppStrings.inventory,
                style: tSw600dp14fontF.copyWith(
                  color: AppColors.colorPrimary,
                ))
          ]),
        ),
        SizedBox(
          width: getWidth(SizeConstants.dp40),
        ),
        GestureDetector(
          onTap: () {
            // Get.to(const ConsignedScreen());
          },
          child: Container(
            width: getWidth(SizeConstants.dp100),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const ImageIcon(
                    AssetImage(AppImages.consignBits),
                    size: SizeConstants.dp40,
                  ),
                  Text(AppStrings.consignedBits,
                      style: tSw600dp14fontF.copyWith(
                        color: AppColors.textColorGreyLight,
                      )),
                ]),
          ),
        ),
        SizedBox(
          width: getWidth(SizeConstants.dp40),
        ),
        Container(
          width: getWidth(SizeConstants.dp90),
          child:
          Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
            const ImageIcon(
              AssetImage(AppImages.billBits),
              size: SizeConstants.dp40,
            ),
            Text(AppStrings.billedBits,
                style: tSw600dp14fontF.copyWith(
                  color: AppColors.textColorGreyLight,
                ))
          ]),
        )
      ]),
    );
  }
}

