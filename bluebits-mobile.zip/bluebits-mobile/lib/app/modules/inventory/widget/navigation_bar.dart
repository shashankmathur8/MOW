import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/utils/logger_common.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';
import 'package:slb_gt_mobile/app/modules/notification/controller/notification_controller.dart';
import 'package:slb_gt_mobile/app/modules/shared/profile_image.dart';

import '../../../core/values/app_colors.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../login/controller/login_controller.dart';
import '../../login/widget/profile_overlay.dart';
import '../../shared/notification_overlay.dart';

class Navigation_Bar extends StatelessWidget {
  final title;

  final LoginController loginController = Get.find();
  final NotificationController notificationController = Get.put(
      NotificationController(),
      tag: (NotificationController).toString());

  Navigation_Bar({super.key, @required this.title});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppColors.topColorPrimaryDark,
            AppColors.bottomColorPrimaryDark
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(
            height: SizeConstants.dp20,
          ),
          Row(
            children: [
              const SizedBox(
                width: SizeConstants.dp20,
              ),
              TextButton(
                onPressed: () {
                  print("Dashboard Action Comes Over Here");
                },
                style: TextButton.styleFrom(padding: EdgeInsets.zero),
                child: const Text(AppValues.dashboardStr,
                    style: TextStyle(
                        fontSize: SizeConstants.dp15,
                        color: AppColors.colorWhite)),
              ),
              const SizedBox(
                width: SizeConstants.dp5,
              ),
              const Icon(Icons.arrow_forward_ios,
                  size: SizeConstants.dp12, color: AppColors.colorWhite),
              const SizedBox(
                width: SizeConstants.dp5,
              ),
              //Text(AppValues.bitsInvStr,
              Text(title == '' ? AppValues.bitsInvStr : title,
                  style: const TextStyle(
                      fontSize: SizeConstants.dp15,
                      color: AppColors.colorWhite,
                      fontWeight: FontWeight.w600)),
              const Spacer(),
              Text(
                loginController.appVersion.value,
                style: tSw400dp14fontF.copyWith(
                  color: AppColors.colorWhite,
                ),
              ),
              const SizedBox(
                width: SizeConstants.dp10,
              ),
              Container(
                width: getWidth(SizeConstants.dp50),
                child: IconButton(
                  icon: Image.asset(AppImages.helpIcon),
                  color: AppColors.colorWhite,
                  onPressed: () {
                    ApplicationLogger()
                        .printInfo("Notifications Action", "NavigationBar");
                  },
                ),
              ),
              const SizedBox(
                width: SizeConstants.dp10,
              ),
              Container(
                width: getWidth(SizeConstants.dp50),
                child: IconButton(
                  icon: Image.asset(AppImages.notificationIcon),
                  color: AppColors.colorWhite,
                  onPressed: () {
                    Navigator.of(context).push(NotificationOverlay());
                  },
                ),
              ),
              const SizedBox(
                width: SizeConstants.dp20,
              ),
              GestureDetector(
                onTap: () {
                  if (loginController.userDetailsList != null && loginController.userDetailsList.isNotEmpty) {
                    Navigator.of(context).push(ProfileOverlay());
                  }
                },
                child: Container(width: getWidth(SizeConstants.dp50), child: ProfileImage(false, true)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
