import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/utils/logger_common.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/modules/inventory/controller/inventory_controller.dart';

import '../../../core/common_widgets/custom_button_material.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../../shared/generic_overlay.dart';
import 'filter_category_collection.dart';
import 'filter_search_item_collection.dart';

class FilterOverlayView extends StatefulWidget {
  FilterOverlayView({Key? key}) : super(key: key);

  @override
  State<FilterOverlayView> createState() => _FilterOverlayViewState();
}

class _FilterOverlayViewState extends State<FilterOverlayView> {
  InventoryController inventoryController = Get.find();

  Widget separatorLine = Container(
    color: AppColors.colorSeparatorLine.withOpacity(0.4),
    height: SizeConstants.dp0_3,
    width: getWidth(SizeConstants.dp450),
  );

  Widget separatorVerticalLine = Container(
    color: AppColors.colorSeparatorLine.withOpacity(0.4),
    width: SizeConstants.dp0_3,
  );

  Widget? descriptionText() {
    return SizedBox(
      width: SizeConstants.dp360,
      child: Text(
        AppStrings.discardChangesDes,
        style: tSw400dp14fontF.copyWith(
          color: AppColors.colorBlack,
          fontSize: SizeConstants.dp18,
        ),
      ),
    );
  }

  Widget bottomButtonWidget(BuildContext context) {
    return ClipRRect(
      borderRadius: const BorderRadius.only(
        bottomLeft: Radius.circular(AppValues.radius_5),
      ),
      child: Container(
        color: AppColors.colorWhite,
        width: getWidth(SizeConstants.dp450),
        padding: EdgeInsets.only(
            top: getHeight(SizeConstants.dp18),
            bottom: getHeight(SizeConstants.dp20),
            right: getWidth(SizeConstants.dp20)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            CustomButtonMaterial(
              width: getWidth(SizeConstants.dp102),
              height: getHeight(SizeConstants.dp45),
              backgroundColor: AppColors.colorWhite,
              foregroundColor: AppColors.colorPrimary,
              borderRadius: AppValues.radius_4,
              text: AppStrings.close,
              style: tSw500dp16fontF,
              side: const BorderSide(
                width: SizeConstants.dp1,
                color: AppColors.colorPrimary,
              ),
              onPressCallback: () {
                inventoryController.filterSearchController.clear();
                Get.back();
                if (inventoryController.filterDiscardPopupToShow) {
                  inventoryController.filterDiscardPopupToShow = false;
                  //open popup of discard
                  Navigator.of(context).push(GenericOverlay(
                      iconPath: AppImages.alertNoBitsConsign,
                      title: AppStrings.discardChanges,
                      messageWidget: descriptionText(),
                      negativeButtonText: AppStrings.no,
                      positiveButtonText: AppStrings.yes,
                      onPositivePressCallback: () async {
                        inventoryController.updateInventorySelectedFilterTile();
                        Get.back();
                      }));
                }
              },
            ),
            SizedBox(
              width: getWidth(SizeConstants.dp10),
            ),
            CustomButtonMaterial(
              width: getWidth(SizeConstants.dp130),
              height: getHeight(SizeConstants.dp45),
              backgroundColor: AppColors.colorPrimary,
              foregroundColor: AppColors.colorWhite,
              borderRadius: AppValues.radius_4,
              text: AppStrings.apply,
              style: tSw500dp16fontF,
              onPressCallback: () {
                inventoryController.filterSearchController.clear();
                inventoryController.filterDiscardPopupToShow = false;
                inventoryController.updateInventorySelectedFilterTile();
                Get.back();
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget headerInformationView() {
    return ClipRRect(
      borderRadius: const BorderRadius.only(
        topLeft: Radius.circular(AppValues.radius_5),
      ),
      child: Container(
        color: AppColors.colorWhite,
        width: getWidth(SizeConstants.dp450),
        padding: EdgeInsets.only(
            top: getHeight(SizeConstants.dp15),
            bottom: getHeight(SizeConstants.dp14),
            left: getWidth(SizeConstants.dp28),
            right: getWidth(SizeConstants.dp25)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              AppStrings.filters,
              style: tSw700fontF.copyWith(
                color: AppColors.colorBlack,
                fontSize: SizeConstants.dp24,
              ),
            ),
            Obx(() => Visibility(
                  visible: inventoryController.filterCheckBoxItemList
                      .where(
                          (element) => element.selectedFilterCount().isNotEmpty)
                      .toList()
                      .isNotEmpty,
                  child: GestureDetector(
                    onTap: () {
                      ApplicationLogger()
                          .printInfo('Clear All Clicked', AppStrings.clearAll);
                      inventoryController.resetFilter(
                          isCancelButtonEnable: false);
                      inventoryController.filterDiscardPopupToShow = true;
                      inventoryController.filterSearchController.clear();
                    },
                    child: Text(
                      AppStrings.clearAll,
                      style: tSw500dp16fontF.copyWith(
                        color: AppColors.colorPrimary,
                        fontSize: SizeConstants.dp12,
                      ),
                    ),
                  ),
                ))
          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    Future.delayed(const Duration(milliseconds: 300)).then((value) {
      inventoryController.applySelectedFilterValueToPopup();
    });
  }

  @override
  Widget build(BuildContext context) {
    return IntrinsicHeight(
      child: SizedBox(
        height: SizeConstants.dp130,
        width: SizeConstants.dp130,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            headerInformationView(),
            separatorLine,
            Expanded(
                child: Container(
              width: getWidth(SizeConstants.dp450),
              color: AppColors.colorWhite,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                      color: AppColors.colorWhite,
                      width: getWidth(SizeConstants.dp182),
                      child: FilterCategoryCollection(inventoryController)),
                  Container(
                      color: AppColors.colorBackgroundPanel,
                      width: getWidth(SizeConstants.dp268),
                      child: FilterSearchItemCollection(inventoryController)),
                ],
              ),
            )),
            separatorLine,
            bottomButtonWidget(context),
          ],
        ),
      ),
    );
  }
}
