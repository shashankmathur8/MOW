import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/modules/inventory/controller/inventory_controller.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/filter_checkbox_item.dart';

import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/common_widget.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';

class FilterSearchItemCollection extends StatefulWidget {
  final InventoryController inventoryController;

  const FilterSearchItemCollection(this.inventoryController, {Key? key})
      : super(key: key);

  @override
  State<FilterSearchItemCollection> createState() =>
      _FilterSearchItemCollectionState();
}

class _FilterSearchItemCollectionState
    extends State<FilterSearchItemCollection> {
  var outLineBorder = outLineBorderDecor(
      AppValues.radius_10, SizeConstants.dp1, AppColors.colorSeparatorLine);

  Widget filterSearchWidget() {
    return Container(
      height: getHeight(SizeConstants.dp38),
      padding: EdgeInsets.symmetric(horizontal: getWidth(SizeConstants.dp15)),
      decoration: BoxDecoration(
        color: AppColors.colorGreyInputBox,
        border: Border.all(
            width: getWidth(SizeConstants.dp1),
            color: AppColors.colorSeparatorLine),
        borderRadius:
            const BorderRadius.all(Radius.circular(AppValues.radius_10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Flexible(
            child: Obx(() => TextFormField(
                  controller: widget.inventoryController.filterSearchController,
                  autocorrect: false,
                  enableSuggestions: false,
                  cursorColor: AppColors.colorPrimary,
                  autofocus: false,
                  maxLines: 1,
                  minLines: 1,
                  keyboardType: TextInputType.text,
                  textAlign: TextAlign.start,
                  style: tSw400dp14fontF.copyWith(
                    color: AppColors.colorMainText,
                  ),
                  inputFormatters: [
                    filteringTextInputFormatter,
                  ],
                  decoration: InputDecoration(
                      filled: false,
                      hintText:
                          '${AppStrings.search} ${widget.inventoryController.getActiveSelectedCategoryName()}',
                      hintStyle: tSw400dp14fontF.copyWith(
                        color: AppColors.colorSubText,
                      ),
                      border: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      errorBorder: InputBorder.none,
                      disabledBorder: InputBorder.none,
                      floatingLabelBehavior: FloatingLabelBehavior.never,
                      isDense: true),
                  onChanged: (value) {
                    widget.inventoryController.filterSearchValue(value ?? '');
                  },
                  onTapOutside: (event) {
                    FocusManager.instance.primaryFocus?.unfocus();
                  },
                )),
          ),
          IconButton(
              constraints: const BoxConstraints(maxHeight: SizeConstants.dp24),
              padding: const EdgeInsets.all(SizeConstants.dp0),
              splashColor: AppColors.transparentColor,
              icon: Image.asset(AppImages.search),
              onPressed: () {})
        ],
      ),
    );
  }

  Widget checkboxView(String key, bool value) {
    return CheckboxListTile(
      title: Text(
        key,
        style: tSw400dp14fontF.copyWith(color: AppColors.colorMainText),
      ),
      dense: true,
      checkboxShape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppValues.radius_2),
      ),
      //splashRadius: 0,
      side: const BorderSide(
          width: SizeConstants.dp1,
          color: AppColors.colorCheckBoxUnselected,
          style: BorderStyle.solid),
      activeColor: AppColors.colorCheckBoxSelected,
      checkColor: AppColors.colorWhite,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppValues.radius_2),
      ),
      contentPadding: const EdgeInsets.all(SizeConstants.dp0),
      controlAffinity: ListTileControlAffinity.leading,
      value: value,
      onChanged: (val) {
        widget.inventoryController.categoryFilterItemCheckChange(key, val!);
      },
    );
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
          left: getWidth(AppValues.padding_11),
          right: getWidth(AppValues.padding_15),
          top: getHeight(AppValues.padding_14),
          bottom: getHeight(AppValues.padding_14)),
      child: Column(
        children: [
          filterSearchWidget(),
          Expanded(
              child: Obx(
            () => widget.inventoryController
                    .getActiveCategory()!
                    .categoryItem
                    .isNotEmpty
                ? ListView.builder(
                    padding: const EdgeInsets.all(8.0),
                    itemBuilder: (BuildContext context, int index) {
                      return checkboxView(
                          widget.inventoryController.filterSearchMap.keys
                              .elementAt(index),
                          widget.inventoryController.filterSearchMap.values
                              .elementAt(index));
                    },
                    itemCount:
                        widget.inventoryController.filterSearchMap.length,
                    physics: const ScrollPhysics(),
                  )
                : noDataWidget(AppStrings.noDataFound),
          )),
        ],
      ),
    );
  }
}
