import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';
import 'package:slb_gt_mobile/app/modules/inventory/controller/inventory_controller.dart';
import 'package:slb_gt_mobile/app/modules/inventory/widget/request_bit_overlay.dart';

import '../../../core/common_widgets/no_overscroll_behavior.dart';
import '../../../core/common_widgets/toast_message.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../shared/recent_searches.dart';
import 'filter_overlay.dart';

class InventoryTabView extends StatefulWidget {
  InventoryController controller;

  InventoryTabView(this.controller, {super.key});

  @override
  State<InventoryTabView> createState() => _InventoryTabViewState();
}

class _InventoryTabViewState extends State<InventoryTabView> {
  void getSeletcedtab(String selectedTabName) {
    setState(() {
      if (widget.controller.defaultTab.value != selectedTabName) {
        widget.controller.defaultTab.value = selectedTabName;

        widget.controller.updateTab(widget.controller.defaultTab.value);
      }
    });
  }

  List<String> tabs = [
    AppValues.myTruckTabStr,
    AppValues.myDistrictTabStr,
    AppValues.otherDistrictTabStr
  ];

  void showToastMsg(BuildContext context, String message, ToastStatus status) {
    Timer(const Duration(seconds: AppValues.timeDuration1), () {
      var msg = ToastMessage(message: message, status: status);
      Navigator.of(context).push(msg);
      Timer(const Duration(seconds: AppValues.timeDuration3), () {
        Navigator.of(context).pop();
      });
    });
  }

  Widget filterListWidget() {
    return Container(
      margin: const EdgeInsets.only(
          top: AppValues.margin_8, bottom: AppValues.margin_7),
      height: getHeight(SizeConstants.dp30),
      child: widget.controller.selectedFilterTileList.isNotEmpty
          ? ScrollConfiguration(
              behavior: NoOverscrollBehavior(),
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: widget.controller.selectedFilterTileList.length > 4
                    ? 6
                    : widget.controller.selectedFilterTileList.length == 4
                        ? 5
                        : widget.controller.selectedFilterTileList.length + 1,
                itemBuilder: (ctx, index) {
                  var listLength = widget
                              .controller.selectedFilterTileList.length >
                          4
                      ? 6
                      : widget.controller.selectedFilterTileList.length == 4
                          ? 5
                          : widget.controller.selectedFilterTileList.length + 1;

                  if (index == listLength - 1) {
                    return _filterClearAllTile();
                  } else if (listLength == 6 && index == listLength - 2) {
                    return _filterMoreTile();
                  } else {
                    return _filterSelectedItem(
                        widget.controller.selectedFilterTileList[index], index);
                  }
                },
              ),
            )
          : Container(),
    );
  }

  Widget _filterSelectedItem(String tileText, int index) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: AppValues.margin_5),
      padding: const EdgeInsets.symmetric(
          vertical: AppValues.padding_4, horizontal: AppValues.padding_7),
      constraints: BoxConstraints(
        minWidth: getWidth(SizeConstants.dp30),
      ),
      decoration: BoxDecoration(
        color: AppColors.colorFilterTag,
        borderRadius: BorderRadius.circular(AppValues.radius_4),
        border: Border.all(
            width: SizeConstants.dp1, color: AppColors.colorFilterTagBorder),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Text(
            tileText,
            style: tSw500dp16fontF.copyWith(
              fontSize: SizeConstants.dp11,
              color: AppColors.colorMainText,
            ),
            maxLines: 1,
          ),
          SizedBox(
            width: getWidth(SizeConstants.dp15),
          ),
          InkWell(
            child: Image.asset(
              AppImages.cancelBlackPng,
              width: getWidth(SizeConstants.dp18),
              height: getHeight(SizeConstants.dp18),
            ),
            onTap: () {
              widget.controller.removeFilterTile(tileText);
            },
          )
        ],
      ),
    );
  }

  Widget _filterMoreTile() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: AppValues.margin_5),
      padding: const EdgeInsets.symmetric(
          vertical: AppValues.padding_4, horizontal: AppValues.padding_11),
      constraints: BoxConstraints(
        minWidth: getWidth(SizeConstants.dp70),
      ),
      decoration: BoxDecoration(
        color: AppColors.transparentColor,
        borderRadius: BorderRadius.circular(AppValues.radius_4),
        border:
            Border.all(width: SizeConstants.dp1, color: AppColors.colorSubText),
      ),
      child: Center(
        child: InkWell(
          onTap: () {
            Navigator.of(context).push(FilterOverlay());
          },
          child: Text(
            '+ ${widget.controller.selectedFilterCheckBox.length - 4} ${AppStrings.more}',
            style: tSw500dp16fontF.copyWith(
              fontSize: SizeConstants.dp12,
              color: AppColors.colorMainText,
            ),
            textAlign: TextAlign.center,
            maxLines: 1,
          ),
        ),
      ),
    );
  }

  Widget _filterClearAllTile() {
    return Container(
      padding: const EdgeInsets.symmetric(
          vertical: AppValues.padding_4, horizontal: AppValues.padding_11),
      constraints: BoxConstraints(
        minWidth: getWidth(SizeConstants.dp70),
      ),
      child: Center(
        child: InkWell(
          onTap: () {
            widget.controller.getAllBitsListBasedOnTab();
          },
          child: Text(
            AppStrings.clearAll,
            style: tSw500dp16fontF.copyWith(
              fontSize: SizeConstants.dp13,
              color: AppColors.colorPrimary,
            ),
            textAlign: TextAlign.center,
            maxLines: 1,
          ),
        ),
      ),
    );
  }

  Widget refreshButton() {
    return Row(
      children: [
        InkWell(
          onTap: () {
            widget.controller.fetchData();
          },
          child: Container(
              padding: EdgeInsets.only(
                  right: getWidth(SizeConstants.dp8),
                  left: getWidth(SizeConstants.dp8)),
              child: const Icon(
                Icons.refresh,
                color: AppColors.colorBlack,
              )),
        ),
        SizedBox(
          width: getWidth(SizeConstants.dp10),
        ),
      ],
    );
  }

  Widget filterButtonWidget() {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () {
        //Get.dialog(FilterOverlay(),useSafeArea: true,barrierDismissible: false, barrierColor: AppColors.color38393C.withOpacity(0.4));
        Navigator.of(context).push(FilterOverlay());
      },
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          SizedBox(
            height: SizeConstants.dp23,
            width: SizeConstants.dp23,
            child: Stack(
              children: [
                Center(
                  child: Container(
                      padding: const EdgeInsets.all(SizeConstants.dp4),
                      height: SizeConstants.dp14,
                      width: SizeConstants.dp14,
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(AppImages.filter),
                          fit: BoxFit.fill,
                        ),
                      ),
                      child: null),
                ),
                widget.controller.selectedFilterTileList.isNotEmpty
                    ? Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          width: SizeConstants.dp8,
                          height: SizeConstants.dp8,
                          margin: const EdgeInsets.all(SizeConstants.dp2),
                          child: const Image(
                            image: AssetImage(AppImages.filterApplied),
                            fit: BoxFit.cover,
                          ),
                        ),
                      )
                    : Container()
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(
                SizeConstants.dp9, 0, SizeConstants.dp19, 0),
            child: Text(
              AppValues.filterStr,
              style: tSw500dp16fontF.copyWith(
                  fontSize: SizeConstants.dp15, color: AppColors.colorBlack),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(onTap: () {
      if(widget.controller.searchController.text.isEmpty){
          widget.controller.entry.remove();
          widget.controller.searchController.text = "";
          setState(() {
            widget.controller.getAllBitsListBasedOnTab();
            //widget.controller.isSearchEnabled = false;
            //hideOverLay();
            widget.controller.focusNode.unfocus();
          });
        }
      },
      child: Column(
        children: [
          Container(
            color: AppColors.colorTopPanel,
            height: SizeConstants.dp55,
            child: Row(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(SizeConstants.dp20, 0, 0, 0),
                  child: Row(children: [
                    CustomInventoryTab(tabs[0],
                        widget.controller.defaultTab.value, getSeletcedtab),
                    CustomInventoryTab(tabs[1],
                        widget.controller.defaultTab.value, getSeletcedtab),
                    CustomInventoryTab(tabs[2],
                        widget.controller.defaultTab.value, getSeletcedtab),
                  ]),
                ),
                const Spacer(),
                widget.controller.isSearchEnabled
                    ? RecentSearches(
                        localSearches: widget.controller.localSearches,
                      )
                    : GestureDetector(
                        child: Image.asset(AppImages.search),
                        onTap: () {
                          setState(() {
                            // TODO Set State to be removed
                            widget.controller.focusNode.requestFocus();
                            widget.controller.isSearchEnabled =
                                !widget.controller.isSearchEnabled;
                          });
                        },
                      ),
                const SizedBox(
                  width: SizeConstants.dp15,
                ),
                Container(
                  width: 1,
                  height: SizeConstants.dp15,
                  decoration: const ShapeDecoration(
                    shape: RoundedRectangleBorder(
                      side: BorderSide(
                        width: 0.50,
                        strokeAlign: BorderSide.strokeAlignCenter,
                        color: AppColors.colorSeparatorLine,
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  width: SizeConstants.dp15,
                ),
                InkWell(
                  onTap: () {
                    Navigator.of(context).push(RequestBitOverlay(
                        bitSubmittedCallBak: (value) => {
                              if (value == true)
                                {
                                  showToastMsg(context, AppStrings.bitSuccessMsg,
                                      ToastStatus.success)
                                }
                              else
                                {
                                  showToastMsg(context, AppStrings.bitFailureMsg,
                                      ToastStatus.failure)
                                }
                            } //85 initial and 30 padding 40 end space
                        ));
                  },
                  child: Row(
                    children: [
                      Image.asset(AppImages.icAddColored),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(
                            SizeConstants.dp5,
                            SizeConstants.dp0,
                            SizeConstants.dp19,
                            SizeConstants.dp0),
                        child: Text(
                          AppValues.requestBitStr,
                          style: tSw600dp14fontF.copyWith(
                            fontSize: SizeConstants.dp14,
                            color: AppColors.colorPrimary,
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
          const Divider(
            height: SizeConstants.dp1,
            color: AppColors.colorSeparatorLine,
          ),
          Container(
            color: AppColors.colorTopPanel,
            height: SizeConstants.dp45,
            child: Obx(
              () => Row(
                children: [
                  Padding(
                    padding:
                        const EdgeInsets.fromLTRB(SizeConstants.dp40, 0, 0, 0),
                    child: GestureDetector(
                      onTap: () {
                        // widget.controller.registerNotification();
                      },
                      child: widget.controller.defaultTab.value ==
                                  AppStrings.myTruck ||
                              widget.controller.defaultTab.value ==
                                  AppStrings.myDistrict
                          ? RichText(
                              text: TextSpan(
                                  text: widget.controller.defaultTab.value ==
                                          AppStrings.myTruck
                                      ? AppStrings.slocPrefix
                                      : AppStrings.districtPrefix,
                                  style: tSw400dp14fontF.copyWith(
                                    color: AppColors.colorMainText,
                                  ),
                                  children: [
                                  TextSpan(
                                    text: widget.controller.userSloc.value,
                                    style: tSw600dp14fontF.copyWith(
                                      color: AppColors.colorMainText,
                                    ),
                                  )
                                ]))
                          : RichText(
                              text: TextSpan(
                              text: widget.controller.userSloc.value,
                              style: tSw600dp14fontF.copyWith(
                                color: AppColors.colorMainText,
                              ),
                            )),
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.symmetric(
                        vertical: SizeConstants.dp15,
                        horizontal: SizeConstants.dp10),
                    child: VerticalDivider(
                      color: AppColors.colorSeparatorLine,
                    ),
                  ),
                  Text(
                    "${widget.controller.numberOfBits.value} ${AppStrings.bits}",
                    style: tSw400dp14fontF.copyWith(
                      color: AppColors.colorSubText,
                    ),
                  ),
                  SizedBox(
                    width: getWidth(SizeConstants.dp20),
                  ),
                  Flexible(child: filterListWidget()),
                  refreshButton(),
                  filterButtonWidget()
                ],
              ),
            ),
          ),
          const Divider(
            height: SizeConstants.dp1,
            color: AppColors.colorSeparatorLine, //.withOpacity(0.30),
          ),
        ],
      ),
    );
  }
}

// ignore: must_be_immutable
class CustomInventoryTab extends StatefulWidget {
  String tabText;
  String selectedTab;
  Function getSelectedTab;

  CustomInventoryTab(this.tabText, this.selectedTab, this.getSelectedTab,
      {super.key});

  @override
  State<CustomInventoryTab> createState() => _CustomInventoryTabState();
}

class _CustomInventoryTabState extends State<CustomInventoryTab> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 0, SizeConstants.dp10, 0),
      child: Container(
          child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          primary: (widget.selectedTab == widget.tabText) ? AppColors.bottomColorPrimaryDark : AppColors.transparentColor,
          onPrimary: (widget.selectedTab == widget.tabText) ? AppColors.colorWhite : AppColors.colorPrimary,
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(SizeConstants.dp32)),
        ),
        onPressed: () {
          setState(() {
            widget.getSelectedTab(widget.tabText);
          });
        },
        child: Text(
          widget.tabText,
          style: widget.selectedTab == widget.tabText
              ? tSw500dp15fontF.copyWith(color: AppColors.colorWhite)
              : tSw400dp14fontF.copyWith(fontSize: SizeConstants.dp15),
        ),
      )),
    );
  }
}
