import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:printing/printing.dart';
import 'package:realm/realm.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:signature/signature.dart';
import 'package:slb_gt_mobile/app/core/base/base_controller.dart';
import 'package:slb_gt_mobile/app/core/common_widgets/toast_message.dart';
import 'package:slb_gt_mobile/app/core/utils/logger_common.dart';
import 'package:slb_gt_mobile/app/core/values/app_enum.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';
import 'package:slb_gt_mobile/app/data/model/response/bit_movement_response.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/model/consignment_model.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/model/step_item.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart' as pdf;
import 'package:slb_gt_mobile/app/modules/inventory/models/consignmentSchema.dart';
import 'package:slb_gt_mobile/app/modules/login/controller/login_controller.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../../../common_binding/realm_initial.dart';
import '../../../core/connectivity_utils/connectivity_controller.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/preference_constants.dart';
import '../../../data/model/request/bit_movment_param.dart';
import '../../../data/repository/inventory_repo.dart';
import '../../../network/exceptions/app_exception.dart';
import '../../../utils/msal_login.dart';
import '../../inventory/models/bitState.dart';
import '../../inventory/models/customerSchema.dart';
import '../../inventory/models/rigsSchema.dart';
import '../model/schema/pricebook_schema.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import '../widget/quote_web_view.dart';
import 'dart:ui' as ui;

class ConsignController extends BaseController {
  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());
  final InventoryRepo _repository = Get.find(tag: (InventoryRepo).toString());
  final ConnectivityController connectivityController = Get.find();
  final LoginController loginController = Get.find();

  var index = 0.obs;
  final _consignmentModel = ConsignmentModel().obs;

  final _priceBookSelectedTab = 0.obs;

  final _onPriceLineItemSelected = (-1).obs;
  List<dynamic> selectedPriceLineItem = [];
  final _priceBookLineItem = <dynamic>[].obs;

  var webHtmlViewController = WebViewController();

  QuoteHtml quoteHtml = QuoteHtml();

  late RealmResults<Rig> _rigsList;
  var visiblityDropDown = [].obs;
  late RealmResults<Customer> _customerList;
  late RealmResults<PriceBook> _priceBooksList;

  var customers = [].obs;
  var rigs = [].obs;
  var pricebookList = <PriceBook>[].obs;

  var swapList;

  var editLineItemIndex = -1;

  final _onPriceBookSelected = 0.obs;
  PriceBook? selectedPriceBook;
  final _searchByMasterCode = ''.obs;
  final _searchBySlbMaterial = ''.obs;
  final _searchBySlbDescription = ''.obs;
  final _masterCodeList = <String>[].obs;
  final _slbMaterialList = <String>[].obs;
  final _slbDescriptionList = <String>[].obs;
  final _priceBookWithIdList = <String>[].obs;

  final _isEnterDetailNextEnable = false.obs;
  final _isPriceBookNextEnable = false.obs;
  final _isQuoteNextEnable = false.obs;
  final _isQuotePreview = false.obs;
  final _isConfirmationScreen = false.obs;
  var nextButtonStatus = NextButtonState.hide.name.obs;

  var filePath = ''.obs;
  var fileSize = 0.obs;
  var fileProcessingRunning = false.obs;
  var isChecked = false.obs;
  final maxAllowedFileSize = 20;
  List<XFile>? _mediaFileList;

  var pdfFormat = pdf.PdfPageFormat.standard;
  final _quotePdfBase64 = ''.obs;
  var tag = AppStrings.isDigital.obs;
  var refreshUi = "".obs;
  var isConsignSearchEnabled = false.obs;

  var isBitsSelected = false.obs;
  var isSelectedBitStatusValid = false.obs;
  var currentConsignmentForBilling = "";
  var selectedValueList = [];
  final lineItemBuffer = StringBuffer('');
  final mainItemBuffer = StringBuffer('');
  int count = 0;
  double totalBalance = 0.0;
  String pbID = "";

  final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
  late SharedPreferences prefs;

  final _signatureString = ''.obs;
  var customerName = AppStrings.firstLastName.obs;
  var userName = AppStrings.firstLastName.obs;

  String selectedValueCustomer = "";

  var selectedValueRig = "";

  String? draftConsignmentID;

  bool isDraftEdit = false;

  List<String> get signType => [AppStrings.customer, AppStrings.user];
  var _selectedSignTab = 0.obs;

  bool isDigitalSignTab = true;
  var isDigitalSignDone = false.obs;
  var isQuoteUploaded = false.obs;
  var isLoadHtml = false.obs;

  final _steps = <StepItem>[
    StepItem(
        title: ConsignStep.stepTitle1,
        description: ConsignStep.stepDescription1),
    StepItem(
        title: ConsignStep.stepTitle2,
        description: ConsignStep.stepDescription2),
    StepItem(
        title: ConsignStep.stepTitle3,
        description: ConsignStep.stepDescription3),
    StepItem(
        title: ConsignStep.stepTitle4,
        description: ConsignStep.stepDescription4),
  ].obs;

  //String for empty base64

  ConsignmentModel get consignmentModel => _consignmentModel.value;

  set consignmentModel(ConsignmentModel value) {
    _consignmentModel.value = value;
    _consignmentModel.refresh();
  }

  Rig? get rig => consignmentModel.rig;

  set rig(Rig? value) {
    consignmentModel.rig = value;
  }

  Customer? get customer => consignmentModel.customer;

  set customer(Customer? value) {
    consignmentModel.customer = value;
  }

  List<StepItem> get steps => _steps.value;

  set steps(List<StepItem> value) {
    _steps.value = value;
  }

  List<Bits> get selectedBits => consignmentModel.bits ?? [];

  set selectedBits(value) {
    consignmentModel.bits = value;
    _consignmentModel.refresh();
  }

  // Start User Customer Sign

  get selectedSignTab => _selectedSignTab;

  set selectedSignTab(value) {
    _selectedSignTab = value;
  }

  // End User Customer Sign
  String get email => consignmentModel.customerEmail ?? '';

  set email(String value) {
    consignmentModel.customerEmail = value;
    _consignmentModel.refresh();
  }

  // consignmentID
  String get consignmentID => consignmentModel.consignmentID ?? '';

  set consignmentID(String value) {
    consignmentModel.consignmentID = value;
    _consignmentModel.refresh();
  }

  String get quoteID => consignmentModel.quoteID ?? '';

  set quoteID(String value) {
    consignmentModel.quoteID = value;
    _consignmentModel.refresh();
  }

  get isEnterDetailNextEnable => _isEnterDetailNextEnable.value;

  set isEnterDetailNextEnable(value) {
    _isEnterDetailNextEnable.value = value;
  }

  get quotePdfBase64 => _quotePdfBase64.value;

  set quotePdfBase64(value) {
    _quotePdfBase64.value = value;
  }

  get isPriceBookNextEnable => _isPriceBookNextEnable.value;

  set isPriceBookNextEnable(value) {
    _isPriceBookNextEnable.value = value;
  }

  get isQuoteNextEnable => _isQuoteNextEnable.value;

  set isQuoteNextEnable(value) {
    _isQuoteNextEnable.value = value;
  }

  get isQuotePreview => _isQuotePreview.value;

  set isQuotePreview(value) {
    _isQuotePreview.value = value;
  }

  get isConfirmationScreen => _isConfirmationScreen.value;

  set isConfirmationScreen(value) {
    _isConfirmationScreen.value = value;
  }

  get priceBookSelectedTab => _priceBookSelectedTab.value;

  set priceBookSelectedTab(value) {
    _priceBookSelectedTab.value = value;
  }

  get onPriceLineItemSelected => _onPriceLineItemSelected.value;

  set onPriceLineItemSelected(value) {
    _onPriceLineItemSelected.value = value;
  }

  get onPriceBookSelected => _onPriceBookSelected.value;

  set onPriceBookSelected(value) {
    _onPriceBookSelected.value = value;
  }

  List<dynamic> get priceBookLineItem => _priceBookLineItem;

  set priceBookLineItem(List<dynamic> value) {
    _priceBookLineItem.value = value;
  }

  List<String> get masterCodeList => _masterCodeList;

  set masterCodeList(value) {
    _masterCodeList.value = value;
  }

  List<String> get slbMaterialList => _slbMaterialList;

  set slbMaterialList(value) {
    _slbMaterialList.value = value;
  }

  List<String> get slbDescriptionList => _slbDescriptionList;

  set slbDescriptionList(value) {
    _slbDescriptionList.value = value;
  }

  List<String> get priceBookWithIdList => _priceBookWithIdList;

  set priceBookWithIdList(value) {
    _priceBookWithIdList.value = value;
  }

  get searchByMasterCode => _searchByMasterCode.value;

  set searchByMasterCode(value) {
    _searchByMasterCode.value = value;
  }

  get searchBySlbMaterial => _searchBySlbMaterial.value;

  set searchBySlbMaterial(value) {
    _searchBySlbMaterial.value = value;
  }

  get searchBySlbDescription => _searchBySlbDescription.value;

  set searchBySlbDescription(value) {
    _searchBySlbDescription.value = value;
  }

  @override
  void onInit() {
    // TODO: implement onInit
    fetchData();
  }

  //New methods from Jitendra

  List<String> getBitsExceptSelected() {
    List<String> bits = [];
    for (int i = 0; i < selectedBits.length; i++) {
      if (i != priceBookSelectedTab) {
        var bit = selectedBits[i];
        bits.add(bit.bit?.serialNumber ?? '');
      }
    }
    return bits;
  }

  /*--------------Quote Screen----------------*/

  var isStartUserSignDraw = false.obs;
  var isCustomerStartDraw = false.obs;

  var isCustomerSignDone = false.obs;
  var isUserSignDone = false.obs;
  var isUserSignTap = false.obs;

  refreshUI() {
    refreshUi.value = AppStrings.updatedValue;
    refreshUi.refresh();
  }

  getSignature() {
    return _signatureString.value;
  }

  Future<bool> setSignature() async {
    try {
      await setCustomerNameAndSignNew(customerSignatureController);
      await setUserNameAndSignNew(userSignatureController);
      return true;
    } catch (exception) {
      return false;
    }
  }

  openQuoteScreen(ConsignController consignController) {
    if (isLoadHtml.value) {
      loadWebView(consignController);
    } else {
      if (isQuoteUploaded.value) {
        loadPdf();
      } else {
        loadHtml(consignController);
      }
    }
  }

  showTabGreenTick(int signType) {
    //logic to show green tick on tabbar
    //signType -> 0 = Customer, 1= User
    if (signType == 0) {
      if (getCustomerName().isNotEmpty && getCustomerSignature().isNotEmpty) {
        isCustomerSignDone.value = true;
      } else {
        isCustomerSignDone.value = false;
      }
    } else {
      if (getUserName().isNotEmpty && getSignature().isNotEmpty) {
        isUserSignDone.value = true;
      } else {
        isUserSignDone.value = false;
      }
    }
  }

  onTapSignatureTabButton(isDigital, ConsignController consignController) {
    if (isDigital) {
      tag.value = AppStrings.isDigital;
      isDigitalSignTab = true;
      loadHtml(consignController);
    } else {
      tag.value = AppStrings.isManual;
      isDigitalSignTab = false;
      if (isQuoteUploaded.value) {
        loadPdf();
      } else {
        loadHtmlForPrint(consignController);
      }
    }
    tag.refresh();
  }

  loadWebView(ConsignController consignController) {
    isLoadHtml.value = true;
    quoteHtml.createLineItemList(consignController);
    late final PlatformWebViewControllerCreationParams params;
    params = const PlatformWebViewControllerCreationParams();

    webHtmlViewController =
        WebViewController.fromPlatformCreationParams(params);
    webHtmlViewController.setJavaScriptMode(JavaScriptMode.unrestricted);
    webHtmlViewController.setBackgroundColor(AppColors.transparentColor);

    _reloadHtml(consignController, true);
  }

  loadHtml(ConsignController consignController) {
    isLoadHtml.value = true;
    quoteHtml.createLineItemList(consignController);
    _reloadHtml(consignController, true);
  }

  loadHtmlForPrint(ConsignController consignController) {
    isLoadHtml.value = true;
    quoteHtml.createLineItemList(consignController);
    _reloadHtml(consignController, false);
  }

  _reloadHtml(ConsignController consignController, isLoadSign) {
    if (isLoadSign && tag == AppStrings.isDigital) {
      webHtmlViewController.loadRequest(Uri.dataFromString(
          quoteHtml.quoteHtml(AppStrings.tag, consignController),
          mimeType: AppStrings.htmlMime));
    } else {
      webHtmlViewController.loadRequest(Uri.dataFromString(
          quoteHtml.quoteHtml(AppStrings.tag, consignController),
          mimeType: AppStrings.htmlMime));
    }
  }

  Future<String> htmlToBase64(ConsignController consignController) async {
    final page1 = await Printing.convertHtml(
      format: pdfFormat,
      html: quoteHtml.quoteHtml(AppStrings.tag, consignController),
    );
    String pdfString = base64Encode(page1);
    quotePdfBase64 = pdfString;

    return quotePdfBase64;
  }

  Widget loadPdf() {
    isLoadHtml.value = false;
    return SfPdfViewer.file(
      File(filePath.value),
      canShowScrollHead: true,
      canShowScrollStatus: true,
      enableDoubleTapZooming: false,
      enableHyperlinkNavigation: false,
      enableDocumentLinkAnnotation: false,
      enableTextSelection: false,
    );
  }

  //For clear manual sign pdf and showing default UI view
  deleteManualPdf(ConsignController consignController) {
    clearManualPickData();
    isQuoteUploaded.value = false;
    isLoadHtml.value = false;
    loadHtmlForPrint(consignController);

    //Update steps data for block/unblock step 1 & 2
    updateStepItemStatus(currentIndex: index.value);
  }

  printingHtml(ConsignController consignController) async {
    await Printing.layoutPdf(
        format: pdfFormat,
        onLayout: (pdf.PdfPageFormat format) async =>
            await Printing.convertHtml(
              format: pdfFormat,
              html: quoteHtml.quoteHtml(AppStrings.tag, consignController),
            ));
  }

  var isDigitalSignChecked = false.obs;
  var enterCustomerName = ''.obs;
  var enterUserName = ''.obs;

  var customerNameTxt = TextEditingController();
  var userNameTxt = TextEditingController();

  final _customerSignatureController = SignatureController(
    onDrawStart: () => onCustomerSignDraw(),
  ).obs;

  final _userSignatureController = SignatureController(
    onDrawStart: () => onUserSignDraw(),
  ).obs;

  static void onCustomerSignDraw() {
    var obj = ConsignController();
    obj.isCustomerStartDraw.value = true;
  }

  static onUserSignDraw() {
    var obj = ConsignController();
    obj.isStartUserSignDraw.value = true;
  }

  SignatureController get userSignatureController =>
      _userSignatureController.value;

  set userSignatureControllerModel(SignatureController value) {
    _userSignatureController.value = value;
    _userSignatureController.refresh();
  }

  SignatureController get customerSignatureController =>
      _customerSignatureController.value;

  set customerSignatureControllerModel(SignatureController value) {
    _customerSignatureController.value = value;
    _customerSignatureController.refresh();
  }

  setCustomerNameAndSignNew(SignatureController controller) async {
    //convert logic to transfer in png
    // Customer signature base64
    addCustomerName(enterCustomerName.value);

    final customerData = await controller.toImage();
    final customerDataBytes =
        await customerData?.toByteData(format: ui.ImageByteFormat.png);
    Uint8List? customerUInt8List = customerDataBytes?.buffer.asUint8List();
    // base64 encode the bytes
    String customerImgBase64String =
        base64.encode(customerUInt8List as List<int>);
    addCustomerSignatureBase64(customerImgBase64String);
  }

  setUserNameAndSignNew(SignatureController controller) async {
    //convert logic to transfer in png
    // Customer signature base64

    addUserName(enterUserName.value);
    final customerData = await controller.toImage();
    final customerDataBytes =
        await customerData?.toByteData(format: ui.ImageByteFormat.png);
    Uint8List? customerUInt8List = customerDataBytes?.buffer.asUint8List();
    // base64 encode the bytes
    String customerImgBase64String =
        base64.encode(customerUInt8List as List<int>);
    addUserSignatureBase64(customerImgBase64String);
  }

  clearAllNew(SignatureController customerController,
      SignatureController userController) {
    clearUserNameSignNew(userController, true);
    clearCustomerNameSignNew(customerController, true);
    isDigitalSignDone.value = false;
    isDigitalSignChecked.value = false;

    //Update steps data for block/unblock step 1 & 2
    updateStepItemStatus(currentIndex: index.value);
  }

  clearCustomerNameSignNew(SignatureController controller, bool isClearAll) {
    controller.clear();
    isCustomerStartDraw.value = false;

    addCustomerSignatureBase64('');
    if (isClearAll) {
      enterCustomerName.value = '';
      addCustomerName(enterCustomerName.value);
      customerNameTxt.clear();
    }

    isCustomerSignDone.value = false;
  }

  clearUserNameSignNew(SignatureController controller, bool isClearAll) {
    controller.clear();
    isStartUserSignDraw.value = false;
    addUserSignatureBase64('');
    if (isClearAll) {
      enterUserName.value = '';
      addUserName(enterUserName.value);
      userNameTxt.clear();
    }
    isUserSignDone.value = false;
  }

  var customerSignatureString = ''.obs;

  getCustomerSignature() {
    return customerSignatureString.value;
  }

  void addCustomerSignatureBase64(String base64string) {
    customerSignatureString.value = base64string;
  }

  void addUserSignatureBase64(String base64string) {
    _signatureString.value = base64string;
  }

  getCustomerName() {
    return customerName.value;
  }

  addCustomerName(String custName) {
    customerName.value = custName;
  }

  getUserName() {
    return userName.value;
  }

  addUserName(String uName) {
    userName.value = uName;
  }

  /*-----end Quote Screen------*/

  List<LineItems>? get currentLineItemsOfSelectedBit {
    var currentBit = selectedBits[priceBookSelectedTab];
    return currentBit.lineItem;
  }

  void clearManualPickData() {
    isChecked.value = false;
    fileProcessingRunning.value = false;
    filePath.value = '';
    fileSize.value = 0;
  }

  double getFileSize(BuildContext context) {
    var mb = 1024 * 1024;
    var fileMBSize = (fileSize.value / mb).toPrecision(2);
    ApplicationLogger().printInfo(
        'File size:- $fileMBSize', 'ConsignController.getFileSize()');

    if (fileMBSize > maxAllowedFileSize) {
      showToastMsg(context, 'File size accessed $maxAllowedFileSize MB limit.',
          ToastStatus.failure);
    }
    return fileMBSize;
  }

  void showToastMsg(BuildContext context, String message, ToastStatus status) {
    Timer(const Duration(seconds: AppValues.timeDuration1), () {
      var msg = ToastMessage(message: message, status: status);
      Navigator.of(context).push(msg);
      Timer(const Duration(seconds: AppValues.timeDuration3), () {
        Navigator.of(context).pop();
        clearManualPickData();
      });
    });
  }

  openGalleryPicker(BuildContext context) async {
    ApplicationLogger().printInfo("Process start", 'openGalleryPicker()');
    final ImagePicker picker = ImagePicker();
    fileProcessingRunning.value = true;
    ApplicationLogger().printInfo("List init start", 'openGalleryPicker()');
    List<XFile> images = [];
    try {
      images = await picker.pickMultiImage(imageQuality: 60);
      if (images.length > 20) {
        showToastMsg(
            context, AppStrings.maximumNumOfFilesAllowed, ToastStatus.failure);
        return;
      }
      ApplicationLogger().printInfo("File picked.", 'openGalleryPicker()');
    } catch (e) {
      showToastMsg(
          context, AppStrings.imagePickErrorMessage, ToastStatus.failure);
      ApplicationLogger()
          .printInfo('$e', 'ConsignController.openGalleryPicker()');
    }
    if (images.isEmpty) {
      fileProcessingRunning.value = false;
    }
    ApplicationLogger().printInfo("Image Length data ${images.length}",
        'ConsignController.openGalleryPicker()');

    PdfDocument document = PdfDocument();

    try {
      if (images.isNotEmpty) {
        for (int i = 0; i < images.length; i++) {
          await Future(
            () async {
              Uint8List? fileByte = await _readFileByteSync(images[i].path);
              final PdfBitmap image = PdfBitmap(fileByte);

              // Add a PDF page and draw text.
              var page = document.pages.add().graphics;

              // Save the document.
              page.drawImage(
                  image,
                  Rect.fromLTWH(
                      0, 0, page.clientSize.width, page.clientSize.height));
            },
          );
        }

        Directory? documentDirectory = await getApplicationDocumentsDirectory();

        String? documentPath = documentDirectory.path;

        String id = DateTime.now().toString();
        File file = File("$documentPath/$id${AppStrings.pdfExtension}");
        await file.writeAsBytes(await document.save());

        // Dispose the document.
        document.dispose();
        fileSize.value = file.lengthSync();
        filePath.value = file.path;

        fileProcessingRunning.value = false;
        String pdfString = base64Encode(file.readAsBytesSync());
        quotePdfBase64 = pdfString;

        ApplicationLogger().printInfo(
            'file_path $filePath', 'ConsignController.openGalleryPicker()');
      }
    } catch (e) {
      ApplicationLogger()
          .printError('error $e', 'ConsignController.openGalleryPicker()');
      fileProcessingRunning.value = false;
    }
  }

  openFilePicker() async {
    fileProcessingRunning.value = true;
    FilePickerResult? result = await FilePicker.platform.pickFiles(
        allowMultiple: false,
        allowedExtensions: ['pdf'],
        type: FileType.custom);

    if (result == null) {
      fileProcessingRunning.value = false;
    } else {
      var file = File(result.files.first.path!);
      fileSize.value = file.lengthSync();
      filePath.value = result.files.first.path.toString();
      fileProcessingRunning.value = false;
      String pdfString = base64Encode(file.readAsBytesSync());
      quotePdfBase64 = pdfString;
    }
  }

  Future<Uint8List?> _readFileByte(String filePath) async {
    Uri myUri = Uri.parse(filePath);
    File file = File.fromUri(myUri);
    Uint8List? bytes;
    await file.readAsBytes().then((value) {
      bytes = Uint8List.fromList(value);
      //print('reading of bytes is completed');
    }).catchError((onError) {
      //print('Exception Error while reading file from path:$onError');
    });
    return bytes;
  }

  Future<Uint8List> _readFileByteSync(String filePath) async {
    Uri myUri = Uri.parse(filePath);
    File file = File.fromUri(myUri);
    Uint8List? bytes = file.readAsBytesSync();
    return bytes;
  }

  LineItems getLineItemFromIndex(int index) {
    var currentBit = selectedBits[priceBookSelectedTab];
    if (currentBit.lineItem?.isNotEmpty == true) {
      return (currentBit.lineItem ?? [])[index];
    }
    return LineItems();
  }

  bool checkDuplicacy(int index) {
    var currentBitLineItems = selectedBits[priceBookSelectedTab].lineItem;

    var current = currentBitLineItems?[index];

    for (int i = 0; i < index; i++) {
      var lineItem = currentBitLineItems?[i];
      if (current?.lineCondition == lineItem?.lineCondition) {
        return true;
      }
    }
    return false;
  }

  setLineItemValues(
      ConsignController consignController, String type, int index) {
    var value = consignController
        .selectedBits[consignController.priceBookSelectedTab].lineItem![index];
    if (type == InputFieldType.bestPrice.name && value.bestPrice != null) {
      return TextEditingController(
          text: value.bestPrice != 0.0 ? '${value.bestPrice}' : '');
    } else if (type == InputFieldType.comments.name) {
      return TextEditingController(text: value.comments);
    } else if (type == InputFieldType.unitDrilled.name &&
        value.unitDrilled != null) {
      return TextEditingController(
          text: value.unitDrilled != 0.0 ? '${value.unitDrilled}' : '');
    } else if (type == InputFieldType.pricePerUnit.name &&
        value.pricePerUnit != null) {
      return TextEditingController(
          text: value.pricePerUnit != 0.0 ? '${value.pricePerUnit}' : '');
    }
  }

  /*
  * Update bit line item with value changed data
  * */
  void updateConsignmentModel(String value, String type, int index) {
    var currentBitLineItems = selectedBits[priceBookSelectedTab].lineItem;
    var selectedLineItem = currentBitLineItems?[index];
    double enteredValue = 0.0;

    if (type != InputFieldType.comments.name &&
        type != InputFieldType.lineCondition.name) {
      try {
        enteredValue = double.parse(value);
      } catch (e) {
        ApplicationLogger().printError(
            e.toString(), 'ConsignController.updateConsignmentModel');
      }
    }

    if (type == InputFieldType.unitDrilled.name) {
      selectedLineItem?.unitDrilled = enteredValue;
    } else if (type == InputFieldType.pricePerUnit.name) {
      selectedLineItem?.pricePerUnit = enteredValue;
    } else if (type == InputFieldType.comments.name) {
      selectedLineItem?.comments = value;
    } else if (type == InputFieldType.bestPrice.name) {
      selectedLineItem?.bestPrice = enteredValue;
    } else if (type == InputFieldType.lineCondition.name) {
      selectedLineItem?.lineCondition = value;
    } else {}

    currentBitLineItems?[index] = selectedLineItem as LineItems;

    var currentBit = Bits(
        bit: selectedBits[priceBookSelectedTab].bit,
        lineItem: currentBitLineItems);

    var newSelectedBits = selectedBits;
    newSelectedBits[priceBookSelectedTab] = currentBit;

    consignmentModel.bits = newSelectedBits;
    if (type == InputFieldType.lineCondition.name) {
      _consignmentModel.refresh();
    }
    ifAllLineItemsHasAtLeastOneBit();
  }

  Future<void> cloneFullBitToAnotherBit(String serialNumber) async {
    if (selectedBits[priceBookSelectedTab].lineItem == null) {
      return;
    }

    var currentBitLineItems =
        selectedBits[priceBookSelectedTab].lineItem as List<LineItems>;

    List<LineItems> tempCurrentBitLineItems = [];
    for (var i = 0; i < currentBitLineItems.length; i++) {
      LineItems object =
          currentBitLineItems[i].copyWith(currentBitLineItems[i]);
      tempCurrentBitLineItems.add(object);
    }

    var toBit =
        selectedBits.where((bit) => bit.bit?.serialNumber == serialNumber);

    var indexToMove = 0; // Position of bits in list
    for (var i = 0; i < selectedBits.length; i++) {
      var bit = selectedBits[i];
      if (bit.bit?.serialNumber == serialNumber) {
        indexToMove = i;
        break;
      }
    }

    var toBitLineItems = toBit.first.lineItem ?? [];

    if (toBitLineItems.isNotEmpty == true) {
      toBitLineItems =
          (toBitLineItems).followedBy(tempCurrentBitLineItems).toList();
    } else {
      toBitLineItems = tempCurrentBitLineItems;
    }

    var refreshedToBit = Bits(bit: toBit.first.bit, lineItem: toBitLineItems);

    var newSelectedBits = selectedBits;
    newSelectedBits[indexToMove] = refreshedToBit;

    priceBookSelectedTab = indexToMove;
    consignmentModel.bits = newSelectedBits;
    _consignmentModel.refresh();
    ifAllLineItemsHasAtLeastOneBit();
  }

  Future<void> checkAndAssignPriceBook(String priceBookId) async {
    ApplicationLogger().printInfo(
        'Selected priceBook id:- $priceBookId - ${selectedPriceBook?.priceBookId ?? ''}',
        'ConsignController.checkAndAssignPriceBook()');
    if (priceBookId.isNotEmpty &&
        (selectedPriceBook == null ||
            selectedPriceBook?.priceBookId != priceBookId)) {
      selectedPriceBook = _priceBooksList
          .firstWhere((element) => element.priceBookId == priceBookId);
    }
  }

  Future<void> cloneLineItem(LineItems line, int index) async {
    var currentBitLineItems = selectedBits[priceBookSelectedTab].lineItem;
    currentBitLineItems?.insert(index, LineItems().copyWith(line));

    var currentBit = Bits(
        bit: selectedBits[priceBookSelectedTab].bit,
        lineItem: currentBitLineItems);

    var newSelectedBits = selectedBits;
    newSelectedBits[priceBookSelectedTab] = currentBit;

    consignmentModel.bits = newSelectedBits;
    _consignmentModel.refresh();
    ifAllLineItemsHasAtLeastOneBit();
  }

  void changeExpandModeOfLine(LineItems line, int index) {
    var currentBitLineItems = selectedBits[priceBookSelectedTab].lineItem;
    var selectedLineItem = currentBitLineItems?[index];
    selectedLineItem?.isExpanded = !(selectedLineItem.isExpanded as bool);
    currentBitLineItems?[index] = selectedLineItem as LineItems;

    var currentBit = Bits(
        bit: selectedBits[priceBookSelectedTab].bit,
        lineItem: currentBitLineItems);

    var newSelectedBits = selectedBits;
    newSelectedBits[priceBookSelectedTab] = currentBit;

    consignmentModel.bits = newSelectedBits;
    _consignmentModel.refresh();
    ifAllLineItemsHasAtLeastOneBit();
  }

  Future<void> replaceLineItemsAtIndex(String priceBookId) async {
    var currentBitLineItems = selectedBits[priceBookSelectedTab].lineItem;
    var selectedLineItem = getRecord(priceBookId, selectedPriceLineItem.first);
    currentBitLineItems?[editLineItemIndex] = selectedLineItem;

    var currentBit = Bits(
        bit: selectedBits[priceBookSelectedTab].bit,
        lineItem: currentBitLineItems);

    var newSelectedBits = selectedBits;
    newSelectedBits[priceBookSelectedTab] = currentBit;

    consignmentModel.bits = newSelectedBits;
    _consignmentModel.refresh();
    ifAllLineItemsHasAtLeastOneBit();
  }

  bool checkIfLineItemIsDBR(LineItems line) {
    if (line.lineCondition == null ||
        line.lineCondition == LineCondition.dbr.value ||
        line.lineCondition == LineCondition.rental.value ||
        line.lineCondition == LineCondition.lih.value ||
        line.lineCondition == LineCondition.sale.value) {
      return true;
    }
    return false;
  }

  String getUnit(LineItems line) {
    if ((line.lineCondition as String) == LineCondition.rentalByFeet.value) {
      return AppStrings.feet;
    } else if ((line.lineCondition as String) ==
        LineCondition.rentalByMeter.value) {
      return AppStrings.meter;
    } else if ((line.lineCondition as String) ==
        LineCondition.rentalByDay.value) {
      return AppStrings.day;
    } else if ((line.lineCondition as String) ==
        LineCondition.rentalByHour.value) {
      return AppStrings.hour;
    } else if ((line.lineCondition as String) ==
        LineCondition.rentalByWeek.value) {
      return AppStrings.week;
    }
    return '';
  }

  Future<void> removeLineItem(int index) async {
    var currentBitLineItems = selectedBits[priceBookSelectedTab].lineItem;
    currentBitLineItems?.removeAt(index);

    var currentBit = Bits(
        bit: selectedBits[priceBookSelectedTab].bit,
        lineItem: currentBitLineItems);

    var newSelectedBits = selectedBits;
    newSelectedBits[priceBookSelectedTab] = currentBit;

    consignmentModel.bits = newSelectedBits;
    _consignmentModel.refresh();
    ifAllLineItemsHasAtLeastOneBit();
  }

  void removeSelectedBit(int index) {
    //Updated again to select 0 position tab on
    // select priceBook due to remove bits position update
    priceBookSelectedTab = 0;
    unBlockBitsSelectedBit(selectedBits[index].bit!);
    var tempSelectedBits = selectedBits;
    tempSelectedBits.removeAt(index);
    selectedBits = tempSelectedBits;
  }

  void setupSelectedBits(List<Bit> selectedBits) {
    List<Bits> bits = [];
    for (var bit in selectedBits) {
      bits.add(Bits(bit: bit));
    }
    consignmentModel.bits = bits;
    _consignmentModel.refresh();
  }

  void setupSelectedBitsDrafts(List<Bits> selectedBits) {
    List<Bits> bits = [];
    for (var bit in selectedBits) {
      bits.add(Bits(bit: bit.bit, lineItem: bit.lineItem));
    }
    consignmentModel.bits = bits;
    _consignmentModel.refresh();
    ifAllLineItemsHasAtLeastOneBit();
  }

  FocusNode focusNode = FocusNode();
  TextEditingController searchController = TextEditingController();

  void resetLineItemSelection() {
    onPriceLineItemSelected = (-1);
    selectedPriceLineItem = <LineItems>[];
  }

  void clearAndUpdateLineItemSelected(
      {required bool isClear, dynamic lineItem, int index = -1}) {
    onPriceLineItemSelected = index;

    List<dynamic> list = <dynamic>[];
    if (!isClear && lineItem != null) {
      list.add(lineItem);
    }
    selectedPriceLineItem = [];
    selectedPriceLineItem.addAll(list);
  }

  void fetchData() async {
    prefs = await _prefs;
    _rigsList = realm.getRigs();
    _customerList = realm.getCustomers(
        loginController.userDetailsList.first.country ??
            AppStrings.usCountryCode);
    _priceBooksList = realm.getPriceBooksList(
        loginController.userDetailsList.first.country ??
            AppStrings.usCountryCode);

    List<dynamic> customer = [];
    for (var c in _customerList) {
      customer.add(c);
    }

    List<dynamic> rig = [];
    for (var r in _rigsList) {
      rig.add(r);
    }

    List<PriceBook> priceBooksListTemp = [];
    for (var p in _priceBooksList) {
      priceBooksListTemp.add(p);
    }

    customers.value = customer;
    rigs.value = rig;
    pricebookList.value = priceBooksListTemp;
    update();
  }

  void addGenericLineItem() {
    ApplicationLogger().printInfo(
        '${draftConsignmentID?.trim().isEmpty}', 'EnterDetails.initState');
    fillBitWithGenericLineItem();
  }

  void updateStepItemStatus({required int currentIndex}) {
    index.value = currentIndex;
    bool isSignedOrUploaded = isDigitalSignDone.value || isQuoteUploaded.value;

    for (int i = 0; i < steps.length; i++) {
      if (i == 0) {
        updateStepItemValue(steps[i], i == index.value ? true : false,
            isConfirmationScreen, isEnterDetailNextEnable, isSignedOrUploaded);
      } else if (i == 1) {
        var bitWithAtLeastOneLineItem = selectedBits
            .where((bit) => (bit.lineItem ?? <LineItems>[]).isNotEmpty == true);

        updateStepItemValue(
            steps[i],
            i == index.value ? true : false,
            isConfirmationScreen,
            bitWithAtLeastOneLineItem.isNotEmpty,
            isSignedOrUploaded);
      } else if (i == 2) {
        updateStepItemValue(
            steps[i],
            i == index.value ? true : false,
            isConfirmationScreen,
            isPriceBookNextEnable && isQuotePreview,
            false);
      } else if (i == 3) {
        updateStepItemValue(steps[i], i == index.value ? true : false,
            isConfirmationScreen, false, isSignedOrUploaded);
      }
    }
    _steps.refresh();
  }

  void updateStepItemValue(StepItem stepItem, bool isCurrentIndex,
      bool isLastStep, bool isCompleted, bool isSignedOrUploaded) {
    stepItem.isCurrentIndex = isCurrentIndex;
    stepItem.isLastStep = isLastStep;
    stepItem.isCompleted = isCompleted;
    stepItem.isSignedOrUploaded = isSignedOrUploaded;
  }

  void checkAndRemoveSignedQuoteDocument() {
    //printLog('checkAndRemoveSignedQuoteDocument()');
  }

  void fillBitWithGenericLineItem() {
    //select priceBook
    selectedPriceBook = pricebookList.value.first;
    ApplicationLogger().printInfo(
        '${selectedPriceBook?.priceBookId ?? ''} - ${selectedPriceBook?.priceBookName ?? ''}',
        'fillBitWithGenericLineItem');

    //Add line item
    selectedPBLineItem();

    List<Bits> bits = [];
    dynamic genericLineItem;
    dynamic priceBookId = selectedPriceBook?.priceBookId;

    //Logic for find generic line item
    for (var element in priceBookLineItem) {
      if (element is PriceBookLinesLowLevelItems) {
        PriceBookLinesLowLevelItems lowLevelItems = element;
        if (lowLevelItems.hLReference == AppStrings.genericLineItemCode) {
          genericLineItem = lowLevelItems;
        }
      } else {
        PriceBookLinesFlatLevelItems flatLevelItems = element;
        if (flatLevelItems.sHLReference == AppStrings.genericLineItemCode) {
          genericLineItem = flatLevelItems;
        }
      }
    }

    //if generic line item found && price book id not null then add line item in all bits
    if (genericLineItem != null && priceBookId != null) {
      for (var i = 0; i < selectedBits.length; i++) {
        List<LineItems> lineItem = selectedBits[i].lineItem ?? <LineItems>[];

        //if bit haven't any item then add otherwise keep as it is with same value
        if (lineItem.isEmpty) {
          ApplicationLogger().printInfo(
              '${selectedBits[i].bit?.bitId} haven\'t data',
              'fillBitWithGenericLineItem');
          List<LineItems> lineItemAdd = <LineItems>[];
          lineItemAdd.add(getRecord(priceBookId, genericLineItem));
          bits.add(Bits(bit: selectedBits[i].bit, lineItem: lineItemAdd));
        } else {
          bits.add(Bits(bit: selectedBits[i].bit, lineItem: lineItem));
          ApplicationLogger().printInfo(
              '${selectedBits[i].bit?.bitId} have already data',
              'fillBitWithGenericLineItem');
        }
      }
      consignmentModel.bits = bits;
      _consignmentModel.refresh();

      //After add line item above checking button enable/disable & visibility status
      ifAllLineItemsHasAtLeastOneBit();
    }
  }

  int noOfLineItemForSelectedBit() {
    return selectedBits.elementAt(priceBookSelectedTab).lineItem?.length ?? 0;
  }

  returnAllLineItems() {
    mainItemBuffer.clear();
    lineItemBuffer.clear();
    totalBalance = 0.0;
    count = 0;
    var allBit = selectedBits;
    for (var i = 0; i < selectedBits.length; i++) {
      lineItemBuffer.clear();
      totalBalance = 0.0;
      List<LineItems> lineItems = selectedBits[i].lineItem ?? <LineItems>[];
      lineItems.forEach((element) {
        addLineItem(element, selectedBits[i].bit);
      });
      addLineItemsToMainBuffer(selectedBits[i].bit?.serialNumber);
    }
  }

  //TODO ask about size for line item????
  void addLineItemsToMainBuffer(String? srnbr) {
    mainItemBuffer.write("""
    <div class="divQte">
<b>Serial Number # : <span>${srnbr}</span></b>        
        <table class="tblQte">
            <tr>
                <th style="width:10%">Id</th>
                <th style="width:10%">PB ID</th>
                <th style="width:5%">Size</th>
                <th style="width:20%">Local SPN</th>
                <th style="width:20%">Description</th>                                
                <th style="width:10%">Local UOM</th>
                <th style="width:5%">PB condition</th>
                <th style="width:10%">Price <span class="subtitle">(USD)</span></th>
                <th style="width:10%">Disc<span class="subtitle">(%)</span></th>
                <th style="width:10%">Net Amount<span class="subtitle">(USD)</span></th>                
            </tr>
            ${lineItemBuffer}
            <br>   
        </table>
        <b class="totalAmt">Net Total (USD): <span id="total">${getTotalBalance()}</span></b>
        </div>
        <div class="spacer"></div>

            """);
  }

  getLineItemsBuffer() {
    return mainItemBuffer;
  }

  getTotalBalance() {
    return totalBalance;
  }

  addLineItem(LineItems lineItem, Bit? bit) {
    var disc;
    if (lineItem.unitPrice! < lineItem.bestPrice!) {
      disc = "-";
    } else {
      disc =
          (((lineItem.unitPrice! - lineItem.bestPrice!) / lineItem.unitPrice!) *
                  100)
              .toStringAsFixed(2);
      disc = "$disc%";
    }

    lineItemBuffer.write("""<tr class="ll">
                <td>${lineItem.pricingId}</td>
                <td>${lineItem.priceBookId}</td>
                <td>${bit?.inch ?? ''}</td>
                <td>${lineItem.hLReference}</td>
                <td>${bit?.materialDescription ?? ''}</td>
                <td>${lineItem.uOM}</td>
                <td>${lineItem.lineCondition}</td>
                <td>${lineItem.unitPrice}</td>
                <td>${disc}</td>
                <td>${lineItem.bestPrice}</td>
                <td></td>
            </tr>
            <tr>
                <td>Comments</td>
                <td style="padding-bottom: 2%;" colspan="9" id="comments">${lineItem.comments}
                    </td>
            </tr>   """);
    pbID = lineItem.priceBookId.toString();
    totalBalance += lineItem.bestPrice!.toDouble();
  }

  String ifAllLineItemsHasAtLeastOneBit() {
    //Call function off clear digital/manual sign document if already done then
    checkAndRemoveSignedQuoteDocument();

    var currentBit = selectedBits[priceBookSelectedTab];
    List<LineItems> currentLineItem = currentBit.lineItem ?? <LineItems>[];

    isPriceBookNextEnable = false;
    updateStepItemStatus(currentIndex: index.value);

    var allBit = selectedBits
        .where((bit) => (bit.lineItem ?? <LineItems>[]).isEmpty == false);
    if (allBit.isEmpty == true) {
      nextButtonStatus.value = NextButtonState.hide.name;
      return nextButtonStatus.value.toString();
    } else {
      if (currentLineItem.isEmpty == true) {
        nextButtonStatus.value = NextButtonState.disable.name;
        return nextButtonStatus.value.toString();
      } else {
        for (var i = 0; i < selectedBits.length; i++) {
          List<LineItems> lineItem = selectedBits[i].lineItem ?? <LineItems>[];
          if (lineItem.isEmpty == true) {
            nextButtonStatus.value = NextButtonState.disable.name;
            return nextButtonStatus.value.toString();
          }

          //Checking price book line item validation
          for (var j = 0; j < lineItem.length; j++) {
            if (checkDuplicateLineItemValidation(j, lineItem) ||
                !checkLineItemValidation(lineItem[j])) {
              nextButtonStatus.value = NextButtonState.disable.name;
              return nextButtonStatus.value.toString();
            }
          }
        }
        isPriceBookNextEnable = true;
        updateStepItemStatus(currentIndex: index.value);
        nextButtonStatus.value = NextButtonState.enable.name;
        return nextButtonStatus.value.toString();
      }
    }
  }

  bool checkDuplicateLineItemValidation(
    int index,
    List<LineItems> lineItems,
  ) {
    var current = lineItems[index];

    for (int i = 0; i < index; i++) {
      var lineItem = lineItems[i];
      if (current.lineCondition == lineItem.lineCondition) {
        ApplicationLogger().printInfo(
            'Line item :- ${current.pricingId} is duplicate clone.',
            'checkDuplicateLineItemValidation');
        return true;
      }
    }
    return false;
  }

  bool checkLineItemValidation(LineItems lineItem) {
    if (lineItem.lineCondition == null) {
      return false;
    } else if (checkIfLineItemIsDBR(lineItem)) {
      if (lineItem.bestPrice == null || lineItem.bestPrice == 0.0) {
        return false;
      }
    } else {
      if (lineItem.bestPrice == null || lineItem.bestPrice == 0.0) {
        return false;
      } else if (lineItem.unitDrilled == null || lineItem.unitDrilled == 0.0) {
        return false;
      } else if (lineItem.pricePerUnit == null ||
          lineItem.pricePerUnit == 0.0) {
        return false;
      }
    }

    return true;
  }

  Future<void> addLineItemToBit(String priceBookId) async {
    List<Bits> bits = [];
    for (var i = 0; i < selectedBits.length; i++) {
      if (i == priceBookSelectedTab) {
        List<LineItems> lineItem = selectedBits[i].lineItem ?? <LineItems>[];
        lineItem.add(getRecord(priceBookId, selectedPriceLineItem.first));
        bits.add(Bits(bit: selectedBits[i].bit, lineItem: lineItem));
      } else {
        bits.add(selectedBits[i]);
      }
    }

    onPriceBookSelected = 0;
    consignmentModel.bits = bits;
    _consignmentModel.refresh();
    ifAllLineItemsHasAtLeastOneBit();
  }

  void clearPriceBookDropDownValue() {
    searchByMasterCode = '';
    searchBySlbMaterial = '';
    searchBySlbDescription = '';
  }

  void getPriceBookWithIdList() {
    List<String> priceBookIdNameList = <String>[];
    for (var priceBook in pricebookList.value) {
      priceBookIdNameList
          .add('${priceBook.priceBookId} - ${priceBook.priceBookName}');
      ApplicationLogger().printInfo(
          '${priceBook.priceBookId} - ${priceBook.priceBookName}',
          'ConsignController.getPriceBookWithIdList()');
    }
    priceBookWithIdList = priceBookIdNameList;
    _priceBookWithIdList.refresh();
  }

  Future<void> selectedPBLineItem({initialCall = false}) async {
    //On search filter we clear selection of lineItem if any selected then
    clearAndUpdateLineItemSelected(isClear: true);

    List<dynamic>? lineItemList = <dynamic>[];
    List? listRecord;

    if (selectedPriceBook != null && selectedPriceBook?.lines != null) {
      for (var lineItems in selectedPriceBook!.lines) {
        if (lineItems.type == 1 || lineItems.type == 4) {
          //Flat Line Items
          listRecord = filterRecord(lineItems.flatLevelItems);
          if (listRecord != null || listRecord?.isNotEmpty == true) {
            lineItemList.addAll(listRecord as Iterable);
          }
        } else if (lineItems.type == 2 || lineItems.type == 3) {
          //Low Lvl Line Items
          listRecord = filterRecord(lineItems.lowLevelItems);
          if (listRecord != null || listRecord?.isNotEmpty == true) {
            lineItemList.addAll(listRecord as Iterable);
          }
        }
      }
    }

    if (initialCall) {
      setupDropDownValuePriceBook(lineItemList);
    }

    priceBookLineItem = lineItemList;
    _priceBookLineItem.refresh();
  }

  void setupDropDownValuePriceBook(List<dynamic> lineItemList) {
    masterCodeList =
        getItemCollection(lineItemList, DropDownValue.masterCode.name)
            .toSet()
            .toList();

    slbMaterialList =
        getItemCollection(lineItemList, DropDownValue.slbMaterial.name)
            .toSet()
            .toList();

    slbDescriptionList =
        getItemCollection(lineItemList, DropDownValue.slbDescription.name)
            .toSet()
            .toList();

    ApplicationLogger().printInfo(
        'masterCodeList:- ${masterCodeList.length}, slbMaterialList:- ${slbMaterialList.length}, slbDescriptionList:- ${slbDescriptionList.length}, totalSize:- ${lineItemList.length}',
        'ConsignController.selectedPBLineItem()');

    _masterCodeList.refresh();
    _slbMaterialList.refresh();
    _slbDescriptionList.refresh();
  }

  List<String> getItemCollection(List lineItemList, String columnName) {
    var columnCollection = <String>[];
    for (dynamic lineItem in lineItemList) {
      var itemValue = getColumnValue(lineItem, columnName);
      if (itemValue.trim().isNotEmpty && itemValue.trim() != '-') {
        columnCollection.add(itemValue);
      }
    }
    return columnCollection;
  }

  String getColumnValue(dynamic lineItem, String columnName) {
    if (lineItem is PriceBookLinesLowLevelItems) {
      PriceBookLinesLowLevelItems lowLevelItems = lineItem;
      if (columnName == DropDownValue.slbDescription.name) {
        return lowLevelItems.materialDescription ?? '';
      } else if (columnName == DropDownValue.slbMaterial.name) {
        return lowLevelItems.materialNumber ?? '';
      } else if (columnName == DropDownValue.masterCode.name) {
        return lowLevelItems.masterCode ?? '';
      } else {
        return '-';
      }
    } else {
      PriceBookLinesFlatLevelItems flatLevelItems = lineItem;
      if (columnName == DropDownValue.slbDescription.name) {
        return flatLevelItems.materialDescription ?? '';
      } else if (columnName == DropDownValue.slbMaterial.name) {
        return flatLevelItems.materialNumber ?? '';
      } else {
        return '-';
      }
    }
  }

  List<dynamic>? filterRecord(List<dynamic>? lineItems) {
    List<dynamic>? lineItemList = <dynamic>[];
    String? materialDescription = '';
    String? materialNumber = '';
    String? masterCode = '';
    bool isGenericLineItem = false;

    /*1- all blank
      2- only 1st selected
      3- only 2nd selected
      4- only 3rd selected
      5- 1st & 2nd selected
      6- 1st & 3rd selected
      7- 2nd & 3rd selected
      8- all selected*/

    /*list of line item is empty so no filter apply*/
    if (lineItems == null) {
      return lineItemList;
    }

    for (var lineItem in lineItems) {
      if (lineItem is PriceBookLinesLowLevelItems) {
        PriceBookLinesLowLevelItems lowLevelItems = lineItem;

        materialDescription = lowLevelItems.materialDescription;
        materialNumber = lowLevelItems.materialNumber;
        masterCode = lowLevelItems.masterCode;
        if (lowLevelItems.hLReference == AppStrings.genericLineItemCode) {
          isGenericLineItem = true;
        }
      } else {
        PriceBookLinesFlatLevelItems flatLevelItems = lineItem;

        materialDescription = flatLevelItems.materialDescription;
        materialNumber = flatLevelItems.materialNumber;
        masterCode = '';
        if (flatLevelItems.sHLReference == AppStrings.genericLineItemCode) {
          isGenericLineItem = true;
        }
      }

      bool doesMasterCodeContainsString =
          (masterCode?.toLowerCase() == searchByMasterCode.toLowerCase()) ==
              true;

      bool doesMaterialNumberContainsString = (materialNumber?.toLowerCase() ==
              searchBySlbMaterial.toLowerCase()) ==
          true;

      bool doesMaterialDescriptionContainsString =
          (materialDescription?.toLowerCase() ==
                  searchBySlbDescription.toLowerCase()) ==
              true;

      /*search filter is empty so send as it is list of data without filter apply.*/
      if (searchByMasterCode.isEmpty &&
          searchBySlbMaterial.isEmpty &&
          searchBySlbDescription.isEmpty &&
          isGenericLineItem) {
        lineItemList.add(lineItem);
      } else if (searchByMasterCode.isNotEmpty &&
          searchBySlbMaterial.isEmpty &&
          searchBySlbDescription.isEmpty &&
          doesMasterCodeContainsString &&
          isGenericLineItem) {
        lineItemList.add(lineItem);
      } else if (searchByMasterCode.isEmpty &&
          searchBySlbMaterial.isNotEmpty &&
          searchBySlbDescription.isEmpty &&
          doesMaterialNumberContainsString &&
          isGenericLineItem) {
        lineItemList.add(lineItem);
      } else if (searchByMasterCode.isEmpty &&
          searchBySlbMaterial.isEmpty &&
          searchBySlbDescription.isNotEmpty &&
          doesMaterialDescriptionContainsString &&
          isGenericLineItem) {
        lineItemList.add(lineItem);
      } else if (searchByMasterCode.isNotEmpty &&
          searchBySlbMaterial.isNotEmpty &&
          searchBySlbDescription.isEmpty &&
          doesMasterCodeContainsString &&
          doesMaterialNumberContainsString &&
          isGenericLineItem) {
        lineItemList.add(lineItem);
      } else if (searchByMasterCode.isNotEmpty &&
          searchBySlbMaterial.isEmpty &&
          searchBySlbDescription.isNotEmpty &&
          doesMasterCodeContainsString &&
          doesMaterialDescriptionContainsString &&
          isGenericLineItem) {
        lineItemList.add(lineItem);
      } else if (searchByMasterCode.isEmpty &&
          searchBySlbMaterial.isNotEmpty &&
          searchBySlbDescription.isNotEmpty &&
          doesMaterialNumberContainsString &&
          doesMaterialDescriptionContainsString &&
          isGenericLineItem) {
        lineItemList.add(lineItem);
      } else if (searchByMasterCode.isNotEmpty &&
          searchBySlbMaterial.isNotEmpty &&
          searchBySlbDescription.isNotEmpty &&
          doesMasterCodeContainsString &&
          doesMaterialNumberContainsString &&
          doesMaterialDescriptionContainsString &&
          isGenericLineItem) {
        lineItemList.add(lineItem);
      }
    }
    return lineItemList;
  }

  LineItems getRecord(String priceBookId, dynamic lineItem) {
    if (lineItem is PriceBookLinesLowLevelItems) {
      PriceBookLinesLowLevelItems lowLevelItems = lineItem;
      return LineItems(
          priceBookId: priceBookId,
          currency: lowLevelItems.currency,
          hLReference: lowLevelItems.hLReference,
          isActive: lowLevelItems.isActive,
          masterCode: lowLevelItems.masterCode,
          materialDescription: lowLevelItems.materialDescription,
          materialLocalDescription: lowLevelItems.materialLocalDescription,
          materialLocalNumber: lowLevelItems.materialLocalNumber,
          materialNumber: lowLevelItems.materialNumber,
          pricingId: lowLevelItems.pricingId,
          sHLReference: lowLevelItems.sHLReference,
          uOM: lowLevelItems.uOM,
          unitPrice: lowLevelItems.unitPrice,
          bestPrice: 0.0,
          comments: '',
          discountAmount: 0.0,
          discountPercentage: 0.0,
          unitDrilled: 0.0,
          pricePerUnit: 0.0,
          isExpanded: true,
          isDuplicate: false,
          lineCondition: null);
    } else {
      PriceBookLinesFlatLevelItems flatLevelItems = lineItem;
      return LineItems(
          priceBookId: priceBookId,
          currency: flatLevelItems.currency,
          hLReference: '',
          isActive: flatLevelItems.isActive,
          masterCode: '',
          materialDescription: flatLevelItems.materialDescription,
          materialLocalDescription: flatLevelItems.materialLocalDescription,
          materialLocalNumber: flatLevelItems.materialLocalNumber,
          materialNumber: flatLevelItems.materialNumber,
          pricingId: flatLevelItems.pricingId,
          sHLReference: flatLevelItems.sHLReference,
          uOM: flatLevelItems.uOM,
          unitPrice: flatLevelItems.unitPrice,
          bestPrice: 0.0,
          comments: '',
          discountAmount: 0.0,
          discountPercentage: 0.0,
          unitDrilled: 0.0,
          pricePerUnit: 0.0,
          isExpanded: true,
          isDuplicate: false,
          lineCondition: null);
    }
  }

  void addConsignment(String status) async {
    var draftObjectID = "";
    if (isDraftEdit) {
      draftObjectID = draftConsignmentID!;
    }
    List<Bit> bits = [];
    selectedBits.forEach((element) {
      bits.add(element.bit!);
    });

/*
Test cases for Below if else condition
1. new consign 2 bit and save draft -->>else pass -- test pass
2. new consign 2 bit and process  -->>else pass -->> test pass
3. draft 2 bit remove one and save draft -->> if pass -->> test pass
4. draft 2 bit remove 1 bit and process  -->> if pass -->> test pass
5. draft 2 bit and process -->> if pass --->> test pass
6. if only one bit is avaliibe and deleted in the enter
detail screen it should delete the draft and un block the bit
 */

    if (draftConsignmentID != null) {
      await draftEnterDetailsBitListComparison(consignmentID);
    } else {
      await blockBitsSelectedBit(selectedBits);
    }

    /*
      priceBook
      */
    if (!(rig == null &&
        customer == null &&
        consignmentModel.customerEmail == null)) {
      await realm
          .insertConsignedBitRequest(
              email,
              selectedBits,
              pricebookList.first,
              rig,
              customer,
              bits,
              status,
              quotePdfBase64,
              consignmentID,
              draftObjectID,
              consignmentModel.quoteID)
          .then((value) {
        if (value && status == AppStrings.processing) {
          updatePrefsIfMovementHappen();
          hitMovementApi(connectivityController.isConnected.value);
        }
      });
    }
  }

  void hitMovementApi(bool isInternetConnected) {
    ApplicationLogger().printInfo(
        'hitBitMovementApi:- $isInternetConnected', 'hitBitMovementApi()');
    if (isInternetConnected) {
      if (prefs.getBool(PreferenceConstants.isMovementHappen)!) {
        var queryParam = BitMovementParam(
            requestedBy: prefs.getString(PreferenceConstants.userEmail)!,
            truckUserMappingId:
                prefs.getString(PreferenceConstants.userTruckMapping)!);
        var bitMovementService = _repository.bitMovement(queryParam);
        callDataService(bitMovementService,
            onSuccess: _handleProjectListResponseSuccess,
            onError: _handleBitMovmentError);
      }
    } else if (prefs.getBool(PreferenceConstants.isMovementHappen)!) {
      showToastMsg(Get.context!, AppStrings.noInternet, ToastStatus.info);
    }
  }

  void _handleBitMovmentError(Exception response) async {
    if (response is AppCustomException) {
      if (response.message.contains("401")) {
        await AADAuthentication.instance.acquireTokenSilently();
        hitMovementApi(true);
      }
    }
    prefs.setBool(PreferenceConstants.isMovementHappen, false);
  }

  updatePrefsIfMovementHappen() {
    prefs.setBool(PreferenceConstants.isMovementHappen, true);
  }

  void _handleProjectListResponseSuccess(BitMovementResponseModel response) {
    var repoList = response.message;
    prefs.setBool(PreferenceConstants.isMovementHappen, false);
  }

  void createConsignmentID() {
    if (consignmentID.trim().isEmpty) {
      consignmentID =
          "${AppStrings.prefixConsignmentID}${DateTime.now().toUtc().millisecondsSinceEpoch}";
    }
  }

  void createQuoteID() {
    if (quoteID.trim().isEmpty) {
      quoteID =
          "${AppStrings.prefixQuoteID}${DateTime.now().toUtc().millisecondsSinceEpoch}";
    }
  }

  late List<BitState> bitsState;

  Future<void> unBlockBitsSelectedBit(Bit bit) async {
    List<Bit> unSelectedBitList = [];
    unSelectedBitList.add(bit);
    await realm.setBitListStatusToUnBlock(
        unSelectedBitList, AppStrings.bitIsRemovedFromTheDraft);
  }

  Future<void> blockBitsSelectedBit(List<Bits> bitList) async {
    List<Bit> bits = [];
    bitList.forEach((bit) {
      if (bit.bit != null) {
        bits.add(bit.bit!);
      }
    });
    await realm.setBitListStatusToBlock(
        bits, AppStrings.bitIsEitherInDraftOrConsigned);
  }

  Future<void> draftEnterDetailsBitListComparison(String consignID) async {
    List<Consignment> consignmentDraft = realm.getConsignDraft(consignID);
    List<String> listOfBitForQuery = [];
    List<String> consginBits = [];
    List<String> selectedBitSerialList = [];

    var consignModel = consignmentDraft[0].bits;

    for (int i = 0; i < consignModel.length; i++) {
      consginBits.add(consignModel[i].serialNumber!);
    }

    for (int j = 0; j < selectedBits.length; j++) {
      if (selectedBits[j].bit != null) {
        selectedBitSerialList.add(selectedBits[j].bit!.serialNumber ?? '');
      }
    }
    List<String> difference =
        consginBits.toSet().difference(selectedBitSerialList.toSet()).toList();

    difference.forEach((serialNum) {
      listOfBitForQuery.add('\'$serialNum\'');
    });
    var query =
        listOfBitForQuery.toString().replaceAll('[', '{').replaceAll(']', '}');

    if (query.isNotEmpty) {
      await realm.setBitListStatusToUnBlockRealm(query);
    }
  }
}
