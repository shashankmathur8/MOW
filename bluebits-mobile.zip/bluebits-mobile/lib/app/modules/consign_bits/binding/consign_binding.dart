import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/controller/consign_controller.dart';

class ConsignBinding extends Bindings {
  @override
  void dependencies() {
    //Get.lazyPut<ConsignController>(() => ConsignController());
  }
}
