import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/customerSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/rigsSchema.dart';

class ConsignmentModel {
  late Rig? rig;
  late Customer? customer;
  late String? customerEmail;
  late String? consignmentID;
  late String? quoteID;
  late List<Bits>? bits;

  ConsignmentModel({
    this.rig,
    this.customer,
    this.customerEmail,
    this.bits,
    this.consignmentID,
    this.quoteID
  });

  @override
  String toString() {
    return 'ConsignmentModel{rig: $rig, customer: $customer, customerEmail: $customerEmail, consignmentID: $consignmentID, bits: $bits}';
  }
}

class Bits {
  late Bit? bit;
  late List<LineItems>? lineItem;

  Bits({
    this.bit,
    this.lineItem,
  });

  @override
  String toString() {
    return 'Bits{bit: $bit, lineItem: $lineItem}';
  }
}

class LineItems {
  late String? currency;
  late String? hLReference;
  late bool? isActive;
  late String? masterCode;
  late String? materialDescription;
  late String? materialLocalDescription;
  late String? materialLocalNumber;
  late String? materialNumber;
  late int? pricingId;
  late String? sHLReference;
  late String? uOM;
  late double? unitPrice;
  late double? bestPrice;
  late String? comments;
  late double? discountAmount;
  late double? discountPercentage;
  late double? unitDrilled;
  late double? pricePerUnit;
  late bool? isExpanded;
  late bool? isDuplicate;
  late String? priceBookId;
  String? lineCondition = null;

  LineItems({
    this.priceBookId,
    this.currency,
    this.hLReference,
    this.isActive,
    this.masterCode,
    this.materialDescription,
    this.materialLocalDescription,
    this.materialLocalNumber,
    this.materialNumber,
    this.pricingId,
    this.sHLReference,
    this.uOM,
    this.unitPrice,
    this.bestPrice,
    this.comments,
    this.discountAmount,
    this.discountPercentage,
    this.unitDrilled,
    this.pricePerUnit,
    this.isExpanded,
    this.isDuplicate,
    this.lineCondition
  });

  LineItems copyWith(LineItems lineItems) {
    return LineItems(
        priceBookId: lineItems.priceBookId,
        currency: lineItems.currency,
        hLReference: lineItems.hLReference,
        isActive: lineItems.isActive,
        masterCode: lineItems.masterCode,
        materialDescription: lineItems.materialDescription,
        materialLocalDescription: lineItems.materialLocalDescription,
        materialLocalNumber: lineItems.materialLocalNumber,
        materialNumber: lineItems.materialNumber,
        pricingId: lineItems.pricingId,
        sHLReference: lineItems.sHLReference,
        uOM: lineItems.uOM,
        unitPrice: lineItems.unitPrice,
        bestPrice: lineItems.bestPrice,
        comments: lineItems.comments,
        discountAmount: lineItems.discountAmount,
        discountPercentage: lineItems.discountPercentage,
        unitDrilled: lineItems.unitDrilled,
        pricePerUnit: lineItems.pricePerUnit,
        isExpanded: true,
        isDuplicate: false,
        lineCondition: lineItems.lineCondition
    );
  }

  @override
  String toString() {
    return 'LineItems{priceBookId: $priceBookId, currency: $currency, hLReference: $hLReference, isActive: $isActive, masterCode: $masterCode, materialDescription: $materialDescription, materialLocalDescription: $materialLocalDescription, materialLocalNumber: $materialLocalNumber, materialNumber: $materialNumber, pricingId: $pricingId, sHLReference: $sHLReference, uOM: $uOM, unitPrice: $unitPrice, bestPrice: $bestPrice, comments: $comments, discountAmount: $discountAmount, discountPercentage: $discountPercentage, unitDrilled: $unitDrilled, pricePerUnit: $pricePerUnit, isExpanded: $isExpanded, isDuplicate: $isDuplicate, lineCondition: $lineCondition}';
  }
}
