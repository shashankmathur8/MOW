// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pricebook_schema.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class PriceBook extends _PriceBook
    with RealmEntity, RealmObjectBase, RealmObject {
  PriceBook(
    ObjectId? id, {
    String? comments,
    String? contractNumber,
    String? country,
    String? createdBy,
    DateTime? createdDate,
    String? currency,
    String? customerName,
    String? geoMarket,
    bool? isActive,
    String? modifiedBy,
    DateTime? modifiedDate,
    String? priceBookDescription,
    String? priceBookId,
    String? priceBookName,
    String? roundingRule,
    String? segment,
    String? sourceSystem,
    String? subSegment,
    String? subSegmentDescription,
    DateTime? validFrom,
    DateTime? validTo,
    Iterable<PriceBookLines> lines = const [],
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'comments', comments);
    RealmObjectBase.set(this, 'contractNumber', contractNumber);
    RealmObjectBase.set(this, 'country', country);
    RealmObjectBase.set(this, 'createdBy', createdBy);
    RealmObjectBase.set(this, 'createdDate', createdDate);
    RealmObjectBase.set(this, 'currency', currency);
    RealmObjectBase.set(this, 'customerName', customerName);
    RealmObjectBase.set(this, 'geoMarket', geoMarket);
    RealmObjectBase.set(this, 'isActive', isActive);
    RealmObjectBase.set(this, 'modifiedBy', modifiedBy);
    RealmObjectBase.set(this, 'modifiedDate', modifiedDate);
    RealmObjectBase.set(this, 'priceBookDescription', priceBookDescription);
    RealmObjectBase.set(this, 'priceBookId', priceBookId);
    RealmObjectBase.set(this, 'priceBookName', priceBookName);
    RealmObjectBase.set(this, 'roundingRule', roundingRule);
    RealmObjectBase.set(this, 'segment', segment);
    RealmObjectBase.set(this, 'sourceSystem', sourceSystem);
    RealmObjectBase.set(this, 'subSegment', subSegment);
    RealmObjectBase.set(this, 'subSegmentDescription', subSegmentDescription);
    RealmObjectBase.set(this, 'validFrom', validFrom);
    RealmObjectBase.set(this, 'validTo', validTo);
    RealmObjectBase.set<RealmList<PriceBookLines>>(
        this, 'lines', RealmList<PriceBookLines>(lines));
  }

  PriceBook._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get comments =>
      RealmObjectBase.get<String>(this, 'comments') as String?;
  @override
  set comments(String? value) => RealmObjectBase.set(this, 'comments', value);

  @override
  String? get contractNumber =>
      RealmObjectBase.get<String>(this, 'contractNumber') as String?;
  @override
  set contractNumber(String? value) =>
      RealmObjectBase.set(this, 'contractNumber', value);

  @override
  String? get country =>
      RealmObjectBase.get<String>(this, 'country') as String?;
  @override
  set country(String? value) => RealmObjectBase.set(this, 'country', value);

  @override
  String? get createdBy =>
      RealmObjectBase.get<String>(this, 'createdBy') as String?;
  @override
  set createdBy(String? value) => RealmObjectBase.set(this, 'createdBy', value);

  @override
  DateTime? get createdDate =>
      RealmObjectBase.get<DateTime>(this, 'createdDate') as DateTime?;
  @override
  set createdDate(DateTime? value) =>
      RealmObjectBase.set(this, 'createdDate', value);

  @override
  String? get currency =>
      RealmObjectBase.get<String>(this, 'currency') as String?;
  @override
  set currency(String? value) => RealmObjectBase.set(this, 'currency', value);

  @override
  String? get customerName =>
      RealmObjectBase.get<String>(this, 'customerName') as String?;
  @override
  set customerName(String? value) =>
      RealmObjectBase.set(this, 'customerName', value);

  @override
  String? get geoMarket =>
      RealmObjectBase.get<String>(this, 'geoMarket') as String?;
  @override
  set geoMarket(String? value) => RealmObjectBase.set(this, 'geoMarket', value);

  @override
  bool? get isActive => RealmObjectBase.get<bool>(this, 'isActive') as bool?;
  @override
  set isActive(bool? value) => RealmObjectBase.set(this, 'isActive', value);

  @override
  RealmList<PriceBookLines> get lines =>
      RealmObjectBase.get<PriceBookLines>(this, 'lines')
          as RealmList<PriceBookLines>;
  @override
  set lines(covariant RealmList<PriceBookLines> value) =>
      throw RealmUnsupportedSetError();

  @override
  String? get modifiedBy =>
      RealmObjectBase.get<String>(this, 'modifiedBy') as String?;
  @override
  set modifiedBy(String? value) =>
      RealmObjectBase.set(this, 'modifiedBy', value);

  @override
  DateTime? get modifiedDate =>
      RealmObjectBase.get<DateTime>(this, 'modifiedDate') as DateTime?;
  @override
  set modifiedDate(DateTime? value) =>
      RealmObjectBase.set(this, 'modifiedDate', value);

  @override
  String? get priceBookDescription =>
      RealmObjectBase.get<String>(this, 'priceBookDescription') as String?;
  @override
  set priceBookDescription(String? value) =>
      RealmObjectBase.set(this, 'priceBookDescription', value);

  @override
  String? get priceBookId =>
      RealmObjectBase.get<String>(this, 'priceBookId') as String?;
  @override
  set priceBookId(String? value) =>
      RealmObjectBase.set(this, 'priceBookId', value);

  @override
  String? get priceBookName =>
      RealmObjectBase.get<String>(this, 'priceBookName') as String?;
  @override
  set priceBookName(String? value) =>
      RealmObjectBase.set(this, 'priceBookName', value);

  @override
  String? get roundingRule =>
      RealmObjectBase.get<String>(this, 'roundingRule') as String?;
  @override
  set roundingRule(String? value) =>
      RealmObjectBase.set(this, 'roundingRule', value);

  @override
  String? get segment =>
      RealmObjectBase.get<String>(this, 'segment') as String?;
  @override
  set segment(String? value) => RealmObjectBase.set(this, 'segment', value);

  @override
  String? get sourceSystem =>
      RealmObjectBase.get<String>(this, 'sourceSystem') as String?;
  @override
  set sourceSystem(String? value) =>
      RealmObjectBase.set(this, 'sourceSystem', value);

  @override
  String? get subSegment =>
      RealmObjectBase.get<String>(this, 'subSegment') as String?;
  @override
  set subSegment(String? value) =>
      RealmObjectBase.set(this, 'subSegment', value);

  @override
  String? get subSegmentDescription =>
      RealmObjectBase.get<String>(this, 'subSegmentDescription') as String?;
  @override
  set subSegmentDescription(String? value) =>
      RealmObjectBase.set(this, 'subSegmentDescription', value);

  @override
  DateTime? get validFrom =>
      RealmObjectBase.get<DateTime>(this, 'validFrom') as DateTime?;
  @override
  set validFrom(DateTime? value) =>
      RealmObjectBase.set(this, 'validFrom', value);

  @override
  DateTime? get validTo =>
      RealmObjectBase.get<DateTime>(this, 'validTo') as DateTime?;
  @override
  set validTo(DateTime? value) => RealmObjectBase.set(this, 'validTo', value);

  @override
  Stream<RealmObjectChanges<PriceBook>> get changes =>
      RealmObjectBase.getChanges<PriceBook>(this);

  @override
  PriceBook freeze() => RealmObjectBase.freezeObject<PriceBook>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(PriceBook._);
    return const SchemaObject(ObjectType.realmObject, PriceBook, 'PriceBook', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('comments', RealmPropertyType.string, optional: true),
      SchemaProperty('contractNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('country', RealmPropertyType.string, optional: true),
      SchemaProperty('createdBy', RealmPropertyType.string, optional: true),
      SchemaProperty('createdDate', RealmPropertyType.timestamp,
          optional: true),
      SchemaProperty('currency', RealmPropertyType.string, optional: true),
      SchemaProperty('customerName', RealmPropertyType.string, optional: true),
      SchemaProperty('geoMarket', RealmPropertyType.string, optional: true),
      SchemaProperty('isActive', RealmPropertyType.bool, optional: true),
      SchemaProperty('lines', RealmPropertyType.object,
          linkTarget: 'PriceBook_lines',
          collectionType: RealmCollectionType.list),
      SchemaProperty('modifiedBy', RealmPropertyType.string, optional: true),
      SchemaProperty('modifiedDate', RealmPropertyType.timestamp,
          optional: true),
      SchemaProperty('priceBookDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('priceBookId', RealmPropertyType.string, optional: true),
      SchemaProperty('priceBookName', RealmPropertyType.string, optional: true),
      SchemaProperty('roundingRule', RealmPropertyType.string, optional: true),
      SchemaProperty('segment', RealmPropertyType.string, optional: true),
      SchemaProperty('sourceSystem', RealmPropertyType.string, optional: true),
      SchemaProperty('subSegment', RealmPropertyType.string, optional: true),
      SchemaProperty('subSegmentDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('validFrom', RealmPropertyType.timestamp, optional: true),
      SchemaProperty('validTo', RealmPropertyType.timestamp, optional: true),
    ]);
  }
}

class PriceBookLines extends _PriceBookLines
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  PriceBookLines({
    int? type,
    String? typeDescription,
    Iterable<PriceBookLinesFlatLevelItems> flatLevelItems = const [],
    Iterable<PriceBookLinesHighLevelItems> highLevelItems = const [],
    Iterable<PriceBookLinesLowLevelItems> lowLevelItems = const [],
    Iterable<PriceBookLinesSuperHighLevelItems> superHighLevelItems = const [],
  }) {
    RealmObjectBase.set(this, 'type', type);
    RealmObjectBase.set(this, 'typeDescription', typeDescription);
    RealmObjectBase.set<RealmList<PriceBookLinesFlatLevelItems>>(
        this,
        'flatLevelItems',
        RealmList<PriceBookLinesFlatLevelItems>(flatLevelItems));
    RealmObjectBase.set<RealmList<PriceBookLinesHighLevelItems>>(
        this,
        'highLevelItems',
        RealmList<PriceBookLinesHighLevelItems>(highLevelItems));
    RealmObjectBase.set<RealmList<PriceBookLinesLowLevelItems>>(this,
        'lowLevelItems', RealmList<PriceBookLinesLowLevelItems>(lowLevelItems));
    RealmObjectBase.set<RealmList<PriceBookLinesSuperHighLevelItems>>(
        this,
        'superHighLevelItems',
        RealmList<PriceBookLinesSuperHighLevelItems>(superHighLevelItems));
  }

  PriceBookLines._();

  @override
  RealmList<PriceBookLinesFlatLevelItems> get flatLevelItems =>
      RealmObjectBase.get<PriceBookLinesFlatLevelItems>(this, 'flatLevelItems')
          as RealmList<PriceBookLinesFlatLevelItems>;
  @override
  set flatLevelItems(covariant RealmList<PriceBookLinesFlatLevelItems> value) =>
      throw RealmUnsupportedSetError();

  @override
  RealmList<PriceBookLinesHighLevelItems> get highLevelItems =>
      RealmObjectBase.get<PriceBookLinesHighLevelItems>(this, 'highLevelItems')
          as RealmList<PriceBookLinesHighLevelItems>;
  @override
  set highLevelItems(covariant RealmList<PriceBookLinesHighLevelItems> value) =>
      throw RealmUnsupportedSetError();

  @override
  RealmList<PriceBookLinesLowLevelItems> get lowLevelItems =>
      RealmObjectBase.get<PriceBookLinesLowLevelItems>(this, 'lowLevelItems')
          as RealmList<PriceBookLinesLowLevelItems>;
  @override
  set lowLevelItems(covariant RealmList<PriceBookLinesLowLevelItems> value) =>
      throw RealmUnsupportedSetError();

  @override
  RealmList<PriceBookLinesSuperHighLevelItems> get superHighLevelItems =>
      RealmObjectBase.get<PriceBookLinesSuperHighLevelItems>(
              this, 'superHighLevelItems')
          as RealmList<PriceBookLinesSuperHighLevelItems>;
  @override
  set superHighLevelItems(
          covariant RealmList<PriceBookLinesSuperHighLevelItems> value) =>
      throw RealmUnsupportedSetError();

  @override
  int? get type => RealmObjectBase.get<int>(this, 'type') as int?;
  @override
  set type(int? value) => RealmObjectBase.set(this, 'type', value);

  @override
  String? get typeDescription =>
      RealmObjectBase.get<String>(this, 'typeDescription') as String?;
  @override
  set typeDescription(String? value) =>
      RealmObjectBase.set(this, 'typeDescription', value);

  @override
  Stream<RealmObjectChanges<PriceBookLines>> get changes =>
      RealmObjectBase.getChanges<PriceBookLines>(this);

  @override
  PriceBookLines freeze() => RealmObjectBase.freezeObject<PriceBookLines>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(PriceBookLines._);
    return const SchemaObject(
        ObjectType.embeddedObject, PriceBookLines, 'PriceBook_lines', [
      SchemaProperty('flatLevelItems', RealmPropertyType.object,
          linkTarget: 'PriceBook_lines_flatLevelItems',
          collectionType: RealmCollectionType.list),
      SchemaProperty('highLevelItems', RealmPropertyType.object,
          linkTarget: 'PriceBook_lines_highLevelItems',
          collectionType: RealmCollectionType.list),
      SchemaProperty('lowLevelItems', RealmPropertyType.object,
          linkTarget: 'PriceBook_lines_lowLevelItems',
          collectionType: RealmCollectionType.list),
      SchemaProperty('superHighLevelItems', RealmPropertyType.object,
          linkTarget: 'PriceBook_lines_superHighLevelItems',
          collectionType: RealmCollectionType.list),
      SchemaProperty('type', RealmPropertyType.int, optional: true),
      SchemaProperty('typeDescription', RealmPropertyType.string,
          optional: true),
    ]);
  }
}

class PriceBookLinesFlatLevelItems extends _PriceBookLinesFlatLevelItems
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  PriceBookLinesFlatLevelItems({
    String? currency,
    bool? isActive,
    String? lastModifiedBy,
    DateTime? lastModifiedDate,
    String? materialDescription,
    String? materialLocalDescription,
    String? materialLocalNumber,
    String? materialNumber,
    int? pricingId,
    String? sHLReference,
    String? uOM,
    String? uOMLocal,
    double? unitPrice,
    double? unitPriceSecondary,
  }) {
    RealmObjectBase.set(this, 'currency', currency);
    RealmObjectBase.set(this, 'isActive', isActive);
    RealmObjectBase.set(this, 'lastModifiedBy', lastModifiedBy);
    RealmObjectBase.set(this, 'lastModifiedDate', lastModifiedDate);
    RealmObjectBase.set(this, 'materialDescription', materialDescription);
    RealmObjectBase.set(
        this, 'materialLocalDescription', materialLocalDescription);
    RealmObjectBase.set(this, 'materialLocalNumber', materialLocalNumber);
    RealmObjectBase.set(this, 'materialNumber', materialNumber);
    RealmObjectBase.set(this, 'pricingId', pricingId);
    RealmObjectBase.set(this, 'sHLReference', sHLReference);
    RealmObjectBase.set(this, 'uOM', uOM);
    RealmObjectBase.set(this, 'uOMLocal', uOMLocal);
    RealmObjectBase.set(this, 'unitPrice', unitPrice);
    RealmObjectBase.set(this, 'unitPriceSecondary', unitPriceSecondary);
  }

  PriceBookLinesFlatLevelItems._();

  @override
  String? get currency =>
      RealmObjectBase.get<String>(this, 'currency') as String?;
  @override
  set currency(String? value) => RealmObjectBase.set(this, 'currency', value);

  @override
  bool? get isActive => RealmObjectBase.get<bool>(this, 'isActive') as bool?;
  @override
  set isActive(bool? value) => RealmObjectBase.set(this, 'isActive', value);

  @override
  String? get lastModifiedBy =>
      RealmObjectBase.get<String>(this, 'lastModifiedBy') as String?;
  @override
  set lastModifiedBy(String? value) =>
      RealmObjectBase.set(this, 'lastModifiedBy', value);

  @override
  DateTime? get lastModifiedDate =>
      RealmObjectBase.get<DateTime>(this, 'lastModifiedDate') as DateTime?;
  @override
  set lastModifiedDate(DateTime? value) =>
      RealmObjectBase.set(this, 'lastModifiedDate', value);

  @override
  String? get materialDescription =>
      RealmObjectBase.get<String>(this, 'materialDescription') as String?;
  @override
  set materialDescription(String? value) =>
      RealmObjectBase.set(this, 'materialDescription', value);

  @override
  String? get materialLocalDescription =>
      RealmObjectBase.get<String>(this, 'materialLocalDescription') as String?;
  @override
  set materialLocalDescription(String? value) =>
      RealmObjectBase.set(this, 'materialLocalDescription', value);

  @override
  String? get materialLocalNumber =>
      RealmObjectBase.get<String>(this, 'materialLocalNumber') as String?;
  @override
  set materialLocalNumber(String? value) =>
      RealmObjectBase.set(this, 'materialLocalNumber', value);

  @override
  String? get materialNumber =>
      RealmObjectBase.get<String>(this, 'materialNumber') as String?;
  @override
  set materialNumber(String? value) =>
      RealmObjectBase.set(this, 'materialNumber', value);

  @override
  int? get pricingId => RealmObjectBase.get<int>(this, 'pricingId') as int?;
  @override
  set pricingId(int? value) => RealmObjectBase.set(this, 'pricingId', value);

  @override
  String? get sHLReference =>
      RealmObjectBase.get<String>(this, 'sHLReference') as String?;
  @override
  set sHLReference(String? value) =>
      RealmObjectBase.set(this, 'sHLReference', value);

  @override
  String? get uOM => RealmObjectBase.get<String>(this, 'uOM') as String?;
  @override
  set uOM(String? value) => RealmObjectBase.set(this, 'uOM', value);

  @override
  String? get uOMLocal =>
      RealmObjectBase.get<String>(this, 'uOMLocal') as String?;
  @override
  set uOMLocal(String? value) => RealmObjectBase.set(this, 'uOMLocal', value);

  @override
  double? get unitPrice =>
      RealmObjectBase.get<double>(this, 'unitPrice') as double?;
  @override
  set unitPrice(double? value) => RealmObjectBase.set(this, 'unitPrice', value);

  @override
  double? get unitPriceSecondary =>
      RealmObjectBase.get<double>(this, 'unitPriceSecondary') as double?;
  @override
  set unitPriceSecondary(double? value) =>
      RealmObjectBase.set(this, 'unitPriceSecondary', value);

  @override
  Stream<RealmObjectChanges<PriceBookLinesFlatLevelItems>> get changes =>
      RealmObjectBase.getChanges<PriceBookLinesFlatLevelItems>(this);

  @override
  PriceBookLinesFlatLevelItems freeze() =>
      RealmObjectBase.freezeObject<PriceBookLinesFlatLevelItems>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(PriceBookLinesFlatLevelItems._);
    return const SchemaObject(ObjectType.embeddedObject,
        PriceBookLinesFlatLevelItems, 'PriceBook_lines_flatLevelItems', [
      SchemaProperty('currency', RealmPropertyType.string, optional: true),
      SchemaProperty('isActive', RealmPropertyType.bool, optional: true),
      SchemaProperty('lastModifiedBy', RealmPropertyType.string,
          optional: true),
      SchemaProperty('lastModifiedDate', RealmPropertyType.timestamp,
          optional: true),
      SchemaProperty('materialDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('materialLocalDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('materialLocalNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('materialNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('pricingId', RealmPropertyType.int, optional: true),
      SchemaProperty('sHLReference', RealmPropertyType.string, optional: true),
      SchemaProperty('uOM', RealmPropertyType.string, optional: true),
      SchemaProperty('uOMLocal', RealmPropertyType.string, optional: true),
      SchemaProperty('unitPrice', RealmPropertyType.double, optional: true),
      SchemaProperty('unitPriceSecondary', RealmPropertyType.double,
          optional: true),
    ]);
  }
}

class PriceBookLinesHighLevelItems extends _PriceBookLinesHighLevelItems
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  PriceBookLinesHighLevelItems({
    String? masterCode,
    String? materialDescription,
    String? materialLocalDescription,
    String? materialLocalNumber,
    String? materialNumber,
    int? pricingId,
    String? sHLReference,
    String? subSegment,
    String? uOM,
    String? uOMLocal,
  }) {
    RealmObjectBase.set(this, 'masterCode', masterCode);
    RealmObjectBase.set(this, 'materialDescription', materialDescription);
    RealmObjectBase.set(
        this, 'materialLocalDescription', materialLocalDescription);
    RealmObjectBase.set(this, 'materialLocalNumber', materialLocalNumber);
    RealmObjectBase.set(this, 'materialNumber', materialNumber);
    RealmObjectBase.set(this, 'pricingId', pricingId);
    RealmObjectBase.set(this, 'sHLReference', sHLReference);
    RealmObjectBase.set(this, 'subSegment', subSegment);
    RealmObjectBase.set(this, 'uOM', uOM);
    RealmObjectBase.set(this, 'uOMLocal', uOMLocal);
  }

  PriceBookLinesHighLevelItems._();

  @override
  String? get masterCode =>
      RealmObjectBase.get<String>(this, 'masterCode') as String?;
  @override
  set masterCode(String? value) =>
      RealmObjectBase.set(this, 'masterCode', value);

  @override
  String? get materialDescription =>
      RealmObjectBase.get<String>(this, 'materialDescription') as String?;
  @override
  set materialDescription(String? value) =>
      RealmObjectBase.set(this, 'materialDescription', value);

  @override
  String? get materialLocalDescription =>
      RealmObjectBase.get<String>(this, 'materialLocalDescription') as String?;
  @override
  set materialLocalDescription(String? value) =>
      RealmObjectBase.set(this, 'materialLocalDescription', value);

  @override
  String? get materialLocalNumber =>
      RealmObjectBase.get<String>(this, 'materialLocalNumber') as String?;
  @override
  set materialLocalNumber(String? value) =>
      RealmObjectBase.set(this, 'materialLocalNumber', value);

  @override
  String? get materialNumber =>
      RealmObjectBase.get<String>(this, 'materialNumber') as String?;
  @override
  set materialNumber(String? value) =>
      RealmObjectBase.set(this, 'materialNumber', value);

  @override
  int? get pricingId => RealmObjectBase.get<int>(this, 'pricingId') as int?;
  @override
  set pricingId(int? value) => RealmObjectBase.set(this, 'pricingId', value);

  @override
  String? get sHLReference =>
      RealmObjectBase.get<String>(this, 'sHLReference') as String?;
  @override
  set sHLReference(String? value) =>
      RealmObjectBase.set(this, 'sHLReference', value);

  @override
  String? get subSegment =>
      RealmObjectBase.get<String>(this, 'subSegment') as String?;
  @override
  set subSegment(String? value) =>
      RealmObjectBase.set(this, 'subSegment', value);

  @override
  String? get uOM => RealmObjectBase.get<String>(this, 'uOM') as String?;
  @override
  set uOM(String? value) => RealmObjectBase.set(this, 'uOM', value);

  @override
  String? get uOMLocal =>
      RealmObjectBase.get<String>(this, 'uOMLocal') as String?;
  @override
  set uOMLocal(String? value) => RealmObjectBase.set(this, 'uOMLocal', value);

  @override
  Stream<RealmObjectChanges<PriceBookLinesHighLevelItems>> get changes =>
      RealmObjectBase.getChanges<PriceBookLinesHighLevelItems>(this);

  @override
  PriceBookLinesHighLevelItems freeze() =>
      RealmObjectBase.freezeObject<PriceBookLinesHighLevelItems>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(PriceBookLinesHighLevelItems._);
    return const SchemaObject(ObjectType.embeddedObject,
        PriceBookLinesHighLevelItems, 'PriceBook_lines_highLevelItems', [
      SchemaProperty('masterCode', RealmPropertyType.string, optional: true),
      SchemaProperty('materialDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('materialLocalDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('materialLocalNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('materialNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('pricingId', RealmPropertyType.int, optional: true),
      SchemaProperty('sHLReference', RealmPropertyType.string, optional: true),
      SchemaProperty('subSegment', RealmPropertyType.string, optional: true),
      SchemaProperty('uOM', RealmPropertyType.string, optional: true),
      SchemaProperty('uOMLocal', RealmPropertyType.string, optional: true),
    ]);
  }
}

class PriceBookLinesLowLevelItems extends _PriceBookLinesLowLevelItems
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  PriceBookLinesLowLevelItems({
    String? currency,
    String? hLReference,
    bool? isActive,
    String? lastModifiedBy,
    DateTime? lastModifiedDate,
    String? masterCode,
    String? materialDescription,
    String? materialLocalDescription,
    String? materialLocalNumber,
    String? materialNumber,
    int? pricingId,
    String? sHLReference,
    String? subSegment,
    String? uOM,
    String? uOMLocal,
    double? unitPrice,
    double? unitPriceSecondary,
  }) {
    RealmObjectBase.set(this, 'currency', currency);
    RealmObjectBase.set(this, 'hLReference', hLReference);
    RealmObjectBase.set(this, 'isActive', isActive);
    RealmObjectBase.set(this, 'lastModifiedBy', lastModifiedBy);
    RealmObjectBase.set(this, 'lastModifiedDate', lastModifiedDate);
    RealmObjectBase.set(this, 'masterCode', masterCode);
    RealmObjectBase.set(this, 'materialDescription', materialDescription);
    RealmObjectBase.set(
        this, 'materialLocalDescription', materialLocalDescription);
    RealmObjectBase.set(this, 'materialLocalNumber', materialLocalNumber);
    RealmObjectBase.set(this, 'materialNumber', materialNumber);
    RealmObjectBase.set(this, 'pricingId', pricingId);
    RealmObjectBase.set(this, 'sHLReference', sHLReference);
    RealmObjectBase.set(this, 'subSegment', subSegment);
    RealmObjectBase.set(this, 'uOM', uOM);
    RealmObjectBase.set(this, 'uOMLocal', uOMLocal);
    RealmObjectBase.set(this, 'unitPrice', unitPrice);
    RealmObjectBase.set(this, 'unitPriceSecondary', unitPriceSecondary);
  }

  PriceBookLinesLowLevelItems._();

  @override
  String? get currency =>
      RealmObjectBase.get<String>(this, 'currency') as String?;
  @override
  set currency(String? value) => RealmObjectBase.set(this, 'currency', value);

  @override
  String? get hLReference =>
      RealmObjectBase.get<String>(this, 'hLReference') as String?;
  @override
  set hLReference(String? value) =>
      RealmObjectBase.set(this, 'hLReference', value);

  @override
  bool? get isActive => RealmObjectBase.get<bool>(this, 'isActive') as bool?;
  @override
  set isActive(bool? value) => RealmObjectBase.set(this, 'isActive', value);

  @override
  String? get lastModifiedBy =>
      RealmObjectBase.get<String>(this, 'lastModifiedBy') as String?;
  @override
  set lastModifiedBy(String? value) =>
      RealmObjectBase.set(this, 'lastModifiedBy', value);

  @override
  DateTime? get lastModifiedDate =>
      RealmObjectBase.get<DateTime>(this, 'lastModifiedDate') as DateTime?;
  @override
  set lastModifiedDate(DateTime? value) =>
      RealmObjectBase.set(this, 'lastModifiedDate', value);

  @override
  String? get masterCode =>
      RealmObjectBase.get<String>(this, 'masterCode') as String?;
  @override
  set masterCode(String? value) =>
      RealmObjectBase.set(this, 'masterCode', value);

  @override
  String? get materialDescription =>
      RealmObjectBase.get<String>(this, 'materialDescription') as String?;
  @override
  set materialDescription(String? value) =>
      RealmObjectBase.set(this, 'materialDescription', value);

  @override
  String? get materialLocalDescription =>
      RealmObjectBase.get<String>(this, 'materialLocalDescription') as String?;
  @override
  set materialLocalDescription(String? value) =>
      RealmObjectBase.set(this, 'materialLocalDescription', value);

  @override
  String? get materialLocalNumber =>
      RealmObjectBase.get<String>(this, 'materialLocalNumber') as String?;
  @override
  set materialLocalNumber(String? value) =>
      RealmObjectBase.set(this, 'materialLocalNumber', value);

  @override
  String? get materialNumber =>
      RealmObjectBase.get<String>(this, 'materialNumber') as String?;
  @override
  set materialNumber(String? value) =>
      RealmObjectBase.set(this, 'materialNumber', value);

  @override
  int? get pricingId => RealmObjectBase.get<int>(this, 'pricingId') as int?;
  @override
  set pricingId(int? value) => RealmObjectBase.set(this, 'pricingId', value);

  @override
  String? get sHLReference =>
      RealmObjectBase.get<String>(this, 'sHLReference') as String?;
  @override
  set sHLReference(String? value) =>
      RealmObjectBase.set(this, 'sHLReference', value);

  @override
  String? get subSegment =>
      RealmObjectBase.get<String>(this, 'subSegment') as String?;
  @override
  set subSegment(String? value) =>
      RealmObjectBase.set(this, 'subSegment', value);

  @override
  String? get uOM => RealmObjectBase.get<String>(this, 'uOM') as String?;
  @override
  set uOM(String? value) => RealmObjectBase.set(this, 'uOM', value);

  @override
  String? get uOMLocal =>
      RealmObjectBase.get<String>(this, 'uOMLocal') as String?;
  @override
  set uOMLocal(String? value) => RealmObjectBase.set(this, 'uOMLocal', value);

  @override
  double? get unitPrice =>
      RealmObjectBase.get<double>(this, 'unitPrice') as double?;
  @override
  set unitPrice(double? value) => RealmObjectBase.set(this, 'unitPrice', value);

  @override
  double? get unitPriceSecondary =>
      RealmObjectBase.get<double>(this, 'unitPriceSecondary') as double?;
  @override
  set unitPriceSecondary(double? value) =>
      RealmObjectBase.set(this, 'unitPriceSecondary', value);

  @override
  Stream<RealmObjectChanges<PriceBookLinesLowLevelItems>> get changes =>
      RealmObjectBase.getChanges<PriceBookLinesLowLevelItems>(this);

  @override
  PriceBookLinesLowLevelItems freeze() =>
      RealmObjectBase.freezeObject<PriceBookLinesLowLevelItems>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(PriceBookLinesLowLevelItems._);
    return const SchemaObject(ObjectType.embeddedObject,
        PriceBookLinesLowLevelItems, 'PriceBook_lines_lowLevelItems', [
      SchemaProperty('currency', RealmPropertyType.string, optional: true),
      SchemaProperty('hLReference', RealmPropertyType.string, optional: true),
      SchemaProperty('isActive', RealmPropertyType.bool, optional: true),
      SchemaProperty('lastModifiedBy', RealmPropertyType.string,
          optional: true),
      SchemaProperty('lastModifiedDate', RealmPropertyType.timestamp,
          optional: true),
      SchemaProperty('masterCode', RealmPropertyType.string, optional: true),
      SchemaProperty('materialDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('materialLocalDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('materialLocalNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('materialNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('pricingId', RealmPropertyType.int, optional: true),
      SchemaProperty('sHLReference', RealmPropertyType.string, optional: true),
      SchemaProperty('subSegment', RealmPropertyType.string, optional: true),
      SchemaProperty('uOM', RealmPropertyType.string, optional: true),
      SchemaProperty('uOMLocal', RealmPropertyType.string, optional: true),
      SchemaProperty('unitPrice', RealmPropertyType.double, optional: true),
      SchemaProperty('unitPriceSecondary', RealmPropertyType.double,
          optional: true),
    ]);
  }
}

class PriceBookLinesSuperHighLevelItems
    extends _PriceBookLinesSuperHighLevelItems
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  PriceBookLinesSuperHighLevelItems({
    String? masterCode,
    String? materialDescription,
    String? materialLocalDescription,
    String? materialLocalNumber,
    String? materialNumber,
    int? pricingId,
    String? subSegment,
    String? uOM,
    String? uOMLocal,
  }) {
    RealmObjectBase.set(this, 'masterCode', masterCode);
    RealmObjectBase.set(this, 'materialDescription', materialDescription);
    RealmObjectBase.set(
        this, 'materialLocalDescription', materialLocalDescription);
    RealmObjectBase.set(this, 'materialLocalNumber', materialLocalNumber);
    RealmObjectBase.set(this, 'materialNumber', materialNumber);
    RealmObjectBase.set(this, 'pricingId', pricingId);
    RealmObjectBase.set(this, 'subSegment', subSegment);
    RealmObjectBase.set(this, 'uOM', uOM);
    RealmObjectBase.set(this, 'uOMLocal', uOMLocal);
  }

  PriceBookLinesSuperHighLevelItems._();

  @override
  String? get masterCode =>
      RealmObjectBase.get<String>(this, 'masterCode') as String?;
  @override
  set masterCode(String? value) =>
      RealmObjectBase.set(this, 'masterCode', value);

  @override
  String? get materialDescription =>
      RealmObjectBase.get<String>(this, 'materialDescription') as String?;
  @override
  set materialDescription(String? value) =>
      RealmObjectBase.set(this, 'materialDescription', value);

  @override
  String? get materialLocalDescription =>
      RealmObjectBase.get<String>(this, 'materialLocalDescription') as String?;
  @override
  set materialLocalDescription(String? value) =>
      RealmObjectBase.set(this, 'materialLocalDescription', value);

  @override
  String? get materialLocalNumber =>
      RealmObjectBase.get<String>(this, 'materialLocalNumber') as String?;
  @override
  set materialLocalNumber(String? value) =>
      RealmObjectBase.set(this, 'materialLocalNumber', value);

  @override
  String? get materialNumber =>
      RealmObjectBase.get<String>(this, 'materialNumber') as String?;
  @override
  set materialNumber(String? value) =>
      RealmObjectBase.set(this, 'materialNumber', value);

  @override
  int? get pricingId => RealmObjectBase.get<int>(this, 'pricingId') as int?;
  @override
  set pricingId(int? value) => RealmObjectBase.set(this, 'pricingId', value);

  @override
  String? get subSegment =>
      RealmObjectBase.get<String>(this, 'subSegment') as String?;
  @override
  set subSegment(String? value) =>
      RealmObjectBase.set(this, 'subSegment', value);

  @override
  String? get uOM => RealmObjectBase.get<String>(this, 'uOM') as String?;
  @override
  set uOM(String? value) => RealmObjectBase.set(this, 'uOM', value);

  @override
  String? get uOMLocal =>
      RealmObjectBase.get<String>(this, 'uOMLocal') as String?;
  @override
  set uOMLocal(String? value) => RealmObjectBase.set(this, 'uOMLocal', value);

  @override
  Stream<RealmObjectChanges<PriceBookLinesSuperHighLevelItems>> get changes =>
      RealmObjectBase.getChanges<PriceBookLinesSuperHighLevelItems>(this);

  @override
  PriceBookLinesSuperHighLevelItems freeze() =>
      RealmObjectBase.freezeObject<PriceBookLinesSuperHighLevelItems>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(PriceBookLinesSuperHighLevelItems._);
    return const SchemaObject(
        ObjectType.embeddedObject,
        PriceBookLinesSuperHighLevelItems,
        'PriceBook_lines_superHighLevelItems', [
      SchemaProperty('masterCode', RealmPropertyType.string, optional: true),
      SchemaProperty('materialDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('materialLocalDescription', RealmPropertyType.string,
          optional: true),
      SchemaProperty('materialLocalNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('materialNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('pricingId', RealmPropertyType.int, optional: true),
      SchemaProperty('subSegment', RealmPropertyType.string, optional: true),
      SchemaProperty('uOM', RealmPropertyType.string, optional: true),
      SchemaProperty('uOMLocal', RealmPropertyType.string, optional: true),
    ]);
  }
}
