import 'package:realm/realm.dart';
part 'pricebook_schema.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.

@RealmModel()
class _PriceBook {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;

  String? comments;

  String? contractNumber;

  String? country;

  String? createdBy;

  DateTime? createdDate;

  String? currency;

  String? customerName;

  String? geoMarket;

  bool? isActive;

  late List<_PriceBookLines> lines;

  String? modifiedBy;

  DateTime? modifiedDate;

  String? priceBookDescription;

  String? priceBookId;

  String? priceBookName;

  String? roundingRule;

  String? segment;

  String? sourceSystem;

  String? subSegment;

  String? subSegmentDescription;

  DateTime? validFrom;

  DateTime? validTo;
}

@RealmModel(ObjectType.embeddedObject)
@MapTo('PriceBook_lines')
class _PriceBookLines {
  late List<_PriceBookLinesFlatLevelItems> flatLevelItems;
  late List<_PriceBookLinesHighLevelItems> highLevelItems;
  late List<_PriceBookLinesLowLevelItems> lowLevelItems;
  late List<_PriceBookLinesSuperHighLevelItems> superHighLevelItems;
  int? type;
  String? typeDescription;
}

@RealmModel(ObjectType.embeddedObject)
@MapTo('PriceBook_lines_flatLevelItems')
class _PriceBookLinesFlatLevelItems {
  String? currency;
  bool? isActive;
  String? lastModifiedBy;
  DateTime? lastModifiedDate;
  String? materialDescription;
  String? materialLocalDescription;
  String? materialLocalNumber;
  String? materialNumber;
  int? pricingId;
  String? sHLReference;
  String? uOM;
  String? uOMLocal;
  double? unitPrice;
  double? unitPriceSecondary;
}

@RealmModel(ObjectType.embeddedObject)
@MapTo('PriceBook_lines_highLevelItems')
class _PriceBookLinesHighLevelItems {
  String? masterCode;
  String? materialDescription;
  String? materialLocalDescription;
  String? materialLocalNumber;
  String? materialNumber;
  int? pricingId;
  String? sHLReference;
  String? subSegment;
  String? uOM;
  String? uOMLocal;
}

@RealmModel(ObjectType.embeddedObject)
@MapTo('PriceBook_lines_lowLevelItems')
class _PriceBookLinesLowLevelItems {
  String? currency;
  String? hLReference;
  bool? isActive;
  String? lastModifiedBy;
  DateTime? lastModifiedDate;
  String? masterCode;
  String? materialDescription;
  String? materialLocalDescription;
  String? materialLocalNumber;
  String? materialNumber;
  int? pricingId;
  String? sHLReference;
  String? subSegment;
  String? uOM;
  String? uOMLocal;
  double? unitPrice;
  double? unitPriceSecondary;
}

@RealmModel(ObjectType.embeddedObject)
@MapTo('PriceBook_lines_superHighLevelItems')
class _PriceBookLinesSuperHighLevelItems {
  String? masterCode;
  String? materialDescription;
  String? materialLocalDescription;
  String? materialLocalNumber;
  String? materialNumber;
  int? pricingId;
  String? subSegment;
  String? uOM;
  String? uOMLocal;
}
