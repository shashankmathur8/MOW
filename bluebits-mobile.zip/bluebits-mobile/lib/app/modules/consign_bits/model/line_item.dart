import 'package:slb_gt_mobile/app/modules/consign_bits/model/line_item.dart';
class LineItem {
  final String description;
  final String material;
  final String uom;
  final String code;
  final String revenueAccount;
  final String unitPrice;
  final String currency;
  final String hLReference;
  final String sHLReference;

  LineItem({
    this.description = "",
    this.material = "",
    this.uom = "",
    this.code = "",
    this.revenueAccount = "",
    this.unitPrice = "",
    this.currency = "",
    this.hLReference = "",
    this.sHLReference = "",
  });
}
