class StepItem {
  final String title;
  final String description;
  late bool isLastStep;//show as disable
  late bool isSignedOrUploaded;//show as disable
  late bool isCurrentIndex;//show number with fill color
  late bool isCompleted;//show blue tick/ show grey color
  late bool isInValid;


  StepItem({
    this.title = "",
    this.description = "",
    this.isLastStep = false,
    this.isCurrentIndex = false,
    this.isCompleted = false,
    this.isSignedOrUploaded = false,
    this.isInValid = false,
  });

  @override
  String toString() {
    return 'StepItem{title: $title, description: $description, isCurrentIndex: $isCurrentIndex, isCompleted: $isCompleted, isLastStep: $isLastStep, isSignedOrUploaded: $isSignedOrUploaded}';
  }
}
