import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/base/base_view.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/model/consignment_model.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/widget/confirmation_screen.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/widget/enter_details.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/widget/quote_screen.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/widget/select_price_book.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/widget/step_widget.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';

import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../../shared/pending_consignments_overlay.dart';
import '../controller/consign_controller.dart';

class ConsignBits extends BaseView {
  @override
  final ConsignController controller =
      Get.put(ConsignController(), tag: (ConsignController).toString());

  ConsignBits(
      {Key? key, required List<Bit> selectedBits, required bool isDraftEdit})
      : super(key: key) {
    if (isDraftEdit) {
      controller.setupSelectedBitsDrafts(controller.consignmentModel.bits!);
      controller.isDraftEdit = isDraftEdit;
      controller.createQuoteID();
    } else {
      controller.consignmentModel = ConsignmentModel();
      controller.createConsignmentID();
      controller.createQuoteID();
      controller.selectedValueCustomer = "";
      controller.selectedValueRig = "";
      controller.setupSelectedBits(selectedBits);
    }
    controller.updateStepItemStatus(currentIndex: 0);
  }

  @override
  final bool isResizeToAvoidBottomInset = true;

  @override
  PreferredSizeWidget? appBar(BuildContext context) {
    // TODO: implement appBar
    return AppBar(
      automaticallyImplyLeading: false,
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              AppColors.topColorPrimaryDark,
              AppColors.bottomColorPrimaryDark
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
      ),
      centerTitle: false,
      titleSpacing: SizeConstants.dp0,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          IconButton(
              icon: Image.asset(AppImages.navBack, color: AppColors.colorWhite),
              onPressed: () {
                if (controller.isConfirmationScreen ||
                    (controller.rig == null &&
                        controller.customer == null &&
                        controller.consignmentModel.customerEmail == null)) {
                  Get.delete<ConsignController>(
                      tag: (ConsignController).toString(), force: true);
                  Get.back();
                } else {
                  Navigator.of(context).push(PendingConsignmentsOverlay());
                }
              }),
          Text(
            AppStrings.consignBits,
            style: tSw700fontF.copyWith(
                fontSize: SizeConstants.dp15,
                color: AppColors.colorWhite,
                fontStyle: FontStyle.normal),
          ),
        ],
      ),
    );
  }

  @override
  Widget body(BuildContext context) {
    return SafeArea(
      child: Row(children: [
        SizedBox(
          width: getScreenWidth() / 5,
          child: StepWidget(consignController: controller),
        ),
        Obx(
          () => Flexible(
            child: IndexedStack(index: controller.index.value, children: [
              EnterDetails(consignController: controller),
              SelectPriceBook(consignController: controller),
              QuoteScreen(
                consignController: controller,
              ),
              ConfirmationScreen(consignController: controller)
            ]),
          ),
        ),
      ]),
    );
  }
}
