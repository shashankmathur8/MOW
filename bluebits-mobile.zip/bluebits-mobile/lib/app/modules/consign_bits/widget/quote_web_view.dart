import 'package:intl/intl.dart';

class QuoteHtml {
  late DateTime now;
  late var effectiveDate;
  late String formattedDateNow;
  late String effectiveDate3Months;

  QuoteHtml() {
    now = DateTime.now();
    effectiveDate = now.add(const Duration(days: 30));
    formattedDateNow = DateFormat('dd-MM-yy').format(now.toLocal());
    effectiveDate3Months =
        DateFormat('dd-MM-yy').format(effectiveDate.toLocal());
  }

  createLineItemList(consignController) {
    consignController.returnAllLineItems();
  }

  String quoteHtml(String dateStr, consignController) {
    return """<!DOCTYPE html>
<html>

<head>
    <style>
        .divQte {
            page-break-inside: avoid;
        }

        .signHere {
            border-bottom: 1px black solid;
            margin-bottom: 15px;
            width: 70%;
        }

        .spacer {
            height: 30px;
        }

        .details {
            border-collapse: collapse;
        }

        .statutory {
            font-size: 12px;
            border: 1px solid black;
            text-align: center;
            margin: 0 20% 0;
        }

        .footerTable {
            font-size: 12px;
            border: 1px solid black;
            padding: 1%;
        }

        td {
            font-size: 12px;
            vertical-align: text-top;
        }

        .details td {
            border: 1px solid black;
            width: 33%;
        }

        .row {
            vertical-align: top;
            padding-left: 5px;
        }

        .row li {
            vertical-align: text-top;
            display: inline-block;
            width: 49%;
            margin-bottom: 15px;
            word-break: break-word;
        }

        .details .row li:nth-child(odd) {
            font-weight: 600;
        }

        .tblQte {
            table-layout: fixed;
            border-collapse: collapse;
            border-bottom: 2px solid;
        }

        .tblQte td {
            padding-bottom: 10px;
        }

        .tblQte .subtitle {
            font-size: 10px;
            display: block;
        }

        .tblQte tr:nth-child(1) {
            background-color: lightgrey;
        }

        .tblQte th {
            text-align: left;
            background-color: lightgrey;
        }

        .tblQte .shl {
            font-weight: 600;
        }

        .totalAmt {
            margin-top: 5px;
            display: block;
            text-align: right;
        }

        .container {
            max-width: 1180px;
            margin: 0 auto;
            background-color: white !important;
            padding-left: 3%;
            padding-right: 3%;
        }

        .headerInfo {
            display: inline-block;
            width: 100%;
        }

        .qtNum {
            width: 80%;
            display: inline-block;
            text-align: center;
        }

        .logoContainer {
            float: right;
            display: inline-block;
        }

        .logo {
            color: rgb(0 20 220);
            width: 100px;
        }
    </style>
    <title>Quote</title>
</head>

<body>
    <div class="container">
        <div class="spacer"></div>
        <div class="headerInfo">
            <div class="qtNum">
                <h3>GT Quote Number : ${consignController.consignmentModel.quoteID} <span id="gtQuote"></span> </h3>
            </div>
            <div class="logoContainer">
                <div class="logo">
                    <svg-icon>
                        <svg viewBox="0 0 72 44" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-iconXLarge w-iconXLarge" aria-hidden="true">
                            <path d="M33.9836 33.7334C20.2044 22.4966 14.456 8.06677 0 8.06677V33.7334H33.9836Z"
                                fill="CurrentColor"></path>
                            <path
                                d="M63.2895 7.68166C60.4758 7.68166 57.9602 8.92832 56.5015 10.7587V0H53.0995V25.6666H55.9003L56.2595 22.9687C57.2474 24.3158 59.2597 26.0516 63.1261 26.0516C68.3201 26.0516 72 22.2698 72 16.9092C72 11.5485 68.4692 7.68166 63.2903 7.68166H63.2895ZM62.3579 22.8367C58.611 22.8367 56.374 20.5648 56.374 16.8718C56.374 13.1787 58.6657 10.9069 62.3579 10.9069C66.05 10.9069 68.3417 13.1787 68.3417 16.8718C68.3417 20.5648 66.05 22.8367 62.3579 22.8367Z"
                                fill="CurrentColor"></path>
                            <path d="M50.5795 0H47.1775V25.6666H50.5795V0Z" fill="CurrentColor"></path>
                            <path
                                d="M37.5613 23.0596C35.0802 23.0596 32.4752 21.8269 31.0763 20.0552L28.7817 22.2794C31.0194 24.8622 33.9462 26.0516 37.4144 26.0516C42.1743 26.0516 45.1615 23.892 45.1615 20.2502C45.1615 12.68 32.2499 17.4144 32.2499 13.1479C32.2499 11.5866 34.0376 10.7022 36.8218 10.7022C39.3029 10.7022 41.0943 11.5214 42.2081 12.6925L44.5027 10.4683C42.9835 8.80364 40.123 7.68164 36.9075 7.68164C32.0972 7.68164 28.9329 9.99971 28.9329 13.6678C28.9329 21.0298 41.7934 16.3474 41.7934 20.6396C41.7934 22.1488 40.1172 23.0589 37.5605 23.0589L37.5613 23.0596Z"
                                fill="CurrentColor"></path>
                            <path d="M71.6213 31.1666H34.8477C42.4385 37.4755 54.0938 43.9999 71.6213 43.9999V31.1666Z"
                                fill="CurrentColor"></path>
                        </svg>
                    </svg-icon>
                </div>
            </div>
        </div>
        <table class="details">
            <tr>
                <td>

                    <ul class="row">
                        <li>Customer </li>
                        <li id="custaddress">
                            ${consignController.consignmentModel.customer?.name}
                        </li>
                        <li>Comm Agmnt # </li>
                        <li id="custaddress">
                            Comm Agmnt Name
                        </li>
                        <li>
                            PB ID
                        </li>
                        <li id="custaddress">
                            ${consignController.pbID}
                        </li>
                        <li>
                            PB Name
                        </li>
                        <li id="custaddress">
                            RPE_SEGREF_2020_USD _PerfTest
                        </li>
                        <li>Client Contract # </li>
                        <li id="custaddress">
                            aa
                        </li>
                        <li>PO </li>
                        <li id="custaddress">${consignController.consignmentModel.customer?.postalCode}</li>
                        <li>AFE </li>
                        <li id="custaddress">
                            aa
                        </li>
                        <li>Customer Rep </li>
                        <li id="custaddress"> </li>
                    </ul>
                </td>
                <td>
                    <ul class="row">
                        <li>Project # </li>
                        <li id="custaddress">
                            P.4034998
                        </li>
                        <li>Quote Effective Date </li>
                        <li id="custaddress">
                            ${formattedDateNow}
                        </li>
                        <li>Quote Expiration Date </li>
                        <li id="custaddress">
                            ${effectiveDate3Months}
                        </li>
                        <li>SLB Location </li>
                        <li id="custaddress">
                            Congo WL
                        </li>
                        <li>
                            SLB Plant
                        </li>
                        <li id="custaddress">
                            -
                        </li>
                        <li>SLB Rep </li>
                        <li id="custaddress">
                            ${consignController.loginController.userName}
                        </li>
                        <li>External Ref </li>
                        <li id="custaddress">
                            -
                        </li>
                    </ul>
                </td>
                <td>
                    <ul class="row">
                        <li>Field/Block </li>
                        <li id="custaddress">
                            ${consignController.consignmentModel.customer?.city == null ? "-" : consignController.consignmentModel.customer?.city}
                        </li>
                        <li>County/Parish </li>
                        <li id="custaddress">
                            ${consignController.consignmentModel.customer?.county == null ? "-" : consignController.consignmentModel.customer?.county}
                        </li>
                        <li>State/Province </li>
                        <li id="custaddress">
                            ${consignController.consignmentModel.customer?.state == null ? "-" : consignController.consignmentModel.customer?.state}
                        </li>
                        <li>Country </li>
                        <li id="custaddress">
                            ${consignController.consignmentModel.customer?.country == null ? "-" : consignController.consignmentModel.customer?.country}
                        </li>
                        <li>UWI/API</li>
                        <li id="custaddress"> </li>
                        <li>Rig </li>
                        <li id="custaddress">${consignController.consignmentModel.rig?.name}</li>
                    </ul>
                </td>
            </tr>
        </table>
        <div class="spacer"></div>
        ${consignController.getLineItemsBuffer()}
        <div class="footerTable divQte">
            <p><strong>THE ESTIMATED CHARGES SHOWN ABOVE MAY BE EXCLUSIVE OF TAX AND THE FINAL INVOICE WILL INCLUDE ALL
                    APPLICABLE TAXES.</strong></p>

            <p>
                <strong>
                    THIS QUOTATION IS VALID FROM ${formattedDateNow} TO ${effectiveDate3Months}, UNLESS OTHERWISE SPECIFIED BY SCHLUMBERGER,
                    AND WILL BE
                    PERFORMED IN ACCORDANCE WITH THE ATTACHED GENERAL TERMS AND CONDITIONS OR THE TERMS OF A MASTER
                    SERVICE
                    AGREEMENT IF ONE IS IN FORCE BETWEEN CUSTOMER AND SCHLUMBERGER. CUSTOMERS WRITTEN ACCEPTANCE OF THE
                    TERMS OF
                    THIS QUOTATION AND, IN THE ABSENCE OF A MASTER SERVICE AGREEMENT, THE ATTACHED GENERAL TERMS AND
                    CONDITIONS SHALL
                    TOGETHER FORM A BINDING CONTRACT BETWEEN THE PARTIES.
                </strong><br /> &nbsp;
            </p>

            <div>
                <ul class="row">
                    <li>
                        <div>
                            Customer or Authorized Representative
                        </div>
                        <div class="spacer">
                            <div>
                                <img src="data:image/png;base64, ${consignController.getCustomerSignature() == ''?'R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==':consignController.getCustomerSignature()}" style="width:250px;height:50px" />
                            </div>
                        </div>
                        <div class="signHere">
                        </div>
                        <div id="name">
                            ${consignController.getCustomerName()}
                        </div>
                        <div>
                            Date : <span id="date">${formattedDateNow}</span>
                        </div>
                    </li>
                    <li>
                        <div>
                            ${consignController.loginController.userEmail}
                        </div>
                        <div class="spacer">
                            <div>
                                <img src="data:image/png;base64, ${consignController.getSignature()== ''?'R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==':consignController.getSignature()}" style="width:250px;height:50px" />
                            </div>
                        </div>
                        <div class="signHere">
                        </div>
                        <div id="name">
                            ${consignController.getUserName()}
                        </div>
                        <div>
                            Date : <span id="date">${formattedDateNow}</span>
                        </div>
                    </li>
                </ul>
            </div>

        </div>
        <div class="spacer"></div>
        <div class="statutory">
            This document is Confidential and intended for authorized users only
        </div>
        <div class="spacer"></div>
    </div>

</body>
</html> """;
  }
}
