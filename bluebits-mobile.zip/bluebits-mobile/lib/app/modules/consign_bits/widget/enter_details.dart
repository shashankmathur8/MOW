import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/utils/logger_common.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';

import '../../../core/common_widgets/custom_button_material.dart';
import '../../../core/common_widgets/no_overscroll_behavior.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../../consigned_bits/controller/consigned_bits_controller.dart';
import '../../shared/generic_overlay.dart';
import '../../shared/smart_search_view.dart';
import '../controller/consign_controller.dart';

class EnterDetails extends StatefulWidget {
  final ConsignController consignController;

  EnterDetails({Key? key, required this.consignController}) : super(key: key);

  @override
  State<EnterDetails> createState() => _EnterDetailsState();
}

class _EnterDetailsState extends State<EnterDetails> {
  final GlobalKey<FormState> _formKey = GlobalKey();

  late FocusNode focusNodeEmail;
  final emailFormKey = GlobalKey<FormFieldState>();
  final emailController = TextEditingController();

  var outlineBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(AppValues.radius_4),
    borderSide: const BorderSide(
        width: SizeConstants.dp1, color: AppColors.colorSeparatorLine),
  );

  @override
  void initState() {
    super.initState();
    if (widget.consignController.consignmentModel.customerEmail != null) {
      emailController.text =
          (widget.consignController.consignmentModel.customerEmail).toString();

      updateFieldListener();
    }

    Future.delayed(const Duration(milliseconds: 500), () {
      widget.consignController.fetchData();
    });

    focusNodeEmail = FocusNode();

    focusNodeEmail.addListener(() {
      ApplicationLogger().printInfo(
          'Email focus:- ${focusNodeEmail.hasPrimaryFocus} - ${focusNodeEmail.hasFocus}',
          'EnterDetails.initState');
      if (!focusNodeEmail.hasFocus) {
        var isValidated = emailFormKey.currentState?.validate() == true &&
            emailController.text.isNotEmpty &&
            widget.consignController.rig != null &&
            widget.consignController.customer != null;
        widget.consignController.isEnterDetailNextEnable = isValidated;

        if (GetUtils.isEmail(emailController.text)) {
          widget.consignController.email = emailController.text;
        }
        widget.consignController.checkAndRemoveSignedQuoteDocument();
      }
    });
  }

  @override
  void dispose() {
    focusNodeEmail.dispose();
    super.dispose();
  }

  Future<bool> isDeviceOnline() async {
    return true;
  }

  void _saveForm() {
    if (GetUtils.isEmail(emailController.text) &&
        widget.consignController.rig != null &&
        widget.consignController.customer != null) {
      widget.consignController.email = emailController.text;
      widget.consignController.addGenericLineItem();
      int index = widget.consignController.index.value + 1;
      widget.consignController.updateStepItemStatus(currentIndex: index);
    } else {
      widget.consignController.isEnterDetailNextEnable = false;
    }
  }

  void updateFieldListener() {
    if (widget.consignController.rig == null ||
        widget.consignController.customer == null ||
        emailController.text.isBlank == true ||
        !GetUtils.isEmail(emailController.text)) {
      widget.consignController.isEnterDetailNextEnable = false;
    } else {
      widget.consignController.email = emailController.text;
      widget.consignController.isEnterDetailNextEnable = true;
    }
    widget.consignController.checkAndRemoveSignedQuoteDocument();
  }

  @override
  Widget build(BuildContext context) {
    var height = getScreenHeight();

    return Container(
      color: AppColors.colorBackgroundPanel,
      child: Form(
        key: _formKey,
        child: ScrollConfiguration(
          behavior: NoOverscrollBehavior(),
          child: ListView(
            children: [
              Container(
                  padding: EdgeInsets.only(
                      left: getWidth(AppValues.padding_40),
                      top: getHeight(AppValues.padding_34),
                      right: getWidth(AppValues.padding_34)),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      titleHeaderWidget,
                      SizedBox(
                        height: getHeight(SizeConstants.dp21),
                      ),
                      selectedBitsWidget(),
                      bitsListWidget(),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          rigSelectionWidget(),
                          SizedBox(
                            width: getWidth(SizeConstants.dp10),
                          ),
                          customerSelectionWidget(),
                          SizedBox(
                            width: getWidth(SizeConstants.dp10),
                          ),
                          emailWidget()
                        ],
                      ),
                    ],
                  )),
              Container(
                height: height -
                    getHeight(SizeConstants.dp163) -
                    getHeight(SizeConstants.dp250),
              ),
              dividerContainerWidget,
              nextButtonWidget()
            ],
          ),
        ),
      ),
    );
  }

  Widget _bitsSelectedItem(Bit bit, int index) {
    return Container(
      margin: const EdgeInsets.all(AppValues.margin_5),
      padding: const EdgeInsets.symmetric(
          vertical: AppValues.padding_10, horizontal: AppValues.padding_11),
      constraints: BoxConstraints(
        minWidth: getWidth(SizeConstants.dp110),
      ),
      height: getHeight(SizeConstants.dp30),
      decoration: BoxDecoration(
        color: AppColors.colorFilterTag,
        borderRadius: BorderRadius.circular(AppValues.radius_4),
        border: Border.all(
            width: SizeConstants.dp1, color: AppColors.colorFilterTagBorder),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            bit.serialNumber?.toUpperCase() ?? '',
            style: tSw400dp14fontF.copyWith(
              color: AppColors.colorMainText,
            ),
            maxLines: 1,
          ),
          InkWell(
            child: Image.asset(
              AppImages.cancelBlackPng,
              width: getWidth(SizeConstants.dp18),
              height: getHeight(SizeConstants.dp18),
            ),
            onTap: () {
              if (widget.consignController.selectedBits.length > 1) {
                widget.consignController.removeSelectedBit(index);
              } else {
                Navigator.of(context).push(GenericOverlay(
                    iconPath: AppImages.alertNoBitsConsign,
                    title: AppStrings.noBitsToConsign,
                    message: AppStrings.noBitsToConsignDes,
                    negativeButtonText: AppStrings.cancel,
                    positiveButtonText: AppStrings.confirm,
                    onPositivePressCallback: () async {
                      if (widget.consignController.draftConsignmentID != null &&
                          widget.consignController.draftConsignmentID!
                              .trim()
                              .isNotEmpty) {
                        await widget.consignController.realm
                            .deleteDraftFromConsignedBits(widget
                                .consignController
                                .consignmentModel
                                .consignmentID);
                        dismissPopup();
                        ApplicationLogger().printInfo(
                            "Draft Deleted ${widget.consignController.draftConsignmentID}",
                            "Remove Consign popup");
                      } else {
                        dismissPopup();
                      }
                    }));
                //Get.dialog(AlertRemoveConsignBitsOverlay());
              }
            },
          )
        ],
      ),
    );
  }

  void dismissPopup() {
    try {
      ConsignedBitController controller = Get.put(ConsignedBitController(),
          tag: (ConsignedBitController).toString());

      if (controller != null) {
        controller.fetchData();
      }
    } on Exception catch (exception) {
      ApplicationLogger().printError(exception.toString(), 'dismissPopup()');
    }
    Get.delete<ConsignController>(
        tag: (ConsignController).toString(), force: true);

    Get
      ..back()
      ..back();
  }

  Widget titleHeaderWidget = Text(
    AppStrings.enterDetails,
    style: tSw400dp14fontF.copyWith(
      fontSize: SizeConstants.dp24,
      color: AppColors.colorMainText,
    ),
  );

  Widget selectedBitsWidget() {
    return Obx(() => RichText(
          text: TextSpan(
            style: tSw400dp14fontF.copyWith(
              fontSize: SizeConstants.dp16,
              color: AppColors.colorBlack,
            ),
            children: <TextSpan>[
              const TextSpan(text: AppStrings.selectedBits),
              TextSpan(
                  text: '${widget.consignController.selectedBits.length}',
                  style: const TextStyle(color: AppColors.colorSubText)),
            ],
          ),
        ));
  }

  Widget bitsListWidget() {
    return Container(
      margin: const EdgeInsets.only(
          top: AppValues.margin_8, bottom: AppValues.margin_8),
      height: getHeight(SizeConstants.dp45),
      child: ScrollConfiguration(
          behavior: NoOverscrollBehavior(),
          child: Obx(
            () => ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: widget.consignController.selectedBits.length,
              itemBuilder: (ctx, index) {
                return Container(
                    child: _bitsSelectedItem(
                        widget.consignController.selectedBits[index].bit as Bit,
                        index));
              },
            ),
          )),
    );
  }

  Widget rigSelectionWidget() {
    return UserInputView(
        initValue: widget.consignController.selectedValueRig,
        strImage: AppImages.search,
        strHint: AppStrings.selectRig,
        strTitle: AppStrings.rigRequired,
        arrList: widget.consignController.rigs,
        widthInput: getWidth(SizeConstants.dp250),
        inputThreshold: 3,
        headerTextStyle:
            tSw400dp12fontF.copyWith(color: AppColors.colorMainText),
        hintTextStyle: tSw400dp14fontF.copyWith(
          color: AppColors.colorSubText.withOpacity(0.7),
        ),
        labelTextStyle: tSw400dp14fontF.copyWith(
          color: AppColors.colorMainText,
        ),
        smartSearchBoxDecoration: smartSearchDecoration,
        onClickAction: (value) =>
            {widget.consignController.rig = value, updateFieldListener()},
        onRemoveText: () =>
            {widget.consignController.rig = null, updateFieldListener()});
  }

  Widget customerSelectionWidget() {
    return UserInputView(
        initValue: widget.consignController.selectedValueCustomer,
        strImage: AppImages.search,
        strHint: AppStrings.selectCustomer,
        strTitle: AppStrings.customerRequired,
        arrList: widget.consignController.customers,
        widthInput: getWidth(SizeConstants.dp250),
        inputThreshold: 3,
        headerTextStyle:
            tSw400dp12fontF.copyWith(color: AppColors.colorMainText),
        hintTextStyle: tSw400dp14fontF.copyWith(
          color: AppColors.colorSubText.withOpacity(0.7),
        ),
        labelTextStyle: tSw400dp14fontF.copyWith(
          color: AppColors.colorMainText,
        ),
        smartSearchBoxDecoration: smartSearchDecoration,
        onClickAction: (value) =>
            {widget.consignController.customer = value, updateFieldListener()},
        onRemoveText: () =>
            {widget.consignController.customer = null, updateFieldListener()});
  }

  Widget emailWidget() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppStrings.customerEmailReq,
          style: tSw400dp12fontF.copyWith(
            color: AppColors.colorMainText,
          ),
        ),
        SizedBox(
          height: getHeight(SizeConstants.dp7),
        ),
        SizedBox(
          width: getWidth(SizeConstants.dp238),
          child: TextFormField(
            autofocus: false,
            style: tSw400dp14fontF.copyWith(
              color: AppColors.colorMainText,
            ),
            key: emailFormKey,
            focusNode: focusNodeEmail,
            controller: emailController,
            autocorrect: false,
            enableSuggestions: false,
            decoration: InputDecoration(
              hintText: AppStrings.hintEmail,
              hintStyle: tSw400dp14fontF.copyWith(
                color: AppColors.colorSubText.withOpacity(0.7),
              ),
              filled: true,
              fillColor: AppColors.colorGreyInputBox.withOpacity(0.8),
              enabledBorder: outlineBorder,
              focusedBorder: outlineBorder,
              border: outlineBorder,
              focusedErrorBorder: outlineBorder,
              errorBorder: outlineBorder.copyWith(
                borderSide: const BorderSide(color: AppColors.colorRedError),
              ),
              errorStyle: tSw400dp14fontF.copyWith(
                color: AppColors.colorRedError,
              ),
            ),
            maxLines: 1,
            keyboardType: TextInputType.emailAddress,
            textAlign: TextAlign.start,
            validator: (value) {
              if (value == null) return null;

              if (value.isEmpty || !GetUtils.isEmail(value)) {
                return AppStrings.errorEmail;
              } else {
                return null;
              }
            },
            onTapOutside: (event) {
              FocusManager.instance.primaryFocus?.unfocus();
            },
          ),
        ),
      ],
    );
  }

  Widget dividerContainerWidget = Container(
    color: AppColors.colorSeparatorLine,
    height: getHeight(SizeConstants.dp1),
    margin: const EdgeInsets.only(bottom: AppValues.margin_20),
  );

  Widget nextButtonWidget() {
    return Container(
      alignment: Alignment.bottomRight,
      padding: const EdgeInsets.only(
          bottom: AppValues.padding_20, right: AppValues.padding_20),
      child: Obx(
        () => CustomButtonMaterial(
          width: getWidth(SizeConstants.dp130),
          height: getHeight(SizeConstants.dp45),
          /*(_formKey.currentState?.validate() == null ||
                      _formKey.currentState?.validate() == false) ||
                  !isNextEnable*/
          backgroundColor: !widget.consignController.isEnterDetailNextEnable
              ? AppColors.colorPrimary.withOpacity(0.3)
              : AppColors.colorPrimary,
          foregroundColor: AppColors.colorWhite,
          borderRadius: AppValues.radius_4,
          text: AppStrings.next,
          style: tSw500dp16fontF.copyWith(
            color: !widget.consignController.isEnterDetailNextEnable
                ? AppColors.colorWhite.withOpacity(0.4)
                : AppColors.colorWhite,
          ),
          onPressCallback: () {
            _saveForm();
          },
        ),
      ),
    );
  }
}
