import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/common_widgets/toast_message.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_enum.dart';
import 'package:slb_gt_mobile/app/core/values/app_utils.dart';

import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/common_widget.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../../shared/dropdown_small.dart';
import '../../shared/generic_overlay.dart';
import '../controller/consign_controller.dart';
import '../model/consignment_model.dart';
import 'add_price_book_full.dart';
import 'add_price_book_selection.dart';

class PriceBookLineItem extends StatefulWidget {
  final ConsignController consignController;

  PriceBookLineItem({Key? key, required this.consignController})
      : super(key: key) {
    print('PriceBookLineItem render');
  }

  @override
  State<PriceBookLineItem> createState() => _PriceBookLineItemState();
}

class _PriceBookLineItemState extends State<PriceBookLineItem> {
  var outlineBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(AppValues.radius_4),
    borderSide: const BorderSide(
        width: SizeConstants.dp1, color: AppColors.colorSeparatorLine),
  );

  final widthInput = getWidth(SizeConstants.dp152);

  @override
  void initState() {
    super.initState();
  }

  Widget renderImage(String imgName, callback, double width, double height) {
    return InkWell(
        onTap: callback,
        child: Padding(
          padding: EdgeInsets.all(getWidth(SizeConstants.dp10)),
          child: Image.asset(imgName,
              height: getWidth(height), width: getWidth(width)),
        ));
  }

  Widget regularInputWidget(
      int index, LineItems line, String type, String title, String placeholder,
      {double? width}) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: tSw400dp12fontF.copyWith(
            color: AppColors.colorMainText,
          ),
        ),
        SizedBox(
          height: getHeight(SizeConstants.dp7),
        ),
        SizedBox(
          width: width,
          child: TextFormField(
            onChanged: (value) {
              widget.consignController
                  .updateConsignmentModel(value, type, index);
            },
            controller: widget.consignController
                .setLineItemValues(widget.consignController, type, index),
            inputFormatters: type == InputFieldType.comments.name
                ? [
                    filteringTextInputFormatter,
                  ]
                : [
                    filteringTextInputFormatter,
                    FilteringTextInputFormatter.allow(
                        RegExp(r'(^\d*[\.]?\d{0,6})'))
                  ],
            autofocus: false,
            style: tSw400dp14fontF.copyWith(
              color: AppColors.colorMainText,
            ),
            decoration: InputDecoration(
              hintText: placeholder,
              hintStyle: tSw400dp14fontF.copyWith(
                color: AppColors.colorSubText.withOpacity(0.7),
              ),
              filled: true,
              fillColor: AppColors.colorGreyInputBox.withOpacity(0.8),
              enabledBorder: outlineBorder,
              focusedBorder: outlineBorder,
              border: outlineBorder,
              focusedErrorBorder: outlineBorder,
              errorBorder: outlineBorder.copyWith(
                borderSide: const BorderSide(color: AppColors.colorRedError),
              ),
              errorStyle: tSw400dp14fontF.copyWith(
                color: AppColors.colorRedError,
              ),
            ),
            maxLines: 1,
            maxLength: type == InputFieldType.comments.name
                ? SizeConstants.maxLengthLimitText
                : null,
            keyboardType: type == InputFieldType.comments.name
                ? TextInputType.text
                : const TextInputType.numberWithOptions(
                    decimal: true, signed: false),
            textAlign: TextAlign.start,
          ),
        ),
      ],
    );
  }

  Widget conditionTypeWidget(LineItems line, int index) {
    return DropDownViewSmall(
      strImage: AppImages.down_arrow,
      strHint: AppStrings.selectConditionHint,
      arrList: AppStrings.conditionType,
      heightInput: getHeight(SizeConstants.dp26),
      widthInput: getWidth(SizeConstants.dp200),
      selectedValue: line.lineCondition ?? '',
      inputDecoration: smartSearchDecoration.copyWith(
        color: AppColors.colorWhite.withOpacity(0.8),
      ),
      overlayDecoration: overlayDecoration,
      onClickAction: (value) {
        widget.consignController.updateConsignmentModel(
            value, InputFieldType.lineCondition.name, index);
      },
    );
  }

  Widget separatorPipe() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: getWidth(AppValues.margin_20)),
      width: getWidth(SizeConstants.dp1),
      height: getHeight(SizeConstants.dp15),
      color: AppColors.colorSeparatorLine,
    );
  }

  Widget priceWidget(LineItems line) {
    return Container(
      width: getWidth(SizeConstants.dp75),
      margin: EdgeInsets.only(left: getWidth(SizeConstants.dp13)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Image.asset(
            AppImages.pricetag,
            height: getWidth(SizeConstants.dp35),
            width: getWidth(SizeConstants.dp35),
            fit: BoxFit.fill,
          ),
          Text(
            '${AppStrings.price}(${line.currency})',
            style: tSw400dp12fontF.copyWith(
              color: AppColors.colorMainText,
            ),
          ),
          Text(
            '${line.unitPrice}',
            style: tSw400dp18fontF.copyWith(
              color: AppColors.colorMainText,
            ),
            textAlign: TextAlign.right,
          )
        ],
      ),
    );
  }

  Widget dividerContainerWidget() {
    return Container(
      color: AppColors.colorSeparatorLine,
      height: getHeight(SizeConstants.dp75),
      width: getWidth(SizeConstants.dp0_5),
      margin: EdgeInsets.only(
          left: getWidth(SizeConstants.dp15),
          right: getWidth(SizeConstants.dp15)),
    );
  }

  Widget drilledCell(LineItems line, int index) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            regularInputWidget(
                index,
                line,
                InputFieldType.unitDrilled.name,
                '${widget.consignController.getUnit(line)} ${AppStrings.drilled}${AppStrings.required}',
                '${AppStrings.hintDrilled} ${widget.consignController.getUnit(line)}',
                width: widthInput),
            SizedBox(
              width: getWidth(SizeConstants.dp10),
            ),
            regularInputWidget(
                index,
                line,
                InputFieldType.pricePerUnit.name,
                '${AppStrings.priceper} ${widget.consignController.getUnit(line)}${AppStrings.required}',
                AppStrings.hintbestPrice,
                width: widthInput),
            SizedBox(
              width: getWidth(SizeConstants.dp10),
            ),
            regularInputWidget(
                index,
                line,
                InputFieldType.bestPrice.name,
                '${AppStrings.bestPrice}(${line.currency})${AppStrings.required}',
                AppStrings.hintbestPrice,
                width: widthInput),
          ],
        ),
        const SizedBox(
          height: SizeConstants.dp10,
        ),
        regularInputWidget(index, line, InputFieldType.comments.name,
            AppStrings.lineComments, AppStrings.hintlineComments,
            width: getWidth(SizeConstants.dp727))
      ],
    );
  }

  Widget dBRCell(LineItems line, int index) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        regularInputWidget(
            index,
            line,
            InputFieldType.bestPrice.name,
            '${AppStrings.bestPrice}(${line.currency})${AppStrings.required}',
            AppStrings.hintbestPrice,
            width: widthInput),
        SizedBox(
          width: getWidth(SizeConstants.dp10),
        ),
        Expanded(
          child: regularInputWidget(
            index,
            line,
            InputFieldType.comments.name,
            AppStrings.comments,
            AppStrings.hintlineComments,
          ),
        )
      ],
    );
  }

  Widget itemMenuOption(LineItems line, int index) {
    return Row(
      children: [
        renderImage(AppImages.clone, () async {
          await widget.consignController.cloneLineItem(line, index);
        }, SizeConstants.dp18, SizeConstants.dp18),
        SizedBox(
          width: getWidth(SizeConstants.dp15),
        ),
        renderImage(AppImages.edit, () async {
          if (line.priceBookId != null) {
            widget.consignController.editLineItemIndex = index;
            await widget.consignController
                .checkAndAssignPriceBook(line.priceBookId ?? '');
            openFullBottomSheet(true);
          }
        }, SizeConstants.dp18, SizeConstants.dp18),
        SizedBox(
          width: getWidth(SizeConstants.dp15),
        ),
        renderImage(AppImages.delete, () {
          List<LineItems>? lineItemsInCurrentBits =
              widget.consignController.currentLineItemsOfSelectedBit;
          if (lineItemsInCurrentBits != null &&
              lineItemsInCurrentBits.length != 1) {
            Navigator.of(context).push(GenericOverlay(
                title: AppStrings.deleteItem,
                message: AppStrings.deleteConfirmation,
                iconPath: AppImages.alertNoBitsConsign,
                negativeButtonText: AppStrings.cancel,
                positiveButtonText: AppStrings.confirm,
                onPositivePressCallback: () async {
                  await widget.consignController.removeLineItem(index);
                  Get.back();
                }));
          } else {
            showToastMsg(Get.context, 'You can\'t delete last line item',
                ToastStatus.failure);
          }
        }, SizeConstants.dp18, SizeConstants.dp18),
        SizedBox(
          width: getWidth(SizeConstants.dp15),
        ),
        renderImage(
            line.isExpanded == false
                ? AppImages.arrowRight
                : AppImages.down_arrow, () {
          widget.consignController.changeExpandModeOfLine(line, index);
        }, SizeConstants.dp18, SizeConstants.dp18),
      ],
    );
  }

  Widget cell(LineItems line, int index) {
    return Container(
      decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: AppColors.colorBlack.withOpacity(0.1),
              spreadRadius: AppValues.radius_1,
              blurRadius: AppValues.radius_1,
              offset: const Offset(0, 0.5), // changes position of shadow
            ),
          ],
          color: AppColors.colorWhite,
          borderRadius:
              const BorderRadius.all(Radius.circular(SizeConstants.dp5)),
          border: Border.all(
              color: widget.consignController.checkDuplicacy(index) == true
                  ? AppColors.colorRedError
                  : AppColors.colorWhite.withAlpha(0))),
      child: Padding(
        padding: const EdgeInsets.symmetric(
            horizontal: SizeConstants.dp18, vertical: SizeConstants.dp18),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                      '1.${index + 1} - ${line.priceBookId} - ${line.materialDescription ?? ''}',
                      style: tSw400dp18fontF.copyWith(
                        color: AppColors.colorMainText,
                      )),
                ),
                conditionTypeWidget(line, index),
                separatorPipe(),
                itemMenuOption(line, index),
                const SizedBox(
                  width: SizeConstants.dp10,
                )
              ],
            ),
            Visibility(
                visible: line.isExpanded ?? false,
                child: SizedBox(height: getHeight(SizeConstants.dp10))),
            Visibility(
              visible: line.isExpanded ?? false,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  priceWidget(line),
                  dividerContainerWidget(),
                  Expanded(
                      child:
                          widget.consignController.checkIfLineItemIsDBR(line) ==
                                  true
                              ? dBRCell(line, index)
                              : drilledCell(line, index))
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    int totalLineItems =
        widget.consignController.currentLineItemsOfSelectedBit?.length ?? 0;
    return ListView.separated(
        separatorBuilder: (context, index) =>
            SizedBox(height: getHeight(SizeConstants.dp12)),
        itemCount: totalLineItems + 1,
        itemBuilder: (ctx, index) {
          //Adding last item '+ Add Line Item'
          if (index == totalLineItems) {
            return InkWell(
              onTap: () async {
                LineItems zeroPositionLineItems =
                    widget.consignController.getLineItemFromIndex(0);
                if (zeroPositionLineItems.priceBookId != null) {
                  await widget.consignController.checkAndAssignPriceBook(
                      zeroPositionLineItems.priceBookId ?? '');
                  openFullBottomSheet(false);
                }
              },
              child: Row(
                children: [
                  Image.asset(
                    AppImages.icAddColored,
                    color: AppColors.colorMainText,
                    width: getWidth(SizeConstants.dp20),
                    height: getWidth(SizeConstants.dp20),
                  ),
                  Text(AppStrings.addLineItem,
                      style: tSw500dp15fontF.copyWith(
                        fontSize: SizeConstants.dp14,
                        color: AppColors.colorMainText,
                      )),
                ],
              ),
            );
          }
          LineItems currentLine = widget.consignController
              .getLineItemFromIndex(index < totalLineItems ? index : 0);

          //Return actual line item for bits
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              cell(currentLine, index),
              Visibility(
                visible: widget.consignController.checkDuplicacy(index) == true
                    ? true
                    : false,
                child: SizedBox(
                  height: getHeight(SizeConstants.dp5),
                ),
              ),
              Visibility(
                visible: widget.consignController.checkDuplicacy(index) == true
                    ? true
                    : false,
                child: Text(AppStrings.editValue,
                    style: tSw400dp14fontF.copyWith(
                      color: AppColors.colorRedError,
                    )),
              ),
            ],
          );
        });
  }

  void openPriceBookSelectionSheet() {
    widget.consignController.selectedPriceBook = null;
    Get.bottomSheet(
      AddPriceBookSelection(),
      isDismissible: false,
      enableDrag: false,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(AppValues.radius_10),
        ),
      ),
      clipBehavior: Clip.antiAliasWithSaveLayer,
    );
  }

  void openFullBottomSheet(bool isEditMode) {
    Get.bottomSheet(
      AddPriceBookFull(
        isEditMode: isEditMode,
      ),
      isDismissible: false,
      enableDrag: false,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(AppValues.radius_10),
        ),
      ),
      clipBehavior: Clip.antiAliasWithSaveLayer,
    );
  }
}
