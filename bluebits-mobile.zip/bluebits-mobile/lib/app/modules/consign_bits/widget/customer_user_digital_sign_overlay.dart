import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:signature/signature.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';

import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/common_widget.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../controller/consign_controller.dart';

class CustomerUserDigitalSignOverlay extends StatelessWidget {
  final ConsignController consignController;

  CustomerUserDigitalSignOverlay({Key? key, required this.consignController})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: AppColors.transparentColor,
        resizeToAvoidBottomInset: false,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              fit: StackFit.loose,
              children: [
                Container(
                  height: getHeight(SizeConstants.dp40),
                  alignment: Alignment.centerLeft,
                  child: Container(
                    margin:
                        EdgeInsets.only(left: getHeight(AppValues.margin_89)),
                    child: TabBar(
                      labelColor: AppColors.colorPrimaryDarkStep,
                      unselectedLabelColor: AppColors.colorSubText,
                      indicatorColor: AppColors.colorPrimaryDarkStep,
                      indicatorPadding: EdgeInsets.zero,
                      // indicatorSize: TabBarIndicatorSize.label,
                      isScrollable: true,
                      padding: EdgeInsets.zero,
                      labelPadding: const EdgeInsets.only(
                          right: SizeConstants.dp20, left: SizeConstants.dp20),
                      indicatorWeight: 2,

                      onTap: (value) {
                        if (value == 0) {
                          consignController.isUserSignTap.value = false;
                          consignController.showTabGreenTick(0);
                          consignController.setCustomerNameAndSignNew(
                              consignController.customerSignatureController);
                        } else {
                          consignController.isUserSignTap.value = true;
                          consignController.showTabGreenTick(1);
                          consignController.setUserNameAndSignNew(
                              consignController.userSignatureController);
                        }
                      },
                      tabs: [
                        Tab(
                          child: Wrap(
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              Obx(
                                () => Visibility(
                                  visible: consignController
                                              .isCustomerStartDraw.value &&
                                          consignController.enterCustomerName
                                              .value.isNotEmpty
                                      ? true
                                      : false,
                                  child: Image.asset(AppImages.success,
                                      width: getHeight(SizeConstants.dp12),
                                      height: getHeight(SizeConstants.dp12)),
                                ),
                              ),
                              SizedBox(
                                width: getWidth(SizeConstants.dp5),
                              ),
                              Obx(
                                () => Text(
                                  AppStrings.customer,
                                  style: !consignController.isUserSignTap.value
                                      ? tSw700fontF.copyWith(
                                          fontSize: SizeConstants.dp16)
                                      : tSw400dp16fontF.copyWith(
                                          fontSize: SizeConstants.dp16),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Tab(
                          child: Wrap(
                              crossAxisAlignment: WrapCrossAlignment.center,
                              children: [
                                Obx(
                                  () => Visibility(
                                    visible: consignController
                                                .isStartUserSignDraw.value &&
                                            consignController
                                                .enterUserName.value.isNotEmpty
                                        ? true
                                        : false,
                                    child: Image.asset(AppImages.success,
                                        width: getHeight(SizeConstants.dp12),
                                        height: getHeight(SizeConstants.dp12)),
                                  ),
                                ),
                                SizedBox(
                                  width: getWidth(SizeConstants.dp5),
                                ),
                                Obx(
                                  () => Text(
                                    AppStrings.user,
                                    style: consignController.isUserSignTap.value
                                        ? tSw700fontF.copyWith(
                                            fontSize: SizeConstants.dp16)
                                        : tSw400dp16fontF.copyWith(
                                            fontSize: SizeConstants.dp16),
                                  ),
                                ),
                              ]),
                        ),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  top: getWidth(SizeConstants.dp36),
                  width: getWidth(getScreenWidth()),
                  child: const Divider(
                      thickness: 1, color: AppColors.colorSeparatorLine),
                ),
              ],
            ),
            const SizedBox(
              height: SizeConstants.dp19,
            ),
            Expanded(
              child: TabBarView(
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    customerSignUiWidget(),
                    userSignUiWidget(),
                  ]),
            )
          ],
        ),
      ),
    );
  }

  /* User Sign Widget*/
  userSignUiWidget() {
    return Container(
      margin: const EdgeInsets.only(
          left: SizeConstants.dp32, right: SizeConstants.dp30),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Wrap(
                children: [
                  Text(
                    AppStrings.sign2,
                    style: tSw700fontF.copyWith(
                      color: AppColors.colorBlack,
                      fontSize: SizeConstants.dp18,
                    ),
                  ),
                  SizedBox(
                    width: getHeight(SizeConstants.dp10),
                  ),
                  Text(
                    AppStrings.user,
                    style: tSw400dp14fontF.copyWith(
                      color: AppColors.colorBlack,
                      fontSize: SizeConstants.dp18,
                    ),
                  ),
                ],
              ),
              enterUserNameWidget()
            ],
          ),
          Stack(
            children: [
              Container(
                height: getHeight(SizeConstants.dp280),
                color: AppColors.colorBg,
                child: Listener(
                  onPointerMove: (event) {
                    if (!consignController.isStartUserSignDraw.value) {
                      consignController.isStartUserSignDraw.value = true;
                    }
                  },
                  child: Signature(
                    width: (getWidth(getScreenWidth()) -
                        getWidth(SizeConstants.dp360)),
                    height: getHeight(SizeConstants.dp280),
                    controller: consignController.userSignatureController,
                    backgroundColor: AppColors.colorBg,
                  ),
                ),
              ),
              Obx(() => Visibility(
                  visible: consignController.isStartUserSignDraw.value == true
                      ? false
                      : true,
                  child: Positioned(
                      top: getHeight(SizeConstants.dp280) / 2,
                      left: (getWidth(getScreenWidth() -
                                  getWidth(SizeConstants.dp300))) /
                              2 -
                          getWidth(SizeConstants.dp100),
                      child: Text(AppStrings.pleaseSign,
                          style: tSw400dp24fontF.copyWith(
                              color:
                                  AppColors.colorMainText.withAlpha(100)))))),
              Container(
                margin: const EdgeInsets.all(SizeConstants.dp15),
                alignment: Alignment.topRight,
                child: InkWell(
                  onTap: () {
                    if (consignController.userSignatureController.isNotEmpty) {
                      consignController.clearUserNameSignNew(
                          consignController.userSignatureController, false);
                    }
                  },
                  child: Obx(
                    () => Text(
                      AppStrings.clear,
                      style: tSw500dp12fontF.copyWith(
                        fontSize: SizeConstants.dp14,
                        color: consignController.isStartUserSignDraw.value
                            ? AppColors.colorPrimary
                            : AppColors.colorPrimary.withOpacity(0.2),
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
          SizedBox(
            height: getHeight(SizeConstants.dp4),
          ),
        ],
      ),
    );
  }

  Widget enterUserNameWidget() {
    return SizedBox(
      width: getWidth(SizeConstants.dp359),
      height: getHeight(SizeConstants.dp45),
      child: TextFormField(
        controller: consignController.userNameTxt,
        textAlignVertical: TextAlignVertical.center,
        autofocus: false,
        autocorrect: false,
        enableSuggestions: false,
        style: tSw400dp14fontF.copyWith(
          fontSize: SizeConstants.dp18,
          color: AppColors.colorMainText,
        ),
        inputFormatters: [
          filteringTextInputFormatter,
        ],
        decoration: InputDecoration(
            hintText: AppStrings.enterYourNameHint,
            hintStyle: tSw400dp14fontF.copyWith(
              fontSize: SizeConstants.dp18,
              color: AppColors.colorSubText.withOpacity(0.7),
            ),
            filled: true,
            fillColor: AppColors.colorF5F6F5.withOpacity(0.8),
            enabledBorder: outlineBorder,
            focusedBorder: outlineBorder,
            border: outlineBorder,
            focusedErrorBorder: outlineBorder,
            errorBorder: outlineBorder,
            floatingLabelBehavior: FloatingLabelBehavior.never,
            isDense: true),
        maxLines: 1,
        onChanged: (value) {
          consignController.enterUserName.value = value;
        },
        keyboardType: TextInputType.text,
        textAlign: TextAlign.start,
        validator: (value) {
          return null;
        },
      ),
    );
  }

  /* Customer Sign Widget*/
  customerSignUiWidget() {
    return Container(
      margin: const EdgeInsets.only(
          left: SizeConstants.dp32, right: SizeConstants.dp30),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Wrap(
                children: [
                  Text(
                    AppStrings.sign1,
                    style: tSw700fontF.copyWith(
                      color: AppColors.colorBlack,
                      fontSize: SizeConstants.dp18,
                    ),
                  ),
                  SizedBox(
                    width: getHeight(SizeConstants.dp10),
                  ),
                  Text(
                    AppStrings.customer,
                    style: tSw400dp14fontF.copyWith(
                      color: AppColors.colorBlack,
                      fontSize: SizeConstants.dp18,
                    ),
                  ),
                ],
              ),
              enterCustomerNameWidget()
            ],
          ),
          SizedBox(
            height: getHeight(SizeConstants.dp8),
          ),
          Stack(
            children: [
              Container(
                height: getHeight(SizeConstants.dp280),
                color: AppColors.colorBg,
                child: Listener(
                  onPointerMove: (event) {
                    if (!consignController.isCustomerStartDraw.value) {
                      consignController.isCustomerStartDraw.value = true;
                    }
                  },
                  child: Signature(
                    width: (getWidth(getScreenWidth()) -
                        getWidth(SizeConstants.dp360)),
                    height: getHeight(SizeConstants.dp280),
                    controller: consignController.customerSignatureController,
                    backgroundColor: AppColors.colorBg,
                  ),
                ),
              ),
              Obx(
                () => Visibility(
                  visible: consignController.isCustomerStartDraw.value == true
                      ? false
                      : true,
                  child: Positioned(
                      top: getHeight(SizeConstants.dp280) / 2,
                      left: (getWidth(getScreenWidth() -
                                  getWidth(SizeConstants.dp300))) /
                              2 -
                          getWidth(SizeConstants.dp100),
                      child: Text(AppStrings.pleaseSign,
                          style: tSw400dp24fontF.copyWith(
                              color: AppColors.colorMainText.withAlpha(100)))),
                ),
              ),
              Container(
                margin: const EdgeInsets.all(SizeConstants.dp15),
                alignment: Alignment.topRight,
                child: InkWell(
                  onTap: () {
                    if (consignController
                        .customerSignatureController.isNotEmpty) {
                      consignController.clearCustomerNameSignNew(
                          consignController.customerSignatureController, false);
                    }
                  },
                  child: Obx(
                    () => Text(
                      AppStrings.clear,
                      style: tSw500dp12fontF.copyWith(
                        fontSize: SizeConstants.dp14,
                        color: consignController.isCustomerStartDraw.value
                            ? AppColors.colorPrimary
                            : AppColors.colorPrimary.withOpacity(0.2),
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
          SizedBox(
            height: getHeight(SizeConstants.dp4),
          ),
        ],
      ),
    );
  }

  Widget enterCustomerNameWidget() {
    return SizedBox(
      width: getWidth(SizeConstants.dp359),
      height: getHeight(SizeConstants.dp45),
      child: TextFormField(
        controller: consignController.customerNameTxt,
        textAlignVertical: TextAlignVertical.center,
        autofocus: false,
        autocorrect: false,
        enableSuggestions: false,
        style: tSw400dp14fontF.copyWith(
          fontSize: SizeConstants.dp18,
          color: AppColors.colorMainText,
        ),
        inputFormatters: [
          filteringTextInputFormatter,
        ],
        decoration: InputDecoration(
            hintText: AppStrings.customerNameSmall,
            hintStyle: tSw400dp14fontF.copyWith(
              fontSize: SizeConstants.dp18,
              color: AppColors.colorSubText.withOpacity(0.7),
            ),
            filled: true,
            fillColor: AppColors.colorF5F6F5.withOpacity(0.8),
            enabledBorder: outlineBorder,
            focusedBorder: outlineBorder,
            border: outlineBorder,
            focusedErrorBorder: outlineBorder,
            errorBorder: outlineBorder,
            floatingLabelBehavior: FloatingLabelBehavior.never,
            isDense: true),
        maxLines: 1,
        onChanged: (value) {
          consignController.enterCustomerName.value = value;
        },
        keyboardType: TextInputType.text,
        textAlign: TextAlign.start,
        validator: (value) {
          return null;
        },
      ),
    );
  }

  final outlineBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(AppValues.radius_10),
    borderSide: const BorderSide(
        width: SizeConstants.dp1, color: AppColors.colorSeparatorLine),
  );
}
