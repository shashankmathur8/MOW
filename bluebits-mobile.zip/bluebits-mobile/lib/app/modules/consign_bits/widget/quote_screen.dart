import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/common_widgets/custom_button_material.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/controller/consign_controller.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/widget/digital_sign_overlay.dart';
import 'package:slb_gt_mobile/app/modules/shared/signature_confirmation_overlay.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../../shared/generic_overlay.dart';
import 'manual_sign_overlay.dart';

class QuoteScreen extends StatefulWidget {
  final ConsignController consignController;

  const QuoteScreen({Key? key, required this.consignController})
      : super(key: key);

  @override
  State<QuoteScreen> createState() => _QuoteScreenState();
}

class _QuoteScreenState extends State<QuoteScreen> {
  int isDigitalTap = 0;

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => Container(
        color: AppColors.colorBackgroundPanel,
        child: Column(
          children: [
            Row(
              children: [
                Container(
                    alignment: Alignment.centerLeft,
                    margin: EdgeInsets.only(
                      top: getHeight(AppValues.margin_34),
                      left: getWidth(AppValues.margin_40),
                      right: getWidth(AppValues.margin_19),
                    ),
                    child: pageHeaderTitle),
                Flexible(
                  fit: FlexFit.tight,
                  child: Center(
                    child: Container(
                      width: getHeight(SizeConstants.dp255),
                      height: getHeight(SizeConstants.dp40),
                      margin: EdgeInsets.only(
                        top: getHeight(AppValues.margin_28),
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.colorSeparatorLine.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(SizeConstants.dp20),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(SizeConstants.dp4),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            GestureDetector(
                                child: Container(
                                  padding:
                                      const EdgeInsets.all(SizeConstants.dp2),
                                  alignment: Alignment.center,
                                  width: getHeight(SizeConstants.dp123),
                                  height: getHeight(SizeConstants.dp34),
                                  decoration: BoxDecoration(
                                    color: widget.consignController.tag.value ==
                                            AppStrings.isDigital
                                        ? AppColors.colorWhite
                                        : null,
                                    borderRadius: BorderRadius.circular(
                                        SizeConstants.dp20),
                                  ),
                                  child: Text(
                                    AppStrings.digitalSign,
                                    style: tSw500dp15fontF.copyWith(
                                      fontSize: SizeConstants.dp15,
                                      color:
                                          widget.consignController.tag.value ==
                                                  AppStrings.isDigital
                                              ? AppColors.colorMainText
                                              : AppColors.colorSubText,
                                    ),
                                  ),
                                ),
                                onTap: () {
                                  if (widget
                                      .consignController.isDigitalSignTab) {
                                    return;
                                  }

                                  if (widget.consignController.isDigitalSignDone
                                          .value ||
                                      widget.consignController.isQuoteUploaded
                                          .value) {
                                    Navigator.of(context).push(GenericOverlay(
                                        title: AppStrings.switchToDigitalTitle,
                                        message: AppStrings.switchToDigitalMsg,
                                        iconPath: AppImages.warning,
                                        negativeButtonText: AppStrings.no,
                                        positiveButtonText: AppStrings.yes,
                                        onPositivePressCallback: () {
                                          clearManualQuoteUploaded();

                                          Get.back();
                                          selectDigitalSignature();
                                        }));
                                  } else {
                                    selectDigitalSignature();
                                  }
                                }),
                            GestureDetector(
                                child: Container(
                                  alignment: Alignment.center,
                                  width: getHeight(SizeConstants.dp123),
                                  height: getHeight(SizeConstants.dp34),
                                  decoration: BoxDecoration(
                                    color: widget.consignController.tag.value ==
                                            AppStrings.isManual
                                        ? AppColors.colorWhite
                                        : null,
                                    borderRadius: BorderRadius.circular(
                                        SizeConstants.dp20),
                                  ),
                                  child: Text(
                                    AppStrings.manualSign,
                                    style: tSw500dp15fontF.copyWith(
                                      fontSize: SizeConstants.dp15,
                                      color:
                                          widget.consignController.tag.value ==
                                                  AppStrings.isManual
                                              ? AppColors.colorMainText
                                              : AppColors.colorSubText,
                                    ),
                                  ), // button text
                                ),
                                onTap: () {
                                  if (!widget
                                      .consignController.isDigitalSignTab) {
                                    return;
                                  }
                                  if (widget.consignController.isDigitalSignDone
                                      .value) {
                                    Navigator.of(context).push(GenericOverlay(
                                        title: AppStrings.switchToManualTitle,
                                        message: AppStrings.switchToManualMsg,
                                        iconPath: AppImages.warning,
                                        negativeButtonText: AppStrings.no,
                                        positiveButtonText: AppStrings.yes,
                                        onPositivePressCallback: () {
                                          clearDigitalSignature();

                                          Get.back();
                                          selectManualSign();
                                        }));
                                  } else {
                                    selectManualSign();
                                  }
                                }),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Visibility(
                visible: widget.consignController.isDigitalSignDone.value ||
                    widget.consignController.isQuoteUploaded.value,
                child: showStepDisableMessage()),
            Flexible(
              fit: FlexFit.tight,
              child: Center(
                child: Container(
                  height: double.infinity,
                  padding: EdgeInsets.only(
                    top: getHeight(AppValues.padding_15),
                    left: getWidth(AppValues.padding_40),
                    right: getWidth(AppValues.padding_19),
                  ),
                  child: Obx(() => widget.consignController.isLoadHtml.value
                      ? loadHtml()
                      : widget.consignController.loadPdf()),
                ),
              ),
            ),
            //Digital Sign View
            Visibility(
              visible:
                  widget.consignController.tag.value == AppStrings.isDigital
                      ? true
                      : false,
              child: Column(
                children: [
                  dividerContainerBottomWidget,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      signConfirmedMsg(),
                      Wrap(
                        crossAxisAlignment: WrapCrossAlignment.end,
                        children: [
                          confirmButtonWidget(),
                          acceptButtonWidget(),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
            // Manual sign view
            Visibility(
              visible:
                  widget.consignController.tag.value == AppStrings.isDigital
                      ? false
                      : true,
              child: Column(
                children: [
                  dividerContainerBottomWidget,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Visibility(
                        visible: widget.consignController.isQuoteUploaded.value
                            ? true
                            : false,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Wrap(
                              crossAxisAlignment: WrapCrossAlignment.start,
                              children: [
                                quoteUploadedMsg(),
                                SizedBox(
                                  width: getHeight(SizeConstants.dp12),
                                ),
                                //Image.asset(AppImages.verticalDivider),
                                separatorPipe(),
                                SizedBox(
                                  width: getHeight(SizeConstants.dp12),
                                ),
                                GestureDetector(
                                    onTap: () {
                                      clearManualQuoteUploaded();
                                    },
                                    child:
                                        Image.asset(AppImages.quoteDeleteIcon)),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Wrap(
                        crossAxisAlignment: WrapCrossAlignment.end,
                        children: [
                          uploadSignedQuoteButtonWidget(),
                          printButtonWidget(),
                          manualConfirmButtonWidget(),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget loadHtml() {
    return WebViewWidget(
        controller: widget.consignController.webHtmlViewController);
  }

  Widget pageHeaderTitle = Text(
    AppStrings.quote,
    style: tSw400dp14fontF.copyWith(
      fontSize: SizeConstants.dp24,
      color: AppColors.colorMainText,
    ),
  );

  Widget dividerContainerBottomWidget = Container(
    color: AppColors.colorSeparatorLine,
    height: getHeight(SizeConstants.dp1),
    margin: const EdgeInsets.only(bottom: AppValues.margin_20),
  );

  /// **************** Manual Signature *******************

  Widget separatorPipe() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: getWidth(AppValues.margin_7)),
      width: getWidth(SizeConstants.dp1),
      height: getHeight(SizeConstants.dp15),
      color: AppColors.colorSeparatorLine,
    );
  }

  Widget printButtonWidget() {
    return Obx(
      () => Visibility(
        visible: widget.consignController.isQuoteUploaded.value ? false : true,
        child: Container(
          alignment: Alignment.bottomRight,
          padding: const EdgeInsets.only(
              bottom: AppValues.padding_20, right: AppValues.padding_20),
          child: CustomButtonMaterial(
            width: getWidth(SizeConstants.dp149),
            height: getHeight(SizeConstants.dp45),
            backgroundColor: AppColors.colorPrimary,
            foregroundColor: AppColors.colorWhite,
            borderRadius: AppValues.radius_4,
            text: AppStrings.print,
            style: tSw600dp16fontF.copyWith(
              color: AppColors.colorWhite,
            ),
            onPressCallback: () {
              widget.consignController.printingHtml(widget.consignController);
            },
          ),
        ),
      ),
    );
  }

  Widget uploadSignedQuoteButtonWidget() {
    return Obx(
      () => Visibility(
        visible: widget.consignController.isQuoteUploaded.value ? false : true,
        child: Container(
          alignment: Alignment.bottomRight,
          padding: const EdgeInsets.only(
              bottom: AppValues.padding_20, right: AppValues.padding_20),
          child: CustomButtonMaterial(
            width: getWidth(SizeConstants.dp199),
            height: getHeight(SizeConstants.dp45),
            backgroundColor: AppColors.transparentColor,
            foregroundColor: AppColors.transparentColor,
            borderRadius: AppValues.radius_4,
            text: AppStrings.uploadSignedQuote,
            side: const BorderSide(
              width: SizeConstants.dp1,
              color: AppColors.colorPrimary,
            ),
            style: tSw600dp16fontF.copyWith(
              color: AppColors.colorPrimary,
            ),
            onPressCallback: () {
              Navigator.of(context)
                  .push(ManualSignOverlay(widget.consignController));
            },
          ),
          //  ),
        ),
      ),
    );
  }

  Widget quoteUploadedMsg() {
    return Container(
      alignment: Alignment.centerLeft,
      margin: EdgeInsets.only(
        left: getHeight(AppValues.margin_30),
      ),
      child: Wrap(
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          Image.asset(AppImages.greenTick),
          SizedBox(width: getHeight(SizeConstants.dp7)),
          Text(
            AppStrings.quoteUploaded,
            style: tSw400dp16fontF.copyWith(
              fontSize: SizeConstants.dp16,
              color: AppColors.colorBlack,
            ),
          ),
        ],
      ),
    );
  }

  Widget manualConfirmButtonWidget() {
    return Obx(
      () => Visibility(
        visible: widget.consignController.isQuoteUploaded.value ? true : false,
        child: Container(
          alignment: Alignment.bottomRight,
          padding: const EdgeInsets.only(
              bottom: AppValues.padding_20, right: AppValues.padding_20),
          child: CustomButtonMaterial(
            width: getWidth(SizeConstants.dp149),
            height: getHeight(SizeConstants.dp45),
            backgroundColor: AppColors.colorPrimary,
            foregroundColor: AppColors.colorWhite,
            borderRadius: AppValues.radius_4,
            text: AppStrings.confirm,
            style: tSw600dp16fontF.copyWith(
              color: AppColors.colorWhite,
            ),
            onPressCallback: () {
              Navigator.of(context)
                  .push(SignatureConfirmationOverlay(widget.consignController));
            },
          ),
        ),
      ),
    );
  }

  /// **************** Digital Signature *******************

  Widget signConfirmedMsg() {
    return Obx(
      () => Visibility(
        visible:
            widget.consignController.isDigitalSignDone.value ? true : false,
        child: Container(
          alignment: Alignment.centerLeft,
          margin: EdgeInsets.only(
            left: getHeight(AppValues.margin_30),
          ),
          child: Wrap(
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Image.asset(AppImages.greenTick),
              SizedBox(width: getHeight(SizeConstants.dp7)),
              Text(
                AppStrings.signCaptured,
                style: tSw400dp16fontF.copyWith(
                  fontSize: SizeConstants.dp16,
                  color: AppColors.colorBlack,
                ),
              ),
              SizedBox(width: getHeight(SizeConstants.dp7)),
              separatorPipe(),
              SizedBox(width: getHeight(SizeConstants.dp7)),
              GestureDetector(
                  onTap: () {
                    clearDigitalSignature();
                    selectDigitalSignature();
                  },
                  child: Image.asset(AppImages.quoteDeleteIcon)),
            ],
          ),
        ),
      ),
    );
  }

  Widget confirmButtonWidget() {
    return Obx(
      () => Visibility(
        visible:
            widget.consignController.isDigitalSignDone.value ? true : false,
        child: Container(
          alignment: Alignment.bottomRight,
          padding: const EdgeInsets.only(
              bottom: AppValues.padding_20, right: AppValues.padding_20),
          child: CustomButtonMaterial(
            width: getWidth(SizeConstants.dp149),
            height: getHeight(SizeConstants.dp45),
            backgroundColor: AppColors.colorPrimary,
            foregroundColor: AppColors.colorWhite,
            borderRadius: AppValues.radius_4,
            text: AppStrings.confirm,
            style: tSw600dp16fontF.copyWith(
              color: AppColors.colorWhite,
            ),
            onPressCallback: () {
              Navigator.of(context)
                  .push(SignatureConfirmationOverlay(widget.consignController));
            },
          ),
        ),
      ),
    );
  }

  Widget acceptButtonWidget() {
    return Obx(
      () => Visibility(
        visible:
            widget.consignController.isDigitalSignDone.value ? false : true,
        child: Container(
          alignment: Alignment.bottomRight,
          padding: const EdgeInsets.only(
              bottom: AppValues.padding_20, right: AppValues.padding_20),
          child: CustomButtonMaterial(
            width: getWidth(SizeConstants.dp149),
            height: getHeight(SizeConstants.dp45),
            backgroundColor: AppColors.colorPrimary,
            foregroundColor: AppColors.colorWhite,
            borderRadius: AppValues.radius_4,
            text: AppStrings.acceptSign,
            style: tSw600dp16fontF.copyWith(
              color: AppColors.colorWhite,
            ),
            onPressCallback: () {
              Navigator.of(context)
                  .push(DigitalSignOverlay(widget.consignController));
            },
          ),
          // ),
        ),
      ),
    );
  }

  Widget showStepDisableMessage() {
    return Padding(
      padding: EdgeInsets.only(top: getHeight(SizeConstants.dp15)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: getHeight(SizeConstants.dp45),
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: AppColors.colorGrey.withOpacity(0.3),
                  spreadRadius: AppValues.radius_2,
                  blurRadius: AppValues.radius_7,
                  offset: const Offset(0, 3), // changes position of shadow
                ),
              ],
              color: AppColors.colorMainText,
              borderRadius:
                  const BorderRadius.all(Radius.circular(SizeConstants.dp6)),
              border: Border.all(
                  width: SizeConstants.dp1, color: AppColors.colorMainText),
            ),
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: getWidth(SizeConstants.dp20),
              ),
              child: Row(
                children: [
                  Container(
                      height: getWidth(SizeConstants.dp20),
                      width: getWidth(SizeConstants.dp20),
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(AppImages.icInfoW),
                          fit: BoxFit.fill,
                        ),
                      ),
                      child: null),
                  Container(
                    margin: EdgeInsets.only(left: getWidth(SizeConstants.dp15)),
                    child: Text(
                      AppStrings.infoMessageForDisableStepsDigital,
                      style: tSw400dp14fontF.copyWith(
                        color: AppColors.colorWhite,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  void clearDigitalSignature() {
    widget.consignController.clearAllNew(
        widget.consignController.customerSignatureController,
        widget.consignController.userSignatureController);
  }

  void selectDigitalSignature() {
    widget.consignController
        .onTapSignatureTabButton(true, widget.consignController);
  }

  void clearManualQuoteUploaded() {
    widget.consignController.deleteManualPdf(widget.consignController);
  }

  void selectManualSign() {
    widget.consignController
        .onTapSignatureTabButton(false, widget.consignController);
  }
}
