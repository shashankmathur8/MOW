import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/controller/consign_controller.dart';

import '../../../core/common_widgets/custom_button_material.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../../bottomNavigation/dashboard.dart';

class ConfirmationScreen extends StatefulWidget {
  final ConsignController consignController;

  const ConfirmationScreen({Key? key, required this.consignController})
      : super(key: key);

  @override
  State<ConfirmationScreen> createState() => _ConfirmationScreenState();
}

class _ConfirmationScreenState extends State<ConfirmationScreen> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        color: AppColors.colorBackgroundPanel,
        alignment: Alignment.center,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
                child: Container(
              alignment: Alignment.center,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      AppStrings.consignmentTicketSubmitted,
                      style: tSw700fontF.copyWith(
                        fontSize: SizeConstants.dp30,
                        color: AppColors.colorMainText,
                      ),
                    ),
                    SizedBox(
                      height: getHeight(SizeConstants.dp53),
                    ),
                    Image(
                      image: const AssetImage(AppImages.tktSubmittedIcon),
                      width: getWidth(AppValues.iconSize_80),
                      height: getWidth(AppValues.iconSize_80),
                    ),
                    SizedBox(
                      height: getHeight(SizeConstants.dp30),
                    ),
                    Text(
                      "${AppStrings.consignmentId}${widget.consignController.consignmentID}",
                      style: tSw500dp18fontF.copyWith(
                        color: AppColors.colorMainText,
                      ),
                    ),
                    SizedBox(
                      height: getHeight(SizeConstants.dp8),
                    ),
                    Text(
                      AppStrings.consignmentCopy,
                      style: tSw400dp14fontF.copyWith(
                        color: AppColors.colorMainText,
                      ),
                    ),
                    SizedBox(height: getHeight(SizeConstants.dp29)),
                    gotoConsignedBitsButtonWidget(),
                  ],
                ),
              ),
            )),
            // const Spacer(),
            dividerContainerWidget,
            nextButtonWidget(),
          ],
        ),
      ),
    );
  }

  Widget dividerContainerWidget = Container(
    color: AppColors.colorSeparatorLine,
    height: getHeight(SizeConstants.dp1),
    margin: EdgeInsets.only(bottom: getHeight(AppValues.margin_20)),
  );

  Widget gotoConsignedBitsButtonWidget() {
    return CustomButtonMaterial(
      width: getWidth(SizeConstants.dp213),
      height: getHeight(SizeConstants.dp50),
      backgroundColor: AppColors.transparentColor,
      foregroundColor: AppColors.colorPrimary,
      borderRadius: AppValues.radius_10,
      text: AppStrings.gotoConsignedBits,
      style: tSw600dp16fontF,
      side: const BorderSide(
        width: SizeConstants.dp1,
        color: AppColors.colorPrimary,
      ),
      onPressCallback: () {
        Get.delete<ConsignController>(
            tag: (ConsignController).toString(), force: true);

        Get.off(
            Dashboard(
              pageIndex: 1,
            ),
            transition: Transition.downToUp,
            duration: const Duration(seconds: 1));
      },
    );
  }

  Widget nextButtonWidget() {
    return Container(
      alignment: Alignment.bottomRight,
      padding: const EdgeInsets.only(
          bottom: AppValues.padding_20, right: AppValues.padding_20),
      child: CustomButtonMaterial(
        width: getWidth(SizeConstants.dp219),
        height: getHeight(SizeConstants.dp45),
        backgroundColor: AppColors.colorPrimary,
        foregroundColor: AppColors.colorWhite,
        borderRadius: AppValues.radius_4,
        text: AppStrings.backToInventory,
        style: tSw600dp16fontF.copyWith(
          color: AppColors.colorWhite,
        ),
        onPressCallback: () {
          Get.delete<ConsignController>(
              tag: (ConsignController).toString(), force: true);
          Get.back();
        },
      ),
    );
  }
}
