import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

import '../../../core/common_widgets/custom_button_material.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../controller/consign_controller.dart';

class ManualSignOverlay extends ModalRoute<void> {
  final ConsignController consignController;

  ManualSignOverlay(this.consignController);

  @override
  Duration get transitionDuration => const Duration(milliseconds: 0);

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => false;

  @override
  Color get barrierColor => AppColors.colorBlack.withOpacity(0.3);

  @override
  String get barrierLabel => '';

  @override
  bool get maintainState => true;

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    // This makes sure that text and other content follows the material style
    return Material(
      type: MaterialType.transparency,
      // make sure that the overlay content is not cut off
      child: SafeArea(
        child: _buildOverlayContent(context),
      ),
    );
  }

  Widget _buildOverlayContent(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(SizeConstants.dp20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: getWidth(getScreenWidth() - SizeConstants.dp300),
              decoration: BoxDecoration(
                  color: AppColors.colorWhite,
                  borderRadius: BorderRadius.circular(SizeConstants.dp10),
                  boxShadow: [
                    BoxShadow(
                        color: AppColors.colorBlack.withOpacity(0.3),
                        blurRadius: SizeConstants.dp7)
                  ]),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: SizeConstants.dp20,
                    vertical: SizeConstants.dp25),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: getHeight(SizeConstants.dp64),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: AppColors.colorCircleIcon,
                                radius: SizeConstants.dp32,
                                child: Container(
                                    height: getWidth(SizeConstants.dp30),
                                    width: getWidth(SizeConstants.dp30),
                                    decoration: const BoxDecoration(
                                      image: DecorationImage(
                                        image: AssetImage(
                                            AppImages.uploadSignQuote),
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                    child: null),
                              ),
                              const SizedBox(
                                width: SizeConstants.dp16,
                              ),
                              const Text(
                                AppStrings.uploadSignedQuote,
                                style: warehouseTextStyle,
                              ),
                            ],
                          ),
                          Visibility(
                            visible: true,
                            child: InkWell(
                              onTap: () {
                                consignController.clearManualPickData();
                              },
                              child: Text(
                                AppStrings.clear,
                                style: tSw500dp12fontF.copyWith(
                                  fontSize: SizeConstants.dp14,
                                  color: AppColors.colorPrimary,
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: getHeight(SizeConstants.dp4),
                    ),
                    Stack(
                      children: [
                        Container(
                          height: getHeight(SizeConstants.dp280),
                          color: AppColors.colorBg,
                        ),
                        Obx(() => Container(
                            color: AppColors.transparentColor,
                            height: getHeight(SizeConstants.dp280),
                            padding: const EdgeInsets.all(SizeConstants.dp10),
                            child: consignController.filePath.value != '' &&
                                    consignController.getFileSize(context) <
                                        consignController.maxAllowedFileSize &&
                                    !consignController
                                        .fileProcessingRunning.value
                                ? SfPdfViewer.file(
                                    File(consignController.filePath.value),
                                    canShowScrollHead: true,
                                    canShowScrollStatus: true,
                                    enableDoubleTapZooming: false,
                                    enableHyperlinkNavigation: false,
                                    enableDocumentLinkAnnotation: false,
                                    enableTextSelection: false,
                                  )
                                : consignController.fileProcessingRunning.value
                                    ? const Center(
                                        child: CircularProgressIndicator(
                                        color: AppColors.colorPrimary,
                                        strokeWidth: SizeConstants.dp3,
                                      ))
                                    : optionFileChooseWidget(context))),
                      ],
                    ),
                    SizedBox(
                      height: getHeight(SizeConstants.dp4),
                    ),
                    checkboxRowWidget(),
                    SizedBox(
                      height: getHeight(SizeConstants.dp20),
                    ),
                    bottomButtonWidget(context)
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget optionFileChooseWidget(BuildContext context) {
    return SizedBox(
      child: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            GestureDetector(
              onTap: () async {
                await consignController.openFilePicker();
              },
              child: uploadUIWidget(
                  AppImages.uploadAttachmentFolderIcon,
                  AppStrings.chooseFile,
                  AppStrings.toUpload,
                  AppStrings.warningMbSize),
            ),
            GestureDetector(
              onTap: () async {
                await consignController.openGalleryPicker(context);
              },
              child: uploadUIWidget(
                  AppImages.galleryUploadIcon,
                  AppStrings.chooseFile,
                  AppStrings.toUpload,
                  AppStrings.warningMbSize),
            ),
          ],
        ),
      ),
    );
  }

  Widget uploadUIWidget(String imagePath, String chooseText, String uploadText,
      String sizeLimitText) {
    return Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(imagePath),
          Wrap(
            children: [
              Text(chooseText,
                  style: tSw500dp16fontF.copyWith(
                    color: AppColors.colorPrimary,
                  )),
              Text(' '),
              Text(
                uploadText,
                style: tSw500dp16fontF.copyWith(
                  color: AppColors.colorMainText,
                ),
              )
            ],
          ),
          Text(
            sizeLimitText,
            style: tSw400dp14fontF.copyWith(
              color: AppColors.colorSubText,
            ),
          )
        ]);
  }

  Widget checkboxRowWidget() {
    return Container(
      color: AppColors.colorWhite,
      height: getHeight(SizeConstants.dp40),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Obx(() => Checkbox(
                value: consignController.isChecked.value,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppValues.radius_2),
                ),
                side: const BorderSide(
                    width: SizeConstants.dp1,
                    color: AppColors.colorCheckBoxUnselected,
                    style: BorderStyle.solid),
                activeColor: AppColors.colorCheckBoxSelected,
                checkColor: AppColors.colorWhite,
                onChanged: (val) {
                  consignController.isChecked.value =
                      !consignController.isChecked.value;
                },
              )),
          SizedBox(
            width: getWidth(SizeConstants.dp1),
          ),
          Expanded(
            child: Text(
              maxLines: 2,
              AppStrings.iAgreeStatementOnUploadAttachment,
              style: tSw400dp14fontF.copyWith(
                color: AppColors.colorMainText,
                fontSize: SizeConstants.dp16,
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget bottomButtonWidget(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        CustomButtonMaterial(
          width: getWidth(SizeConstants.dp102),
          height: getHeight(SizeConstants.dp45),
          backgroundColor: AppColors.colorWhite,
          foregroundColor: AppColors.colorPrimary,
          borderRadius: AppValues.radius_4,
          text: AppStrings.cancel,
          style: tSw500dp16fontF,
          side: const BorderSide(
            width: SizeConstants.dp1,
            color: AppColors.colorPrimary,
          ),
          onPressCallback: () {
            Get.back();
          },
        ),
        SizedBox(
          width: getWidth(SizeConstants.dp10),
        ),
        Obx(() => CustomButtonMaterial(
              width: getWidth(SizeConstants.dp130),
              height: getHeight(SizeConstants.dp45),
              backgroundColor: consignController.filePath.value != '' &&
                      consignController.getFileSize(context) <
                          consignController.maxAllowedFileSize &&
                      !consignController.fileProcessingRunning.value &&
                      consignController.isChecked.value
                  ? AppColors.colorPrimary
                  : AppColors.colorPrimary.withOpacity(0.2),
              foregroundColor: AppColors.colorWhite,
              borderRadius: AppValues.radius_4,
              text: AppStrings.confirm,
              style: tSw500dp16fontF,
              onPressCallback: () async {
                if (consignController.filePath.value != '' &&
                    consignController.getFileSize(context) <
                        consignController.maxAllowedFileSize &&
                    !consignController.fileProcessingRunning.value &&
                    consignController.isChecked.value) {
                  consignController.isQuoteUploaded.value = true;
                  //need to pass index because on step change we passing index of step click
                  consignController.updateStepItemStatus(
                      currentIndex: consignController.index.value);

                  consignController.isDigitalSignTab = false;
                  consignController.isLoadHtml.value = false;
                  Get.back();
                }
              },
            )),
      ],
    );
  }

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    // You can add your own animations for the overlay content
    return FadeTransition(
      opacity: animation,
      child: ScaleTransition(
        scale: animation,
        child: child,
      ),
    );
  }
}
