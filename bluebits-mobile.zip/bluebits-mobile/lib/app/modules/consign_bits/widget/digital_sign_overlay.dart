import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/controller/consign_controller.dart';

import '../../../core/common_widgets/custom_button_material.dart';
import '../../../core/common_widgets/toast_message.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_utils.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import 'customer_user_digital_sign_overlay.dart';

class DigitalSignOverlay extends ModalRoute<void> {
  final ConsignController consignController;

  DigitalSignOverlay(this.consignController);

  @override
  Duration get transitionDuration => const Duration(milliseconds: 0);

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => false;

  @override
  Color get barrierColor => Colors.black.withOpacity(0.3);

  @override
  String get barrierLabel => '';

  @override
  bool get maintainState => true;

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    return Material(
      type: MaterialType.transparency,
      child: SafeArea(
        child: _buildOverlayContent(context),
      ),
    );
  }

  Widget _buildOverlayContent(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(SizeConstants.dp20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: getWidth(getScreenWidth() - SizeConstants.dp275),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(SizeConstants.dp10),
                  boxShadow: [
                    BoxShadow(
                        color: AppColors.colorBlack.withOpacity(0.3),
                        blurRadius: SizeConstants.dp7)
                  ]),
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.colorWhite,
                  borderRadius: BorderRadius.circular(SizeConstants.dp10),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: SizeConstants.dp1,
                      vertical: SizeConstants.dp25),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      headerUiWidget(),
                      SizedBox(
                        height: getHeight(SizeConstants.dp420),
                        child: CustomerUserDigitalSignOverlay(
                          consignController: consignController,
                        ),
                      ),
                      checkboxRowUiWidget(),
                      SizedBox(
                        height: getHeight(SizeConstants.dp10),
                      ),
                      bottomButtonWidget(context),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
// You can add your own animations for the overlay content
    return FadeTransition(
      opacity: animation,
      child: ScaleTransition(
        scale: animation,
        child: child,
      ),
    );
  }

  Widget headerUiWidget() {
    return Container(
      margin: const EdgeInsets.only(
          left: AppValues.margin_20, right: AppValues.margin_30),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: AppColors.colorCircleIcon,
                radius: SizeConstants.dp32,
                child: Container(
                    height: getWidth(SizeConstants.dp30),
                    width: getWidth(SizeConstants.dp30),
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage(AppImages.icSignaturePen),
                        fit: BoxFit.fill,
                      ),
                    ),
                    child: null),
              ),
              const SizedBox(
                width: SizeConstants.dp19,
              ),
              const Text(
                AppStrings.addNameSignature,
                style: warehouseTextStyle,
              ),
            ],
          ),
          InkWell(
            onTap: () => {
              if (consignController.enterCustomerName.value.trim().isNotEmpty &&
                  consignController.customerSignatureController.isNotEmpty &&
                  consignController.enterUserName.value.trim().isNotEmpty &&
                  consignController.userSignatureController.isNotEmpty)
                {
                  consignController.clearAllNew(
                      consignController.customerSignatureController,
                      consignController.userSignatureController),
                }
            },
            child: Obx(
              () => Text(
                AppStrings.clearAll,
                style: tSw500dp12fontF.copyWith(
                  fontSize: SizeConstants.dp14,
                  color: consignController.isCustomerStartDraw.value &&
                          consignController.isStartUserSignDraw.value &&
                          consignController.enterCustomerName.value
                              .trim()
                              .isNotEmpty &&
                          consignController
                              .customerSignatureController.isNotEmpty &&
                          consignController.enterUserName.value
                              .trim()
                              .isNotEmpty &&
                          consignController.userSignatureController.isNotEmpty
                      ? AppColors.colorPrimary
                      : AppColors.colorPrimary.withOpacity(0.2),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  var outlineBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(AppValues.radius_10),
    borderSide: const BorderSide(
        width: SizeConstants.dp1, color: AppColors.colorSeparatorLine),
  );

  Widget checkboxRowUiWidget() {
    return Container(
      margin: const EdgeInsets.only(
          left: AppValues.margin_20, right: AppValues.margin_49),
      color: Colors.white,
      height: getHeight(SizeConstants.dp40),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Obx(() => Checkbox(
                value: consignController.isDigitalSignChecked.value,
                onChanged: (val) {
                  consignController.isDigitalSignChecked.value =
                      !consignController.isDigitalSignChecked.value;
                },
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppValues.radius_2),
                ),
                side: const BorderSide(
                    width: SizeConstants.dp1,
                    color: AppColors.colorCheckBoxUnselected,
                    style: BorderStyle.solid),
                activeColor: AppColors.colorCheckBoxSelected,
                checkColor: AppColors.colorWhite,
              )),
          SizedBox(
            width: getWidth(SizeConstants.dp1),
          ),
          Expanded(
            child: Text(
              maxLines: 2,
              AppStrings.addSignatureInfo,
              style: tSw400dp14fontF.copyWith(
                color: AppColors.colorMainText,
                fontSize: SizeConstants.dp16,
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget bottomButtonWidget(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(
        right: AppValues.margin_30,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          CustomButtonMaterial(
            width: getWidth(SizeConstants.dp102),
            height: getHeight(SizeConstants.dp45),
            backgroundColor: AppColors.colorWhite,
            foregroundColor: AppColors.colorPrimary,
            borderRadius: AppValues.radius_4,
            text: AppStrings.cancel,
            style: tSw500dp16fontF,
            side: const BorderSide(
              width: SizeConstants.dp1,
              color: AppColors.colorPrimary,
            ),
            onPressCallback: () {
              //clear both sign and name
              consignController.clearAllNew(
                  consignController.customerSignatureController,
                  consignController.userSignatureController);
              Get.back();
            },
          ),
          SizedBox(
            width: getWidth(SizeConstants.dp10),
          ),
          Obx(() => CustomButtonMaterial(
                width: getWidth(SizeConstants.dp130),
                height: getHeight(SizeConstants.dp45),
                backgroundColor: consignController.isCustomerStartDraw.value &&
                        consignController.isStartUserSignDraw.value &&
                        consignController.isDigitalSignChecked.value == true &&
                        consignController.enterCustomerName.value
                            .trim()
                            .isNotEmpty &&
                        consignController
                            .customerSignatureController.isNotEmpty &&
                        consignController.enterUserName.value
                            .trim()
                            .isNotEmpty &&
                        consignController.userSignatureController.isNotEmpty
                    ? AppColors.colorPrimary
                    : AppColors.colorPrimary.withOpacity(0.2),
                foregroundColor: Colors.white,
                borderRadius: AppValues.radius_4,
                text: AppStrings.confirm,
                style: tSw500dp16fontF,
                onPressCallback: () async {
                  consignController.setSignature().then((value) {
                    if (!value) {
                      showToastMsg(
                          context, AppStrings.signIssue, ToastStatus.failure);
                      return;
                    }
                    //convert logic to transfer in pdf
                    if (consignController.isDigitalSignChecked.value == true &&
                        consignController.getCustomerName().isNotEmpty &&
                        consignController.getUserName().isNotEmpty &&
                        consignController.getCustomerSignature().isNotEmpty &&
                        consignController.getSignature().isNotEmpty) {
                      consignController.loadHtml(consignController);
                      consignController.isDigitalSignDone.value = true;

                      //need to pass index because on step change we passing index of step click
                      consignController.updateStepItemStatus(
                          currentIndex: consignController.index.value);
                      consignController
                          .htmlToBase64(consignController)
                          .then((value) {
                        if (value.isNotEmpty) {
                          Get.back();
                        } else {
                          showToastMsg(Get.context!, AppStrings.wentWrong,
                              ToastStatus.failure);
                        }
                      });
                    }
                  });
                },
              )),
        ],
      ),
    );
  }
}
