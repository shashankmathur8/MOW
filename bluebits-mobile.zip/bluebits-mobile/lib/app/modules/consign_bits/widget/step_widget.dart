import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:slb_gt_mobile/app/core/values/app_utils.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/model/step_item.dart';

import '../../../core/common_widgets/no_overscroll_behavior.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../controller/consign_controller.dart';

class StepWidget extends StatefulWidget {
  ConsignController consignController;

  StepWidget({Key? key, required this.consignController}) : super(key: key);

  @override
  State<StepWidget> createState() => _StepWidgetState();
}

class _StepWidgetState extends State<StepWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.colorTopPanel.withOpacity(0.7),
      child: Container(
        margin: const EdgeInsets.only(
            left: AppValues.margin_20,
            right: AppValues.margin_20,
            top: AppValues.margin_75),
        child: ScrollConfiguration(
          behavior: NoOverscrollBehavior(),
          child: Obx(() => ListView.builder(
                scrollDirection: Axis.vertical,
                itemCount: widget.consignController.steps.length,
                itemBuilder: (ctx, index) {
                  return _stepsItem(
                      index: index,
                      stepItem: widget.consignController.steps[index]);
                },
              )),
        ),
      ),
    );
  }

  Widget _stepsItem({required int index, required StepItem stepItem}) {
    return Container(
      margin: const EdgeInsets.only(bottom: AppValues.margin_47),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: getWidth(SizeConstants.dp26),
                height: getWidth(SizeConstants.dp26),
                margin: const EdgeInsets.only(right: AppValues.margin_7),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    //For filled color background
                    stepItem.isCurrentIndex
                        ? Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.all(Radius.circular(
                                  getWidth(AppValues.radius_13))),
                              color: AppColors.colorPrimaryDarkStep,
                            ),
                          )
                        : Container(),
                    //For step done tick mark
                    !stepItem.isCurrentIndex && stepItem.isCompleted
                        ? SizedBox(
                            width: getWidth(SizeConstants.dp26),
                            height: getWidth(SizeConstants.dp26),
                            child: ImageIcon(
                              color:
                                  isNotLastStepAndOnLastStepOrIsQuoteSignedUploaded(
                                          index, stepItem)
                                      ? AppColors.colorPrimaryDarkStep.withOpacity(0.3)
                                      : AppColors.colorPrimaryDarkStep,
                              const AssetImage(
                                AppImages.icBlueTickMark,
                              ),
                            ),
                          )
                        : Container(),
                    //for show step number
                    (stepItem.isCurrentIndex && stepItem.isCompleted) ||
                            !stepItem.isCompleted
                        ? Text(
                            '${index + 1}',
                            style: tSw400dp12fontF.copyWith(
                              color:
                                  widget.consignController.index.value == index
                                      ? AppColors.colorWhite
                                      : AppColors.colorSubText.withOpacity(0.6),
                            ),
                          )
                        : Container(),
                    //for color border done/pending
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(
                            Radius.circular(getWidth(AppValues.radius_13))),
                        border: Border.all(
                            width: SizeConstants.dp1,
                            color:
                                isNotLastStepAndOnLastStepOrIsQuoteSignedUploaded(
                                        index, stepItem)
                                    ? AppColors.colorPrimaryDarkStep.withOpacity(0.3)
                                    : stepItem.isCompleted
                                        ? AppColors.colorPrimaryDarkStep
                                        : AppColors.colorSubText
                                            .withOpacity(0.6)),
                      ),
                    ),
                  ],
                ),
              ),
              Flexible(
                fit: FlexFit.tight,
                child: GestureDetector(
                  onTap: () {
                    if (index == 0 &&
                        widget.consignController.isConfirmationScreen ==
                            false &&
                        !isNotLastStepAndOnLastStepOrIsQuoteSignedUploaded(
                            index, stepItem)) {
                      widget.consignController
                          .updateStepItemStatus(currentIndex: index);
                    } else if (index == 1 &&
                        widget.consignController.isEnterDetailNextEnable &&
                        widget.consignController.isConfirmationScreen ==
                            false &&
                        !isNotLastStepAndOnLastStepOrIsQuoteSignedUploaded(
                            index, stepItem)) {
                      widget.consignController.addGenericLineItem();
                      widget.consignController
                          .updateStepItemStatus(currentIndex: index);
                    } else if (index == 2 &&
                        widget.consignController.isEnterDetailNextEnable &&
                        widget.consignController.isPriceBookNextEnable &&
                        widget.consignController.isConfirmationScreen ==
                            false) {
                      widget.consignController
                          .updateStepItemStatus(currentIndex: index);
                      widget.consignController.isQuotePreview = true;

                      // open Quote screen with default Digital sign Tab selected
                      widget.consignController
                          .openQuoteScreen(widget.consignController);
                    } else if (index == 3 &&
                        widget.consignController.isEnterDetailNextEnable &&
                        widget.consignController.isPriceBookNextEnable &&
                        widget.consignController.isQuoteNextEnable) {
                      widget.consignController.isConfirmationScreen = true;
                      widget.consignController
                          .updateStepItemStatus(currentIndex: index);
                    }
                  },
                  child: Text(
                    stepItem.title,
                    style: tSw700fontF.copyWith(
                      fontSize: SizeConstants.dp15,
                      color: isNotLastStepAndOnLastStepOrIsQuoteSignedUploaded(
                              index, stepItem)
                          ? AppColors.colorMainText.withOpacity(0.3)
                          : stepItem.isCurrentIndex || stepItem.isCompleted
                              ? AppColors.colorMainText
                              : AppColors.colorSubText.withOpacity(0.6),
                    ),
                  ),
                ),
              ),
            ],
          ),
          Row(
            children: [
              SizedBox(
                width: getWidth(SizeConstants.dp33),
              ),
              Flexible(
                fit: FlexFit.tight,
                child: Text(
                  stepItem.description,
                  style: tSw400dp12fontF.copyWith(
                    color: isNotLastStepAndOnLastStepOrIsQuoteSignedUploaded(
                            index, stepItem)
                        ? AppColors.colorSubText.withOpacity(0.3)
                        : stepItem.isCurrentIndex || stepItem.isCompleted
                            ? AppColors.colorSubText
                            : AppColors.colorSubText.withOpacity(0.6),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  bool isNotLastStepAndOnLastStepOrIsQuoteSignedUploaded(
      int index, StepItem stepItem) {
    return (index != 3 && (stepItem.isLastStep || stepItem.isSignedOrUploaded));
  }
}
