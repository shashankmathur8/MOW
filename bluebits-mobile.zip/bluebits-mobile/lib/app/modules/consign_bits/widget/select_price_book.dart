import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/common_widgets/custom_button_material.dart';
import 'package:slb_gt_mobile/app/core/common_widgets/no_overscroll_behavior.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_enum.dart';
import 'package:slb_gt_mobile/app/core/values/app_images.dart';
import 'package:slb_gt_mobile/app/core/values/app_utils.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/controller/consign_controller.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/widget/add_price_book_selection.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/widget/material_tab_view.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/widget/pricebook_line_item.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';

import '../../../core/values/app_colors.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';

class SelectPriceBook extends StatefulWidget {
  final ConsignController consignController;

  const SelectPriceBook({Key? key, required this.consignController})
      : super(key: key);

  @override
  State<SelectPriceBook> createState() => _SelectPriceBookState();
}

class _SelectPriceBookState extends State<SelectPriceBook> {
  Widget pageHeaderTitle = Text(
    AppStrings.selectPricebook,
    style: tSw400dp14fontF.copyWith(
      fontSize: SizeConstants.dp24,
      color: AppColors.colorMainText,
    ),
  );

  Widget selectedRigWidget() {
    return Text(
      widget.consignController.consignmentModel.rig?.name ?? '',
      style: tSw400dp12fontF.copyWith(
        color: AppColors.colorMainText,
      ),
    );
  }

  Widget selectedCustomerWidget() {
    return Text(
      widget.consignController.consignmentModel.customer?.name ?? '',
      style: tSw400dp12fontF.copyWith(
        color: AppColors.colorMainText,
      ),
    );
  }

  Widget selectedEmailWidget() {
    return Obx(
      () => Text(
        widget.consignController.email,
        style: tSw400dp12fontF.copyWith(
          color: AppColors.colorMainText,
        ),
      ),
    );
  }

  Widget separatorPipe() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: getWidth(AppValues.margin_13)),
      width: getWidth(SizeConstants.dp1),
      height: getHeight(SizeConstants.dp18),
      color: AppColors.colorSeparatorLine,
    );
  }

  Widget bitsListSizeWidget() {
    return Container(
      margin: EdgeInsets.only(
          left: getWidth(AppValues.margin_40),
          top: getHeight(AppValues.margin_10),
          bottom: getHeight(AppValues.margin_10),
          right: getWidth(AppValues.margin_15)),
      height: getHeight(SizeConstants.dp35),
      child: ScrollConfiguration(
        behavior: NoOverscrollBehavior(),
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: 1 +
              (widget.consignController.getBitsExceptSelected().isEmpty
                  ? 0
                  : 1),
          itemBuilder: (ctx, index) {
            if (index == 1) {
              return PopupMenuButton(
                icon: Image.asset(AppImages.clone),
                itemBuilder: (BuildContext context) {
                  return widget.consignController
                      .getBitsExceptSelected()
                      .map((String item) {
                    return PopupMenuItem<String>(
                      value: item,
                      child: Text(item.toUpperCase()),
                    );
                  }).toList();
                },
                onSelected: (String value) {
                  // Handle selected value
                  print('Bits selected value:- $value');
                  widget.consignController.cloneFullBitToAnotherBit(value);
                },
              );
            } else {
              return Obx(
                () => Container(
                    child: _bitsSelectedItem(
                        widget
                            .consignController
                            .selectedBits[
                                widget.consignController.priceBookSelectedTab]
                            .bit as Bit,
                        index)),
              );
            }
          },
        ),
      ),
    );
  }

  Widget _bitsSelectedItem(Bit selectedBit, int index) {
    return Container(
      margin: EdgeInsets.only(right: getWidth(SizeConstants.dp10)),
      padding: const EdgeInsets.all(AppValues.padding_7),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppValues.radius_6),
        border: Border.all(
            color: AppColors.colorSeparatorLine, width: SizeConstants.dp1),
        color: AppColors.transparentColor,
      ),
      child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              selectedBit.materialNumber?.toUpperCase() ?? '',
              style: tSw400dp14fontF.copyWith(
                fontSize: SizeConstants.dp15,
                color: AppColors.colorMainText,
              ),
            ),
            separatorPipe(),
            Text(
              selectedBit.inch.formatStringIfNull(),
              style: tSw400dp12fontF.copyWith(
                color: AppColors.colorSubText,
              ),
            ),
          ]),
    );
  }

  Widget dividerContainerTopWidget = Container(
      height: getHeight(SizeConstants.dp1),
      color: AppColors.colorSeparatorLine.withOpacity(0.6));

  Widget emptyLineItem() {
    return Visibility(
      visible: true,
      child: Center(
        child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset(
                AppImages.icAddPriceBook,
                width: getWidth(SizeConstants.dp105),
                height: getWidth(SizeConstants.dp105),
                fit: BoxFit.cover,
              ),
              Container(
                margin: EdgeInsets.only(
                    top: getHeight(AppValues.margin_11),
                    bottom: getHeight(AppValues.margin_36)),
                child: Text(
                  AppStrings.searchPricebookMasterCode,
                  textAlign: TextAlign.center,
                  style: tSw400dp14fontF.copyWith(
                    fontSize: SizeConstants.dp20,
                    color: AppColors.colorSubText.withOpacity(0.7),
                  ),
                ),
              ),
              CustomButtonMaterial(
                width: getWidth(SizeConstants.dp173),
                height: getHeight(SizeConstants.dp45),
                backgroundColor: AppColors.colorPrimary,
                foregroundColor: AppColors.colorWhite,
                borderRadius: AppValues.radius_4,
                text: AppStrings.addPricebook,
                style: tSw500dp16fontF.copyWith(
                  color: AppColors.colorWhite,
                ),
                iconPath: AppImages.icAddWhite,
                onPressCallback: () {
                  openBottomSheet();
                },
              ),
            ]),
      ),
    );
  }

  Widget dividerContainerBottomWidget = Container(
    color: AppColors.colorSeparatorLine,
    height: getHeight(SizeConstants.dp1),
    margin: const EdgeInsets.only(bottom: AppValues.margin_20),
  );

  Widget nextButtonWidget() {
    return Container(
      alignment: Alignment.bottomRight,
      padding: const EdgeInsets.only(
          bottom: AppValues.padding_20, right: AppValues.padding_20),
      child: Obx(
        () => CustomButtonMaterial(
          width: getWidth(SizeConstants.dp140),
          height: getHeight(SizeConstants.dp45),
          backgroundColor: widget.consignController.nextButtonStatus.value ==
                  NextButtonState.disable.name
              ? AppColors.colorPrimary.withOpacity(0.3)
              : AppColors.colorPrimary,
          foregroundColor: AppColors.colorWhite,
          borderRadius: AppValues.radius_4,
          text: AppStrings.quotePreview,
          style: tSw500dp16fontF.copyWith(
            color: widget.consignController.nextButtonStatus.value ==
                    NextButtonState.disable.name
                ? AppColors.colorWhite.withOpacity(0.4)
                : AppColors.colorWhite,
          ),
          onPressCallback: () {
            if (widget.consignController.nextButtonStatus.value ==
                NextButtonState.enable.name) {
              widget.consignController
                  .openQuoteScreen(widget.consignController);
              int index = widget.consignController.index.value + 1;
              widget.consignController
                  .updateStepItemStatus(currentIndex: index);
              widget.consignController.isQuotePreview = true;
            }
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.colorBackgroundPanel,
      child: SingleChildScrollView(
        child: SizedBox(
          height: getScreenHeight() -
              AppBar().preferredSize.height -
              SizeConstants.dp20,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                  margin: EdgeInsets.only(
                    top: getHeight(AppValues.margin_34),
                    left: getWidth(AppValues.margin_40),
                    right: getWidth(AppValues.margin_19),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          pageHeaderTitle,
                          Row(
                            children: [
                              selectedRigWidget(),
                              separatorPipe(),
                              selectedCustomerWidget(),
                              separatorPipe(),
                              selectedEmailWidget(),
                            ],
                          )
                        ],
                      ),
                      SizedBox(
                        height: getHeight(SizeConstants.dp16),
                      ),
                      MaterialTabView(),
                    ],
                  )),
              dividerContainerTopWidget,
              bitsListSizeWidget(),
              Flexible(
                fit: FlexFit.loose,
                child: Container(
                    padding: EdgeInsets.only(
                        left: getWidth(AppValues.padding_40),
                        right: getWidth(AppValues.padding_19),
                        bottom: getHeight(AppValues.padding_7)),
                    child: Obx(() =>
                        widget.consignController.noOfLineItemForSelectedBit() !=
                                0
                            ? PriceBookLineItem(
                                consignController: widget.consignController)
                            : emptyLineItem())),
              ),
              Obx(() => Visibility(
                    visible: widget.consignController.nextButtonStatus.value ==
                            NextButtonState.hide.name
                        ? false
                        : true,
                    child: Column(
                      children: [
                        dividerContainerBottomWidget,
                        nextButtonWidget(),
                      ],
                    ),
                  ))
            ],
          ),
        ),
      ),
    );
  }

  void openBottomSheet() {
    widget.consignController.selectedPriceBook = null;
    Get.bottomSheet(
      AddPriceBookSelection(),
      isDismissible: false,
      enableDrag: false,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(AppValues.radius_10),
        ),
      ),
      clipBehavior: Clip.antiAliasWithSaveLayer,
    );
  }
}
