import 'package:get/get.dart';

class TicketingBitsBinding extends Bindings {
  @override
  void dependencies() {
    //Get.put(TicketingBitsController(), tag: (TicketingBitsController).toString(), permanent: false);
  }
}
