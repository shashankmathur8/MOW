import 'package:realm/realm.dart';
part 'wells_schema.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.

@RealmModel()
class _Well {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;

  String? bottomDatum;

  String? bottomLatitude;

  String? bottomLongitude;

  DateTime? completionDate;

  late String country;

  String? county;

  DateTime? createdDate;

  String? description;

  String? fieldName;

  DateTime? lastUpdatedDate;

  String? name;

  String? number;

  String? operatingEnvironment;

  DateTime? permitIssueDate;

  String? postalCode;

  String? sourceSystem;

  String? state;

  late String status;

  String? surfaceDatum;

  String? surfaceLatitude;

  String? surfaceLongitude;

  String? wellId;
}
