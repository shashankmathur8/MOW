import 'package:realm/realm.dart';
part 'sales_representative_schema.g.dart';
// NOTE: These Realm models are private and therefore should be copied into the same .dart file.
@RealmModel()
class _SalesRepresentative {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;
  String? alias;
  String? fullName;
  String? plantId;
  String? refId;
  String? role;
  String? value;
}