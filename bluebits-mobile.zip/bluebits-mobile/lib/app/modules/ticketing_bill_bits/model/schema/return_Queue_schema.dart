import 'package:realm/realm.dart';
part 'return_Queue_schema.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.

@RealmModel()
class _ReturnQueue {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;

  late List<_ReturnQueueBits> bits;

  String? comments;

  DateTime? consignmentDate;

  String? consignmentNumber;

  DateTime? createdAt;

  String? createdBy;

  String? createdByFullName;

  String? destinationPlant;

  String? destinationStorageLocation;

  bool? isProcessing;

  String? lat;

  String? long;

  DateTime? modifiedAt;

  String? modifiedBy;

  String? modifiedByFullName;

  String? returnTicketNumber;

  String? sourcePlant;

  String? sourceStorageLocation;

  String? truckUserMappingId;
}

@RealmModel(ObjectType.embeddedObject)
@MapTo('ReturnQueue_bits')
class _ReturnQueueBits {
  String? comments;

  String? materialId;

  String? runFlag;

  String? serialNumber;

  String? uom;

  String? valuationType;
}

