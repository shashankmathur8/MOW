import 'package:realm/realm.dart';
part 'ticketing_Queue_schema.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.

@RealmModel()
class _TicketQueue {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;

  late List<_TicketQueueBits> bits;

  String? consignmentId;

  DateTime? createdAt;

  String? createdBy;

  String? createdByFullName;

  String? destinationPlant;

  String? destinationStorageLocation;

  DateTime? modifiedAt;

  String? modifiedBy;

  String? modifiedByFullName;

  String? sourcePlant;

  String? sourceStorageLocation;

  String? ticketId;

  String? truckUserMappingId;
}
@RealmModel(ObjectType.embeddedObject)
@MapTo('TicketQueue_bits')
class _TicketQueueBits {
  String? billFlag;

  String? materialId;

  String? pickupFlag;

  String? serialNumber;

  String? uom;

  String? valuationType;
}


