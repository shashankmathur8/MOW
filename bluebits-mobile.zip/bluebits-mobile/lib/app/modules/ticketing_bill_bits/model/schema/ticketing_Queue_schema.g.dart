// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ticketing_Queue_schema.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class TicketQueue extends _TicketQueue
    with RealmEntity, RealmObjectBase, RealmObject {
  TicketQueue(
    ObjectId? id, {
    String? consignmentId,
    DateTime? createdAt,
    String? createdBy,
    String? createdByFullName,
    String? destinationPlant,
    String? destinationStorageLocation,
    DateTime? modifiedAt,
    String? modifiedBy,
    String? modifiedByFullName,
    String? sourcePlant,
    String? sourceStorageLocation,
    String? ticketId,
    String? truckUserMappingId,
    Iterable<TicketQueueBits> bits = const [],
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'consignmentId', consignmentId);
    RealmObjectBase.set(this, 'createdAt', createdAt);
    RealmObjectBase.set(this, 'createdBy', createdBy);
    RealmObjectBase.set(this, 'createdByFullName', createdByFullName);
    RealmObjectBase.set(this, 'destinationPlant', destinationPlant);
    RealmObjectBase.set(
        this, 'destinationStorageLocation', destinationStorageLocation);
    RealmObjectBase.set(this, 'modifiedAt', modifiedAt);
    RealmObjectBase.set(this, 'modifiedBy', modifiedBy);
    RealmObjectBase.set(this, 'modifiedByFullName', modifiedByFullName);
    RealmObjectBase.set(this, 'sourcePlant', sourcePlant);
    RealmObjectBase.set(this, 'sourceStorageLocation', sourceStorageLocation);
    RealmObjectBase.set(this, 'ticketId', ticketId);
    RealmObjectBase.set(this, 'truckUserMappingId', truckUserMappingId);
    RealmObjectBase.set<RealmList<TicketQueueBits>>(
        this, 'bits', RealmList<TicketQueueBits>(bits));
  }

  TicketQueue._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  RealmList<TicketQueueBits> get bits =>
      RealmObjectBase.get<TicketQueueBits>(this, 'bits')
          as RealmList<TicketQueueBits>;
  @override
  set bits(covariant RealmList<TicketQueueBits> value) =>
      throw RealmUnsupportedSetError();

  @override
  String? get consignmentId =>
      RealmObjectBase.get<String>(this, 'consignmentId') as String?;
  @override
  set consignmentId(String? value) =>
      RealmObjectBase.set(this, 'consignmentId', value);

  @override
  DateTime? get createdAt =>
      RealmObjectBase.get<DateTime>(this, 'createdAt') as DateTime?;
  @override
  set createdAt(DateTime? value) =>
      RealmObjectBase.set(this, 'createdAt', value);

  @override
  String? get createdBy =>
      RealmObjectBase.get<String>(this, 'createdBy') as String?;
  @override
  set createdBy(String? value) => RealmObjectBase.set(this, 'createdBy', value);

  @override
  String? get createdByFullName =>
      RealmObjectBase.get<String>(this, 'createdByFullName') as String?;
  @override
  set createdByFullName(String? value) =>
      RealmObjectBase.set(this, 'createdByFullName', value);

  @override
  String? get destinationPlant =>
      RealmObjectBase.get<String>(this, 'destinationPlant') as String?;
  @override
  set destinationPlant(String? value) =>
      RealmObjectBase.set(this, 'destinationPlant', value);

  @override
  String? get destinationStorageLocation =>
      RealmObjectBase.get<String>(this, 'destinationStorageLocation')
          as String?;
  @override
  set destinationStorageLocation(String? value) =>
      RealmObjectBase.set(this, 'destinationStorageLocation', value);

  @override
  DateTime? get modifiedAt =>
      RealmObjectBase.get<DateTime>(this, 'modifiedAt') as DateTime?;
  @override
  set modifiedAt(DateTime? value) =>
      RealmObjectBase.set(this, 'modifiedAt', value);

  @override
  String? get modifiedBy =>
      RealmObjectBase.get<String>(this, 'modifiedBy') as String?;
  @override
  set modifiedBy(String? value) =>
      RealmObjectBase.set(this, 'modifiedBy', value);

  @override
  String? get modifiedByFullName =>
      RealmObjectBase.get<String>(this, 'modifiedByFullName') as String?;
  @override
  set modifiedByFullName(String? value) =>
      RealmObjectBase.set(this, 'modifiedByFullName', value);

  @override
  String? get sourcePlant =>
      RealmObjectBase.get<String>(this, 'sourcePlant') as String?;
  @override
  set sourcePlant(String? value) =>
      RealmObjectBase.set(this, 'sourcePlant', value);

  @override
  String? get sourceStorageLocation =>
      RealmObjectBase.get<String>(this, 'sourceStorageLocation') as String?;
  @override
  set sourceStorageLocation(String? value) =>
      RealmObjectBase.set(this, 'sourceStorageLocation', value);

  @override
  String? get ticketId =>
      RealmObjectBase.get<String>(this, 'ticketId') as String?;
  @override
  set ticketId(String? value) => RealmObjectBase.set(this, 'ticketId', value);

  @override
  String? get truckUserMappingId =>
      RealmObjectBase.get<String>(this, 'truckUserMappingId') as String?;
  @override
  set truckUserMappingId(String? value) =>
      RealmObjectBase.set(this, 'truckUserMappingId', value);

  @override
  Stream<RealmObjectChanges<TicketQueue>> get changes =>
      RealmObjectBase.getChanges<TicketQueue>(this);

  @override
  TicketQueue freeze() => RealmObjectBase.freezeObject<TicketQueue>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(TicketQueue._);
    return const SchemaObject(
        ObjectType.realmObject, TicketQueue, 'TicketQueue', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('bits', RealmPropertyType.object,
          linkTarget: 'TicketQueue_bits',
          collectionType: RealmCollectionType.list),
      SchemaProperty('consignmentId', RealmPropertyType.string, optional: true),
      SchemaProperty('createdAt', RealmPropertyType.timestamp, optional: true),
      SchemaProperty('createdBy', RealmPropertyType.string, optional: true),
      SchemaProperty('createdByFullName', RealmPropertyType.string,
          optional: true),
      SchemaProperty('destinationPlant', RealmPropertyType.string,
          optional: true),
      SchemaProperty('destinationStorageLocation', RealmPropertyType.string,
          optional: true),
      SchemaProperty('modifiedAt', RealmPropertyType.timestamp, optional: true),
      SchemaProperty('modifiedBy', RealmPropertyType.string, optional: true),
      SchemaProperty('modifiedByFullName', RealmPropertyType.string,
          optional: true),
      SchemaProperty('sourcePlant', RealmPropertyType.string, optional: true),
      SchemaProperty('sourceStorageLocation', RealmPropertyType.string,
          optional: true),
      SchemaProperty('ticketId', RealmPropertyType.string, optional: true),
      SchemaProperty('truckUserMappingId', RealmPropertyType.string,
          optional: true),
    ]);
  }
}

class TicketQueueBits extends _TicketQueueBits
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  TicketQueueBits({
    String? billFlag,
    String? materialId,
    String? pickupFlag,
    String? serialNumber,
    String? uom,
    String? valuationType,
  }) {
    RealmObjectBase.set(this, 'billFlag', billFlag);
    RealmObjectBase.set(this, 'materialId', materialId);
    RealmObjectBase.set(this, 'pickupFlag', pickupFlag);
    RealmObjectBase.set(this, 'serialNumber', serialNumber);
    RealmObjectBase.set(this, 'uom', uom);
    RealmObjectBase.set(this, 'valuationType', valuationType);
  }

  TicketQueueBits._();

  @override
  String? get billFlag =>
      RealmObjectBase.get<String>(this, 'billFlag') as String?;
  @override
  set billFlag(String? value) => RealmObjectBase.set(this, 'billFlag', value);

  @override
  String? get materialId =>
      RealmObjectBase.get<String>(this, 'materialId') as String?;
  @override
  set materialId(String? value) =>
      RealmObjectBase.set(this, 'materialId', value);

  @override
  String? get pickupFlag =>
      RealmObjectBase.get<String>(this, 'pickupFlag') as String?;
  @override
  set pickupFlag(String? value) =>
      RealmObjectBase.set(this, 'pickupFlag', value);

  @override
  String? get serialNumber =>
      RealmObjectBase.get<String>(this, 'serialNumber') as String?;
  @override
  set serialNumber(String? value) =>
      RealmObjectBase.set(this, 'serialNumber', value);

  @override
  String? get uom => RealmObjectBase.get<String>(this, 'uom') as String?;
  @override
  set uom(String? value) => RealmObjectBase.set(this, 'uom', value);

  @override
  String? get valuationType =>
      RealmObjectBase.get<String>(this, 'valuationType') as String?;
  @override
  set valuationType(String? value) =>
      RealmObjectBase.set(this, 'valuationType', value);

  @override
  Stream<RealmObjectChanges<TicketQueueBits>> get changes =>
      RealmObjectBase.getChanges<TicketQueueBits>(this);

  @override
  TicketQueueBits freeze() =>
      RealmObjectBase.freezeObject<TicketQueueBits>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(TicketQueueBits._);
    return const SchemaObject(
        ObjectType.embeddedObject, TicketQueueBits, 'TicketQueue_bits', [
      SchemaProperty('billFlag', RealmPropertyType.string, optional: true),
      SchemaProperty('materialId', RealmPropertyType.string, optional: true),
      SchemaProperty('pickupFlag', RealmPropertyType.string, optional: true),
      SchemaProperty('serialNumber', RealmPropertyType.string, optional: true),
      SchemaProperty('uom', RealmPropertyType.string, optional: true),
      SchemaProperty('valuationType', RealmPropertyType.string, optional: true),
    ]);
  }
}
