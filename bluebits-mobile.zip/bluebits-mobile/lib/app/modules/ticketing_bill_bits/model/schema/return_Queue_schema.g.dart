// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'return_Queue_schema.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class ReturnQueue extends _ReturnQueue
    with RealmEntity, RealmObjectBase, RealmObject {
  ReturnQueue(
    ObjectId? id, {
    String? comments,
    DateTime? consignmentDate,
    String? consignmentNumber,
    DateTime? createdAt,
    String? createdBy,
    String? createdByFullName,
    String? destinationPlant,
    String? destinationStorageLocation,
    bool? isProcessing,
    String? lat,
    String? long,
    DateTime? modifiedAt,
    String? modifiedBy,
    String? modifiedByFullName,
    String? returnTicketNumber,
    String? sourcePlant,
    String? sourceStorageLocation,
    String? truckUserMappingId,
    Iterable<ReturnQueueBits> bits = const [],
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'comments', comments);
    RealmObjectBase.set(this, 'consignmentDate', consignmentDate);
    RealmObjectBase.set(this, 'consignmentNumber', consignmentNumber);
    RealmObjectBase.set(this, 'createdAt', createdAt);
    RealmObjectBase.set(this, 'createdBy', createdBy);
    RealmObjectBase.set(this, 'createdByFullName', createdByFullName);
    RealmObjectBase.set(this, 'destinationPlant', destinationPlant);
    RealmObjectBase.set(
        this, 'destinationStorageLocation', destinationStorageLocation);
    RealmObjectBase.set(this, 'isProcessing', isProcessing);
    RealmObjectBase.set(this, 'lat', lat);
    RealmObjectBase.set(this, 'long', long);
    RealmObjectBase.set(this, 'modifiedAt', modifiedAt);
    RealmObjectBase.set(this, 'modifiedBy', modifiedBy);
    RealmObjectBase.set(this, 'modifiedByFullName', modifiedByFullName);
    RealmObjectBase.set(this, 'returnTicketNumber', returnTicketNumber);
    RealmObjectBase.set(this, 'sourcePlant', sourcePlant);
    RealmObjectBase.set(this, 'sourceStorageLocation', sourceStorageLocation);
    RealmObjectBase.set(this, 'truckUserMappingId', truckUserMappingId);
    RealmObjectBase.set<RealmList<ReturnQueueBits>>(
        this, 'bits', RealmList<ReturnQueueBits>(bits));
  }

  ReturnQueue._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  RealmList<ReturnQueueBits> get bits =>
      RealmObjectBase.get<ReturnQueueBits>(this, 'bits')
          as RealmList<ReturnQueueBits>;
  @override
  set bits(covariant RealmList<ReturnQueueBits> value) =>
      throw RealmUnsupportedSetError();

  @override
  String? get comments =>
      RealmObjectBase.get<String>(this, 'comments') as String?;
  @override
  set comments(String? value) => RealmObjectBase.set(this, 'comments', value);

  @override
  DateTime? get consignmentDate =>
      RealmObjectBase.get<DateTime>(this, 'consignmentDate') as DateTime?;
  @override
  set consignmentDate(DateTime? value) =>
      RealmObjectBase.set(this, 'consignmentDate', value);

  @override
  String? get consignmentNumber =>
      RealmObjectBase.get<String>(this, 'consignmentNumber') as String?;
  @override
  set consignmentNumber(String? value) =>
      RealmObjectBase.set(this, 'consignmentNumber', value);

  @override
  DateTime? get createdAt =>
      RealmObjectBase.get<DateTime>(this, 'createdAt') as DateTime?;
  @override
  set createdAt(DateTime? value) =>
      RealmObjectBase.set(this, 'createdAt', value);

  @override
  String? get createdBy =>
      RealmObjectBase.get<String>(this, 'createdBy') as String?;
  @override
  set createdBy(String? value) => RealmObjectBase.set(this, 'createdBy', value);

  @override
  String? get createdByFullName =>
      RealmObjectBase.get<String>(this, 'createdByFullName') as String?;
  @override
  set createdByFullName(String? value) =>
      RealmObjectBase.set(this, 'createdByFullName', value);

  @override
  String? get destinationPlant =>
      RealmObjectBase.get<String>(this, 'destinationPlant') as String?;
  @override
  set destinationPlant(String? value) =>
      RealmObjectBase.set(this, 'destinationPlant', value);

  @override
  String? get destinationStorageLocation =>
      RealmObjectBase.get<String>(this, 'destinationStorageLocation')
          as String?;
  @override
  set destinationStorageLocation(String? value) =>
      RealmObjectBase.set(this, 'destinationStorageLocation', value);

  @override
  bool? get isProcessing =>
      RealmObjectBase.get<bool>(this, 'isProcessing') as bool?;
  @override
  set isProcessing(bool? value) =>
      RealmObjectBase.set(this, 'isProcessing', value);

  @override
  String? get lat => RealmObjectBase.get<String>(this, 'lat') as String?;
  @override
  set lat(String? value) => RealmObjectBase.set(this, 'lat', value);

  @override
  String? get long => RealmObjectBase.get<String>(this, 'long') as String?;
  @override
  set long(String? value) => RealmObjectBase.set(this, 'long', value);

  @override
  DateTime? get modifiedAt =>
      RealmObjectBase.get<DateTime>(this, 'modifiedAt') as DateTime?;
  @override
  set modifiedAt(DateTime? value) =>
      RealmObjectBase.set(this, 'modifiedAt', value);

  @override
  String? get modifiedBy =>
      RealmObjectBase.get<String>(this, 'modifiedBy') as String?;
  @override
  set modifiedBy(String? value) =>
      RealmObjectBase.set(this, 'modifiedBy', value);

  @override
  String? get modifiedByFullName =>
      RealmObjectBase.get<String>(this, 'modifiedByFullName') as String?;
  @override
  set modifiedByFullName(String? value) =>
      RealmObjectBase.set(this, 'modifiedByFullName', value);

  @override
  String? get returnTicketNumber =>
      RealmObjectBase.get<String>(this, 'returnTicketNumber') as String?;
  @override
  set returnTicketNumber(String? value) =>
      RealmObjectBase.set(this, 'returnTicketNumber', value);

  @override
  String? get sourcePlant =>
      RealmObjectBase.get<String>(this, 'sourcePlant') as String?;
  @override
  set sourcePlant(String? value) =>
      RealmObjectBase.set(this, 'sourcePlant', value);

  @override
  String? get sourceStorageLocation =>
      RealmObjectBase.get<String>(this, 'sourceStorageLocation') as String?;
  @override
  set sourceStorageLocation(String? value) =>
      RealmObjectBase.set(this, 'sourceStorageLocation', value);

  @override
  String? get truckUserMappingId =>
      RealmObjectBase.get<String>(this, 'truckUserMappingId') as String?;
  @override
  set truckUserMappingId(String? value) =>
      RealmObjectBase.set(this, 'truckUserMappingId', value);

  @override
  Stream<RealmObjectChanges<ReturnQueue>> get changes =>
      RealmObjectBase.getChanges<ReturnQueue>(this);

  @override
  ReturnQueue freeze() => RealmObjectBase.freezeObject<ReturnQueue>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(ReturnQueue._);
    return const SchemaObject(
        ObjectType.realmObject, ReturnQueue, 'ReturnQueue', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('bits', RealmPropertyType.object,
          linkTarget: 'ReturnQueue_bits',
          collectionType: RealmCollectionType.list),
      SchemaProperty('comments', RealmPropertyType.string, optional: true),
      SchemaProperty('consignmentDate', RealmPropertyType.timestamp,
          optional: true),
      SchemaProperty('consignmentNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('createdAt', RealmPropertyType.timestamp, optional: true),
      SchemaProperty('createdBy', RealmPropertyType.string, optional: true),
      SchemaProperty('createdByFullName', RealmPropertyType.string,
          optional: true),
      SchemaProperty('destinationPlant', RealmPropertyType.string,
          optional: true),
      SchemaProperty('destinationStorageLocation', RealmPropertyType.string,
          optional: true),
      SchemaProperty('isProcessing', RealmPropertyType.bool, optional: true),
      SchemaProperty('lat', RealmPropertyType.string, optional: true),
      SchemaProperty('long', RealmPropertyType.string, optional: true),
      SchemaProperty('modifiedAt', RealmPropertyType.timestamp, optional: true),
      SchemaProperty('modifiedBy', RealmPropertyType.string, optional: true),
      SchemaProperty('modifiedByFullName', RealmPropertyType.string,
          optional: true),
      SchemaProperty('returnTicketNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('sourcePlant', RealmPropertyType.string, optional: true),
      SchemaProperty('sourceStorageLocation', RealmPropertyType.string,
          optional: true),
      SchemaProperty('truckUserMappingId', RealmPropertyType.string,
          optional: true),
    ]);
  }
}

class ReturnQueueBits extends _ReturnQueueBits
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  ReturnQueueBits({
    String? comments,
    String? materialId,
    String? runFlag,
    String? serialNumber,
    String? uom,
    String? valuationType,
  }) {
    RealmObjectBase.set(this, 'comments', comments);
    RealmObjectBase.set(this, 'materialId', materialId);
    RealmObjectBase.set(this, 'runFlag', runFlag);
    RealmObjectBase.set(this, 'serialNumber', serialNumber);
    RealmObjectBase.set(this, 'uom', uom);
    RealmObjectBase.set(this, 'valuationType', valuationType);
  }

  ReturnQueueBits._();

  @override
  String? get comments =>
      RealmObjectBase.get<String>(this, 'comments') as String?;
  @override
  set comments(String? value) => RealmObjectBase.set(this, 'comments', value);

  @override
  String? get materialId =>
      RealmObjectBase.get<String>(this, 'materialId') as String?;
  @override
  set materialId(String? value) =>
      RealmObjectBase.set(this, 'materialId', value);

  @override
  String? get runFlag =>
      RealmObjectBase.get<String>(this, 'runFlag') as String?;
  @override
  set runFlag(String? value) => RealmObjectBase.set(this, 'runFlag', value);

  @override
  String? get serialNumber =>
      RealmObjectBase.get<String>(this, 'serialNumber') as String?;
  @override
  set serialNumber(String? value) =>
      RealmObjectBase.set(this, 'serialNumber', value);

  @override
  String? get uom => RealmObjectBase.get<String>(this, 'uom') as String?;
  @override
  set uom(String? value) => RealmObjectBase.set(this, 'uom', value);

  @override
  String? get valuationType =>
      RealmObjectBase.get<String>(this, 'valuationType') as String?;
  @override
  set valuationType(String? value) =>
      RealmObjectBase.set(this, 'valuationType', value);

  @override
  Stream<RealmObjectChanges<ReturnQueueBits>> get changes =>
      RealmObjectBase.getChanges<ReturnQueueBits>(this);

  @override
  ReturnQueueBits freeze() =>
      RealmObjectBase.freezeObject<ReturnQueueBits>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(ReturnQueueBits._);
    return const SchemaObject(
        ObjectType.embeddedObject, ReturnQueueBits, 'ReturnQueue_bits', [
      SchemaProperty('comments', RealmPropertyType.string, optional: true),
      SchemaProperty('materialId', RealmPropertyType.string, optional: true),
      SchemaProperty('runFlag', RealmPropertyType.string, optional: true),
      SchemaProperty('serialNumber', RealmPropertyType.string, optional: true),
      SchemaProperty('uom', RealmPropertyType.string, optional: true),
      SchemaProperty('valuationType', RealmPropertyType.string, optional: true),
    ]);
  }
}
