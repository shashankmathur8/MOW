// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ticketing_schema.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class Ticket extends _Ticket with RealmEntity, RealmObjectBase, RealmObject {
  Ticket(
    ObjectId? id, {
    String? statusMessage,
    String? activityId,
    String? billToCustomerId,
    String? cEC,
    String? consignmentGuid,
    String? consignmentId,
    String? consumptionType,
    DateTime? createdAt,
    String? createdBy,
    String? createdByFullName,
    String? customerEmail,
    String? ticketingId,
    String? wellName,
    DateTime? endDate,
    String? finalPdf,
    String? gTQuoteId,
    bool? isEmailSent,
    String? lat,
    String? long,
    bool? ticketLater,
    String? modifiedBy,
    String? truckUserMappingId,
    String? wellId,
    String? wellNumber,
    String? rigContractor,
    String? rigId,
    String? rigName,
    String? shipToCustomerId,
    DateTime? startDate,
    String? status,
    String? wBSNumber,
    String? customerId,
    String? modifiedByFullName,
    String? customerName,
    String? operationId,
    String? designEngineer,
    String? projectId,
    Iterable<TicketBits> bits = const [],
    Iterable<TicketDigitalAttachments> digitalAttachments = const [],
    Iterable<TicketManualAttachments> manualAttachments = const [],
  }) {
    RealmObjectBase.set(this, 'statusMessage', statusMessage);
    RealmObjectBase.set(this, 'activityId', activityId);
    RealmObjectBase.set(this, 'billToCustomerId', billToCustomerId);
    RealmObjectBase.set(this, 'cEC', cEC);
    RealmObjectBase.set(this, 'consignmentGuid', consignmentGuid);
    RealmObjectBase.set(this, 'consignmentId', consignmentId);
    RealmObjectBase.set(this, 'consumptionType', consumptionType);
    RealmObjectBase.set(this, 'createdAt', createdAt);
    RealmObjectBase.set(this, 'createdBy', createdBy);
    RealmObjectBase.set(this, 'createdByFullName', createdByFullName);
    RealmObjectBase.set(this, 'customerEmail', customerEmail);
    RealmObjectBase.set(this, 'ticketingId', ticketingId);
    RealmObjectBase.set(this, 'wellName', wellName);
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'endDate', endDate);
    RealmObjectBase.set(this, 'finalPdf', finalPdf);
    RealmObjectBase.set(this, 'gTQuoteId', gTQuoteId);
    RealmObjectBase.set(this, 'isEmailSent', isEmailSent);
    RealmObjectBase.set(this, 'lat', lat);
    RealmObjectBase.set(this, 'long', long);
    RealmObjectBase.set(this, 'ticketLater', ticketLater);
    RealmObjectBase.set(this, 'modifiedBy', modifiedBy);
    RealmObjectBase.set(this, 'truckUserMappingId', truckUserMappingId);
    RealmObjectBase.set(this, 'wellId', wellId);
    RealmObjectBase.set(this, 'wellNumber', wellNumber);
    RealmObjectBase.set(this, 'rigContractor', rigContractor);
    RealmObjectBase.set(this, 'rigId', rigId);
    RealmObjectBase.set(this, 'rigName', rigName);
    RealmObjectBase.set(this, 'shipToCustomerId', shipToCustomerId);
    RealmObjectBase.set(this, 'startDate', startDate);
    RealmObjectBase.set(this, 'status', status);
    RealmObjectBase.set(this, 'wBSNumber', wBSNumber);
    RealmObjectBase.set(this, 'customerId', customerId);
    RealmObjectBase.set(this, 'modifiedByFullName', modifiedByFullName);
    RealmObjectBase.set(this, 'customerName', customerName);
    RealmObjectBase.set(this, 'operationId', operationId);
    RealmObjectBase.set(this, 'designEngineer', designEngineer);
    RealmObjectBase.set(this, 'projectId', projectId);
    RealmObjectBase.set<RealmList<TicketBits>>(
        this, 'bits', RealmList<TicketBits>(bits));
    RealmObjectBase.set<RealmList<TicketDigitalAttachments>>(
        this,
        'digitalAttachments',
        RealmList<TicketDigitalAttachments>(digitalAttachments));
    RealmObjectBase.set<RealmList<TicketManualAttachments>>(
        this,
        'manualAttachments',
        RealmList<TicketManualAttachments>(manualAttachments));
  }

  Ticket._();

  @override
  String? get statusMessage =>
      RealmObjectBase.get<String>(this, 'statusMessage') as String?;
  @override
  set statusMessage(String? value) =>
      RealmObjectBase.set(this, 'statusMessage', value);

  @override
  String? get activityId =>
      RealmObjectBase.get<String>(this, 'activityId') as String?;
  @override
  set activityId(String? value) =>
      RealmObjectBase.set(this, 'activityId', value);

  @override
  String? get billToCustomerId =>
      RealmObjectBase.get<String>(this, 'billToCustomerId') as String?;
  @override
  set billToCustomerId(String? value) =>
      RealmObjectBase.set(this, 'billToCustomerId', value);

  @override
  RealmList<TicketBits> get bits =>
      RealmObjectBase.get<TicketBits>(this, 'bits') as RealmList<TicketBits>;
  @override
  set bits(covariant RealmList<TicketBits> value) =>
      throw RealmUnsupportedSetError();

  @override
  String? get cEC => RealmObjectBase.get<String>(this, 'cEC') as String?;
  @override
  set cEC(String? value) => RealmObjectBase.set(this, 'cEC', value);

  @override
  String? get consignmentGuid =>
      RealmObjectBase.get<String>(this, 'consignmentGuid') as String?;
  @override
  set consignmentGuid(String? value) =>
      RealmObjectBase.set(this, 'consignmentGuid', value);

  @override
  String? get consignmentId =>
      RealmObjectBase.get<String>(this, 'consignmentId') as String?;
  @override
  set consignmentId(String? value) =>
      RealmObjectBase.set(this, 'consignmentId', value);

  @override
  String? get consumptionType =>
      RealmObjectBase.get<String>(this, 'consumptionType') as String?;
  @override
  set consumptionType(String? value) =>
      RealmObjectBase.set(this, 'consumptionType', value);

  @override
  DateTime? get createdAt =>
      RealmObjectBase.get<DateTime>(this, 'createdAt') as DateTime?;
  @override
  set createdAt(DateTime? value) =>
      RealmObjectBase.set(this, 'createdAt', value);

  @override
  String? get createdBy =>
      RealmObjectBase.get<String>(this, 'createdBy') as String?;
  @override
  set createdBy(String? value) => RealmObjectBase.set(this, 'createdBy', value);

  @override
  String? get createdByFullName =>
      RealmObjectBase.get<String>(this, 'createdByFullName') as String?;
  @override
  set createdByFullName(String? value) =>
      RealmObjectBase.set(this, 'createdByFullName', value);

  @override
  String? get customerEmail =>
      RealmObjectBase.get<String>(this, 'customerEmail') as String?;
  @override
  set customerEmail(String? value) =>
      RealmObjectBase.set(this, 'customerEmail', value);

  @override
  String? get ticketingId =>
      RealmObjectBase.get<String>(this, 'ticketingId') as String?;
  @override
  set ticketingId(String? value) =>
      RealmObjectBase.set(this, 'ticketingId', value);

  @override
  String? get wellName =>
      RealmObjectBase.get<String>(this, 'wellName') as String?;
  @override
  set wellName(String? value) => RealmObjectBase.set(this, 'wellName', value);

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  RealmList<TicketDigitalAttachments> get digitalAttachments =>
      RealmObjectBase.get<TicketDigitalAttachments>(this, 'digitalAttachments')
          as RealmList<TicketDigitalAttachments>;
  @override
  set digitalAttachments(covariant RealmList<TicketDigitalAttachments> value) =>
      throw RealmUnsupportedSetError();

  @override
  DateTime? get endDate =>
      RealmObjectBase.get<DateTime>(this, 'endDate') as DateTime?;
  @override
  set endDate(DateTime? value) => RealmObjectBase.set(this, 'endDate', value);

  @override
  String? get finalPdf =>
      RealmObjectBase.get<String>(this, 'finalPdf') as String?;
  @override
  set finalPdf(String? value) => RealmObjectBase.set(this, 'finalPdf', value);

  @override
  String? get gTQuoteId =>
      RealmObjectBase.get<String>(this, 'gTQuoteId') as String?;
  @override
  set gTQuoteId(String? value) => RealmObjectBase.set(this, 'gTQuoteId', value);

  @override
  bool? get isEmailSent =>
      RealmObjectBase.get<bool>(this, 'isEmailSent') as bool?;
  @override
  set isEmailSent(bool? value) =>
      RealmObjectBase.set(this, 'isEmailSent', value);

  @override
  String? get lat => RealmObjectBase.get<String>(this, 'lat') as String?;
  @override
  set lat(String? value) => RealmObjectBase.set(this, 'lat', value);

  @override
  String? get long => RealmObjectBase.get<String>(this, 'long') as String?;
  @override
  set long(String? value) => RealmObjectBase.set(this, 'long', value);

  @override
  bool? get ticketLater =>
      RealmObjectBase.get<bool>(this, 'ticketLater') as bool?;
  @override
  set ticketLater(bool? value) =>
      RealmObjectBase.set(this, 'ticketLater', value);

  @override
  String? get modifiedBy =>
      RealmObjectBase.get<String>(this, 'modifiedBy') as String?;
  @override
  set modifiedBy(String? value) =>
      RealmObjectBase.set(this, 'modifiedBy', value);

  @override
  String? get truckUserMappingId =>
      RealmObjectBase.get<String>(this, 'truckUserMappingId') as String?;
  @override
  set truckUserMappingId(String? value) =>
      RealmObjectBase.set(this, 'truckUserMappingId', value);

  @override
  String? get wellId => RealmObjectBase.get<String>(this, 'wellId') as String?;
  @override
  set wellId(String? value) => RealmObjectBase.set(this, 'wellId', value);

  @override
  String? get wellNumber =>
      RealmObjectBase.get<String>(this, 'wellNumber') as String?;
  @override
  set wellNumber(String? value) =>
      RealmObjectBase.set(this, 'wellNumber', value);

  @override
  String? get rigContractor =>
      RealmObjectBase.get<String>(this, 'rigContractor') as String?;
  @override
  set rigContractor(String? value) =>
      RealmObjectBase.set(this, 'rigContractor', value);

  @override
  String? get rigId => RealmObjectBase.get<String>(this, 'rigId') as String?;
  @override
  set rigId(String? value) => RealmObjectBase.set(this, 'rigId', value);

  @override
  String? get rigName =>
      RealmObjectBase.get<String>(this, 'rigName') as String?;
  @override
  set rigName(String? value) => RealmObjectBase.set(this, 'rigName', value);

  @override
  String? get shipToCustomerId =>
      RealmObjectBase.get<String>(this, 'shipToCustomerId') as String?;
  @override
  set shipToCustomerId(String? value) =>
      RealmObjectBase.set(this, 'shipToCustomerId', value);

  @override
  DateTime? get startDate =>
      RealmObjectBase.get<DateTime>(this, 'startDate') as DateTime?;
  @override
  set startDate(DateTime? value) =>
      RealmObjectBase.set(this, 'startDate', value);

  @override
  String? get status => RealmObjectBase.get<String>(this, 'status') as String?;
  @override
  set status(String? value) => RealmObjectBase.set(this, 'status', value);

  @override
  String? get wBSNumber =>
      RealmObjectBase.get<String>(this, 'wBSNumber') as String?;
  @override
  set wBSNumber(String? value) => RealmObjectBase.set(this, 'wBSNumber', value);

  @override
  RealmList<TicketManualAttachments> get manualAttachments =>
      RealmObjectBase.get<TicketManualAttachments>(this, 'manualAttachments')
          as RealmList<TicketManualAttachments>;
  @override
  set manualAttachments(covariant RealmList<TicketManualAttachments> value) =>
      throw RealmUnsupportedSetError();

  @override
  String? get customerId =>
      RealmObjectBase.get<String>(this, 'customerId') as String?;
  @override
  set customerId(String? value) =>
      RealmObjectBase.set(this, 'customerId', value);

  @override
  String? get modifiedByFullName =>
      RealmObjectBase.get<String>(this, 'modifiedByFullName') as String?;
  @override
  set modifiedByFullName(String? value) =>
      RealmObjectBase.set(this, 'modifiedByFullName', value);

  @override
  String? get customerName =>
      RealmObjectBase.get<String>(this, 'customerName') as String?;
  @override
  set customerName(String? value) =>
      RealmObjectBase.set(this, 'customerName', value);

  @override
  String? get operationId =>
      RealmObjectBase.get<String>(this, 'operationId') as String?;
  @override
  set operationId(String? value) =>
      RealmObjectBase.set(this, 'operationId', value);

  @override
  String? get designEngineer =>
      RealmObjectBase.get<String>(this, 'designEngineer') as String?;
  @override
  set designEngineer(String? value) =>
      RealmObjectBase.set(this, 'designEngineer', value);

  @override
  String? get projectId =>
      RealmObjectBase.get<String>(this, 'projectId') as String?;
  @override
  set projectId(String? value) => RealmObjectBase.set(this, 'projectId', value);

  @override
  Stream<RealmObjectChanges<Ticket>> get changes =>
      RealmObjectBase.getChanges<Ticket>(this);

  @override
  Ticket freeze() => RealmObjectBase.freezeObject<Ticket>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(Ticket._);
    return const SchemaObject(ObjectType.realmObject, Ticket, 'Ticket', [
      SchemaProperty('statusMessage', RealmPropertyType.string, optional: true),
      SchemaProperty('activityId', RealmPropertyType.string, optional: true),
      SchemaProperty('billToCustomerId', RealmPropertyType.string,
          optional: true),
      SchemaProperty('bits', RealmPropertyType.object,
          linkTarget: 'Ticket_bits', collectionType: RealmCollectionType.list),
      SchemaProperty('cEC', RealmPropertyType.string, optional: true),
      SchemaProperty('consignmentGuid', RealmPropertyType.string,
          optional: true),
      SchemaProperty('consignmentId', RealmPropertyType.string, optional: true),
      SchemaProperty('consumptionType', RealmPropertyType.string,
          optional: true),
      SchemaProperty('createdAt', RealmPropertyType.timestamp, optional: true),
      SchemaProperty('createdBy', RealmPropertyType.string, optional: true),
      SchemaProperty('createdByFullName', RealmPropertyType.string,
          optional: true),
      SchemaProperty('customerEmail', RealmPropertyType.string, optional: true),
      SchemaProperty('ticketingId', RealmPropertyType.string, optional: true),
      SchemaProperty('wellName', RealmPropertyType.string, optional: true),
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('digitalAttachments', RealmPropertyType.object,
          linkTarget: 'Ticket_digitalAttachments',
          collectionType: RealmCollectionType.list),
      SchemaProperty('endDate', RealmPropertyType.timestamp, optional: true),
      SchemaProperty('finalPdf', RealmPropertyType.string, optional: true),
      SchemaProperty('gTQuoteId', RealmPropertyType.string, optional: true),
      SchemaProperty('isEmailSent', RealmPropertyType.bool, optional: true),
      SchemaProperty('lat', RealmPropertyType.string, optional: true),
      SchemaProperty('long', RealmPropertyType.string, optional: true),
      SchemaProperty('ticketLater', RealmPropertyType.bool, optional: true),
      SchemaProperty('modifiedBy', RealmPropertyType.string, optional: true),
      SchemaProperty('truckUserMappingId', RealmPropertyType.string,
          optional: true),
      SchemaProperty('wellId', RealmPropertyType.string, optional: true),
      SchemaProperty('wellNumber', RealmPropertyType.string, optional: true),
      SchemaProperty('rigContractor', RealmPropertyType.string, optional: true),
      SchemaProperty('rigId', RealmPropertyType.string, optional: true),
      SchemaProperty('rigName', RealmPropertyType.string, optional: true),
      SchemaProperty('shipToCustomerId', RealmPropertyType.string,
          optional: true),
      SchemaProperty('startDate', RealmPropertyType.timestamp, optional: true),
      SchemaProperty('status', RealmPropertyType.string, optional: true),
      SchemaProperty('wBSNumber', RealmPropertyType.string, optional: true),
      SchemaProperty('manualAttachments', RealmPropertyType.object,
          linkTarget: 'Ticket_manualAttachments',
          collectionType: RealmCollectionType.list),
      SchemaProperty('customerId', RealmPropertyType.string, optional: true),
      SchemaProperty('modifiedByFullName', RealmPropertyType.string,
          optional: true),
      SchemaProperty('customerName', RealmPropertyType.string, optional: true),
      SchemaProperty('operationId', RealmPropertyType.string, optional: true),
      SchemaProperty('designEngineer', RealmPropertyType.string,
          optional: true),
      SchemaProperty('projectId', RealmPropertyType.string, optional: true),
    ]);
  }
}

class TicketManualAttachments extends _TicketManualAttachments
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  TicketManualAttachments({
    Iterable<String> draftQuote = const [],
  }) {
    RealmObjectBase.set<RealmList<String>>(
        this, 'draftQuote', RealmList<String>(draftQuote));
  }

  TicketManualAttachments._();

  @override
  RealmList<String> get draftQuote =>
      RealmObjectBase.get<String>(this, 'draftQuote') as RealmList<String>;
  @override
  set draftQuote(covariant RealmList<String> value) =>
      throw RealmUnsupportedSetError();

  @override
  Stream<RealmObjectChanges<TicketManualAttachments>> get changes =>
      RealmObjectBase.getChanges<TicketManualAttachments>(this);

  @override
  TicketManualAttachments freeze() =>
      RealmObjectBase.freezeObject<TicketManualAttachments>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(TicketManualAttachments._);
    return const SchemaObject(ObjectType.embeddedObject,
        TicketManualAttachments, 'Ticket_manualAttachments', [
      SchemaProperty('draftQuote', RealmPropertyType.string,
          collectionType: RealmCollectionType.list),
    ]);
  }
}

class TicketBits extends _TicketBits
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  TicketBits({
    String? billFlag,
    String? bom,
    String? iadcCode,
    String? materialId,
    String? noOfRuns,
    String? pickupFlag,
    String? pinConnection,
    String? serialNumber,
    String? size,
    String? type,
    Iterable<TicketBitsPriceBookDetails> priceBookDetails = const [],
  }) {
    RealmObjectBase.set(this, 'billFlag', billFlag);
    RealmObjectBase.set(this, 'bom', bom);
    RealmObjectBase.set(this, 'iadcCode', iadcCode);
    RealmObjectBase.set(this, 'materialId', materialId);
    RealmObjectBase.set(this, 'noOfRuns', noOfRuns);
    RealmObjectBase.set(this, 'pickupFlag', pickupFlag);
    RealmObjectBase.set(this, 'pinConnection', pinConnection);
    RealmObjectBase.set(this, 'serialNumber', serialNumber);
    RealmObjectBase.set(this, 'size', size);
    RealmObjectBase.set(this, 'type', type);
    RealmObjectBase.set<RealmList<TicketBitsPriceBookDetails>>(
        this,
        'priceBookDetails',
        RealmList<TicketBitsPriceBookDetails>(priceBookDetails));
  }

  TicketBits._();

  @override
  String? get billFlag =>
      RealmObjectBase.get<String>(this, 'billFlag') as String?;
  @override
  set billFlag(String? value) => RealmObjectBase.set(this, 'billFlag', value);

  @override
  String? get bom => RealmObjectBase.get<String>(this, 'bom') as String?;
  @override
  set bom(String? value) => RealmObjectBase.set(this, 'bom', value);

  @override
  String? get iadcCode =>
      RealmObjectBase.get<String>(this, 'iadcCode') as String?;
  @override
  set iadcCode(String? value) => RealmObjectBase.set(this, 'iadcCode', value);

  @override
  String? get materialId =>
      RealmObjectBase.get<String>(this, 'materialId') as String?;
  @override
  set materialId(String? value) =>
      RealmObjectBase.set(this, 'materialId', value);

  @override
  String? get noOfRuns =>
      RealmObjectBase.get<String>(this, 'noOfRuns') as String?;
  @override
  set noOfRuns(String? value) => RealmObjectBase.set(this, 'noOfRuns', value);

  @override
  String? get pickupFlag =>
      RealmObjectBase.get<String>(this, 'pickupFlag') as String?;
  @override
  set pickupFlag(String? value) =>
      RealmObjectBase.set(this, 'pickupFlag', value);

  @override
  String? get pinConnection =>
      RealmObjectBase.get<String>(this, 'pinConnection') as String?;
  @override
  set pinConnection(String? value) =>
      RealmObjectBase.set(this, 'pinConnection', value);

  @override
  RealmList<TicketBitsPriceBookDetails> get priceBookDetails =>
      RealmObjectBase.get<TicketBitsPriceBookDetails>(this, 'priceBookDetails')
          as RealmList<TicketBitsPriceBookDetails>;
  @override
  set priceBookDetails(covariant RealmList<TicketBitsPriceBookDetails> value) =>
      throw RealmUnsupportedSetError();

  @override
  String? get serialNumber =>
      RealmObjectBase.get<String>(this, 'serialNumber') as String?;
  @override
  set serialNumber(String? value) =>
      RealmObjectBase.set(this, 'serialNumber', value);

  @override
  String? get size => RealmObjectBase.get<String>(this, 'size') as String?;
  @override
  set size(String? value) => RealmObjectBase.set(this, 'size', value);

  @override
  String? get type => RealmObjectBase.get<String>(this, 'type') as String?;
  @override
  set type(String? value) => RealmObjectBase.set(this, 'type', value);

  @override
  Stream<RealmObjectChanges<TicketBits>> get changes =>
      RealmObjectBase.getChanges<TicketBits>(this);

  @override
  TicketBits freeze() => RealmObjectBase.freezeObject<TicketBits>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(TicketBits._);
    return const SchemaObject(
        ObjectType.embeddedObject, TicketBits, 'Ticket_bits', [
      SchemaProperty('billFlag', RealmPropertyType.string, optional: true),
      SchemaProperty('bom', RealmPropertyType.string, optional: true),
      SchemaProperty('iadcCode', RealmPropertyType.string, optional: true),
      SchemaProperty('materialId', RealmPropertyType.string, optional: true),
      SchemaProperty('noOfRuns', RealmPropertyType.string, optional: true),
      SchemaProperty('pickupFlag', RealmPropertyType.string, optional: true),
      SchemaProperty('pinConnection', RealmPropertyType.string, optional: true),
      SchemaProperty('priceBookDetails', RealmPropertyType.object,
          linkTarget: 'Ticket_bits_priceBookDetails',
          collectionType: RealmCollectionType.list),
      SchemaProperty('serialNumber', RealmPropertyType.string, optional: true),
      SchemaProperty('size', RealmPropertyType.string, optional: true),
      SchemaProperty('type', RealmPropertyType.string, optional: true),
    ]);
  }
}

class TicketDigitalAttachments extends _TicketDigitalAttachments
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  TicketDigitalAttachments({
    Iterable<String> draftQuote = const [],
  }) {
    RealmObjectBase.set<RealmList<String>>(
        this, 'draftQuote', RealmList<String>(draftQuote));
  }

  TicketDigitalAttachments._();

  @override
  RealmList<String> get draftQuote =>
      RealmObjectBase.get<String>(this, 'draftQuote') as RealmList<String>;
  @override
  set draftQuote(covariant RealmList<String> value) =>
      throw RealmUnsupportedSetError();

  @override
  Stream<RealmObjectChanges<TicketDigitalAttachments>> get changes =>
      RealmObjectBase.getChanges<TicketDigitalAttachments>(this);

  @override
  TicketDigitalAttachments freeze() =>
      RealmObjectBase.freezeObject<TicketDigitalAttachments>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(TicketDigitalAttachments._);
    return const SchemaObject(ObjectType.embeddedObject,
        TicketDigitalAttachments, 'Ticket_digitalAttachments', [
      SchemaProperty('draftQuote', RealmPropertyType.string,
          collectionType: RealmCollectionType.list),
    ]);
  }
}

class TicketBitsPriceBookDetails extends _TicketBitsPriceBookDetails
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  TicketBitsPriceBookDetails({
    double? bestPrice,
    String? comments,
    String? commercialAgreementId,
    String? currency,
    String? customerContactName,
    double? discountAmount,
    int? discountPercentage,
    String? hlMaterialNumber,
    String? llMaterialNumber,
    String? priceBookId,
    String? pricePerUnit,
    String? pricingId,
    String? unitDrilled,
    String? unitPrice,
    String? uom,
  }) {
    RealmObjectBase.set(this, 'bestPrice', bestPrice);
    RealmObjectBase.set(this, 'comments', comments);
    RealmObjectBase.set(this, 'commercialAgreementId', commercialAgreementId);
    RealmObjectBase.set(this, 'currency', currency);
    RealmObjectBase.set(this, 'customerContactName', customerContactName);
    RealmObjectBase.set(this, 'discountAmount', discountAmount);
    RealmObjectBase.set(this, 'discountPercentage', discountPercentage);
    RealmObjectBase.set(this, 'hlMaterialNumber', hlMaterialNumber);
    RealmObjectBase.set(this, 'llMaterialNumber', llMaterialNumber);
    RealmObjectBase.set(this, 'priceBookId', priceBookId);
    RealmObjectBase.set(this, 'pricePerUnit', pricePerUnit);
    RealmObjectBase.set(this, 'pricingId', pricingId);
    RealmObjectBase.set(this, 'unitDrilled', unitDrilled);
    RealmObjectBase.set(this, 'unitPrice', unitPrice);
    RealmObjectBase.set(this, 'uom', uom);
  }

  TicketBitsPriceBookDetails._();

  @override
  double? get bestPrice =>
      RealmObjectBase.get<double>(this, 'bestPrice') as double?;
  @override
  set bestPrice(double? value) => RealmObjectBase.set(this, 'bestPrice', value);

  @override
  String? get comments =>
      RealmObjectBase.get<String>(this, 'comments') as String?;
  @override
  set comments(String? value) => RealmObjectBase.set(this, 'comments', value);

  @override
  String? get commercialAgreementId =>
      RealmObjectBase.get<String>(this, 'commercialAgreementId') as String?;
  @override
  set commercialAgreementId(String? value) =>
      RealmObjectBase.set(this, 'commercialAgreementId', value);

  @override
  String? get currency =>
      RealmObjectBase.get<String>(this, 'currency') as String?;
  @override
  set currency(String? value) => RealmObjectBase.set(this, 'currency', value);

  @override
  String? get customerContactName =>
      RealmObjectBase.get<String>(this, 'customerContactName') as String?;
  @override
  set customerContactName(String? value) =>
      RealmObjectBase.set(this, 'customerContactName', value);

  @override
  double? get discountAmount =>
      RealmObjectBase.get<double>(this, 'discountAmount') as double?;
  @override
  set discountAmount(double? value) =>
      RealmObjectBase.set(this, 'discountAmount', value);

  @override
  int? get discountPercentage =>
      RealmObjectBase.get<int>(this, 'discountPercentage') as int?;
  @override
  set discountPercentage(int? value) =>
      RealmObjectBase.set(this, 'discountPercentage', value);

  @override
  String? get hlMaterialNumber =>
      RealmObjectBase.get<String>(this, 'hlMaterialNumber') as String?;
  @override
  set hlMaterialNumber(String? value) =>
      RealmObjectBase.set(this, 'hlMaterialNumber', value);

  @override
  String? get llMaterialNumber =>
      RealmObjectBase.get<String>(this, 'llMaterialNumber') as String?;
  @override
  set llMaterialNumber(String? value) =>
      RealmObjectBase.set(this, 'llMaterialNumber', value);

  @override
  String? get priceBookId =>
      RealmObjectBase.get<String>(this, 'priceBookId') as String?;
  @override
  set priceBookId(String? value) =>
      RealmObjectBase.set(this, 'priceBookId', value);

  @override
  String? get pricePerUnit =>
      RealmObjectBase.get<String>(this, 'pricePerUnit') as String?;
  @override
  set pricePerUnit(String? value) =>
      RealmObjectBase.set(this, 'pricePerUnit', value);

  @override
  String? get pricingId =>
      RealmObjectBase.get<String>(this, 'pricingId') as String?;
  @override
  set pricingId(String? value) => RealmObjectBase.set(this, 'pricingId', value);

  @override
  String? get unitDrilled =>
      RealmObjectBase.get<String>(this, 'unitDrilled') as String?;
  @override
  set unitDrilled(String? value) =>
      RealmObjectBase.set(this, 'unitDrilled', value);

  @override
  String? get unitPrice =>
      RealmObjectBase.get<String>(this, 'unitPrice') as String?;
  @override
  set unitPrice(String? value) => RealmObjectBase.set(this, 'unitPrice', value);

  @override
  String? get uom => RealmObjectBase.get<String>(this, 'uom') as String?;
  @override
  set uom(String? value) => RealmObjectBase.set(this, 'uom', value);

  @override
  Stream<RealmObjectChanges<TicketBitsPriceBookDetails>> get changes =>
      RealmObjectBase.getChanges<TicketBitsPriceBookDetails>(this);

  @override
  TicketBitsPriceBookDetails freeze() =>
      RealmObjectBase.freezeObject<TicketBitsPriceBookDetails>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(TicketBitsPriceBookDetails._);
    return const SchemaObject(ObjectType.embeddedObject,
        TicketBitsPriceBookDetails, 'Ticket_bits_priceBookDetails', [
      SchemaProperty('bestPrice', RealmPropertyType.double, optional: true),
      SchemaProperty('comments', RealmPropertyType.string, optional: true),
      SchemaProperty('commercialAgreementId', RealmPropertyType.string,
          optional: true),
      SchemaProperty('currency', RealmPropertyType.string, optional: true),
      SchemaProperty('customerContactName', RealmPropertyType.string,
          optional: true),
      SchemaProperty('discountAmount', RealmPropertyType.double,
          optional: true),
      SchemaProperty('discountPercentage', RealmPropertyType.int,
          optional: true),
      SchemaProperty('hlMaterialNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('llMaterialNumber', RealmPropertyType.string,
          optional: true),
      SchemaProperty('priceBookId', RealmPropertyType.string, optional: true),
      SchemaProperty('pricePerUnit', RealmPropertyType.string, optional: true),
      SchemaProperty('pricingId', RealmPropertyType.string, optional: true),
      SchemaProperty('unitDrilled', RealmPropertyType.string, optional: true),
      SchemaProperty('unitPrice', RealmPropertyType.string, optional: true),
      SchemaProperty('uom', RealmPropertyType.string, optional: true),
    ]);
  }
}
