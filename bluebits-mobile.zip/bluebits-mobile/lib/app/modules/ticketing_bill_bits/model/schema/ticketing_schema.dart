import 'package:realm/realm.dart';
part 'ticketing_schema.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.

@RealmModel()
class _Ticket {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;

  String? activityId;

  String? billToCustomerId;

  late List<_TicketBits> bits;

  String? cEC;

  String? consignmentGuid;

  String? consignmentId;

  String? consumptionType;

  DateTime? createdAt;

  String? createdBy;

  String? createdByFullName;

  String? customerEmail;

  String? customerId;

  String? customerName;

  String? designEngineer;

  late List<_TicketDigitalAttachments> digitalAttachments;

  DateTime? endDate;

  String? finalPdf;

  String? gTQuoteId;

  bool? isEmailSent;

  String? lat;

  String? long;

  late List<_TicketManualAttachments> manualAttachments;

  String? modifiedBy;

  String? modifiedByFullName;

  String? operationId;

  String? projectId;

  String? rigContractor;

  String? rigId;

  String? rigName;

  String? shipToCustomerId;

  DateTime? startDate;

  String? status;

  String? statusMessage;

  bool? ticketLater;

  String? ticketingId;

  String? truckUserMappingId;

  String? wBSNumber;

  String? wellId;

  String? wellName;

  String? wellNumber;
}
@RealmModel(ObjectType.embeddedObject)
@MapTo('Ticket_manualAttachments')
class _TicketManualAttachments {
  late List<String> draftQuote;
}


@RealmModel(ObjectType.embeddedObject)
@MapTo('Ticket_bits')
class _TicketBits {
  String? billFlag;

  String? bom;

  String? iadcCode;

  String? materialId;

  String? noOfRuns;

  String? pickupFlag;

  String? pinConnection;

  late List<_TicketBitsPriceBookDetails> priceBookDetails;

  String? serialNumber;

  String? size;

  String? type;
}
@RealmModel(ObjectType.embeddedObject)
@MapTo('Ticket_digitalAttachments')
class _TicketDigitalAttachments {
  late List<String> draftQuote;
}

@RealmModel(ObjectType.embeddedObject)
@MapTo('Ticket_bits_priceBookDetails')
class _TicketBitsPriceBookDetails {
  double? bestPrice;

  String? comments;

  String? commercialAgreementId;

  String? currency;

  String? customerContactName;

  double? discountAmount;

  int? discountPercentage;

  String? hlMaterialNumber;

  String? llMaterialNumber;

  String? priceBookId;

  String? pricePerUnit;

  String? pricingId;

  String? unitDrilled;

  String? unitPrice;

  String? uom;
}


