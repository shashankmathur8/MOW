// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'billedBits.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class BilledBits extends _BilledBits
    with RealmEntity, RealmObjectBase, RealmObject {
  BilledBits(
    ObjectId? id, {
    String? billingID,
    String? well,
    String? startDate,
    String? endDate,
    String? cec,
    String? officeSalesMan,
    String? noOfBilledBits,
    String? status,
    String? attachment,
    Iterable<BilledBitsList> billedBitsList = const [],
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'billingID', billingID);
    RealmObjectBase.set(this, 'well', well);
    RealmObjectBase.set(this, 'startDate', startDate);
    RealmObjectBase.set(this, 'endDate', endDate);
    RealmObjectBase.set(this, 'cec', cec);
    RealmObjectBase.set(this, 'officeSalesMan', officeSalesMan);
    RealmObjectBase.set(this, 'noOfBilledBits', noOfBilledBits);
    RealmObjectBase.set(this, 'status', status);
    RealmObjectBase.set(this, 'attachment', attachment);
    RealmObjectBase.set<RealmList<BilledBitsList>>(
        this, 'billedBitsList', RealmList<BilledBitsList>(billedBitsList));
  }

  BilledBits._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get billingID =>
      RealmObjectBase.get<String>(this, 'billingID') as String?;
  @override
  set billingID(String? value) => RealmObjectBase.set(this, 'billingID', value);

  @override
  String? get well => RealmObjectBase.get<String>(this, 'well') as String?;
  @override
  set well(String? value) => RealmObjectBase.set(this, 'well', value);

  @override
  String? get startDate =>
      RealmObjectBase.get<String>(this, 'startDate') as String?;
  @override
  set startDate(String? value) => RealmObjectBase.set(this, 'startDate', value);

  @override
  String? get endDate =>
      RealmObjectBase.get<String>(this, 'endDate') as String?;
  @override
  set endDate(String? value) => RealmObjectBase.set(this, 'endDate', value);

  @override
  String? get cec => RealmObjectBase.get<String>(this, 'cec') as String?;
  @override
  set cec(String? value) => RealmObjectBase.set(this, 'cec', value);

  @override
  String? get officeSalesMan =>
      RealmObjectBase.get<String>(this, 'officeSalesMan') as String?;
  @override
  set officeSalesMan(String? value) =>
      RealmObjectBase.set(this, 'officeSalesMan', value);

  @override
  String? get noOfBilledBits =>
      RealmObjectBase.get<String>(this, 'noOfBilledBits') as String?;
  @override
  set noOfBilledBits(String? value) =>
      RealmObjectBase.set(this, 'noOfBilledBits', value);

  @override
  String? get status => RealmObjectBase.get<String>(this, 'status') as String?;
  @override
  set status(String? value) => RealmObjectBase.set(this, 'status', value);

  @override
  String? get attachment =>
      RealmObjectBase.get<String>(this, 'attachment') as String?;
  @override
  set attachment(String? value) =>
      RealmObjectBase.set(this, 'attachment', value);

  @override
  RealmList<BilledBitsList> get billedBitsList =>
      RealmObjectBase.get<BilledBitsList>(this, 'billedBitsList')
          as RealmList<BilledBitsList>;
  @override
  set billedBitsList(covariant RealmList<BilledBitsList> value) =>
      throw RealmUnsupportedSetError();

  @override
  Stream<RealmObjectChanges<BilledBits>> get changes =>
      RealmObjectBase.getChanges<BilledBits>(this);

  @override
  BilledBits freeze() => RealmObjectBase.freezeObject<BilledBits>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(BilledBits._);
    return const SchemaObject(
        ObjectType.realmObject, BilledBits, 'BilledBits', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('billingID', RealmPropertyType.string, optional: true),
      SchemaProperty('well', RealmPropertyType.string, optional: true),
      SchemaProperty('startDate', RealmPropertyType.string, optional: true),
      SchemaProperty('endDate', RealmPropertyType.string, optional: true),
      SchemaProperty('cec', RealmPropertyType.string, optional: true),
      SchemaProperty('officeSalesMan', RealmPropertyType.string,
          optional: true),
      SchemaProperty('noOfBilledBits', RealmPropertyType.string,
          optional: true),
      SchemaProperty('status', RealmPropertyType.string, optional: true),
      SchemaProperty('attachment', RealmPropertyType.string, optional: true),
      SchemaProperty('billedBitsList', RealmPropertyType.object,
          linkTarget: 'BilledBitsList',
          collectionType: RealmCollectionType.list),
    ]);
  }
}

class BilledBitsList extends _BilledBitsList
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  BilledBitsList({
    String? bom,
    String? serialNumber,
    String? type,
    String? size,
    String? pinConnection,
    String? iadcCode,
    String? noOfRuns,
  }) {
    RealmObjectBase.set(this, 'bom', bom);
    RealmObjectBase.set(this, 'serialNumber', serialNumber);
    RealmObjectBase.set(this, 'type', type);
    RealmObjectBase.set(this, 'size', size);
    RealmObjectBase.set(this, 'pinConnection', pinConnection);
    RealmObjectBase.set(this, 'iadcCode', iadcCode);
    RealmObjectBase.set(this, 'noOfRuns', noOfRuns);
  }

  BilledBitsList._();

  @override
  String? get bom => RealmObjectBase.get<String>(this, 'bom') as String?;
  @override
  set bom(String? value) => RealmObjectBase.set(this, 'bom', value);

  @override
  String? get serialNumber =>
      RealmObjectBase.get<String>(this, 'serialNumber') as String?;
  @override
  set serialNumber(String? value) =>
      RealmObjectBase.set(this, 'serialNumber', value);

  @override
  String? get type => RealmObjectBase.get<String>(this, 'type') as String?;
  @override
  set type(String? value) => RealmObjectBase.set(this, 'type', value);

  @override
  String? get size => RealmObjectBase.get<String>(this, 'size') as String?;
  @override
  set size(String? value) => RealmObjectBase.set(this, 'size', value);

  @override
  String? get pinConnection =>
      RealmObjectBase.get<String>(this, 'pinConnection') as String?;
  @override
  set pinConnection(String? value) =>
      RealmObjectBase.set(this, 'pinConnection', value);

  @override
  String? get iadcCode =>
      RealmObjectBase.get<String>(this, 'iadcCode') as String?;
  @override
  set iadcCode(String? value) => RealmObjectBase.set(this, 'iadcCode', value);

  @override
  String? get noOfRuns =>
      RealmObjectBase.get<String>(this, 'noOfRuns') as String?;
  @override
  set noOfRuns(String? value) => RealmObjectBase.set(this, 'noOfRuns', value);

  @override
  Stream<RealmObjectChanges<BilledBitsList>> get changes =>
      RealmObjectBase.getChanges<BilledBitsList>(this);

  @override
  BilledBitsList freeze() => RealmObjectBase.freezeObject<BilledBitsList>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(BilledBitsList._);
    return const SchemaObject(
        ObjectType.embeddedObject, BilledBitsList, 'BilledBitsList', [
      SchemaProperty('bom', RealmPropertyType.string, optional: true),
      SchemaProperty('serialNumber', RealmPropertyType.string, optional: true),
      SchemaProperty('type', RealmPropertyType.string, optional: true),
      SchemaProperty('size', RealmPropertyType.string, optional: true),
      SchemaProperty('pinConnection', RealmPropertyType.string, optional: true),
      SchemaProperty('iadcCode', RealmPropertyType.string, optional: true),
      SchemaProperty('noOfRuns', RealmPropertyType.string, optional: true),
    ]);
  }
}
