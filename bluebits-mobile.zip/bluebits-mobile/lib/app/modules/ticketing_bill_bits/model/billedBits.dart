import 'package:realm/realm.dart';
part 'billedBits.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.

@RealmModel()
class _BilledBits {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;
  String? billingID;
  String? well;
  String? startDate;
  String? endDate;
  String? cec;
  String? officeSalesMan;
  String? noOfBilledBits;
  String? status;
  String? attachment;
  late List<_BilledBitsList> billedBitsList;
}

@RealmModel(ObjectType.embeddedObject)
@MapTo('BilledBitsList')
class _BilledBitsList {
  String? bom;

  String? serialNumber;

  String? type;

  String? size;
  String? pinConnection;
  String? iadcCode;
  String? noOfRuns;
}
