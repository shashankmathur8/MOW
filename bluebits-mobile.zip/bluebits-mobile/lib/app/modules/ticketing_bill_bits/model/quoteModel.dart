class QuoteModel {
  bool isUserSignCaptured;
  bool isCustomerSignCaptured;
  bool isFileUploaded;
  String customerName;
  String userName;
  bool isDigitalSignDone;
  bool isUserSignTap;
  String customerSign;
  String userSign;
  bool isCustomerSignStartDraw;
  bool isUserSignStartDraw;
  bool isDigitalSignChecked;
  bool isLoadHtml;

  QuoteModel({
    this.isUserSignCaptured = false,
    this.isCustomerSignCaptured = false,
    this.isFileUploaded = false,
    this.customerName = '',
    this.userName = '',
    this.isDigitalSignDone = false,
    this.isUserSignTap = false,
    this.customerSign = '',
    this.userSign = '',
    this.isCustomerSignStartDraw = false,
    this.isUserSignStartDraw = false,
    this.isDigitalSignChecked = false,
    this.isLoadHtml = false,
  });

  @override
  String toString() {
    return 'QuoteModel{isUserSignCaptured: $isUserSignCaptured, isCustomerSignCaptured: $isCustomerSignCaptured, isFileUploaded: $isFileUploaded, customerName: $customerName, userName: $userName, isDigitalSignDone: $isDigitalSignDone, isUserSignTap: $isUserSignTap, customerSign: $customerSign, userSign: $userSign, isCustomerSignStartDraw: $isCustomerSignStartDraw, isUserSignStartDraw: $isUserSignStartDraw, isDigitalSignChecked: $isDigitalSignChecked, isLoadHtml: $isLoadHtml}';
  }
}
