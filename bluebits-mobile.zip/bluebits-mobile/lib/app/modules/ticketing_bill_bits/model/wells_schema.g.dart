// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wells_schema.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class Well extends _Well with RealmEntity, RealmObjectBase, RealmObject {
  Well(
    ObjectId? id,
    String country,
    String status, {
    String? bottomDatum,
    String? bottomLatitude,
    String? bottomLongitude,
    DateTime? completionDate,
    String? county,
    DateTime? createdDate,
    String? description,
    String? fieldName,
    DateTime? lastUpdatedDate,
    String? name,
    String? number,
    String? operatingEnvironment,
    DateTime? permitIssueDate,
    String? postalCode,
    String? sourceSystem,
    String? state,
    String? surfaceDatum,
    String? surfaceLatitude,
    String? surfaceLongitude,
    String? wellId,
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'bottomDatum', bottomDatum);
    RealmObjectBase.set(this, 'bottomLatitude', bottomLatitude);
    RealmObjectBase.set(this, 'bottomLongitude', bottomLongitude);
    RealmObjectBase.set(this, 'completionDate', completionDate);
    RealmObjectBase.set(this, 'country', country);
    RealmObjectBase.set(this, 'county', county);
    RealmObjectBase.set(this, 'createdDate', createdDate);
    RealmObjectBase.set(this, 'description', description);
    RealmObjectBase.set(this, 'fieldName', fieldName);
    RealmObjectBase.set(this, 'lastUpdatedDate', lastUpdatedDate);
    RealmObjectBase.set(this, 'name', name);
    RealmObjectBase.set(this, 'number', number);
    RealmObjectBase.set(this, 'operatingEnvironment', operatingEnvironment);
    RealmObjectBase.set(this, 'permitIssueDate', permitIssueDate);
    RealmObjectBase.set(this, 'postalCode', postalCode);
    RealmObjectBase.set(this, 'sourceSystem', sourceSystem);
    RealmObjectBase.set(this, 'state', state);
    RealmObjectBase.set(this, 'status', status);
    RealmObjectBase.set(this, 'surfaceDatum', surfaceDatum);
    RealmObjectBase.set(this, 'surfaceLatitude', surfaceLatitude);
    RealmObjectBase.set(this, 'surfaceLongitude', surfaceLongitude);
    RealmObjectBase.set(this, 'wellId', wellId);
  }

  Well._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get bottomDatum =>
      RealmObjectBase.get<String>(this, 'bottomDatum') as String?;
  @override
  set bottomDatum(String? value) =>
      RealmObjectBase.set(this, 'bottomDatum', value);

  @override
  String? get bottomLatitude =>
      RealmObjectBase.get<String>(this, 'bottomLatitude') as String?;
  @override
  set bottomLatitude(String? value) =>
      RealmObjectBase.set(this, 'bottomLatitude', value);

  @override
  String? get bottomLongitude =>
      RealmObjectBase.get<String>(this, 'bottomLongitude') as String?;
  @override
  set bottomLongitude(String? value) =>
      RealmObjectBase.set(this, 'bottomLongitude', value);

  @override
  DateTime? get completionDate =>
      RealmObjectBase.get<DateTime>(this, 'completionDate') as DateTime?;
  @override
  set completionDate(DateTime? value) =>
      RealmObjectBase.set(this, 'completionDate', value);

  @override
  String get country => RealmObjectBase.get<String>(this, 'country') as String;
  @override
  set country(String value) => RealmObjectBase.set(this, 'country', value);

  @override
  String? get county => RealmObjectBase.get<String>(this, 'county') as String?;
  @override
  set county(String? value) => RealmObjectBase.set(this, 'county', value);

  @override
  DateTime? get createdDate =>
      RealmObjectBase.get<DateTime>(this, 'createdDate') as DateTime?;
  @override
  set createdDate(DateTime? value) =>
      RealmObjectBase.set(this, 'createdDate', value);

  @override
  String? get description =>
      RealmObjectBase.get<String>(this, 'description') as String?;
  @override
  set description(String? value) =>
      RealmObjectBase.set(this, 'description', value);

  @override
  String? get fieldName =>
      RealmObjectBase.get<String>(this, 'fieldName') as String?;
  @override
  set fieldName(String? value) => RealmObjectBase.set(this, 'fieldName', value);

  @override
  DateTime? get lastUpdatedDate =>
      RealmObjectBase.get<DateTime>(this, 'lastUpdatedDate') as DateTime?;
  @override
  set lastUpdatedDate(DateTime? value) =>
      RealmObjectBase.set(this, 'lastUpdatedDate', value);

  @override
  String? get name => RealmObjectBase.get<String>(this, 'name') as String?;
  @override
  set name(String? value) => RealmObjectBase.set(this, 'name', value);

  @override
  String? get number => RealmObjectBase.get<String>(this, 'number') as String?;
  @override
  set number(String? value) => RealmObjectBase.set(this, 'number', value);

  @override
  String? get operatingEnvironment =>
      RealmObjectBase.get<String>(this, 'operatingEnvironment') as String?;
  @override
  set operatingEnvironment(String? value) =>
      RealmObjectBase.set(this, 'operatingEnvironment', value);

  @override
  DateTime? get permitIssueDate =>
      RealmObjectBase.get<DateTime>(this, 'permitIssueDate') as DateTime?;
  @override
  set permitIssueDate(DateTime? value) =>
      RealmObjectBase.set(this, 'permitIssueDate', value);

  @override
  String? get postalCode =>
      RealmObjectBase.get<String>(this, 'postalCode') as String?;
  @override
  set postalCode(String? value) =>
      RealmObjectBase.set(this, 'postalCode', value);

  @override
  String? get sourceSystem =>
      RealmObjectBase.get<String>(this, 'sourceSystem') as String?;
  @override
  set sourceSystem(String? value) =>
      RealmObjectBase.set(this, 'sourceSystem', value);

  @override
  String? get state => RealmObjectBase.get<String>(this, 'state') as String?;
  @override
  set state(String? value) => RealmObjectBase.set(this, 'state', value);

  @override
  String get status => RealmObjectBase.get<String>(this, 'status') as String;
  @override
  set status(String value) => RealmObjectBase.set(this, 'status', value);

  @override
  String? get surfaceDatum =>
      RealmObjectBase.get<String>(this, 'surfaceDatum') as String?;
  @override
  set surfaceDatum(String? value) =>
      RealmObjectBase.set(this, 'surfaceDatum', value);

  @override
  String? get surfaceLatitude =>
      RealmObjectBase.get<String>(this, 'surfaceLatitude') as String?;
  @override
  set surfaceLatitude(String? value) =>
      RealmObjectBase.set(this, 'surfaceLatitude', value);

  @override
  String? get surfaceLongitude =>
      RealmObjectBase.get<String>(this, 'surfaceLongitude') as String?;
  @override
  set surfaceLongitude(String? value) =>
      RealmObjectBase.set(this, 'surfaceLongitude', value);

  @override
  String? get wellId => RealmObjectBase.get<String>(this, 'wellId') as String?;
  @override
  set wellId(String? value) => RealmObjectBase.set(this, 'wellId', value);

  @override
  Stream<RealmObjectChanges<Well>> get changes =>
      RealmObjectBase.getChanges<Well>(this);

  @override
  Well freeze() => RealmObjectBase.freezeObject<Well>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(Well._);
    return const SchemaObject(ObjectType.realmObject, Well, 'Well', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('bottomDatum', RealmPropertyType.string, optional: true),
      SchemaProperty('bottomLatitude', RealmPropertyType.string,
          optional: true),
      SchemaProperty('bottomLongitude', RealmPropertyType.string,
          optional: true),
      SchemaProperty('completionDate', RealmPropertyType.timestamp,
          optional: true),
      SchemaProperty('country', RealmPropertyType.string),
      SchemaProperty('county', RealmPropertyType.string, optional: true),
      SchemaProperty('createdDate', RealmPropertyType.timestamp,
          optional: true),
      SchemaProperty('description', RealmPropertyType.string, optional: true),
      SchemaProperty('fieldName', RealmPropertyType.string, optional: true),
      SchemaProperty('lastUpdatedDate', RealmPropertyType.timestamp,
          optional: true),
      SchemaProperty('name', RealmPropertyType.string, optional: true),
      SchemaProperty('number', RealmPropertyType.string, optional: true),
      SchemaProperty('operatingEnvironment', RealmPropertyType.string,
          optional: true),
      SchemaProperty('permitIssueDate', RealmPropertyType.timestamp,
          optional: true),
      SchemaProperty('postalCode', RealmPropertyType.string, optional: true),
      SchemaProperty('sourceSystem', RealmPropertyType.string, optional: true),
      SchemaProperty('state', RealmPropertyType.string, optional: true),
      SchemaProperty('status', RealmPropertyType.string),
      SchemaProperty('surfaceDatum', RealmPropertyType.string, optional: true),
      SchemaProperty('surfaceLatitude', RealmPropertyType.string,
          optional: true),
      SchemaProperty('surfaceLongitude', RealmPropertyType.string,
          optional: true),
      SchemaProperty('wellId', RealmPropertyType.string, optional: true),
    ]);
  }
}
