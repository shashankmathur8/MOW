import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/customerSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/rigsSchema.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/model/sales_representative_schema.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/model/wells_schema.dart';

class TicketingModel {
  late Rig? rig;
  late Customer? customer;
  late String? customerEmail;
  late String? consignmentID;
  late String? consignmentGUID; //Consignment object id
  late String? ticketingID;
  late String? quoteID;
  late String? lat;
  late String? long;
  late List<TicketingBit>? bits;
  late Well? well;
  late DateTime? startDate;
  late DateTime? endDate;
  late String? consumptionType;
  late Customer? shipTo;
  late Customer? billTo;
  late SalesRepresentative? cec;
  late SalesRepresentative? designEngineer;
  late bool? isTicketLater;

  TicketingModel(
      {this.rig,
      this.customer,
      this.customerEmail,
      this.consignmentID,
      this.consignmentGUID,
      this.ticketingID,
      this.quoteID,
      this.lat,
      this.long,
      this.bits,
      this.well,
      this.startDate,
      this.endDate,
      this.consumptionType,
      this.shipTo,
      this.billTo,
      this.cec,
      this.designEngineer,
      this.isTicketLater});

  @override
  String toString() {
    return 'TicketingModel{rig: $rig, customer: $customer, customerEmail: $customerEmail, consignmentID: $consignmentID, consignmentGUID: $consignmentGUID, ticketingID: $ticketingID, quoteID: $quoteID, lat: $lat, long: $long, bits: $bits, well: $well, startDate: $startDate, endDate: $endDate, consumptionType: $consumptionType, shipTo: $shipTo, billTo: $billTo, cec: $cec, designEngineer: $designEngineer}';
  }
}

class TicketingBit {
  late Bit? bit;
  late List<TicketingLineItems>? lineItem;

  TicketingBit({
    this.bit,
    this.lineItem,
  });

  @override
  String toString() {
    return 'Bits{bit: $bit, lineItem: $lineItem}';
  }
}

class TicketingLineItems {
  late String? currency;
  late String? hLReference;
  late bool? isActive;
  late String? masterCode;
  late String? materialDescription;
  late String? materialLocalDescription;
  late String? materialLocalNumber;
  late String? materialNumber;
  late int? pricingId;
  late String? sHLReference;
  late String? uOM;
  late double? unitPrice;
  late double? bestPrice;
  late String? comments;
  late double? discountAmount;
  late double? discountPercentage;
  late double? unitDrilled;
  late double? pricePerUnit;
  late bool? isExpanded;
  late bool? isDuplicate;
  late String? priceBookId;

  TicketingLineItems({
    this.priceBookId,
    this.currency,
    this.hLReference,
    this.isActive,
    this.masterCode,
    this.materialDescription,
    this.materialLocalDescription,
    this.materialLocalNumber,
    this.materialNumber,
    this.pricingId,
    this.sHLReference,
    this.uOM,
    this.unitPrice,
    this.bestPrice,
    this.comments,
    this.discountAmount,
    this.discountPercentage,
    this.unitDrilled,
    this.pricePerUnit,
    this.isExpanded,
    this.isDuplicate,
  });

  TicketingLineItems copyWith(TicketingLineItems lineItems) {
    return TicketingLineItems(
        priceBookId: lineItems.priceBookId,
        currency: lineItems.currency,
        hLReference: lineItems.hLReference,
        isActive: lineItems.isActive,
        masterCode: lineItems.masterCode,
        materialDescription: lineItems.materialDescription,
        materialLocalDescription: lineItems.materialLocalDescription,
        materialLocalNumber: lineItems.materialLocalNumber,
        materialNumber: lineItems.materialNumber,
        pricingId: lineItems.pricingId,
        sHLReference: lineItems.sHLReference,
        uOM: lineItems.uOM,
        unitPrice: lineItems.unitPrice,
        bestPrice: lineItems.bestPrice,
        comments: lineItems.comments,
        discountAmount: lineItems.discountAmount,
        discountPercentage: lineItems.discountPercentage,
        unitDrilled: lineItems.unitDrilled,
        pricePerUnit: lineItems.pricePerUnit,
        isExpanded: true,
        isDuplicate: false);
  }

  @override
  String toString() {
    return 'LineItems{priceBookId: $priceBookId, currency: $currency, hLReference: $hLReference, isActive: $isActive, masterCode: $masterCode, materialDescription: $materialDescription, materialLocalDescription: $materialLocalDescription, materialLocalNumber: $materialLocalNumber, materialNumber: $materialNumber, pricingId: $pricingId, sHLReference: $sHLReference, uOM: $uOM, unitPrice: $unitPrice, bestPrice: $bestPrice, comments: $comments, discountAmount: $discountAmount, discountPercentage: $discountPercentage, unitDrilled: $unitDrilled, pricePerUnit: $pricePerUnit, isExpanded: $isExpanded, isDuplicate: $isDuplicate}';
  }
}
