// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sales_representative_schema.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class SalesRepresentative extends _SalesRepresentative
    with RealmEntity, RealmObjectBase, RealmObject {
  SalesRepresentative(
    ObjectId? id, {
    String? alias,
    String? fullName,
    String? plantId,
    String? refId,
    String? role,
    String? value,
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'alias', alias);
    RealmObjectBase.set(this, 'fullName', fullName);
    RealmObjectBase.set(this, 'plantId', plantId);
    RealmObjectBase.set(this, 'refId', refId);
    RealmObjectBase.set(this, 'role', role);
    RealmObjectBase.set(this, 'value', value);
  }

  SalesRepresentative._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get alias => RealmObjectBase.get<String>(this, 'alias') as String?;
  @override
  set alias(String? value) => RealmObjectBase.set(this, 'alias', value);

  @override
  String? get fullName =>
      RealmObjectBase.get<String>(this, 'fullName') as String?;
  @override
  set fullName(String? value) => RealmObjectBase.set(this, 'fullName', value);

  @override
  String? get plantId =>
      RealmObjectBase.get<String>(this, 'plantId') as String?;
  @override
  set plantId(String? value) => RealmObjectBase.set(this, 'plantId', value);

  @override
  String? get refId => RealmObjectBase.get<String>(this, 'refId') as String?;
  @override
  set refId(String? value) => RealmObjectBase.set(this, 'refId', value);

  @override
  String? get role => RealmObjectBase.get<String>(this, 'role') as String?;
  @override
  set role(String? value) => RealmObjectBase.set(this, 'role', value);

  @override
  String? get value => RealmObjectBase.get<String>(this, 'value') as String?;
  @override
  set value(String? value) => RealmObjectBase.set(this, 'value', value);

  @override
  Stream<RealmObjectChanges<SalesRepresentative>> get changes =>
      RealmObjectBase.getChanges<SalesRepresentative>(this);

  @override
  SalesRepresentative freeze() =>
      RealmObjectBase.freezeObject<SalesRepresentative>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(SalesRepresentative._);
    return const SchemaObject(
        ObjectType.realmObject, SalesRepresentative, 'SalesRepresentative', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('alias', RealmPropertyType.string, optional: true),
      SchemaProperty('fullName', RealmPropertyType.string, optional: true),
      SchemaProperty('plantId', RealmPropertyType.string, optional: true),
      SchemaProperty('refId', RealmPropertyType.string, optional: true),
      SchemaProperty('role', RealmPropertyType.string, optional: true),
      SchemaProperty('value', RealmPropertyType.string, optional: true),
    ]);
  }
}
