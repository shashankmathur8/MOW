import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_enum.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/model/ticketing_model.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/widget/add_price_book_full_ticketing.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/widget/add_price_book_selection_ticketing.dart';

import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/common_widget.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../../shared/generic_overlay.dart';
import '../controller/ticketing_bits_controller.dart';

class PriceBookLineItemTicketing extends StatefulWidget {
  final TicketingBitsController ticketingBitsController;

  const PriceBookLineItemTicketing(
      {Key? key, required this.ticketingBitsController})
      : super(key: key);

  @override
  State<PriceBookLineItemTicketing> createState() =>
      _PriceBookLineItemTicketingState();
}

class _PriceBookLineItemTicketingState
    extends State<PriceBookLineItemTicketing> {
  var outlineBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(AppValues.radius_4),
    borderSide: const BorderSide(
        width: SizeConstants.dp1, color: AppColors.colorSeparatorLine),
  );

  final widthInput = getWidth(SizeConstants.dp152);

  @override
  void initState() {
    super.initState();
  }

  Widget renderImage(String imgName, callback, double width, double height) {
    return InkWell(
      onTap: callback,
      child: Row(
        children: [
          const SizedBox(
            width: SizeConstants.dp40,
          ),
          Container(
              height: getHeight(SizeConstants.dp16),
              width: getHeight(SizeConstants.dp16),
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(imgName),
                ),
              ),
              child: null),
        ],
      ),
    );
  }

  Widget regularInputWidget(int index, TicketingLineItems line, String type,
      String title, String placeholder,
      {double? width, String? errorMessage}) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: tSw400dp12fontF.copyWith(
            color: AppColors.colorMainText,
          ),
        ),
        SizedBox(
          height: getHeight(SizeConstants.dp7),
        ),
        SizedBox(
            width: width,
            child: Obx(
              () => TextFormField(
                autovalidateMode: AutovalidateMode.always,
                onChanged: (value) {
                  widget.ticketingBitsController
                      .updateConsignmentModel(value, type, index);
                },
                controller: widget.ticketingBitsController
                    .setLineItemValues(type, index),
                inputFormatters: type == InputFieldType.comments.name
                    ? [
                        filteringTextInputFormatter,
                      ]
                    : [
                        filteringTextInputFormatter,
                        FilteringTextInputFormatter.allow(
                            RegExp(r'(^\d*[\.]?\d{0,6})'))
                      ],
                autofocus: false,
                style: tSw400dp14fontF.copyWith(
                  color: AppColors.colorMainText,
                ),
                decoration: InputDecoration(
                  hintText: placeholder,
                  hintStyle: tSw400dp14fontF.copyWith(
                    color: AppColors.colorSubText.withOpacity(0.7),
                  ),
                  filled: true,
                  fillColor: AppColors.colorGreyInputBox.withOpacity(0.8),
                  enabledBorder: outlineBorder,
                  focusedBorder: outlineBorder,
                  border: outlineBorder,
                  focusedErrorBorder: outlineBorder,
                  errorBorder: outlineBorder.copyWith(
                    borderSide:
                        const BorderSide(color: AppColors.colorRedError),
                  ),
                  errorStyle: tSw400dp14fontF.copyWith(
                    color: AppColors.colorRedError,
                  ),
                ),
                maxLines: 1,
                maxLength: type == InputFieldType.comments.name
                    ? SizeConstants.maxLengthLimitText
                    : null,
                keyboardType: type == InputFieldType.comments.name
                    ? TextInputType.text
                    : const TextInputType.numberWithOptions(
                        decimal: true, signed: false),
                textAlign: TextAlign.start,
                validator: (value) {
                  if (value == null) return null;

                  return value.isEmpty &&
                          widget.ticketingBitsController
                              .isPriceBookValidationEnable
                      ? errorMessage
                      : null;
                },
                onTapOutside: (event) {
                  FocusManager.instance.primaryFocus?.unfocus();
                },
              ),
            )),
      ],
    );
  }

  Widget priceWidget(TicketingLineItems line) {
    return Container(
      width: getWidth(SizeConstants.dp75),
      margin: EdgeInsets.only(left: getWidth(SizeConstants.dp13)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Image.asset(
            AppImages.pricetag,
            height: getWidth(SizeConstants.dp35),
            width: getWidth(SizeConstants.dp35),
            fit: BoxFit.fill,
          ),
          Text(
            '${AppStrings.price}(${line.currency})',
            style: tSw400dp12fontF.copyWith(
              color: AppColors.colorMainText,
            ),
          ),
          Text(
            '${line.unitPrice}',
            style: tSw400dp18fontF.copyWith(
              color: AppColors.colorMainText,
            ),
            textAlign: TextAlign.right,
          )
        ],
      ),
    );
  }

  Widget dividerContainerWidget() {
    return Container(
      color: AppColors.colorSeparatorLine,
      height: getHeight(SizeConstants.dp75),
      width: getWidth(SizeConstants.dp0_5),
      margin: EdgeInsets.only(
          left: getWidth(SizeConstants.dp15),
          right: getWidth(SizeConstants.dp15)),
    );
  }

  Widget drilledCell(TicketingLineItems line, int index) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            regularInputWidget(
                index,
                line,
                InputFieldType.unitDrilled.name,
                '${widget.ticketingBitsController.getUnit(line)} ${AppStrings.drilled}${AppStrings.required}',
                '${AppStrings.hintDrilled} ${widget.ticketingBitsController.getUnit(line)}',
                width: widthInput,
                errorMessage:
                    '${AppStrings.errorEnter}${widget.ticketingBitsController.getUnit(line, lowerCase: true)}${AppStrings.errorDrilled}'),
            SizedBox(
              width: getWidth(SizeConstants.dp10),
            ),
            regularInputWidget(
                index,
                line,
                InputFieldType.pricePerUnit.name,
                '${AppStrings.priceper} ${widget.ticketingBitsController.getUnit(line)}${AppStrings.required}',
                AppStrings.hintbestPrice,
                width: widthInput,
                errorMessage:
                    '${AppStrings.errorPricePer}${widget.ticketingBitsController.getUnit(line, lowerCase: true)}'),
            SizedBox(
              width: getWidth(SizeConstants.dp10),
            ),
            regularInputWidget(
                index,
                line,
                InputFieldType.bestPrice.name,
                '${AppStrings.bestPrice}(${line.currency})${AppStrings.required}',
                AppStrings.hintbestPrice,
                width: widthInput,
                errorMessage: AppStrings.errorBestPrice),
          ],
        ),
        const SizedBox(
          height: SizeConstants.dp10,
        ),
        regularInputWidget(index, line, InputFieldType.comments.name,
            AppStrings.lineComments, AppStrings.hintlineComments,
            width: getWidth(SizeConstants.dp727))
      ],
    );
  }

  Widget dBRCell(TicketingLineItems line, int index) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        regularInputWidget(
            index,
            line,
            InputFieldType.bestPrice.name,
            '${AppStrings.bestPrice}(${line.currency})${AppStrings.required}',
            AppStrings.hintbestPrice,
            width: widthInput,
            errorMessage: AppStrings.errorBestPrice),
        SizedBox(
          width: getWidth(SizeConstants.dp10),
        ),
        Expanded(
          child: regularInputWidget(index, line, InputFieldType.comments.name,
              AppStrings.comments, AppStrings.hintlineComments),
        )
      ],
    );
  }

  Widget itemMenuOption(TicketingLineItems line, int index) {
    return Row(
      children: [
        //Removed with PBI 4161216, keep code commented
        /*renderImage(AppImages.clone, () async {
          await widget.ticketingBitsController.cloneLineItem(line, index);
        }, SizeConstants.dp18, SizeConstants.dp18),*/
        renderImage(AppImages.edit, () async {
          if (line.priceBookId != null) {
            widget.ticketingBitsController.editLineItemIndex = index;
            await widget.ticketingBitsController
                .checkAndAssignPriceBook(line.priceBookId ?? '');
            openFullBottomSheet(true);
          }
        }, SizeConstants.dp18, SizeConstants.dp18),
        renderImage(AppImages.delete, () {
          //Below code commented in case ongoing need to implement then
          //List<TicketingLineItems>? lineItemsInCurrentBits = widget.ticketingBitsController.currentLineItemsOfSelectedBit;
          //if (lineItemsInCurrentBits != null && lineItemsInCurrentBits.length != 1) {
          Navigator.of(context).push(GenericOverlay(
              title: AppStrings.deleteItem,
              message: AppStrings.deleteConfirmation,
              iconPath: AppImages.alertNoBitsConsign,
              negativeButtonText: AppStrings.cancel,
              positiveButtonText: AppStrings.confirm,
              onPositivePressCallback: () async {
                await widget.ticketingBitsController.removeLineItem(index);
                Get.back();
              }));

          /*} else {
                        showToastMsg(Get.context, 'You can\'t delete last line item', ToastStatus.failure);
                      }*/
        }, SizeConstants.dp18, SizeConstants.dp18),
        InkWell(
          child: renderImage(
              line.isExpanded == false
                  ? AppImages.arrowRight
                  : AppImages.down_arrow, () {
            widget.ticketingBitsController.changeExpandModeOfLine(line, index);
          },
              line.isExpanded == false
                  ? SizeConstants.dp18
                  : SizeConstants.dp18,
              line.isExpanded == false
                  ? SizeConstants.dp18
                  : SizeConstants.dp18),
        ),
      ],
    );
  }

  Widget cell(TicketingLineItems line, int index) {
    return Container(
      decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: AppColors.colorBlack.withOpacity(0.1),
              spreadRadius: AppValues.radius_1,
              blurRadius: AppValues.radius_1,
              offset: const Offset(0, 0.5), // changes position of shadow
            ),
          ],
          color: AppColors.colorWhite,
          borderRadius:
              const BorderRadius.all(Radius.circular(SizeConstants.dp5)),
          border: Border.all(
              color:
                  widget.ticketingBitsController.checkDuplicacy(index) == true
                      ? AppColors.colorRedError
                      : AppColors.colorWhite.withAlpha(0))),
      child: Padding(
        padding: const EdgeInsets.symmetric(
            horizontal: SizeConstants.dp18, vertical: SizeConstants.dp18),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                      '1.${index + 1} - ${line.priceBookId} - ${line.materialDescription ?? ''}',
                      style: tSw400dp18fontF.copyWith(
                        color: AppColors.colorMainText,
                      )),
                ),
                itemMenuOption(line, index),
                const SizedBox(
                  width: SizeConstants.dp10,
                )
              ],
            ),
            Visibility(
                visible: line.isExpanded ?? false,
                child: SizedBox(height: getHeight(SizeConstants.dp10))),
            Visibility(
              visible: line.isExpanded ?? false,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  priceWidget(line),
                  dividerContainerWidget(),
                  Expanded(
                      child: widget.ticketingBitsController
                                  .checkIfLineItemIsDBR(line) ==
                              true
                          ? dBRCell(line, index)
                          : drilledCell(line, index))
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    int totalLineItems =
        widget.ticketingBitsController.currentLineItemsOfSelectedBit?.length ??
            0;
    return Form(
        key: widget.ticketingBitsController.formKey,
        child: ListView.separated(
            separatorBuilder: (context, index) =>
                SizedBox(height: getHeight(SizeConstants.dp12)),
            itemCount: totalLineItems + 1,
            itemBuilder: (ctx, index) {
              //Adding last item '+ Add Line Item'
              if (index == totalLineItems) {
                return InkWell(
                  onTap: () async {
                    TicketingLineItems zeroPositionLineItems =
                        widget.ticketingBitsController.getLineItemFromIndex(0);
                    if (zeroPositionLineItems.priceBookId != null) {
                      await widget.ticketingBitsController
                          .checkAndAssignPriceBook(
                              zeroPositionLineItems.priceBookId ?? '');
                      openFullBottomSheet(false);
                    }
                    //Below line commented for future changes if need to show small bottom sheet for priceBook selection
                    //openPriceBookSelectionSheet();
                  },
                  child: Row(
                    children: [
                      Image.asset(
                        AppImages.icAddColored,
                        color: AppColors.colorMainText,
                        width: getWidth(SizeConstants.dp20),
                        height: getWidth(SizeConstants.dp20),
                      ),
                      Text(AppStrings.addLineItem,
                          style: tSw500dp15fontF.copyWith(
                            fontSize: SizeConstants.dp14,
                            color: AppColors.colorMainText,
                          )),
                    ],
                  ),
                );
              }
              TicketingLineItems currentLine = widget.ticketingBitsController
                  .getLineItemFromIndex(index < totalLineItems ? index : 0);

              //Return actual line item for bits
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  cell(currentLine, index),
                  Visibility(
                    visible:
                        widget.ticketingBitsController.checkDuplicacy(index) ==
                                true
                            ? true
                            : false,
                    child: SizedBox(
                      height: getHeight(SizeConstants.dp5),
                    ),
                  ),
                  Visibility(
                    visible:
                        widget.ticketingBitsController.checkDuplicacy(index) ==
                                true
                            ? true
                            : false,
                    child: Text(AppStrings.editValue,
                        style: tSw400dp14fontF.copyWith(
                          color: AppColors.colorRedError,
                        )),
                  ),
                ],
              );
            }));
  }

  void openPriceBookSelectionSheet() {
    widget.ticketingBitsController.selectedPriceBook = null;
    Get.bottomSheet(
      AddPriceBookSelectionTicketing(),
      isDismissible: false,
      enableDrag: false,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(AppValues.radius_10),
        ),
      ),
      clipBehavior: Clip.antiAliasWithSaveLayer,
    );
  }

  void openFullBottomSheet(bool isEditMode) {
    Get.bottomSheet(
      AddPriceBookFullTicketing(
        isEditMode: isEditMode,
      ),
      isDismissible: false,
      enableDrag: false,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(AppValues.radius_10),
        ),
      ),
      clipBehavior: Clip.antiAliasWithSaveLayer,
    );
  }
}
