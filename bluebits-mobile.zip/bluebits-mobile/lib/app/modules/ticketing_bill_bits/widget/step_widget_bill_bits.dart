import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/model/step_item.dart';

import '../../../core/common_widgets/no_overscroll_behavior.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_enum.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../controller/ticketing_bits_controller.dart';

class StepWidgetBillBits extends StatefulWidget {
  final TicketingBitsController ticketingBitsController;

  const StepWidgetBillBits({Key? key, required this.ticketingBitsController})
      : super(key: key);

  @override
  State<StepWidgetBillBits> createState() => _StepWidgetBillBitsState();
}

class _StepWidgetBillBitsState extends State<StepWidgetBillBits> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.colorTopPanel.withOpacity(0.7),
      child: Container(
        margin: const EdgeInsets.only(
            left: AppValues.margin_20,
            right: AppValues.margin_20,
            top: AppValues.margin_75),
        child: ScrollConfiguration(
          behavior: NoOverscrollBehavior(),
          child: Obx(() => ListView.builder(
                scrollDirection: Axis.vertical,
                itemCount: widget.ticketingBitsController.steps.length,
                itemBuilder: (ctx, index) {
                  return _stepsItem(
                      index: index,
                      stepItem: widget.ticketingBitsController.steps[index]);
                },
              )),
        ),
      ),
    );
  }

  Widget _stepsItem({required int index, required StepItem stepItem}) {
    return Container(
      margin: const EdgeInsets.only(bottom: AppValues.margin_47),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: getWidth(SizeConstants.dp26),
                height: getWidth(SizeConstants.dp26),
                margin: const EdgeInsets.only(right: AppValues.margin_7),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    //For filled color background
                    stepItem.isCurrentIndex
                        ? Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.all(Radius.circular(
                                  getWidth(AppValues.radius_13))),
                              color: AppColors.colorPrimaryDarkStep,
                            ),
                          )
                        : Container(),

                    //For step done tick mark
                    !stepItem.isCurrentIndex &&
                            stepItem.isCompleted &&
                            !stepItem.isInValid
                        ? SizedBox(
                            width: getWidth(SizeConstants.dp26),
                            height: getWidth(SizeConstants.dp26),
                            child: ImageIcon(
                              color:
                                  isNotLastStepAndOnLastStepOrIsQuoteSignedUploaded(
                                          index, stepItem)
                                      ? AppColors.colorPrimaryDarkStep.withOpacity(0.3)
                                      : AppColors.colorPrimaryDarkStep,
                              const AssetImage(
                                AppImages.icBlueTickMark,
                              ),
                            ),
                          )
                        : Container(),
                    //for show step number
                    (stepItem.isCurrentIndex && stepItem.isCompleted) ||
                            !stepItem.isCompleted ||
                            stepItem.isInValid
                        ? Text(
                            '${index + 1}',
                            style: tSw400dp12fontF.copyWith(
                              color: widget.ticketingBitsController.index
                                          .value ==
                                      index
                                  ? AppColors.colorWhite
                                  : isStep2IsQuoteSignedUploaded(index, stepItem)
                                      ? AppColors.colorPrimaryDarkStep
                                      :stepItem.isInValid
                                      ? AppColors.colorRedError
                                      : AppColors.colorSubText.withOpacity(0.6),
                            ),
                          )
                        : Container(),
                    //for color border done/pending
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(
                            Radius.circular(getWidth(AppValues.radius_13))),
                        border: Border.all(
                            width: SizeConstants.dp1,
                            color:
                                isNotLastStepAndOnLastStepOrIsQuoteSignedUploaded(
                                        index, stepItem)
                                    ? AppColors.colorPrimaryDarkStep.withOpacity(0.3)
                                    : isStep2IsQuoteSignedUploaded(index, stepItem)
                                    ? AppColors.colorPrimaryDarkStep
                                    : stepItem.isCurrentIndex ||
                                            (stepItem.isCompleted &&
                                                !stepItem.isInValid)
                                        ? AppColors.colorPrimaryDarkStep
                                        : stepItem.isInValid
                                            ? AppColors.colorRedError
                                            : AppColors.colorSubText
                                                .withOpacity(0.6)),
                      ),
                    ),
                  ],
                ),
              ),
              Flexible(
                fit: FlexFit.tight,
                child: GestureDetector(
                  onTap: () {
                    // Remove below line and code uncomment once full flow work done
                    if (widget.ticketingBitsController.index.value == index) {
                      return;
                    }

                    //Condition validation for step 2 line item field error validation on step item click without Quote Preview
                    //button click movement
                    if (widget.ticketingBitsController.index.value == 1 && widget.ticketingBitsController.index.value != index &&
                        widget.ticketingBitsController.nextButtonStatus.value != NextButtonState.hide.name) {
                      widget.ticketingBitsController.isPriceBookValidationEnable = true;
                      widget.ticketingBitsController.formKey.currentState?.validate();
                    }

                    if (index == 0 &&
                        widget.ticketingBitsController.isConfirmationScreen ==
                            false &&
                        !isNotLastStepAndOnLastStepOrIsQuoteSignedUploaded(
                            index, stepItem)) {
                      widget.ticketingBitsController
                          .updateStepItemStatus(currentIndex: index);
                    } else if (index == 1 &&
                        widget.ticketingBitsController.isConfirmationScreen ==
                            false &&
                        !isNotLastStepAndOnLastStepOrIsQuoteSignedUploaded(
                            index, stepItem)) {
                      widget.ticketingBitsController.closeEnterDetailOverLay();
                      widget.ticketingBitsController.validateEnterDetail();
                      widget.ticketingBitsController
                          .updateStepItemStatus(currentIndex: index);

                    } else if (index == 2 &&
                        widget.ticketingBitsController.isConfirmationScreen ==
                            false) {
                      widget.ticketingBitsController.closeEnterDetailOverLay();
                      widget.ticketingBitsController.validateEnterDetail();
                      widget.ticketingBitsController
                          .updateStepItemStatus(currentIndex: index);
                      widget.ticketingBitsController.isQuotePreview = true;

                      // open Quote screen with default Digital sign Tab selected
                      widget.ticketingBitsController
                          .openQuoteScreen(widget.ticketingBitsController);
                    } else if (index == 3 &&
                        widget.ticketingBitsController.isQuoteNextEnable) {
                      widget.ticketingBitsController.isConfirmationScreen =
                          true;
                      widget.ticketingBitsController
                          .updateStepItemStatus(currentIndex: index);
                    }
                  },
                  child: Text(
                    stepItem.title,
                    style: tSw700fontF.copyWith(
                      fontSize: SizeConstants.dp15,
                      color: isNotLastStepAndOnLastStepOrIsQuoteSignedUploaded(
                              index, stepItem)
                          ? AppColors.colorMainText.withOpacity(0.3)
                          : stepItem.isCurrentIndex || stepItem.isCompleted
                              ? AppColors.colorMainText
                              : AppColors.colorSubText.withOpacity(0.6),
                    ),
                  ),
                ),
              ),
            ],
          ),
          Row(
            children: [
              SizedBox(
                width: getWidth(SizeConstants.dp33),
              ),
              Flexible(
                fit: FlexFit.tight,
                child: Text(
                  stepItem.description,
                  style: tSw400dp12fontF.copyWith(
                    color: isNotLastStepAndOnLastStepOrIsQuoteSignedUploaded(
                            index, stepItem)
                        ? AppColors.colorSubText.withOpacity(0.3)
                        : stepItem.isCurrentIndex || stepItem.isCompleted
                            ? AppColors.colorSubText
                            : AppColors.colorSubText.withOpacity(0.6),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  bool isNotLastStepAndOnLastStepOrIsQuoteSignedUploaded(
      int index, StepItem stepItem) {
    return (index != 3 && (stepItem.isLastStep || stepItem.isSignedOrUploaded));
  }

  bool isStep2IsQuoteSignedUploaded(int index, StepItem stepItem) {
    return stepItem.isInValid && index == 2 && widget.ticketingBitsController.isQuotePreview;
  }
}
