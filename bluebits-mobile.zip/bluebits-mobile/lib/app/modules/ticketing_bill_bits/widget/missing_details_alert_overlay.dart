import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/controller/ticketing_bits_controller.dart';
import '../../../common_binding/realm_initial.dart';
import '../../../core/common_widgets/common_widget.dart';
import '../../../core/common_widgets/custom_button_material.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';

class MissingDetailsAlertOverlay extends ModalRoute<void> {
  final TicketingBitsController ticketingBitsController;
  final bool isTicketLater;

  MissingDetailsAlertOverlay(this.ticketingBitsController, {this.isTicketLater = false});

  @override
  Duration get transitionDuration => const Duration(milliseconds: 0);

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => false;

  @override
  Color get barrierColor => AppColors.colorBlack.withOpacity(0.3);

  @override
  String get barrierLabel => '';

  @override
  bool get maintainState => true;

  final RealmInitial realm = Get.find(tag: (RealmInitial).toString());

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    // This makes sure that text and other content follows the material style
    return Material(
      type: MaterialType.transparency,
      // make sure that the overlay content is not cut off
      child: SafeArea(
        child: _buildOverlayContent(context),
      ),
    );
  }

  Widget _buildOverlayContent(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: getWidth(SizeConstants.dp570),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(SizeConstants.dp10),
                boxShadow: [BoxShadow(color: AppColors.colorBlack.withOpacity(0.3), blurRadius: SizeConstants.dp7)]),
            child: Container(
              decoration: BoxDecoration(
                color: AppColors.colorWhite,
                borderRadius: BorderRadius.circular(SizeConstants.dp10),
              ),
              child: Padding(
                padding: const EdgeInsets.all(SizeConstants.dp20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Stack(children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          width: getWidth(SizeConstants.dp45),
                          height: getWidth(SizeConstants.dp45),
                          padding: EdgeInsets.all(getWidth(SizeConstants.dp13)),
                          child: InkWell(
                            child: Image.asset(
                              AppImages.cancelBlackPng,
                              fit: BoxFit.cover,
                            ),
                            onTap: () {
                              Get.back();
                            },
                          ),
                        ),
                      ),
                      SizedBox(
                        height: getHeight(SizeConstants.dp64),
                        child: Row(
                          children: [
                            CustomWidgets().roundIconWidget(AppImages.warning),
                            // Image(image: AssetImage(iconPath) ,),
                            const SizedBox(
                              width: SizeConstants.dp16,
                            ),
                            CustomWidgets().headerTitle(AppStrings.pendingInfo, warehouseTextStyle)
                          ],
                        ),
                      )
                    ]),
                    SizedBox(
                      height: getHeight(SizeConstants.dp4),
                    ),
                    Row(
                      children: [
                        const SizedBox(
                          width: SizeConstants.dp75,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              AppStrings.pendingInfoMsg,
                              style: wareHouseStaticTextStyle,
                            ),
                            SizedBox(
                              height: getHeight(SizeConstants.dp19),
                            ),
                            Visibility(
                              visible: ticketingBitsController.isEnterDetailItemInValid,
                              child: GestureDetector(
                                onTap: () {
                                  ticketingBitsController.updateStepItemStatus(currentIndex: 0); //Step 1 navigate
                                  Get.back();
                                },
                                child: Container(
                                  width: getWidth(SizeConstants.dp400),
                                  height: getHeight(SizeConstants.dp60),
                                  decoration: BoxDecoration(
                                    color: AppColors.colorWhite,
                                    border: Border.all(color: AppColors.colorSeparatorLine),
                                    borderRadius: BorderRadius.circular(AppValues.radius_4),
                                  ),
                                  child: Center(
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: SizeConstants.dp16, right: SizeConstants.dp27),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Wrap(
                                            crossAxisAlignment: WrapCrossAlignment.center,
                                            children: [
                                              Container(
                                                width: getWidth(SizeConstants.dp24),
                                                height: getWidth(SizeConstants.dp24),
                                                alignment: Alignment.center,
                                                decoration: BoxDecoration(
                                                  border: Border.all(color: AppColors.colorSubText),
                                                  borderRadius: BorderRadius.circular(SizeConstants.dp12),
                                                ),
                                                child: Text(
                                                  AppStrings.pendingAction1,
                                                  style: tSw400dp12fontF.copyWith(color: AppColors.colorSubText),
                                                ),
                                              ),
                                              const SizedBox(
                                                width: SizeConstants.dp12,
                                              ),
                                              Text(
                                                AppStrings.enterDetails,
                                                style: tSw400dp16fontF.copyWith(color: AppColors.colorMainText),
                                              ),
                                            ],
                                          ),
                                          Text(
                                            AppStrings.actionNeeded,
                                            style: tSw600dp14fontF.copyWith(color: AppColors.colorRedError),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            !isTicketLater
                                ? const SizedBox(
                                    height: SizeConstants.dp10,
                                  )
                                : Container(),
                            Visibility(
                              visible: ticketingBitsController.isPriceBookItemInValid && !isTicketLater,
                              child: GestureDetector(
                                onTap: () {
                                  ticketingBitsController.updateStepItemStatus(currentIndex: 1); //Step 2 navigate
                                  Get.back();
                                },
                                child: Container(
                                  width: getWidth(SizeConstants.dp400),
                                  height: getHeight(SizeConstants.dp60),
                                  decoration: BoxDecoration(
                                    color: AppColors.colorWhite,
                                    border: Border.all(color: AppColors.colorSeparatorLine),
                                    borderRadius: BorderRadius.circular(AppValues.radius_4),
                                  ),
                                  child: Center(
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: SizeConstants.dp16, right: SizeConstants.dp27),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Wrap(
                                            crossAxisAlignment: WrapCrossAlignment.center,
                                            children: [
                                              Container(
                                                width: getWidth(SizeConstants.dp24),
                                                height: getWidth(SizeConstants.dp24),
                                                alignment: Alignment.center,
                                                decoration: BoxDecoration(
                                                  border: Border.all(color: AppColors.colorSubText),
                                                  borderRadius: BorderRadius.circular(SizeConstants.dp12),
                                                ),
                                                child: Text(
                                                  AppStrings.pendingAction2,
                                                  style: tSw400dp12fontF.copyWith(color: AppColors.colorSubText),
                                                ),
                                              ),
                                              const SizedBox(
                                                width: SizeConstants.dp12,
                                              ),
                                              Text(
                                                AppStrings.selectPricebook,
                                                style: tSw400dp16fontF.copyWith(color: AppColors.colorMainText),
                                              ),
                                            ],
                                          ),
                                          Text(
                                            AppStrings.actionNeeded,
                                            style: tSw600dp14fontF.copyWith(color: AppColors.colorRedError),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                    const SizedBox(
                      height: SizeConstants.dp50,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget bottomButtonWidget(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        CustomButtonMaterial(
          width: getWidth(SizeConstants.dp102),
          height: getHeight(SizeConstants.dp45),
          backgroundColor: AppColors.colorWhite,
          foregroundColor: AppColors.colorPrimary,
          borderRadius: AppValues.radius_4,
          text: AppStrings.cancel,
          style: tSw500dp16fontF,
          side: const BorderSide(
            width: SizeConstants.dp1,
            color: AppColors.colorPrimary,
          ),
          onPressCallback: () {
            Get.back();
          },
        ),
        SizedBox(
          width: getWidth(SizeConstants.dp10),
        ),
        CustomButtonMaterial(
          width: getWidth(SizeConstants.dp130),
          height: getHeight(SizeConstants.dp45),
          backgroundColor: AppColors.colorPrimary,
          foregroundColor: Colors.white,
          borderRadius: AppValues.radius_4,
          text: AppStrings.ok,
          style: tSw500dp16fontF,
          onPressCallback: () async {
            Get.back();
          },
        ),
      ],
    );
  }

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation, Animation<double> secondaryAnimation, Widget child) {
    // You can add your own animations for the overlay content
    return FadeTransition(
      opacity: animation,
      child: ScaleTransition(
        scale: animation,
        child: child,
      ),
    );
  }
}
