import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:signature/signature.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/controller/ticketing_bits_controller.dart';

import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/common_widget.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';

class CustomerUserDigitalSignOverlayBillBits extends StatelessWidget {
  final TicketingBitsController ticketingBitsController;

  CustomerUserDigitalSignOverlayBillBits(
      {Key? key, required this.ticketingBitsController})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: AppColors.transparentColor,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              fit: StackFit.loose,
              children: [
                Container(
                  height: getHeight(SizeConstants.dp40),
                  alignment: Alignment.centerLeft,
                  margin: EdgeInsets.only(left: getHeight(AppValues.margin_89)),
                  child: TabBar(
                    labelColor: AppColors.colorPrimaryDarkStep,
                    unselectedLabelColor: AppColors.colorSubText,
                    indicatorColor: AppColors.colorPrimaryDarkStep,
                    indicatorPadding: EdgeInsets.zero,
                    isScrollable: true,
                    padding: EdgeInsets.zero,
                    labelPadding: const EdgeInsets.only(
                        right: SizeConstants.dp20, left: SizeConstants.dp20),
                    indicatorWeight: 2,
                    onTap: (value) {
                      if (value == 0) {
                        ticketingBitsController.quoteSignType.isUserSignTap =
                            false;
                        ticketingBitsController.setCustomerNameAndSignNew(
                            ticketingBitsController
                                .customerSignatureController);
                      } else {
                        ticketingBitsController.quoteSignType.isUserSignTap =
                            true;
                        ticketingBitsController.setUserNameAndSignNew(
                            ticketingBitsController.userSignatureController);
                      }
                      ticketingBitsController.updateQuoteStatusNew();
                    },
                    tabs: [
                      Tab(
                        child: Wrap(
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            Obx(
                              () => Visibility(
                                visible: ticketingBitsController
                                    .quoteSignType.isCustomerSignCaptured,
                                child: Image.asset(AppImages.success,
                                    width: getHeight(SizeConstants.dp12),
                                    height: getHeight(SizeConstants.dp12)),
                              ),
                            ),
                            SizedBox(
                              width: getWidth(SizeConstants.dp5),
                            ),
                            Obx(
                              () => Text(
                                AppStrings.customer,
                                style: !ticketingBitsController
                                        .quoteSignType.isUserSignTap
                                    ? tSw700fontF.copyWith(
                                        fontSize: SizeConstants.dp16)
                                    : tSw400dp16fontF.copyWith(
                                        fontSize: SizeConstants.dp16),
                                /* style: ticketingBitsController
                                        .quoteSignType.isUserSignTap
                                    ?
                                     tSw400dp16fontF.copyWith(
                                        fontSize: SizeConstants.dp16) :
                                tSw700fontF.copyWith(
                                    fontSize: SizeConstants.dp16),*/
                              ),
                            ),
                          ],
                        ),
                      ),
                      Tab(
                        child: Wrap(
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              Obx(
                                () => Visibility(
                                  visible: ticketingBitsController
                                      .quoteSignType.isUserSignCaptured,
                                  child: Image.asset(AppImages.success,
                                      width: getHeight(SizeConstants.dp12),
                                      height: getHeight(SizeConstants.dp12)),
                                ),
                              ),
                              SizedBox(
                                width: getWidth(SizeConstants.dp5),
                              ),
                              Obx(
                                () => Text(
                                  AppStrings.user,
                                  style: ticketingBitsController
                                          .quoteSignType.isUserSignTap
                                      ? tSw700fontF.copyWith(
                                          fontSize: SizeConstants.dp16)
                                      : tSw400dp16fontF.copyWith(
                                          fontSize: SizeConstants.dp16),
                                  /*  style: ticketingBitsController
                                          .quoteSignType.isUserSignTap
                                      ? tSw700fontF.copyWith(
                                          fontSize: SizeConstants.dp16)
                                      : tSw400dp16fontF.copyWith(
                                          fontSize: SizeConstants.dp16),*/
                                ),
                              ),
                            ]),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  top: getWidth(SizeConstants.dp35),
                  width: getWidth(getScreenWidth()),
                  child: const Divider(
                      thickness: 1, color: AppColors.colorSeparatorLine),
                ),
              ],
            ),
            const SizedBox(
              height: SizeConstants.dp19,
            ),
            Expanded(
              child: TabBarView(
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    customerSignUiWidget(),
                    userSignUiWidget(),
                  ]),
            )
          ],
        ),
      ),
    );
  }

  /* User Sign Widget*/
  userSignUiWidget() {
    return Container(
      margin: const EdgeInsets.only(
          left: SizeConstants.dp32, right: SizeConstants.dp30),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Wrap(
                children: [
                  Text(
                    AppStrings.sign2,
                    style: tSw700fontF.copyWith(
                      color: AppColors.colorBlack,
                      fontSize: SizeConstants.dp18,
                    ),
                  ),
                  SizedBox(
                    width: getHeight(SizeConstants.dp10),
                  ),
                  Text(
                    AppStrings.user,
                    style: tSw400dp14fontF.copyWith(
                      color: AppColors.colorBlack,
                      fontSize: SizeConstants.dp18,
                    ),
                  ),
                ],
              ),
              enterUserNameWidget()
            ],
          ),
          SizedBox(
            height: getHeight(SizeConstants.dp5),
          ),
          Stack(
            children: [
              Container(
                height: getHeight(SizeConstants.dp280),
                color: AppColors.colorBg,
                child: Listener(
                  onPointerMove: (event) {
                    ticketingBitsController.quoteSignType.isUserSignStartDraw =
                        true;
                    ticketingBitsController.userGreenTick();
                  },
                  child: Signature(
                    width: (getWidth(getScreenWidth()) -
                        getWidth(SizeConstants.dp360)),
                    height: getHeight(SizeConstants.dp280),
                    controller: ticketingBitsController.userSignatureController,
                    backgroundColor: AppColors.colorBg,
                  ),
                ),
              ),
              Obx(() => Visibility(
                  visible: !ticketingBitsController
                      .quoteSignType.isUserSignStartDraw,
                  child: Positioned(
                      top: getHeight(SizeConstants.dp280) / 2,
                      left: (getWidth(getScreenWidth() -
                                  getWidth(SizeConstants.dp300))) /
                              2 -
                          getWidth(SizeConstants.dp100),
                      child: Text(AppStrings.pleaseSign,
                          style: tSw400dp24fontF.copyWith(
                              color:
                                  AppColors.colorMainText.withAlpha(100)))))),
              Container(
                margin: const EdgeInsets.all(SizeConstants.dp15),
                alignment: Alignment.topRight,
                child: InkWell(
                  onTap: () {
                    if (ticketingBitsController
                        .userSignatureController.isNotEmpty) {
                      ticketingBitsController.clearUserNameSign(
                          ticketingBitsController.userSignatureController,
                          false);
                    }
                  },
                  child: Obx(
                    () => Text(
                      AppStrings.clear,
                      style: tSw500dp12fontF.copyWith(
                        fontSize: SizeConstants.dp14,
                        color: ticketingBitsController
                                .quoteSignType.isUserSignStartDraw
                            ? AppColors.colorPrimary
                            : AppColors.colorPrimary.withOpacity(0.2),
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
          SizedBox(
            height: getHeight(SizeConstants.dp4),
          ),
        ],
      ),
    );
  }

  Widget enterUserNameWidget() {
    return SizedBox(
      width: getWidth(SizeConstants.dp359),
      height: getHeight(SizeConstants.dp45),
      child: TextFormField(
        controller: ticketingBitsController.userNameTxt,
        textAlignVertical: TextAlignVertical.center,
        autofocus: false,
        autocorrect: false,
        enableSuggestions: false,
        style: tSw400dp14fontF.copyWith(
          fontSize: SizeConstants.dp18,
          color: AppColors.colorMainText,
        ),
        inputFormatters: [
          filteringTextInputFormatter,
        ],
        decoration: InputDecoration(
            hintText: AppStrings.enterYourNameHint,
            hintStyle: tSw400dp14fontF.copyWith(
              fontSize: SizeConstants.dp18,
              color: AppColors.colorSubText.withOpacity(0.7),
            ),
            filled: true,
            fillColor: AppColors.colorF5F6F5.withOpacity(0.8),
            enabledBorder: outlineBorder,
            focusedBorder: outlineBorder,
            border: outlineBorder,
            focusedErrorBorder: outlineBorder,
            errorBorder: outlineBorder,
            floatingLabelBehavior: FloatingLabelBehavior.never,
            isDense: true),
        maxLines: 1,
        onChanged: (value) {
          ticketingBitsController.quoteSignType.userName = value;
          ticketingBitsController.userGreenTick();
          //  ticketingBitsController.updateQuoteStatusNew();
        },
        keyboardType: TextInputType.text,
        textAlign: TextAlign.start,
        validator: (value) {
          return null;
        },
      ),
    );
  }

  /* Customer Sign Widget*/
  customerSignUiWidget() {
    return Container(
      margin: const EdgeInsets.only(
          left: SizeConstants.dp32, right: SizeConstants.dp30),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Wrap(
                children: [
                  Text(
                    AppStrings.sign1,
                    style: tSw700fontF.copyWith(
                      color: AppColors.colorBlack,
                      fontSize: SizeConstants.dp18,
                    ),
                  ),
                  SizedBox(
                    width: getHeight(SizeConstants.dp10),
                  ),
                  Text(
                    AppStrings.customer,
                    style: tSw400dp14fontF.copyWith(
                      color: AppColors.colorBlack,
                      fontSize: SizeConstants.dp18,
                    ),
                  ),
                ],
              ),
              enterCustomerNameWidget()
            ],
          ),
          Stack(
            children: [
              Obx(
                () => Container(
                  height: getHeight(SizeConstants.dp280),
                  color: AppColors.colorBg,
                  child: Listener(
                    onPointerMove: (event) {
                      ticketingBitsController
                          .quoteSignType.isCustomerSignStartDraw = true;
                      ticketingBitsController.customerGreenTick();
                    },
                    child: Signature(
                      width: (getWidth(getScreenWidth()) -
                          getWidth(SizeConstants.dp360)),
                      height: getHeight(SizeConstants.dp280),
                      controller:
                          ticketingBitsController.customerSignatureController,
                      backgroundColor: AppColors.colorBg,
                    ),
                  ),
                ),
              ),
              Obx(
                () => Visibility(
                  visible: !ticketingBitsController
                      .quoteSignType.isCustomerSignStartDraw,
                  child: Positioned(
                      top: getHeight(SizeConstants.dp280) / 2,
                      left: (getWidth(getScreenWidth() -
                                  getWidth(SizeConstants.dp300))) /
                              2 -
                          getWidth(SizeConstants.dp100),
                      child: Text(AppStrings.pleaseSign,
                          style: tSw400dp24fontF.copyWith(
                              color: AppColors.colorMainText.withAlpha(100)))),
                ),
              ),
              Container(
                margin: const EdgeInsets.all(SizeConstants.dp15),
                alignment: Alignment.topRight,
                child: InkWell(
                  onTap: () {
                    if (ticketingBitsController
                        .customerSignatureController.value.isNotEmpty) {
                      ticketingBitsController.clearCustomerNameSign(
                          ticketingBitsController.customerSignatureController,
                          false);
                    }
                  },
                  child: Obx(
                    () => Text(
                      AppStrings.clear,
                      style: tSw500dp12fontF.copyWith(
                        fontSize: SizeConstants.dp14,
                        color: ticketingBitsController
                                .quoteSignType.isCustomerSignStartDraw
                            ? AppColors.colorPrimary
                            : AppColors.colorPrimary.withOpacity(0.2),
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
          SizedBox(
            height: getHeight(SizeConstants.dp4),
          ),
        ],
      ),
    );
  }

  Widget enterCustomerNameWidget() {
    return SizedBox(
      width: getWidth(SizeConstants.dp359),
      height: getHeight(SizeConstants.dp45),
      child: TextFormField(
        controller: ticketingBitsController.customerNameTxt,
        textAlignVertical: TextAlignVertical.center,
        autofocus: false,
        autocorrect: false,
        enableSuggestions: false,
        style: tSw400dp14fontF.copyWith(
          fontSize: SizeConstants.dp18,
          color: AppColors.colorMainText,
        ),
        inputFormatters: [
          filteringTextInputFormatter,
        ],
        decoration: InputDecoration(
            hintText: AppStrings.customerNameSmall,
            hintStyle: tSw400dp14fontF.copyWith(
              fontSize: SizeConstants.dp18,
              color: AppColors.colorSubText.withOpacity(0.7),
            ),
            filled: true,
            fillColor: AppColors.colorF5F6F5.withOpacity(0.8),
            enabledBorder: outlineBorder,
            focusedBorder: outlineBorder,
            border: outlineBorder,
            focusedErrorBorder: outlineBorder,
            errorBorder: outlineBorder,
            floatingLabelBehavior: FloatingLabelBehavior.never,
            isDense: true),
        maxLines: 1,
        onChanged: (value) {
          ticketingBitsController.quoteSignType.customerName = value;
          ticketingBitsController.customerGreenTick();
        },
        keyboardType: TextInputType.text,
        textAlign: TextAlign.start,
        validator: (value) {
          return null;
        },
      ),
    );
  }

  final outlineBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(AppValues.radius_10),
    borderSide: const BorderSide(
        width: SizeConstants.dp1, color: AppColors.colorSeparatorLine),
  );
}
