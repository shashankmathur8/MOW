import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/widget/digital_sign_overlay_bill_bits.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../../core/common_widgets/custom_button_material.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../../shared/generic_overlay.dart';
import '../controller/ticketing_bits_controller.dart';
import 'manual_sign_overlay_bill_bits.dart';
import 'missing_details_alert_overlay.dart';

class QuoteScreenBillBits extends StatefulWidget {
  const QuoteScreenBillBits({super.key, required this.ticketingBitsController});

  final TicketingBitsController ticketingBitsController;

  @override
  State<QuoteScreenBillBits> createState() => _QuoteScreenBillBitsState();
}

class _QuoteScreenBillBitsState extends State<QuoteScreenBillBits> {
  @override
  Widget build(BuildContext context) {
    return Obx(
      () => Column(
        children: [
          Row(
            children: [
              Container(
                  alignment: Alignment.centerLeft,
                  margin: EdgeInsets.only(
                    top: getHeight(AppValues.margin_34),
                    left: getWidth(AppValues.margin_40),
                    right: getWidth(AppValues.margin_19),
                  ),
                  child: pageHeaderTitle),
              Flexible(
                fit: FlexFit.tight,
                child: Center(
                  child: Container(
                    width: getHeight(SizeConstants.dp255),
                    height: getHeight(SizeConstants.dp40),
                    margin: EdgeInsets.only(
                      top: getHeight(AppValues.margin_28),
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.colorSeparatorLine.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(SizeConstants.dp20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(SizeConstants.dp4),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          GestureDetector(
                              child: Container(
                                padding:
                                    const EdgeInsets.all(SizeConstants.dp2),
                                alignment: Alignment.center,
                                width: getHeight(SizeConstants.dp123),
                                height: getHeight(SizeConstants.dp34),
                                decoration: BoxDecoration(
                                  color: widget.ticketingBitsController.tag
                                              .value ==
                                          AppStrings.isDigital
                                      ? AppColors.colorWhite
                                      : null,
                                  borderRadius:
                                      BorderRadius.circular(SizeConstants.dp20),
                                ),
                                child: Text(
                                  AppStrings.digitalSign,
                                  style: tSw500dp15fontF.copyWith(
                                    fontSize: SizeConstants.dp15,
                                    color: widget.ticketingBitsController.tag
                                                .value ==
                                            AppStrings.isDigital
                                        ? AppColors.colorMainText
                                        : AppColors.colorSubText,
                                  ),
                                ),
                              ),
                              onTap: () {
                                if (widget
                                    .ticketingBitsController.isDigitalSignTab) {
                                  return;
                                }
                                if (widget.ticketingBitsController.quoteSignType
                                    .isFileUploaded) {
                                  Navigator.of(context).push(GenericOverlay(
                                      title: AppStrings.switchToDigitalTitle,
                                      message: AppStrings.switchToDigitalMsg,
                                      iconPath: AppImages.warning,
                                      negativeButtonText: AppStrings.no,
                                      positiveButtonText: AppStrings.yes,
                                      onPositivePressCallback: () {
                                        widget.ticketingBitsController
                                            .deleteManualPdf(
                                                widget.ticketingBitsController);
                                        Get.back();
                                        widget.ticketingBitsController
                                            .onTapSignatureTabButton(true,
                                                widget.ticketingBitsController);
                                      }));
                                } else {
                                  widget.ticketingBitsController
                                      .onTapSignatureTabButton(
                                          true, widget.ticketingBitsController);
                                }
                              }),
                          GestureDetector(
                              child: Container(
                                alignment: Alignment.center,
                                width: getHeight(SizeConstants.dp123),
                                height: getHeight(SizeConstants.dp34),
                                decoration: BoxDecoration(
                                  color: widget.ticketingBitsController.tag
                                              .value ==
                                          AppStrings.isManual
                                      ? AppColors.colorWhite
                                      : null,
                                  borderRadius:
                                      BorderRadius.circular(SizeConstants.dp20),
                                ),
                                child: Text(
                                  AppStrings.manualSign,
                                  style: tSw500dp15fontF.copyWith(
                                    fontSize: SizeConstants.dp15,
                                    color: widget.ticketingBitsController.tag
                                                .value ==
                                            AppStrings.isManual
                                        ? AppColors.colorMainText
                                        : AppColors.colorSubText,
                                  ),
                                ), // button text
                              ),
                              onTap: () {
                                if (!widget
                                    .ticketingBitsController.isDigitalSignTab) {
                                  return;
                                }
                                if (widget.ticketingBitsController.quoteSignType
                                    .isDigitalSignDone) {
                                  Navigator.of(context).push(GenericOverlay(
                                      title: AppStrings.switchToManualTitle,
                                      message: AppStrings.switchToManualMsg,
                                      iconPath: AppImages.warning,
                                      negativeButtonText: AppStrings.no,
                                      positiveButtonText: AppStrings.yes,
                                      onPositivePressCallback: () {

                                                widget.ticketingBitsController
                                                    .deleteDigitalSignDetails(
                                                widget.ticketingBitsController
                                                    );
                                        Get.back();
                                        widget.ticketingBitsController
                                            .onTapSignatureTabButton(false,
                                                widget.ticketingBitsController);
                                      }));
                                } else {
                                  widget.ticketingBitsController
                                      .onTapSignatureTabButton(false,
                                          widget.ticketingBitsController);
                                }
                              }),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),

          Flexible(
            fit: FlexFit.tight,
            child: Center(
              child: Container(
                height: double.infinity,
                padding: EdgeInsets.only(
                  top: getHeight(AppValues.padding_15),
                  left: getWidth(AppValues.padding_40),
                  right: getWidth(AppValues.padding_19),
                ),
                child: Obx(() =>
                    widget.ticketingBitsController.quoteSignType.isLoadHtml
                        ? loadHtml()
                        : widget.ticketingBitsController.loadPdf()),
              ),
            ),
          ),
          //Digital Sign View
          Visibility(
            visible:
                widget.ticketingBitsController.tag.value == AppStrings.isDigital
                    ? true
                    : false,
            child: Column(
              children: [
                dividerContainerBottomWidget,
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    signConfirmedMsg(),
                    Wrap(
                      crossAxisAlignment: WrapCrossAlignment.end,
                      children: [
                        confirmButtonWidget(),
                        acceptButtonWidget(),
                      ],
                    ),
                  ],
                )
              ],
            ),
          ),
          // Manual sign view
          Visibility(
            visible:
                widget.ticketingBitsController.tag.value == AppStrings.isDigital
                    ? false
                    : true,
            child: Column(
              children: [
                dividerContainerBottomWidget,
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Visibility(
                      visible:
                          widget
                              .ticketingBitsController.quoteSignType.isFileUploaded,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Wrap(
                            crossAxisAlignment: WrapCrossAlignment.start,
                            children: [
                              quoteUploadedMsg(),
                              SizedBox(width: getWidth(SizeConstants.dp7)),
                              separatorPipe(),
                              SizedBox(width: getWidth(SizeConstants.dp7)),
                              GestureDetector(
                                  onTap: () {
                                    widget.ticketingBitsController
                                        .deleteManualPdf(
                                            widget.ticketingBitsController);
                                  },
                                  child:
                                      Image.asset(AppImages.quoteDeleteIcon)),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Wrap(
                      crossAxisAlignment: WrapCrossAlignment.end,
                      children: [
                        uploadSignedQuoteButtonWidget(),
                        printButtonWidget(),
                        manualConfirmButtonWidget(),
                      ],
                    ),
                  ],
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget loadHtml() {
    return WebViewWidget(
        controller: widget.ticketingBitsController.webHtmlViewController);
  }

  Widget pageHeaderTitle = Text(
    AppStrings.ticket,
    style: tSw400dp14fontF.copyWith(
      fontSize: SizeConstants.dp24,
      color: AppColors.colorMainText,
    ),
  );

  Widget dividerContainerBottomWidget = Container(
    color: AppColors.colorSeparatorLine,
    height: getHeight(SizeConstants.dp1),
    margin: const EdgeInsets.only(bottom: AppValues.margin_20),
  );

  /// **************** Manual Signature *******************

  Widget separatorPipe() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: getWidth(AppValues.margin_7)),
      width: getWidth(SizeConstants.dp1),
      height: getHeight(SizeConstants.dp15),
      color: AppColors.colorSeparatorLine,
    );
  }

  Widget printButtonWidget() {
    return Obx(
      () => Visibility(
        visible:
            !widget.ticketingBitsController.quoteSignType.isFileUploaded,
        child: Container(
          alignment: Alignment.bottomRight,
          padding: const EdgeInsets.only(
              bottom: AppValues.padding_20, right: AppValues.padding_20),
          child: CustomButtonMaterial(
            width: getWidth(SizeConstants.dp149),
            height: getHeight(SizeConstants.dp45),
            backgroundColor: AppColors.colorPrimary,
            foregroundColor: AppColors.colorWhite,
            borderRadius: AppValues.radius_4,
            text: AppStrings.print,
            style: tSw600dp16fontF.copyWith(
              color: AppColors.colorWhite,
            ),
            onPressCallback: () {
              if (widget.ticketingBitsController.checkMissingDetails()) {
                Navigator.of(context).push(
                    MissingDetailsAlertOverlay(widget.ticketingBitsController));
              } else {widget.ticketingBitsController
                  .printingHtml(widget.ticketingBitsController);}
            },
          ),
        ),
      ),
    );
  }

  Widget uploadSignedQuoteButtonWidget() {
    return Obx(
      () => Visibility(
        visible:
            !widget.ticketingBitsController.quoteSignType.isFileUploaded,
        child: Container(
          alignment: Alignment.bottomRight,
          padding: const EdgeInsets.only(
              bottom: AppValues.padding_20, right: AppValues.padding_20),
          child: CustomButtonMaterial(
              width: getWidth(SizeConstants.dp199),
              height: getHeight(SizeConstants.dp45),
              backgroundColor: AppColors.transparentColor,
              foregroundColor: AppColors.transparentColor,
              borderRadius: AppValues.radius_4,
              text: AppStrings.uploadSignedQuote,
              side: BorderSide(
                width: SizeConstants.dp1,
                color:
                    widget.ticketingBitsController.checkMissingDetails() ||
                        !widget.ticketingBitsController.isEnableUploadQuoteSign
                        .value
                        ? AppColors.colorPrimary.withOpacity(0.3)
                    : AppColors.colorPrimary,
              ),
              style: tSw600dp16fontF.copyWith(
                color:
                    widget.ticketingBitsController.checkMissingDetails() ||
                        !widget.ticketingBitsController.isEnableUploadQuoteSign
                        .value
                        ? AppColors.colorPrimary.withOpacity(0.3)
                    : AppColors.colorPrimary,
              ),
              onPressCallback: () {
                if (!widget.ticketingBitsController.checkMissingDetails() &&
                    widget.ticketingBitsController.isEnableUploadQuoteSign
                        .value) {
                  Navigator.of(context).push(ManualSignOverlayBillBits(
                      widget.ticketingBitsController));
                }
              }),
        ),
      ),
    );
  }

  Widget quoteUploadedMsg() {
    return Container(
      alignment: Alignment.centerLeft,
      margin: EdgeInsets.only(
        left: getHeight(AppValues.margin_30),
      ),
      child: Wrap(
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          Image.asset(AppImages.greenTick),
          SizedBox(width: getHeight(SizeConstants.dp7)),
          Text(
            AppStrings.quoteUploaded,
            style: tSw400dp16fontF.copyWith(
              fontSize: SizeConstants.dp16,
              color: AppColors.colorBlack,
            ),
          ),
        ],
      ),
    );
  }

  Widget manualConfirmButtonWidget() {
    return Obx(
      () => Visibility(
        visible:
            widget.ticketingBitsController.quoteSignType.isFileUploaded,
        child: Container(
          alignment: Alignment.bottomRight,
          padding: const EdgeInsets.only(
              bottom: AppValues.padding_20, right: AppValues.padding_20),
          child: CustomButtonMaterial(
            width: getWidth(SizeConstants.dp149),
            height: getHeight(SizeConstants.dp45),
            backgroundColor: AppColors.colorPrimary,
            foregroundColor: AppColors.colorWhite,
            borderRadius: AppValues.radius_4,
            text: AppStrings.confirm,
            style: tSw600dp16fontF.copyWith(
              color: AppColors.colorWhite,
            ),
            onPressCallback: () {
              showSignConfirmationPopUp();
            },
          ),
        ),
      ),
    );
  }

  void showSignConfirmationPopUp() {
    Navigator.of(context).push(GenericOverlay(
        iconPath: AppImages.icSignature,
        title: AppStrings.signatureConfirmation,
        message: AppStrings.signatureConfirmationMsg,
        negativeButtonText: AppStrings.cancel,
        positiveButtonText: AppStrings.ok,
        onPositivePressCallback: () {
          widget.ticketingBitsController.addTicket(AppStrings.processing);
          widget.ticketingBitsController.isConfirmationScreen = true;

          int index = widget.ticketingBitsController.index.value + 1;
          widget.ticketingBitsController
              .updateStepItemStatus(currentIndex: index);
          //widget.ticketingBitsController.addBilledBit();
          Get.back();
        }));
  }

  /// **************** Digital Signature *******************

  Widget signConfirmedMsg() {
    return Obx(
      () => Visibility(
        visible: widget.ticketingBitsController.quoteSignType.isDigitalSignDone,
        child: Container(
          alignment: Alignment.centerLeft,
          margin: EdgeInsets.only(
            left: getHeight(AppValues.margin_30),
          ),
          child: Wrap(
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Image.asset(AppImages.greenTick),
              SizedBox(width: getWidth(SizeConstants.dp7)),
              Text(
                AppStrings.signCaptured,
                style: tSw400dp16fontF.copyWith(
                  fontSize: SizeConstants.dp16,
                  color: AppColors.colorBlack,
                ),
              ),
              SizedBox(
                width: getHeight(SizeConstants.dp12),
              ),
              separatorPipe(),
              SizedBox(
                width: getHeight(SizeConstants.dp12),
              ),
              GestureDetector(
                  onTap: () {
                    widget.ticketingBitsController.deleteDigitalSignDetails(
                        widget.ticketingBitsController);
                  },
                  child: Image.asset(AppImages.quoteDeleteIcon)),
            ],
          ),
        ),
      ),
    );
  }

  Widget confirmButtonWidget() {
    return Obx(
      () => Visibility(
        visible: widget.ticketingBitsController.quoteSignType.isDigitalSignDone,
        child: Container(
          alignment: Alignment.bottomRight,
          padding: const EdgeInsets.only(
              bottom: AppValues.padding_20, right: AppValues.padding_20),
          child: CustomButtonMaterial(
            width: getWidth(SizeConstants.dp149),
            height: getHeight(SizeConstants.dp45),
            backgroundColor: AppColors.colorPrimary,
            foregroundColor: AppColors.colorWhite,
            borderRadius: AppValues.radius_4,
            text: AppStrings.confirm,
            style: tSw600dp16fontF.copyWith(
              color: AppColors.colorWhite,
            ),
            onPressCallback: () {
              showSignConfirmationPopUp();
            },
          ),
        ),
      ),
    );
  }

  Widget acceptButtonWidget() {
    return Obx(
      () => Visibility(
        visible: !widget.ticketingBitsController.quoteSignType.isDigitalSignDone,
        child: Container(
          alignment: Alignment.bottomRight,
          padding: const EdgeInsets.only(
              bottom: AppValues.padding_20, right: AppValues.padding_20),
          child: CustomButtonMaterial(
            width: getWidth(SizeConstants.dp149),
            height: getHeight(SizeConstants.dp45),
            backgroundColor: AppColors.colorPrimary,
            foregroundColor: AppColors.colorWhite,
            borderRadius: AppValues.radius_4,
            text: AppStrings.acceptSign,
            style: tSw600dp16fontF.copyWith(
              color: AppColors.colorWhite,
            ),
            onPressCallback: () {
              if (widget.ticketingBitsController.checkMissingDetails()) {Navigator.of(context).push(
                    MissingDetailsAlertOverlay(widget.ticketingBitsController));
              } else {
                Navigator.of(context).push(
                  DigitalSignOverlayBillBits(widget.ticketingBitsController));}
            },
          ),
        ),
      ),
    );
  }
}
