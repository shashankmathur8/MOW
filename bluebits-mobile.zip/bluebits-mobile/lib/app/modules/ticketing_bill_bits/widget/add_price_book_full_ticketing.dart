import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/common_widgets/no_results_screen.dart';
import 'package:slb_gt_mobile/app/modules/shared/dropdown_view.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/widget/add_price_line_item_ticketing.dart';

import '../../../core/common_widgets/common_widget.dart';
import '../../../core/common_widgets/custom_button_material.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/common_widget.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../controller/ticketing_bits_controller.dart';

class AddPriceBookFullTicketing extends StatefulWidget {
  final TicketingBitsController controller =
      Get.find(tag: (TicketingBitsController).toString());
  final bool isEditMode;
  final bool isFromSmallBottomSheet;

  AddPriceBookFullTicketing(
      {Key? key, this.isEditMode = false, this.isFromSmallBottomSheet = false})
      : super(key: key) {
    controller.resetLineItemSelection();
  }

  @override
  State<AddPriceBookFullTicketing> createState() =>
      _AddPriceBookFullTicketingState();
}

class _AddPriceBookFullTicketingState extends State<AddPriceBookFullTicketing> {
  var outlineBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(AppValues.radius_10),
    borderSide: const BorderSide(
        width: SizeConstants.dp1, color: AppColors.colorSeparatorLine),
  );

  Widget circleAvatarWidget() {
    return CustomWidgets().roundIconWidget(AppImages.icAddPriceBookMini);
  }

  Widget titleHeaderWidget() {
    return Text(
      AppStrings.addLineItem,
      style: tSw700fontF.copyWith(
        color: AppColors.colorBlack,
        fontSize: SizeConstants.dp26,
      ),
    );
  }

  Widget filterSearchWidget() {
    return SizedBox(
      width: getWidth(SizeConstants.dp473),
      height: getHeight(SizeConstants.dp50),
      child: TextFormField(
        autofocus: false,
        style: tSw400dp14fontF.copyWith(
          color: AppColors.colorMainText,
        ),
        inputFormatters: [
          filteringTextInputFormatter,
        ],
        decoration: InputDecoration(
          suffixIcon: IconButton(
              splashColor: AppColors.transparentColor,
              icon: Image.asset(AppImages.search),
              onPressed: () {}),
          hintText: AppStrings.searchFilterPriceBook,
          hintStyle: tSw400dp14fontF.copyWith(
            color: AppColors.colorSubText.withOpacity(0.7),
          ),
          filled: true,
          fillColor: AppColors.colorF5F6F5.withOpacity(0.8),
          enabledBorder: outlineBorder,
          focusedBorder: outlineBorder,
          border: outlineBorder,
          focusedErrorBorder: outlineBorder,
          errorBorder: outlineBorder,
        ),
        maxLines: 1,
        onChanged: (value) {
          //controller.selectedPBLineItem(value ?? '');
        },
        keyboardType: TextInputType.text,
        textAlign: TextAlign.start,
        validator: (value) {
          return null;
        },
      ),
    );
  }

  Widget clearAllWidget() {
    return Obx(() =>
        widget.controller.searchByMasterCode.toString().isNotEmpty ||
                widget.controller.searchBySlbMaterial.toString().isNotEmpty ||
                widget.controller.searchBySlbDescription.toString().isNotEmpty
            ? Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  InkWell(
                    highlightColor: AppColors.transparentColor,
                    splashColor: AppColors.transparentColor,
                    splashFactory: NoSplash.splashFactory,
                    onTap: () {
                      clearAllAction();
                    },
                    child: Text(
                      AppStrings.clearAll,
                      style: tSw500dp12fontF.copyWith(
                        color: AppColors.colorPrimary,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: getWidth(SizeConstants.dp10),
                  )
                ],
              )
            : Container());
  }

  Widget searchMasterCodeWidget() {
    return Obx(() => DropDownView(
          strImage: AppImages.down_arrow,
          strHint: AppStrings.searchByMasterCode,
          selectedValue: widget.controller.searchByMasterCode,
          arrList: widget.controller.masterCodeList,
          widthInput: getWidth(SizeConstants.dp213),
          onClickAction: (value) => {
            widget.controller.searchByMasterCode = value,
            widget.controller.selectedPBLineItem(),
          },
          inputDecoration: inputDecorationPriceBook,
          overlayDecoration: overlayDecorationPriceBook,
          textStyle: dropDownTextStylePriceBook,
          hintTextColor: AppColors.colorMainText.withOpacity(0.3),
          textColor: AppColors.colorMainText,
        ));
  }

  Widget searchBySlbMaterialWidget() {
    return Obx(() => DropDownView(
          strImage: AppImages.down_arrow,
          strHint: AppStrings.searchBySlbMaterial,
          selectedValue: widget.controller.searchBySlbMaterial,
          arrList: widget.controller.slbMaterialList,
          widthInput: getWidth(SizeConstants.dp213),
          onClickAction: (value) => {
            widget.controller.searchBySlbMaterial = value,
            widget.controller.selectedPBLineItem(),
          },
          inputDecoration: inputDecorationPriceBook,
          overlayDecoration: overlayDecorationPriceBook,
          textStyle: dropDownTextStylePriceBook,
          hintTextColor: AppColors.colorMainText.withOpacity(0.3),
          textColor: AppColors.colorMainText,
        ));
  }

  Widget searchBySlbDescriptionWidget() {
    return Obx(() => DropDownView(
          strImage: AppImages.down_arrow,
          strHint: AppStrings.searchBySlbDescription,
          selectedValue: widget.controller.searchBySlbDescription,
          arrList: widget.controller.slbDescriptionList,
          widthInput: getWidth(SizeConstants.dp213),
          onClickAction: (value) => {
            widget.controller.searchBySlbDescription = value,
            widget.controller.selectedPBLineItem(),
          },
          inputDecoration: inputDecorationPriceBook,
          overlayDecoration: overlayDecorationPriceBook,
          textStyle: dropDownTextStylePriceBook,
          hintTextColor: AppColors.colorMainText.withOpacity(0.3),
          textColor: AppColors.colorMainText,
        ));
  }

  Widget priceBookIdWithName() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SizedBox(
          width: getWidth(SizeConstants.dp79),
        ),
        Text(
          '${widget.controller.selectedPriceBook?.priceBookId ?? ''} - ${widget.controller.selectedPriceBook?.priceBookName ?? ''}',
          style: tSw400dp14fontF.copyWith(
              fontSize: SizeConstants.dp16, color: AppColors.colorMainText),
        ),
      ],
    );
  }

  Widget priceBookIdWithNameDropDown() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        DropDownView(
          strImage: AppImages.down_arrow,
          selectedValue:
              '${widget.controller.selectedPriceBook?.priceBookId} - ${widget.controller.selectedPriceBook?.priceBookName}',
          arrList: widget.controller.priceBookWithIdList,
          widthInput: getWidth(SizeConstants.dp375),
          heightInput: getHeight(SizeConstants.dp45),
          onClickAction: (value) => {
            widget.controller
                .checkAndAssignPriceBook(value.toString().split(' - ').first),
            initialValueBind(),
          },
          inputDecoration: inputDecorationPriceBook,
          overlayDecoration: overlayDecorationPriceBook,
          textStyle: dropDownTextStylePriceBook,
          textColor: AppColors.colorMainText,
        )
      ],
    );
  }

  Widget bottomButtonWidget(bool? isEditMode, bool isFromSmallBottomSheet) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        CustomButtonMaterial(
          width: getWidth(SizeConstants.dp102),
          height: getHeight(SizeConstants.dp45),
          backgroundColor: AppColors.colorWhite,
          foregroundColor: AppColors.colorPrimary,
          borderRadius: AppValues.radius_4,
          text: AppStrings.cancel,
          style: tSw500dp16fontF,
          side: const BorderSide(
            width: SizeConstants.dp1,
            color: AppColors.colorPrimary,
          ),
          onPressCallback: () {
            Get.back();
          },
        ),
        SizedBox(
          width: getWidth(SizeConstants.dp10),
        ),
        Obx(() => CustomButtonMaterial(
              width: getWidth(SizeConstants.dp130),
              height: getHeight(SizeConstants.dp45),
              backgroundColor: widget.controller.onPriceLineItemSelected != -1
                  ? AppColors.colorPrimary
                  : AppColors.colorPrimary.withOpacity(0.2),
              foregroundColor: AppColors.colorWhite,
              borderRadius: AppValues.radius_4,
              text: AppStrings.add,
              style: tSw500dp16fontF,
              onPressCallback: () async {
                if (widget.controller.onPriceLineItemSelected != -1) {
                  if (isEditMode == true) {
                    await widget.controller.replaceLineItemsAtIndex(
                        widget.controller.selectedPriceBook?.priceBookId ?? '');
                    Get.back();
                  } else {
                    await widget.controller.addLineItemToBit(
                        widget.controller.selectedPriceBook?.priceBookId ?? '');
                    if (isFromSmallBottomSheet) {
                      Get
                        ..back()
                        ..back();
                    } else {
                      Get.back();
                    }
                  }
                }
              },
            )),
      ],
    );
  }

  Widget lineItemHeader() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.colorConsignLeftPanel,
        borderRadius: const BorderRadius.only(
            topRight: Radius.circular(AppValues.radius_10),
            topLeft: Radius.circular(AppValues.radius_10)),
        border: Border.all(
            width: SizeConstants.dp0_5,
            color: AppColors.colorSeparatorLine,
            style: BorderStyle.solid),
      ),
      constraints: BoxConstraints(minHeight: getHeight(SizeConstants.dp40)),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(
            width: getWidth(SizeConstants.dp10),
          ),
          _flexHeader(
              text: AppStrings.rowId, flex: 2, textAlign: TextAlign.end),
          _flexSpacer(),
          _flexHeader(text: AppStrings.description, flex: 10),
          _flexSpacer(),
          _flexHeader(text: AppStrings.material, flex: 6),
          _flexSpacer(),
          _flexHeader(text: AppStrings.uom, flex: 2),
          _flexSpacer(),
          _flexHeader(text: AppStrings.code, flex: 6),
          _flexSpacer(),
          _flexHeader(text: AppStrings.revenueAccount, flex: 4),
          _flexSpacer(),
          _flexHeader(
            text: AppStrings.unitPrice,
            flex: 3,
          ),
          _flexSpacer(),
          _flexHeader(text: AppStrings.currency, flex: 3),
          _flexSpacer(),
          _flexHeader(text: AppStrings.hLReference, flex: 5),
          _flexSpacer(),
          _flexHeader(text: AppStrings.sHLReference, flex: 4),
          SizedBox(
            width: getWidth(SizeConstants.dp10),
          ),
        ],
      ),
    );
  }

  Widget _flexHeader(
      {required String text,
      int flex = 1,
      FlexFit fit = FlexFit.tight,
      TextAlign textAlign = TextAlign.start}) {
    return Flexible(
        flex: flex,
        fit: fit,
        child: Padding(
          padding:
              EdgeInsets.symmetric(vertical: getHeight(AppValues.margin_5)),
          child: Text(text,
              textAlign: textAlign,
              style: tSw700fontF.copyWith(
                  fontSize: SizeConstants.dp12,
                  fontStyle: FontStyle.normal,
                  color: AppColors.colorMainText)),
        ));
  }

  Widget _flexSpacer({int flex = 1, FlexFit fit = FlexFit.tight}) {
    return Flexible(flex: flex, fit: fit, child: Container());
  }

  Widget noResultsUI(double bottomSheetHeight) {
    return Container(
      alignment: Alignment.center,
      constraints: BoxConstraints(
          maxHeight: bottomSheetHeight - getHeight(SizeConstants.dp124)),
      child: NoResultsScreen(
        imagePath: AppImages.noResults,
        titleText: AppStrings.noResultsFound,
        descriptionText: AppStrings.noResultsDescription,
        titleStyle: tSw500dp16fontF.copyWith(
          color: AppColors.colorMainText,
          fontSize: SizeConstants.dp32,
        ),
        descriptionStyle: tSw400dp14fontF.copyWith(
          color: AppColors.colorSubText.withOpacity(0.7),
          fontSize: SizeConstants.dp20,
        ),
        onPressCallback: () {
          clearAllAction();
        },
      ),
    );
  }

  Widget resultsDataUI(double bottomSheetHeight) {
    return Column(
      children: [
        Container(
            constraints: BoxConstraints(
                maxHeight: bottomSheetHeight - getHeight(SizeConstants.dp173)),
            child: Container(
              margin: EdgeInsets.only(
                  top: getHeight(SizeConstants.dp10),
                  bottom: getHeight(SizeConstants.dp15)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  lineItemHeader(), //Header
                  AddPriceLineItemTicketing(
                    controller: widget.controller,
                  ), //List Item
                ],
              ),
            )),
        SizedBox(
            height: getHeight(SizeConstants.dp50),
            child: bottomButtonWidget(
                widget.isEditMode, widget.isFromSmallBottomSheet)),
      ],
    );
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(
        const Duration(
          milliseconds: 300,
        ), () {
      initialValueBind();

      //As of now no edit line item so no need to create dropdown list
      //so commented below code
      /*if (widget.isEditMode || widget.isFromSmallBottomSheet == false) {
        controller.getPriceBookWithIdList();
      }*/
    });
  }

  @override
  Widget build(BuildContext context) {
    var bottomSheetHeight =
        MediaQuery.of(context).size.height - getHeight(SizeConstants.dp52);
    return Material(
        child: SafeArea(
            child: Container(
      height: bottomSheetHeight,
      padding: EdgeInsets.all(
        getWidth(AppValues.padding_20),
      ),
      child: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: getHeight(SizeConstants.dp85),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          circleAvatarWidget(),
                          SizedBox(
                            width: getWidth(SizeConstants.dp19),
                          ),
                          titleHeaderWidget()
                        ],
                      ),
                      Flexible(
                          fit: FlexFit.tight,
                          flex: 2,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              clearAllWidget(),
                              searchMasterCodeWidget(),
                              SizedBox(
                                width: getWidth(SizeConstants.dp10),
                              ),
                              searchBySlbMaterialWidget(),
                              SizedBox(
                                width: getWidth(SizeConstants.dp10),
                              ),
                              searchBySlbDescriptionWidget(),
                            ],
                          )),
                    ],
                  ),
                  SizedBox(
                    height: getHeight(SizeConstants.dp3),
                  ),
                  priceBookIdWithName()
                ],
              ),
            ),
            Obx(() => Container(
                  child: widget.controller.priceBookLineItem.isNotEmpty
                      ? resultsDataUI(bottomSheetHeight)
                      : noResultsUI(bottomSheetHeight),
                ))
          ],
        ),
      ),
    )));
  }

  void initialValueBind() {
    widget.controller.clearPriceBookDropDownValue();
    widget.controller.selectedPBLineItem(initialCall: true);
  }

  void clearAllAction() {
    widget.controller.clearPriceBookDropDownValue();
    widget.controller.selectedPBLineItem();
  }
}
