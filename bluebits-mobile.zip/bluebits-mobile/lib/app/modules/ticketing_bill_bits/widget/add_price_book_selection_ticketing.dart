import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/widget/add_price_book_full_ticketing.dart';

import '../../../core/common_widgets/common_widget.dart';
import '../../../core/common_widgets/custom_button_material.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../../shared/dropdown_view.dart';
import '../controller/ticketing_bits_controller.dart';

class AddPriceBookSelectionTicketing extends StatelessWidget {
  final TicketingBitsController controller =
      Get.find(tag: (TicketingBitsController).toString());

  AddPriceBookSelectionTicketing({Key? key}) : super(key: key);

  Widget circleIcon() {
    return CustomWidgets().roundIconWidget(AppImages.icAddPriceBookMini);
  }

  Widget titleHeaderWidget() {
    return Flexible(
      child: Text(
        AppStrings.addPricebook,
        style: tSw700fontF.copyWith(
          color: AppColors.colorBlack,
          fontSize: SizeConstants.dp26,
        ),
      ),
    );
  }

  Widget centerPartWidget() {
    return Expanded(
      child: Center(
        child: DropDownView(
          strImage: AppImages.down_arrow,
          strHint: AppStrings.selectPricebook,
          arrList: controller.pricebookList.value,
          widthInput: getWidth(SizeConstants.dp375),
          onClickAction: (value) => {
            controller.selectedPriceBook = value,
            controller.onPriceBookSelected = 1
          },
          inputDecoration: inputDecorationPriceBook,
          overlayDecoration: overlayDecorationPriceBook,
          textStyle: dropDownTextStylePriceBook,
          hintTextColor: AppColors.colorMainText.withOpacity(0.3),
          textColor: AppColors.colorMainText,
        ),
      ),
    );
  }

  Widget bottomButtonWidget() {
    return Column(
      children: [
        SizedBox(
          height: getHeight(SizeConstants.dp5),
        ),
        //Flexible(child: Container()),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            CustomButtonMaterial(
              width: getWidth(SizeConstants.dp102),
              height: getHeight(SizeConstants.dp45),
              backgroundColor: AppColors.colorWhite,
              foregroundColor: AppColors.colorPrimary,
              borderRadius: AppValues.radius_4,
              text: AppStrings.cancel,
              style: tSw500dp16fontF,
              side: const BorderSide(
                width: SizeConstants.dp1,
                color: AppColors.colorPrimary,
              ),
              onPressCallback: () {
                controller.onPriceBookSelected = 0;
                controller.selectedPriceBook = null;
                Get.back();
              },
            ),
            SizedBox(
              width: getWidth(SizeConstants.dp10),
            ),
            Obx(
              () => CustomButtonMaterial(
                width: getWidth(SizeConstants.dp130),
                height: getHeight(SizeConstants.dp45),
                backgroundColor: controller.onPriceBookSelected != 0
                    ? AppColors.colorPrimary
                    : AppColors.colorPrimary.withOpacity(0.2),
                foregroundColor: AppColors.colorWhite,
                borderRadius: AppValues.radius_4,
                text: AppStrings.next,
                style: tSw500dp16fontF,
                onPressCallback: () {
                  if (controller.onPriceBookSelected != 0) {
                    Future.delayed(
                        const Duration(
                          milliseconds: 300,
                        ), () {
                      openFullBottomSheet();
                    });
                  }
                },
              ),
            )
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Material(
        child: SafeArea(
            child: Container(
      height: getHeight(SizeConstants.dp360),
      padding: EdgeInsets.all(getWidth(AppValues.padding_30)).copyWith(
          top: getHeight(AppValues.padding_20),
          bottom: getHeight(AppValues.padding_30)),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              circleIcon(),
              SizedBox(
                width: getWidth(SizeConstants.dp16),
              ),
              titleHeaderWidget(),
            ],
          ),
          centerPartWidget(),
          bottomButtonWidget(),
        ],
      ),
    )));
  }

  void openFullBottomSheet() {
    Get.bottomSheet(
      AddPriceBookFullTicketing(
        isFromSmallBottomSheet: true,
      ),
      isDismissible: false,
      enableDrag: false,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(AppValues.radius_10),
        ),
      ),
      clipBehavior: Clip.antiAliasWithSaveLayer,
    );
  }
}
