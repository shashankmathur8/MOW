import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/common_widgets/no_overscroll_behavior.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/model/schema/pricebook_schema.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/controller/ticketing_bits_controller.dart';

import '../../../core/values/app_strings.dart';
import '../../../core/values/common_widget.dart';

class AddPriceLineItemTicketing extends StatefulWidget {
  final TicketingBitsController controller;

  const AddPriceLineItemTicketing({Key? key, required this.controller})
      : super(key: key);

  @override
  State<AddPriceLineItemTicketing> createState() =>
      _AddPriceLineItemTicketingState();
}

class _AddPriceLineItemTicketingState extends State<AddPriceLineItemTicketing> {
  Widget _flexSpacer({int flex = 1, FlexFit fit = FlexFit.tight}) {
    return Flexible(flex: flex, fit: fit, child: Container());
  }

  Widget _lineItemRow(int index, dynamic lineItem) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        SizedBox(
          width: getWidth(SizeConstants.dp10),
        ),
        _flexRowText(
            text: (index + 1).toString(), flex: 2, textAlign: TextAlign.end),
        _flexSpacer(),
        _flexRowText(text: getColumValue(lineItem, 1), flex: 10),
        _flexSpacer(),
        _flexRowText(text: getColumValue(lineItem, 2), flex: 6),
        _flexSpacer(),
        _flexRowText(text: getColumValue(lineItem, 3), flex: 2),
        _flexSpacer(),
        _flexRowText(text: getColumValue(lineItem, 4), flex: 6),
        _flexSpacer(),
        _flexRowText(text: getColumValue(lineItem, 5), flex: 4),
        _flexSpacer(),
        _flexRowText(
            text: getColumValue(lineItem, 6),
            flex: 3,
            textAlign: TextAlign.right),
        _flexSpacer(),
        _flexRowText(text: getColumValue(lineItem, 7), flex: 3),
        _flexSpacer(),
        _flexRowText(text: getColumValue(lineItem, 8), flex: 5),
        _flexSpacer(),
        _flexRowText(text: getColumValue(lineItem, 9), flex: 4),
        SizedBox(
          width: getWidth(SizeConstants.dp10),
        ),
      ],
    );
  }

  String getColumValue(dynamic lineItem, int columIndex) {
    if (lineItem is PriceBookLinesLowLevelItems) {
      PriceBookLinesLowLevelItems lowLevelItems = lineItem;
      if (columIndex == 1) {
        return lowLevelItems.materialDescription ?? '-';
      } else if (columIndex == 2) {
        return lowLevelItems.materialNumber ?? '-';
      } else if (columIndex == 3) {
        return lowLevelItems.uOM ?? '-';
      } else if (columIndex == 4) {
        return lowLevelItems.masterCode ?? '-';
      } else if (columIndex == 5) {
        return '-';
      } else if (columIndex == 6) {
        return (lowLevelItems.unitPrice ?? 0.0).toString();
      } else if (columIndex == 7) {
        return lowLevelItems.currency ?? '-';
      } else if (columIndex == 8) {
        return lowLevelItems.hLReference ?? '-';
      } else if (columIndex == 9) {
        return lowLevelItems.sHLReference ?? '-';
      } else {
        return '-';
      }
    } else {
      PriceBookLinesFlatLevelItems flatLevelItems = lineItem;
      if (columIndex == 1) {
        return flatLevelItems.materialDescription ?? '-';
      } else if (columIndex == 2) {
        return flatLevelItems.materialNumber ?? '-';
      } else if (columIndex == 3) {
        return flatLevelItems.uOM ?? '-';
      } else if (columIndex == 4) {
        return '-';
      } else if (columIndex == 5) {
        return '-';
      } else if (columIndex == 6) {
        return (flatLevelItems.unitPrice ?? 0.0).toString();
      } else if (columIndex == 7) {
        return flatLevelItems.currency ?? '-';
      } else if (columIndex == 8) {
        return '-';
      } else if (columIndex == 9) {
        return flatLevelItems.sHLReference ?? '-';
      } else {
        return '-';
      }
    }
  }

  Widget _flexRowText(
      {required String text,
      int flex = 1,
      FlexFit fit = FlexFit.tight,
      TextAlign textAlign = TextAlign.start}) {
    return Flexible(
        flex: flex,
        fit: fit,
        child: Padding(
          padding:
              EdgeInsets.symmetric(vertical: getHeight(AppValues.margin_13)),
          child: Text(text,
              textAlign: textAlign,
              style: tSw400dp14fontF.copyWith(
                  fontStyle: FontStyle.normal, color: AppColors.colorMainText)),
        ));
  }

  Widget lineItemTable() {
    return Flexible(
      child: Container(
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(AppValues.radius_10),
              bottomRight: Radius.circular(AppValues.radius_10)),
          border: Border.all(
              width: SizeConstants.dp0_5, color: AppColors.colorSeparatorLine),
        ),
        child: Obx(() => ScrollConfiguration(
              behavior: NoOverscrollBehavior(),
              child: widget.controller.priceBookLineItem.isNotEmpty
                  ? ListView.separated(
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      physics: const ScrollPhysics(),
                      itemCount: widget.controller.priceBookLineItem.length,
                      itemBuilder: (ctx, index) {
                        return GestureDetector(
                          onTapDown: (details) {
                            if (widget.controller.onPriceLineItemSelected ==
                                index) {
                              widget.controller.clearAndUpdateLineItemSelected(
                                  isClear: true);
                            } else if (widget
                                    .controller.onPriceLineItemSelected !=
                                index) {
                              widget.controller.clearAndUpdateLineItemSelected(
                                  isClear: false,
                                  lineItem: widget
                                      .controller.priceBookLineItem[index],
                                  index: index);
                            } else {
                              widget.controller.clearAndUpdateLineItemSelected(
                                  isClear: false,
                                  lineItem: widget
                                      .controller.priceBookLineItem[index],
                                  index: index);
                            }
                          },
                          child: Obx(
                            () => Container(
                                color:
                                    widget.controller.onPriceLineItemSelected ==
                                            index
                                        ? AppColors.colorSelection
                                        : AppColors.transparentColor,
                                child: _lineItemRow(
                                    index,
                                    widget
                                        .controller.priceBookLineItem[index])),
                          ),
                        );
                      },
                      separatorBuilder: (context, index) {
                        return const Divider(
                          height: SizeConstants.dp1,
                          color: AppColors.colorSeparatorLine,
                        );
                      },
                    )
                  : noDataWidget(AppStrings.noDataFound),
            )),
      ),
    );
  }

  @override
  void initState() {
    super.initState();

    /*Future.delayed(const Duration(milliseconds: 300,), () {
      widget.controller.selectedPBLineItem(initialCall: true);
    });*/
  }

  @override
  Widget build(BuildContext context) {
    return lineItemTable();
  }
}
