import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/common_widgets/custom_button_material.dart';
import '../../../core/common_widgets/no_overscroll_behavior.dart';
import '../../../core/utils/logger_common.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../../billed_bits/controller/ticketed_bits_controller.dart';
import '../../inventory/models/bitSchema.dart';
import '../../shared/datepicker_view.dart';
import '../../shared/generic_overlay.dart';
import '../../shared/smart_search_view_with_error.dart';
import '../../shared/smart_search_view_with_loader.dart';
import '../controller/ticketing_bits_controller.dart';

class EnterDetailsBillBits extends StatefulWidget {
  const EnterDetailsBillBits({super.key, required this.ticketingBitsController});

  final TicketingBitsController ticketingBitsController;

  @override
  State<EnterDetailsBillBits> createState() => _EnterDetailsBillBitsState();
}

class _EnterDetailsBillBitsState extends State<EnterDetailsBillBits> {
  final GlobalKey<FormState> _formKey = GlobalKey();

  var outlineBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(AppValues.radius_4),
    borderSide: const BorderSide(width: SizeConstants.dp1, color: AppColors.colorSeparatorLine),
  );

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    widget.ticketingBitsController.fetchData();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        widget.ticketingBitsController.closeEnterDetailOverLay();
      },
      child: Container(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: Form(
            key: _formKey,
            child: ScrollConfiguration(
              behavior: NoOverscrollBehavior(),
              child: ListView(
                children: [
                  Container(
                    padding: EdgeInsets.only(
                        left: getWidth(AppValues.padding_40),
                        top: getHeight(AppValues.padding_34),
                        right: getWidth(AppValues.padding_34)),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        titleHeaderWidget,
                        SizedBox(
                          height: getHeight(SizeConstants.dp21),
                        ),
                        selectedBitsWidget(),
                        bitsListWidget(),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: SizeConstants.dp20, right: SizeConstants.dp15),
                              child: Image.asset(AppImages.wellIcon,
                                  height: getHeight(SizeConstants.dp60),
                                  width: getWidth(SizeConstants.dp60),
                                  alignment: Alignment.center),
                            ),
                            wellSelectionWidget(),
                            SizedBox(
                              width: getWidth(SizeConstants.dp10),
                            ),
                            Listener(
                                onPointerHover: (event) {
                                  widget.ticketingBitsController.closeEnterDetailOverLay();
                                },
                                child: startDateWidget()),
                            SizedBox(
                              width: getWidth(SizeConstants.dp10),
                            ),
                            Listener(
                                onPointerHover: (event) {
                                  widget.ticketingBitsController.closeEnterDetailOverLay();
                                },
                                child: endDateWidget()),
                          ],
                        ),
                        SizedBox(
                          height: getHeight(SizeConstants.dp18),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: SizeConstants.dp75),
                          child: consumptionTypeWidget(),
                        ),
                        SizedBox(
                          height: getHeight(SizeConstants.dp20),
                        ),
                        dividerContainerWidget,
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: getWidth(AppValues.padding_40), right: getWidth(AppValues.padding_34)),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            billToWidget(),
                            SizedBox(
                              width: getWidth(SizeConstants.dp10),
                            ),
                            shipToWidget(),
                          ],
                        ),
                        SizedBox(
                          height: getHeight(SizeConstants.dp18),
                        ),
                        Row(children: [
                          cECWidget(),
                          SizedBox(
                            width: getWidth(SizeConstants.dp10),
                          ),
                          designEngineerWidget()
                        ]),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: getHeight(SizeConstants.dp20),
                  ),
                  dividerContainerWidget,
                  nextButtonWidget(),
                  Obx(
                    () => Visibility(
                        visible: widget.ticketingBitsController.isInserted.value,
                        child: SizedBox(
                          height: SizeConstants.dp130,
                        )),
                  )
                ],
              ),
            ),
          )),
    );
  }

  Widget _bitsSelectedItem(Bit bit, int index) {
    return Container(
      margin: const EdgeInsets.all(AppValues.margin_5),
      padding: const EdgeInsets.symmetric(vertical: AppValues.padding_10, horizontal: AppValues.padding_11),
      constraints: BoxConstraints(
        minWidth: getWidth(SizeConstants.dp110),
      ),
      height: getHeight(SizeConstants.dp30),
      decoration: BoxDecoration(
        color: AppColors.colorFilterTag,
        borderRadius: BorderRadius.circular(AppValues.radius_4),
        border: Border.all(width: SizeConstants.dp1, color: AppColors.colorFilterTagBorder),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            bit.serialNumber?.toUpperCase() ?? '',
            style: tSw400dp14fontF.copyWith(
              color: AppColors.colorMainText,
            ),
            maxLines: 1,
          ),
          InkWell(
            child: Image.asset(
              AppImages.cancelBlackPng,
              width: getWidth(SizeConstants.dp18),
              height: getHeight(SizeConstants.dp18),
            ),
            onTap: () {
              widget.ticketingBitsController.closeEnterDetailOverLay();
              if (widget.ticketingBitsController.selectedBits.length > 1) {
                widget.ticketingBitsController.removeSelectedBit(index);
              } else {
                Navigator.of(context).push(GenericOverlay(
                    title: AppStrings.noTicketToConsign,
                    message: AppStrings.noTicketToConsignDes,
                    iconPath: AppImages.alertNoBitsConsign,
                    negativeButtonText: AppStrings.cancel,
                    positiveButtonText: AppStrings.confirm,
                    onPositivePressCallback: () async {
                      if (widget.ticketingBitsController.ticketingID!.trim().isNotEmpty) {
                        await widget.ticketingBitsController.realm
                            .deleteDraftFromTicketedBits(widget.ticketingBitsController.ticketingModel.ticketingID);
                        try {
                          TicketedBitsController ticketedBitsController = Get.find(tag: (TicketedBitsController).toString());

                          ticketedBitsController.fetchData();
                        } on Exception catch (exception) {
                          ApplicationLogger().printError(exception.toString(), 'dismissPopup()');
                        }
                      }

                      // TODO clear ticketing model
                      Get.delete<TicketingBitsController>(tag: (TicketingBitsController).toString(), force: true);
                      Get
                        ..back()
                        ..back();
                    }));
              }
            },
          )
        ],
      ),
    );
  }

  Widget titleHeaderWidget = Text(
    AppStrings.enterDetails,
    style: tSw400dp14fontF.copyWith(
      fontSize: SizeConstants.dp24,
      color: AppColors.colorMainText,
    ),
  );

  Widget selectedBitsWidget() {
    return Obx(() => RichText(
          text: TextSpan(
            style: tSw400dp14fontF.copyWith(
              fontSize: SizeConstants.dp16,
              color: AppColors.colorBlack,
            ),
            children: <TextSpan>[
              const TextSpan(text: AppStrings.selectedBits),
              TextSpan(
                  text: '${widget.ticketingBitsController.selectedBits.length}',
                  style: const TextStyle(color: AppColors.colorSeparatorLine)),
            ],
          ),
        ));
  }

  Widget bitsListWidget() {
    return Container(
      margin: const EdgeInsets.only(top: AppValues.margin_8, bottom: AppValues.margin_8),
      height: getHeight(SizeConstants.dp45),
      child: ScrollConfiguration(
          behavior: NoOverscrollBehavior(),
          child: Obx(
            () => ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: widget.ticketingBitsController.selectedBits.length,
              itemBuilder: (ctx, index) {
                return Container(child: _bitsSelectedItem(widget.ticketingBitsController.selectedBits[index].bit as Bit, index));
              },
            ),
          )),
    );
  }

  Widget wellSelectionWidget() {
    return StreamBuilder(
      stream: widget.ticketingBitsController.wellList.changes,
      builder: (context, snapshot) {
        if (snapshot.hasData && snapshot.data!.results.isNotEmpty) {
          return Obx(
            () => UserInputViewWithError(
              overlayEntry: widget.ticketingBitsController.overlayEntry,
              isInserted: widget.ticketingBitsController.isInserted,
              initValue: widget.ticketingBitsController.ticketingModel.well != null
                  ? (widget.ticketingBitsController.ticketingModel.well?.name).toString()
                  : "",
              fieldType: AppStrings.wellType,
              strImage: AppImages.down_arrow,
              strHint: AppStrings.selectWell,
              strTitle: AppStrings.wellRequired,
              arrList: widget.ticketingBitsController.wellList.toList(),
              widthInput: getWidth(SizeConstants.dp280),
              errorText: widget.ticketingBitsController.well == null && widget.ticketingBitsController.isValidationDone.value
                  ? AppStrings.errSelectValidWell
                  : '',
              showError: widget.ticketingBitsController.well == null && widget.ticketingBitsController.isValidationDone.value
                  ? true
                  : false,
              inputDecoration:
                  widget.ticketingBitsController.well == null && widget.ticketingBitsController.isValidationDone.value
                      ? smartSearchErrorDecoration
                      : smartSearchDecoration,
              overlayDecoration: overlayDecoration,
              onClickAction: (value) => {
                widget.ticketingBitsController.well = value,
              },
              onRemoveText: () => {
                widget.ticketingBitsController.well = null,
              },
            ),
          );
        } else {
          return UserInputViewWithLoader(
            initValue: '',
            strImage: AppImages.down_arrow,
            strHint: AppStrings.selectWell,
            strTitle: AppStrings.wellRequired,
            widthInput: getWidth(SizeConstants.dp280),
            inputDecoration: widget.ticketingBitsController.well == null && widget.ticketingBitsController.isValidationDone.value
                ? smartSearchErrorDecoration
                : smartSearchDecoration,
            overlayDecoration: overlayDecoration,
            onClickAction: (value) => {
              widget.ticketingBitsController.well = value,
            },
          );
        }
      },
    );
  }

  Widget consumptionTypeWidget() {
    return Obx(
      () => UserInputViewWithError(
        overlayEntry: widget.ticketingBitsController.overlayEntry,
        isInserted: widget.ticketingBitsController.isInserted,
        initValue: widget.ticketingBitsController.ticketingModel.consumptionType != null
            ? (widget.ticketingBitsController.ticketingModel.consumptionType).toString()
            : "",
        fieldType: AppStrings.consumptionType,
        strImage: AppImages.down_arrow,
        strHint: AppStrings.consumptionTypeHint,
        strTitle: AppStrings.consumptionTypeRequired,
        arrList: widget.ticketingBitsController.listConsumptionType(),
        widthInput: getWidth(SizeConstants.dp280),
        errorText: widget.ticketingBitsController.consumptionType == null && widget.ticketingBitsController.isValidationDone.value
            ? AppStrings.errSelectConsumptionType
            : '',
        showError: widget.ticketingBitsController.consumptionType == null && widget.ticketingBitsController.isValidationDone.value
            ? true
            : false,
        inputDecoration:
            widget.ticketingBitsController.consumptionType == null && widget.ticketingBitsController.isValidationDone.value
                ? smartSearchErrorDecoration
                : smartSearchDecoration,
        overlayDecoration: overlayDecoration,
        onClickAction: (value) => {
          widget.ticketingBitsController.consumptionType = value,
        },
        onRemoveText: () => {
          widget.ticketingBitsController.consumptionType = null,
        },
      ),
    );
  }

  Widget billToWidget() {
    return StreamBuilder(
      stream: widget.ticketingBitsController.billToList.changes,
      builder: (context, snapshot) {
        return Obx(
          () => UserInputViewWithError(
            customerNumber: widget.ticketingBitsController.consignment.customerId.toString(),
            overlayEntry: widget.ticketingBitsController.overlayEntry,
            isInserted: widget.ticketingBitsController.isInserted,
            initValue: widget.ticketingBitsController.ticketingModel.billTo != null
                ? (widget.ticketingBitsController.ticketingModel.billTo?.addressLine1).toString()
                : "",
            fieldType: AppStrings.billToType,
            strImage: AppImages.down_arrow,
            strHint: AppStrings.selectAddressHint,
            strTitle: AppStrings.billToRequired,
            arrList: widget.ticketingBitsController.billToList.toList(),
            widthInput: getWidth(SizeConstants.dp280),
            errorText: widget.ticketingBitsController.billTo == null && widget.ticketingBitsController.isValidationDone.value
                ? AppStrings.errSelectBillTo
                : '',
            showError: widget.ticketingBitsController.billTo == null && widget.ticketingBitsController.isValidationDone.value
                ? true
                : false,
            inputDecoration:
                widget.ticketingBitsController.billTo == null && widget.ticketingBitsController.isValidationDone.value
                    ? smartSearchErrorDecoration
                    : smartSearchDecoration,
            overlayDecoration: overlayDecoration,
            onClickAction: (value) => {
              widget.ticketingBitsController.billTo = value,
            },
            onRemoveText: () => {
              widget.ticketingBitsController.billTo = null,
            },
          ),
        );
      },
    );
  }

  Widget shipToWidget() {
    return StreamBuilder(
      stream: widget.ticketingBitsController.shipToList.changes,
      builder: (context, snapshot) {
        return Obx(
          () => UserInputViewWithError(
            customerNumber: widget.ticketingBitsController.consignment.customerId.toString(),
            overlayEntry: widget.ticketingBitsController.overlayEntry,
            isInserted: widget.ticketingBitsController.isInserted,
            initValue: widget.ticketingBitsController.ticketingModel.shipTo != null
                ? (widget.ticketingBitsController.ticketingModel.shipTo?.addressLine1).toString()
                : "",
            fieldType: AppStrings.shipToType,
            strImage: AppImages.down_arrow,
            strHint: AppStrings.selectAddressHint,
            strTitle: AppStrings.shipToRequired,
            arrList: widget.ticketingBitsController.shipToList.toList(),
            widthInput: getWidth(SizeConstants.dp280),
            errorText: widget.ticketingBitsController.shipTo == null && widget.ticketingBitsController.isValidationDone.value
                ? AppStrings.errSelectShipTo
                : '',
            showError: widget.ticketingBitsController.shipTo == null && widget.ticketingBitsController.isValidationDone.value
                ? true
                : false,
            inputDecoration:
                widget.ticketingBitsController.shipTo == null && widget.ticketingBitsController.isValidationDone.value
                    ? smartSearchErrorDecoration
                    : smartSearchDecoration,
            overlayDecoration: overlayDecoration,
            onClickAction: (value) => {
              widget.ticketingBitsController.shipTo = value,
            },
            onRemoveText: () => {
              widget.ticketingBitsController.shipTo = null,
            },
          ),
        );
      },
    );
  }

  Widget cECWidget() {
    return StreamBuilder(
      stream: widget.ticketingBitsController.cecList.changes,
      builder: (context, snapshot) {
        return Obx(
          () => UserInputViewWithError(
            overlayEntry: widget.ticketingBitsController.overlayEntry,
            isInserted: widget.ticketingBitsController.isInserted,
            initValue: widget.ticketingBitsController.ticketingModel.cec != null
                ? (widget.ticketingBitsController.ticketingModel.cec?.fullName).toString()
                : "",
            fieldType: AppStrings.cecType,
            strImage: AppImages.down_arrow,
            strHint: AppStrings.selectNameHint,
            strTitle: AppStrings.salesRepresentativeRequired,
            arrList: widget.ticketingBitsController.cecList.toList(),
            widthInput: getWidth(SizeConstants.dp280),
            errorText: widget.ticketingBitsController.cec == null && widget.ticketingBitsController.isValidationDone.value
                ? AppStrings.errSelectCEC
                : '',
            showError: widget.ticketingBitsController.cec == null && widget.ticketingBitsController.isValidationDone.value
                ? true
                : false,
            inputDecoration: widget.ticketingBitsController.cec == null && widget.ticketingBitsController.isValidationDone.value
                ? smartSearchErrorDecoration
                : smartSearchDecoration,
            overlayDecoration: overlayDecoration,
            onClickAction: (value) => {
              widget.ticketingBitsController.cec = value,
            },
            onRemoveText: () => {
              widget.ticketingBitsController.cec = null,
            },
          ),
        );
      },
    );
  }

  Widget designEngineerWidget() {
    return StreamBuilder(
      stream: widget.ticketingBitsController.designEnggList.changes,
      builder: (context, snapshot) {
        return Obx(
          () => UserInputViewWithError(
            overlayEntry: widget.ticketingBitsController.overlayEntry,
            isInserted: widget.ticketingBitsController.isInserted,
            initValue: widget.ticketingBitsController.ticketingModel.designEngineer != null
                ? (widget.ticketingBitsController.ticketingModel.designEngineer?.fullName).toString()
                : "",
            fieldType: AppStrings.designEnggType,
            strImage: AppImages.down_arrow,
            strHint: AppStrings.selectNameHint,
            strTitle: AppStrings.officeSalesManRequired,
            arrList: widget.ticketingBitsController.designEnggList.toList(),
            widthInput: getWidth(SizeConstants.dp280),
            errorText:
                widget.ticketingBitsController.designEngineer == null && widget.ticketingBitsController.isValidationDone.value
                    ? AppStrings.errSelectOfcSalesman
                    : '',
            showError:
                widget.ticketingBitsController.designEngineer == null && widget.ticketingBitsController.isValidationDone.value
                    ? true
                    : false,
            inputDecoration:
                widget.ticketingBitsController.designEngineer == null && widget.ticketingBitsController.isValidationDone.value
                    ? smartSearchErrorDecoration
                    : smartSearchDecoration,
            overlayDecoration: overlayDecoration,
            onClickAction: (value) => {
              widget.ticketingBitsController.designEngineer = value,
            },
            onRemoveText: () => {
              widget.ticketingBitsController.designEngineer = null,
            },
          ),
        );
      },
    );
  }

  Widget startDateWidget() {
    return Obx(
      () => DatePickerView(
        selectedDate: widget.ticketingBitsController.ticketingModel.startDate!,
        strImage: AppImages.calendar,
        strHint: AppStrings.dateformat,
        strTitle: AppStrings.startDateRequired,
        arrList: [],
        firstDate: widget.ticketingBitsController.consignment.createdAt!,
        errorText: (widget.ticketingBitsController.startDate == null && widget.ticketingBitsController.isValidationDone.value)
            ? AppStrings.errEnterDate
            : widget.ticketingBitsController.isDateInvalid.value
                ? AppStrings.errEnterValidDate
                : '',
        showError: widget.ticketingBitsController.startDate == null && widget.ticketingBitsController.isValidationDone.value
            ? true
            : false,
        inputDecoration: widget.ticketingBitsController.startDate == null && widget.ticketingBitsController.isValidationDone.value
            ? smartSearchErrorDecoration
            : smartSearchDecoration,
        widthInput: getWidth(SizeConstants.dp180),
        onClickAction: (value) => {
          widget.ticketingBitsController.startDate = value.toString(),
          widget.ticketingBitsController.checkDate(true),
        },
      ),
    );
  }

  Widget endDateWidget() {
    return Obx(
      () => DatePickerView(
        selectedDate: widget.ticketingBitsController.ticketingModel.endDate!,
        //TODO,
        strImage: AppImages.calendar,
        strHint: AppStrings.dateformat,
        strTitle: AppStrings.endDateRequired,
        arrList: [],
        firstDate: widget.ticketingBitsController.consignment.createdAt!,
        //firstDate: DateTime.now().add(const Duration(days: -30)),
        errorText: (widget.ticketingBitsController.endDate == null && widget.ticketingBitsController.isValidationDone.value)
            ? AppStrings.errEnterDate
            : widget.ticketingBitsController.isDateInvalid.value
                ? AppStrings.errEnterValidDate
                : '',
        showError: widget.ticketingBitsController.endDate == null && widget.ticketingBitsController.isValidationDone.value ||
                widget.ticketingBitsController.isDateInvalid.value
            ? true
            : false,
        inputDecoration:
            widget.ticketingBitsController.endDate == null && widget.ticketingBitsController.isValidationDone.value ||
                    widget.ticketingBitsController.isDateInvalid.value
                ? smartSearchErrorDecoration
                : smartSearchDecoration,
        widthInput: getWidth(SizeConstants.dp180),
        onClickAction: (value) => {
          widget.ticketingBitsController.endDate = value.toString(),
          widget.ticketingBitsController.checkDate(false),
        },
      ),
    );
  }

  Widget dividerContainerWidget = Container(
    color: AppColors.colorSeparatorLine,
    height: getHeight(SizeConstants.dp1),
    margin: const EdgeInsets.only(bottom: AppValues.margin_20),
  );

  Widget nextButtonWidget() {
    return Container(
      alignment: Alignment.bottomRight,
      padding: const EdgeInsets.only(bottom: AppValues.padding_20, right: AppValues.padding_20),
      child: CustomButtonMaterial(
        width: getWidth(SizeConstants.dp130),
        height: getHeight(SizeConstants.dp45),
        backgroundColor: AppColors.colorPrimary,
        foregroundColor: AppColors.colorWhite,
        borderRadius: AppValues.radius_4,
        text: AppStrings.next,
        style: tSw500dp16fontF.copyWith(
          color: AppColors.colorWhite,
        ),
        onPressCallback: () {
          widget.ticketingBitsController.closeEnterDetailOverLay();
          widget.ticketingBitsController.validateEnterDetail();
        },
      ),
    );
  }
}
