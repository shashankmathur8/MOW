import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/values/app_values.dart';

import '../../../core/common_widgets/custom_button_material.dart';
import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../../bottomNavigation/dashboard.dart';
import '../controller/ticketing_bits_controller.dart';

class ConfirmationBillBits extends StatefulWidget {
  final TicketingBitsController ticketingBitsController;

  const ConfirmationBillBits({Key? key, required this.ticketingBitsController})
      : super(key: key);

  @override
  State<ConfirmationBillBits> createState() => _ConfirmationBillBitsState();
}

class _ConfirmationBillBitsState extends State<ConfirmationBillBits> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        alignment: Alignment.center,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
                child: Container(
              alignment: Alignment.center,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      AppStrings.billingTicketSubmitted,
                      style: tSw700fontF.copyWith(
                        fontSize: SizeConstants.dp30,
                        color: AppColors.colorMainText,
                      ),
                    ),
                    SizedBox(
                      height: getHeight(SizeConstants.dp53),
                    ),
                    Image.asset(
                      AppImages.tktSubmittedIcon,
                      width: getWidth(AppValues.iconSize_80),
                      height: getWidth(AppValues.iconSize_80),
                    ),
                    SizedBox(
                      height: getHeight(SizeConstants.dp30),
                    ),
                    Text(
                     "${AppStrings.ticketingId}${widget.ticketingBitsController.ticketingID}",
                      style: tSw500dp18fontF.copyWith(
                        color: AppColors.colorMainText,
                      ),
                    ),
                    SizedBox(
                      height: getHeight(SizeConstants.dp8),
                    ),
                    Text(
                      AppStrings.ticketCopy,
                      style: tSw400dp14fontF.copyWith(
                        color: AppColors.colorMainText,
                      ),
                    ),
                    SizedBox(height: getHeight(SizeConstants.dp29)),
                    gotoBilledBitsButtonWidget(),
                  ],
                ),
              ),
            )),
            // const Spacer(),
            dividerContainerWidget,
            nextButtonWidget(),
          ],
        ),
      ),
    );
  }

  Widget dividerContainerWidget = Container(
    color: AppColors.colorSeparatorLine,
    height: getHeight(SizeConstants.dp1),
    margin: EdgeInsets.only(bottom: getHeight(AppValues.margin_20)),
  );

  Widget gotoBilledBitsButtonWidget() {
    return CustomButtonMaterial(
      width: getWidth(SizeConstants.dp213),
      height: getHeight(SizeConstants.dp50),
      backgroundColor: AppColors.transparentColor,
      foregroundColor: AppColors.colorPrimary,
      borderRadius: AppValues.radius_10,
      text: AppStrings.gotoTicketedBits,
      style: tSw600dp16fontF,
      side: const BorderSide(
        width: SizeConstants.dp1,
        color: AppColors.colorPrimary,
      ),
      onPressCallback: () {
        Get.delete<TicketingBitsController>(
            tag: (TicketingBitsController).toString(), force: true);

        Get.off(
            Dashboard(
              pageIndex: 2,
            ),
            transition: Transition.downToUp,
            duration: const Duration(seconds: 1));
      },
    );
  }

  Widget nextButtonWidget() {
    return Container(
      alignment: Alignment.bottomRight,
      padding: const EdgeInsets.only(
          bottom: AppValues.padding_20, right: AppValues.padding_20),
      child: CustomButtonMaterial(
        width: getWidth(SizeConstants.dp219),
        height: getHeight(SizeConstants.dp45),
        backgroundColor: AppColors.colorPrimary,
        foregroundColor: AppColors.colorWhite,
        borderRadius: AppValues.radius_4,
        text: AppStrings.backToConsignedBits,
        style: tSw600dp16fontF.copyWith(
          color: AppColors.colorWhite,
        ),
        onPressCallback: () {
          Get.delete<TicketingBitsController>(
              tag: (TicketingBitsController).toString(), force: true);
          Get.back();
        },
      ),
    );
  }
}
