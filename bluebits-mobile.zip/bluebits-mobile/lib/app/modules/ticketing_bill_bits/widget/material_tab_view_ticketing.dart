import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/utils/size_config.dart';
import 'package:slb_gt_mobile/app/core/values/app_colors.dart';
import 'package:slb_gt_mobile/app/core/values/size_constants.dart';
import 'package:slb_gt_mobile/app/core/values/text_styles.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/controller/consign_controller.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';

import '../controller/ticketing_bits_controller.dart';

class MaterialTabViewTicketing extends StatelessWidget {
  final TicketingBitsController controller;

  MaterialTabViewTicketing({Key? key, required this.controller})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: getHeight(SizeConstants.dp40),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: controller.selectedBits.length,
        itemBuilder: (ctx, index) {
          return GestureDetector(
            onTap: () {
              controller.priceBookSelectedTab = index;
            },
            child: Container(
                child: _tabViewItem(
                    controller.selectedBits[index].bit as Bit, index)),
          );
        },
      ),
    );
  }

  _tabViewItem(Bit bit, int index) {
    return SizedBox(
        width: getWidth(SizeConstants.dp93),
        child: Obx(
          () => Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: Center(
                  child: Text(
                    bit.serialNumber?.toUpperCase() ?? '',
                    style: controller.priceBookSelectedTab == index
                        ? tSw700fontF.copyWith(
                            color: AppColors.colorPrimaryDarkStep,
                            fontSize: SizeConstants.dp16)
                        : tSw400dp14fontF.copyWith(
                            color: AppColors.colorSubText,
                            fontSize: SizeConstants.dp16),
                  ),
                ),
              ),
              Container(
                color: controller.priceBookSelectedTab == index
                    ? AppColors.colorPrimaryDarkStep
                    : AppColors.transparentColor,
                height: getHeight(SizeConstants.dp2),
              ),
            ],
          ),
        ));
  }
}
