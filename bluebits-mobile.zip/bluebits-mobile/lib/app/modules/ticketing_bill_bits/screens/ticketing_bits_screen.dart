import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/core/base/base_view.dart';
import 'package:slb_gt_mobile/app/core/utils/logger_common.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/consignmentSchema.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/model/ticketing_model.dart';

import '../../../core/utils/size_config.dart';
import '../../../core/values/app_colors.dart';
import '../../../core/values/app_images.dart';
import '../../../core/values/app_strings.dart';
import '../../../core/values/app_values.dart';
import '../../../core/values/size_constants.dart';
import '../../../core/values/text_styles.dart';
import '../../shared/generic_overlay.dart';
import '../controller/ticketing_bits_controller.dart';
import '../widget/confirmation_bill_bits.dart';
import '../widget/enter_details_bill_bits.dart';
import '../widget/missing_details_alert_overlay.dart';
import '../widget/quote_screen_bill_bits.dart';
import '../widget/select_price_book_bill_bits.dart';
import '../widget/step_widget_bill_bits.dart';

class TicketingBits extends BaseView {
  @override
  final TicketingBitsController controller = Get.put(TicketingBitsController(),
      tag: (TicketingBitsController).toString());

  TicketingBits(
      {Key? key,
      required List<Bit> selectedBits,
      required isDraftEdit,
      required Consignment currentConsignment})
      : super(key: key) {
    if (isDraftEdit) {
      controller.setupSelectedBitsDrafts(controller.ticketingModel.bits!);
      controller.isDraftEdit = isDraftEdit;
      controller.createTicketID();
    } else {
      controller.setupSelectedBits(selectedBits);
      controller.ticketingModel =
          TicketingModel(startDate: DateTime.now(), endDate: DateTime.now());
      controller.selectedValueCustomer = "";
      controller.selectedValueRig = "";
      controller.setupSelectedBits(selectedBits);
    }

    controller.createTicketID();
    controller.consignment = currentConsignment;
    controller.isDraftEdit = isDraftEdit;
  }

  @override
  final bool isResizeToAvoidBottomInset = true;

  @override
  PreferredSizeWidget? appBar(BuildContext context) {
    // TODO: implement appBar
    return AppBar(
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              AppColors.topColorPrimaryDark,
              AppColors.bottomColorPrimaryDark
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
      ),
      centerTitle: false,
      leading: IconButton(
          icon: Image.asset(AppImages.navBack, color: AppColors.colorWhite),
          onPressed: () {
            if (controller.isConfirmationScreen || (controller.well == null)) {
              Get.delete<TicketingBitsController>(
                  tag: (TicketingBitsController).toString(), force: true);
              Get.back();
            } else {
              controller.closeEnterDetailOverLay();
              // Pending Ticket Overlay
              Navigator.of(context).push(GenericOverlay(
                  title: AppStrings.pendingBillings,
                  messageWidget: descriptionTitle(),
                  iconPath: AppImages.alertNoBitsConsign,
                  negativeButtonText: AppStrings.cancel,
                  positiveButtonText: AppStrings.confirm,
                  onPositivePressCallback: () async {
                    controller.addTicket(AppStrings.draft);
                    Get.delete<TicketingBitsController>(
                        tag: (TicketingBitsController).toString(), force: true);
                    Get
                      ..back()
                      ..back();
                  }));
            }
          }),
      title: Text(
        AppStrings.ticketBits,
        style: tSw700fontF.copyWith(
            fontSize: SizeConstants.dp15,
            color: AppColors.colorWhite,
            fontStyle: FontStyle.normal),
      ),
    );
  }

  @override
  Widget body(BuildContext context) {
    return SafeArea(
      child: Row(children: [
        Flexible(
          flex: 1,
          fit: FlexFit.tight,
          child: StepWidgetBillBits(ticketingBitsController: controller),
        ),
        Flexible(
          flex: 4,
          fit: FlexFit.tight,
          child: Container(
            color: AppColors.colorBackgroundPanel,
            child: Column(
              children: [
                Obx(() => Visibility(
                      visible: checkVisibilityCondition(),
                      child: showStepDisableMessage(context),
                    )),
                Obx(
                  () => Expanded(
                    flex: 1,
                    child: Container(
                      child: IndexedStack(
                          index: controller.index.value,
                          children: [
                            EnterDetailsBillBits(
                                ticketingBitsController: controller),
                            SelectPriceBookBillBits(
                                ticketingBitsController: controller),
                            QuoteScreenBillBits(
                              ticketingBitsController: controller,
                            ),
                            ConfirmationBillBits(
                                ticketingBitsController: controller)
                          ]),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ]),
    );
  }

  Widget showStepDisableMessage(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: getHeight(SizeConstants.dp10)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: getHeight(SizeConstants.dp45),
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: AppColors.colorGrey.withOpacity(0.3),
                  spreadRadius: AppValues.radius_2,
                  blurRadius: AppValues.radius_7,
                  offset: const Offset(0, 3), // changes position of shadow
                ),
              ],
              color: AppColors.colorMainText,
              borderRadius:
                  const BorderRadius.all(Radius.circular(SizeConstants.dp6)),
              border: Border.all(
                  width: SizeConstants.dp1, color: AppColors.colorMainText),
            ),
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: getWidth(SizeConstants.dp20),
              ),
              child: Row(
                children: [
                  Image.asset(
                    AppImages.icInfoW,
                    height: getWidth(SizeConstants.dp20),
                    width: getWidth(SizeConstants.dp20),
                    fit: BoxFit.fill,
                  ),
                  Container(
                    margin: EdgeInsets.only(
                        left: getWidth(SizeConstants.dp15),
                        right: getWidth(SizeConstants.dp15)),
                    child: Text(
                      AppStrings.infoBillLaterProceed,
                      style: tSw400dp14fontF.copyWith(
                        color: AppColors.colorWhite,
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      if (controller.isEnterDetailItemInValid) {
                        Navigator.of(context).push(MissingDetailsAlertOverlay(controller));
                      } else {
                        Navigator.of(context).push(GenericOverlay(
                            title: AppStrings.ticketLater,
                            messageWidget: descriptionText(),
                            iconPath: AppImages.icBillingColoredBig,
                            negativeButtonText: AppStrings.cancel,
                            positiveButtonText: AppStrings.yes,
                            onPositivePressCallback: () async {
                              //Ticket later processing status record added
                              controller.addTicket(AppStrings.processing,
                                  ticketLater: true);
                              Get.delete<TicketingBitsController>(
                                  tag: (TicketingBitsController).toString(),
                                  force: true);
                              Get
                                ..back()
                                ..back();
                            }));
                      }
                    },
                    child: Text(
                      AppStrings.ticketLater,
                      style: tSw600dp14fontF.copyWith(
                          color: AppColors.colorWhite,
                          decoration: TextDecoration.underline),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget? descriptionText() {
    return SizedBox(
      width: SizeConstants.dp360,
      child: RichText(
          text: TextSpan(
              text: AppStrings.ticketLaterDescription,
              style: tSw400dp18fontF.copyWith(
                color: AppColors.colorMainText,
              ),
              children: <TextSpan>[
            TextSpan(
                text: controller.getSelectedBits(),
                style: const TextStyle(fontWeight: AppValues.fontWeight700)),
            const TextSpan(text: '?'),
          ])),
    );
  }

  Widget descriptionTitle() {
    return SizedBox(
      width: SizeConstants.dp360,
      child: RichText(
        text: TextSpan(
            text: AppStrings.pendingBillDesPrefix,
            style: tSw400dp14fontF.copyWith(
              color: AppColors.colorMainText,
              fontSize: SizeConstants.dp18,
            ),
            children: const <TextSpan>[
              TextSpan(
                  text: AppStrings.pendingBilledDesBold,
                  style: TextStyle(fontWeight: AppValues.fontWeight700)),
              TextSpan(text: ''),
              TextSpan(text: AppStrings.pendingConsignmentsDesSuffix),
            ]),
      ),
    );
  }

  bool checkVisibilityCondition() {
    ApplicationLogger().printInfo('${controller.ticketingModel.consumptionType}', 'checkVisibilityCondition');
    return controller.isBillLater.value &&
        (controller.ticketingModel.consumptionType == AppStrings.rentalConsumptionType ||
            controller.ticketingModel.consumptionType == '' ||
            controller.ticketingModel.consumptionType == null);
  }
}
