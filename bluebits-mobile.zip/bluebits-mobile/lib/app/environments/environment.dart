import 'package:slb_gt_mobile/app/environments/prod_config.dart';
import 'package:slb_gt_mobile/app/environments/qa_config.dart';

import '../../flavors/environment_enum.dart';
import 'base_config.dart';
import 'dev_config.dart';

class Environment {
  factory Environment() {
    return _singleton;
  }

  Environment._internal();

  static final Environment _singleton = Environment._internal();

  URLConfigBasedOnEnv? urlConfigBasedOnEnv;

  initConfig(EnvironmentEnum environment) {
    urlConfigBasedOnEnv = _getConfig(environment);
  }

  URLConfigBasedOnEnv _getConfig(EnvironmentEnum environment) {
    switch (environment) {
      case EnvironmentEnum.PROD:
        return ProdConfig();
      case EnvironmentEnum.QA:
        return QaConfig();
      default:
        return DevConfig();
    }
  }
}
