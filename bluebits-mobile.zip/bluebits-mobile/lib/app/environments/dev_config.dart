import 'package:slb_gt_mobile/flavors/environment_enum.dart';

import 'base_config.dart';

class DevConfig implements URLConfigBasedOnEnv {
  @override
  String get apiHost => "https://apigateway.evt.slb.com";

  @override
  String get endPoint => 'MOGW';

  @override
  String get xEnvironment => 'mogwdev';

  @override
  String get webSocketHost =>
      "wss://cds-customer-bff-svc-dev.azurewebsites.net/graphql";

  @override
  String get pwaHost => "https://cds-customer-dev.azurewebsites.net/";

  @override
  String get clientId => "f7bf90b009904d2d873ab4bfa6ee0218";

  @override
  String get redirectUrl => "com.app.slbapp://oauthredirect";

  @override
  String get issuer => "https://p4d.csi.cloud.slb-ds.com/v2";

  @override
  String get discoveryUrl =>
      "https://p4d.csi.cloud.slb-ds.com/v2/.well-known/openid-configuration";

  @override
  String get postLogoutRedirectUrl => "com.app.slbapp://login";

  @override
  String get scope => "openid";

  @override
  String get authorizationEndpoint =>
      "https://p4d.csi.cloud.slb-ds.com/v2/auth";

  @override
  String get tokenEndpoint => "https://p4d.csi.cloud.slb-ds.com/v2/token";

  @override
  String get endSessionEndpoint => "https://p4d.csi.cloud.slb-ds.com/v2/slo";

  @override
  EnvironmentEnum get env_name => EnvironmentEnum.DEV;

  /* SAP Credential */
/* 
  @override
  String realmAppId = "bluebitssap-gcwxe";

  @override
  String realmAppKey =
      "9NhajnM9gTQTwYp71HhVsUQR1kstxis4D3iUGGtmptLoxo1lzbsxIqUXLckMb6dN"; */

  /* MOGW Credential*/

  @override
  String realmAppId = "bluebitsmogw-dwtur";

  @override
  String realmAppKey =
      "vLWyRH2K6NFlrxoV1Su3QWWRhWydSQEFsQpspB25coKryNS1IXN0QSUkyoIOEEzX";

  @override
  // TODO: implement shouldCollectCrashLog
  bool get shouldCollectCrashLog => true;
}
