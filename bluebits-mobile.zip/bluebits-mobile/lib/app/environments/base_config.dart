// ignore_for_file: non_constant_identifier_names

import '../../flavors/environment_enum.dart';

abstract class URLConfigBasedOnEnv {
  String get apiHost;

  String get endPoint;

  String get xEnvironment;

  String get webSocketHost;

  String get pwaHost;

  String get clientId;

  String get redirectUrl;

  String get issuer;

  String get discoveryUrl;

  String get postLogoutRedirectUrl;

  String get scope;

  String? get authorizationEndpoint;

  String? get tokenEndpoint;

  String? get endSessionEndpoint;

  bool get shouldCollectCrashLog;

  EnvironmentEnum? get env_name;

  String? get realmAppId;

  String? get realmAppKey;
}
