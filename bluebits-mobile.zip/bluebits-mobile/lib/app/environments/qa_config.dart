import 'package:slb_gt_mobile/flavors/environment_enum.dart';

import 'base_config.dart';

class QaConfig implements URLConfigBasedOnEnv {
  @override
  String get apiHost => "https://apigateway.evt.slb.com";

  @override
  String get endPoint => 'MOGW';

  @override
  String get xEnvironment => 'mogwqa';

  @override
  String get webSocketHost =>
      "wss://cds-customer-bff-svc-qa.azurewebsites.net/graphql";

  @override
  String get pwaHost => "https://cds-customer-qa.azurewebsites.net/";

  @override
  String get clientId => "f7bf90b009904d2d873ab4bfa6ee0218";

  @override
  String get redirectUrl => "com.app.slbapp://oauthredirect";

  @override
  String get issuer => "https://p4d.csi.cloud.slb-ds.com/v2";

  @override
  String get discoveryUrl =>
      "https://p4d.csi.cloud.slb-ds.com/v2/.well-known/openid-configuration";

  @override
  String get postLogoutRedirectUrl => "com.app.slbapp://login";

  @override
  String get scope => "openid";

  @override
  String get authorizationEndpoint =>
      "https://p4d.csi.cloud.slb-ds.com/v2/auth";

  @override
  String get tokenEndpoint => "https://p4d.csi.cloud.slb-ds.com/v2/token";

  @override
  String get endSessionEndpoint => "https://p4d.csi.cloud.slb-ds.com/v2/slo";

  @override
  EnvironmentEnum get env_name => EnvironmentEnum.QA;

  @override
  String realmAppId = "bluebitsmogw-uat-ytleq";

  @override
  String realmAppKey =
      "kmpqrAAIZSkbx0CKpMSUITd5h756p0shBzZAbNY5s661yIEvh4e0tZBhZR4Nos8X";

  @override
  // TODO: implement shouldCollectCrashLog
  bool get shouldCollectCrashLog => true;
}
