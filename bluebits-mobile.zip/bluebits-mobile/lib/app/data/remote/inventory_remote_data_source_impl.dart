import 'dart:convert';

import 'package:dio/dio.dart';

import '../../core/base/base_remote_source.dart';
import '../model/request/bit_movment_param.dart';
import '../model/response/bit_movement_response.dart';
import '/app/network/dio_provider.dart';
import 'inventory_remote_data_source.dart';

class InventoryRemoteDataSourceImpl extends BaseRemoteSource
    implements InventoryRemoteDataSource {
  @override
  Future<BitMovementResponseModel> bitMovement(BitMovementParam queryParam) {
    var apiURL =
        "${DioProvider.baseUrl}/bfse_bitmovement/bffsync/sync/initiate/${DioProvider.endPoint}";
    var dioCall = dioClient.post(
      apiURL,
      data: jsonEncode(queryParam),
    );

    try {
      return callApiWithErrorParser(dioCall)
          .then((response) => _parseGithubProjectSearchResponse(response));
    } catch (e) {
      rethrow;
    }
  }

  BitMovementResponseModel _parseGithubProjectSearchResponse(
      Response<dynamic> response) {
    return BitMovementResponseModel.fromJson(response.data);
  }
}
