
import '../model/request/bit_movment_param.dart';
import '../model/response/bit_movement_response.dart';

abstract class InventoryRemoteDataSource {
  Future<BitMovementResponseModel> bitMovement(BitMovementParam queryParam);
}
