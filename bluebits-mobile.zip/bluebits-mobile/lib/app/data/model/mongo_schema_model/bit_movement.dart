import 'package:realm/realm.dart';
part 'bit_movement.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.

@RealmModel()
class _BitMovement {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;
  _BitMovementRequest? request;
  String? requestedBy;
  _BitMovementResponse? response;
  String? transactionId;
  String? truckUserMappingId;
}

@RealmModel(ObjectType.embeddedObject)
@MapTo('BitMovement_request')
class _BitMovementRequest {
  late List<_BitMovementRequestBitsInfo> bitsInfo;
}

@RealmModel(ObjectType.embeddedObject)
@MapTo('BitMovement_request_bitsInfo')
class _BitMovementRequestBitsInfo {
  late List<String> bitIds;
  String? destinationPlant;
  String? destinationSloc;
  String? movementType;
}

@RealmModel(ObjectType.embeddedObject)
@MapTo('BitMovement_response')
class _BitMovementResponse {
  String? message;
  String? statusCode;
}
