import 'package:realm/realm.dart';
part 'app_logger.g.dart';

// NOTE: These Realm models are private and therefore should be copied into the same .dart file.
@RealmModel()
class _AppLogger {
  @PrimaryKey()
  @MapTo('_id')
  ObjectId? id;
  String? alias;
  String? date;
  String? message;
  String? origin;
  String? type;
  String? userTruckMappingId;
}
