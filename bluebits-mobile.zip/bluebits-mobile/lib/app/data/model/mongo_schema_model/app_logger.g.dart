// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_logger.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class AppLogger extends _AppLogger
    with RealmEntity, RealmObjectBase, RealmObject {
  AppLogger(
    ObjectId? id, {
    String? alias,
    String? date,
    String? message,
    String? origin,
    String? type,
    String? userTruckMappingId,
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'alias', alias);
    RealmObjectBase.set(this, 'date', date);
    RealmObjectBase.set(this, 'message', message);
    RealmObjectBase.set(this, 'origin', origin);
    RealmObjectBase.set(this, 'type', type);
    RealmObjectBase.set(this, 'userTruckMappingId', userTruckMappingId);
  }

  AppLogger._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  String? get alias => RealmObjectBase.get<String>(this, 'alias') as String?;
  @override
  set alias(String? value) => RealmObjectBase.set(this, 'alias', value);

  @override
  String? get date => RealmObjectBase.get<String>(this, 'date') as String?;
  @override
  set date(String? value) => RealmObjectBase.set(this, 'date', value);

  @override
  String? get message =>
      RealmObjectBase.get<String>(this, 'message') as String?;
  @override
  set message(String? value) => RealmObjectBase.set(this, 'message', value);

  @override
  String? get origin => RealmObjectBase.get<String>(this, 'origin') as String?;
  @override
  set origin(String? value) => RealmObjectBase.set(this, 'origin', value);

  @override
  String? get type => RealmObjectBase.get<String>(this, 'type') as String?;
  @override
  set type(String? value) => RealmObjectBase.set(this, 'type', value);

  @override
  String? get userTruckMappingId =>
      RealmObjectBase.get<String>(this, 'userTruckMappingId') as String?;
  @override
  set userTruckMappingId(String? value) =>
      RealmObjectBase.set(this, 'userTruckMappingId', value);

  @override
  Stream<RealmObjectChanges<AppLogger>> get changes =>
      RealmObjectBase.getChanges<AppLogger>(this);

  @override
  AppLogger freeze() => RealmObjectBase.freezeObject<AppLogger>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(AppLogger._);
    return const SchemaObject(ObjectType.realmObject, AppLogger, 'AppLogger', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('alias', RealmPropertyType.string, optional: true),
      SchemaProperty('date', RealmPropertyType.string, optional: true),
      SchemaProperty('message', RealmPropertyType.string, optional: true),
      SchemaProperty('origin', RealmPropertyType.string, optional: true),
      SchemaProperty('type', RealmPropertyType.string, optional: true),
      SchemaProperty('userTruckMappingId', RealmPropertyType.string,
          optional: true),
    ]);
  }
}
