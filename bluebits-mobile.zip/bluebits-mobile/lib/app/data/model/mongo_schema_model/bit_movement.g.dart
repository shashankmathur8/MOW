// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'bit_movement.dart';

// **************************************************************************
// RealmObjectGenerator
// **************************************************************************

class BitMovement extends _BitMovement
    with RealmEntity, RealmObjectBase, RealmObject {
  BitMovement(
    ObjectId? id, {
    BitMovementRequest? request,
    String? requestedBy,
    BitMovementResponse? response,
    String? transactionId,
    String? truckUserMappingId,
  }) {
    RealmObjectBase.set(this, '_id', id);
    RealmObjectBase.set(this, 'request', request);
    RealmObjectBase.set(this, 'requestedBy', requestedBy);
    RealmObjectBase.set(this, 'response', response);
    RealmObjectBase.set(this, 'transactionId', transactionId);
    RealmObjectBase.set(this, 'truckUserMappingId', truckUserMappingId);
  }

  BitMovement._();

  @override
  ObjectId? get id => RealmObjectBase.get<ObjectId>(this, '_id') as ObjectId?;
  @override
  set id(ObjectId? value) => RealmObjectBase.set(this, '_id', value);

  @override
  BitMovementRequest? get request =>
      RealmObjectBase.get<BitMovementRequest>(this, 'request')
          as BitMovementRequest?;
  @override
  set request(covariant BitMovementRequest? value) =>
      RealmObjectBase.set(this, 'request', value);

  @override
  String? get requestedBy =>
      RealmObjectBase.get<String>(this, 'requestedBy') as String?;
  @override
  set requestedBy(String? value) =>
      RealmObjectBase.set(this, 'requestedBy', value);

  @override
  BitMovementResponse? get response =>
      RealmObjectBase.get<BitMovementResponse>(this, 'response')
          as BitMovementResponse?;
  @override
  set response(covariant BitMovementResponse? value) =>
      RealmObjectBase.set(this, 'response', value);

  @override
  String? get transactionId =>
      RealmObjectBase.get<String>(this, 'transactionId') as String?;
  @override
  set transactionId(String? value) =>
      RealmObjectBase.set(this, 'transactionId', value);

  @override
  String? get truckUserMappingId =>
      RealmObjectBase.get<String>(this, 'truckUserMappingId') as String?;
  @override
  set truckUserMappingId(String? value) =>
      RealmObjectBase.set(this, 'truckUserMappingId', value);

  @override
  Stream<RealmObjectChanges<BitMovement>> get changes =>
      RealmObjectBase.getChanges<BitMovement>(this);

  @override
  BitMovement freeze() => RealmObjectBase.freezeObject<BitMovement>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(BitMovement._);
    return const SchemaObject(
        ObjectType.realmObject, BitMovement, 'BitMovement', [
      SchemaProperty('id', RealmPropertyType.objectid,
          mapTo: '_id', optional: true, primaryKey: true),
      SchemaProperty('request', RealmPropertyType.object,
          optional: true, linkTarget: 'BitMovement_request'),
      SchemaProperty('requestedBy', RealmPropertyType.string, optional: true),
      SchemaProperty('response', RealmPropertyType.object,
          optional: true, linkTarget: 'BitMovement_response'),
      SchemaProperty('transactionId', RealmPropertyType.string, optional: true),
      SchemaProperty('truckUserMappingId', RealmPropertyType.string,
          optional: true),
    ]);
  }
}

class BitMovementRequest extends _BitMovementRequest
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  BitMovementRequest({
    Iterable<BitMovementRequestBitsInfo> bitsInfo = const [],
  }) {
    RealmObjectBase.set<RealmList<BitMovementRequestBitsInfo>>(
        this, 'bitsInfo', RealmList<BitMovementRequestBitsInfo>(bitsInfo));
  }

  BitMovementRequest._();

  @override
  RealmList<BitMovementRequestBitsInfo> get bitsInfo =>
      RealmObjectBase.get<BitMovementRequestBitsInfo>(this, 'bitsInfo')
          as RealmList<BitMovementRequestBitsInfo>;
  @override
  set bitsInfo(covariant RealmList<BitMovementRequestBitsInfo> value) =>
      throw RealmUnsupportedSetError();

  @override
  Stream<RealmObjectChanges<BitMovementRequest>> get changes =>
      RealmObjectBase.getChanges<BitMovementRequest>(this);

  @override
  BitMovementRequest freeze() =>
      RealmObjectBase.freezeObject<BitMovementRequest>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(BitMovementRequest._);
    return const SchemaObject(
        ObjectType.embeddedObject, BitMovementRequest, 'BitMovement_request', [
      SchemaProperty('bitsInfo', RealmPropertyType.object,
          linkTarget: 'BitMovement_request_bitsInfo',
          collectionType: RealmCollectionType.list),
    ]);
  }
}

class BitMovementRequestBitsInfo extends _BitMovementRequestBitsInfo
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  BitMovementRequestBitsInfo({
    String? destinationPlant,
    String? destinationSloc,
    String? movementType,
    Iterable<String> bitIds = const [],
  }) {
    RealmObjectBase.set(this, 'destinationPlant', destinationPlant);
    RealmObjectBase.set(this, 'destinationSloc', destinationSloc);
    RealmObjectBase.set(this, 'movementType', movementType);
    RealmObjectBase.set<RealmList<String>>(
        this, 'bitIds', RealmList<String>(bitIds));
  }

  BitMovementRequestBitsInfo._();

  @override
  RealmList<String> get bitIds =>
      RealmObjectBase.get<String>(this, 'bitIds') as RealmList<String>;
  @override
  set bitIds(covariant RealmList<String> value) =>
      throw RealmUnsupportedSetError();

  @override
  String? get destinationPlant =>
      RealmObjectBase.get<String>(this, 'destinationPlant') as String?;
  @override
  set destinationPlant(String? value) =>
      RealmObjectBase.set(this, 'destinationPlant', value);

  @override
  String? get destinationSloc =>
      RealmObjectBase.get<String>(this, 'destinationSloc') as String?;
  @override
  set destinationSloc(String? value) =>
      RealmObjectBase.set(this, 'destinationSloc', value);

  @override
  String? get movementType =>
      RealmObjectBase.get<String>(this, 'movementType') as String?;
  @override
  set movementType(String? value) =>
      RealmObjectBase.set(this, 'movementType', value);

  @override
  Stream<RealmObjectChanges<BitMovementRequestBitsInfo>> get changes =>
      RealmObjectBase.getChanges<BitMovementRequestBitsInfo>(this);

  @override
  BitMovementRequestBitsInfo freeze() =>
      RealmObjectBase.freezeObject<BitMovementRequestBitsInfo>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(BitMovementRequestBitsInfo._);
    return const SchemaObject(ObjectType.embeddedObject,
        BitMovementRequestBitsInfo, 'BitMovement_request_bitsInfo', [
      SchemaProperty('bitIds', RealmPropertyType.string,
          collectionType: RealmCollectionType.list),
      SchemaProperty('destinationPlant', RealmPropertyType.string,
          optional: true),
      SchemaProperty('destinationSloc', RealmPropertyType.string,
          optional: true),
      SchemaProperty('movementType', RealmPropertyType.string, optional: true),
    ]);
  }
}

class BitMovementResponse extends _BitMovementResponse
    with RealmEntity, RealmObjectBase, EmbeddedObject {
  BitMovementResponse({
    String? message,
    String? statusCode,
  }) {
    RealmObjectBase.set(this, 'message', message);
    RealmObjectBase.set(this, 'statusCode', statusCode);
  }

  BitMovementResponse._();

  @override
  String? get message =>
      RealmObjectBase.get<String>(this, 'message') as String?;
  @override
  set message(String? value) => RealmObjectBase.set(this, 'message', value);

  @override
  String? get statusCode =>
      RealmObjectBase.get<String>(this, 'statusCode') as String?;
  @override
  set statusCode(String? value) =>
      RealmObjectBase.set(this, 'statusCode', value);

  @override
  Stream<RealmObjectChanges<BitMovementResponse>> get changes =>
      RealmObjectBase.getChanges<BitMovementResponse>(this);

  @override
  BitMovementResponse freeze() =>
      RealmObjectBase.freezeObject<BitMovementResponse>(this);

  static SchemaObject get schema => _schema ??= _initSchema();
  static SchemaObject? _schema;
  static SchemaObject _initSchema() {
    RealmObjectBase.registerFactory(BitMovementResponse._);
    return const SchemaObject(ObjectType.embeddedObject, BitMovementResponse,
        'BitMovement_response', [
      SchemaProperty('message', RealmPropertyType.string, optional: true),
      SchemaProperty('statusCode', RealmPropertyType.string, optional: true),
    ]);
  }
}
