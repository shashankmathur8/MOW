class DraggableCardsModel {
  bool isEnable;

  final String title;
  final String key;

  DraggableCardsModel({
    this.isEnable = false,
    this.title = "",
    this.key = "",
  });
}
