class BitMovementParam {
  String truckUserMappingId;
  String requestedBy;

  BitMovementParam(
      {required this.truckUserMappingId, required this.requestedBy});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['truckUserMappingId'] = truckUserMappingId;
    data['requestedBy'] = requestedBy;
    return data;
  }
}
