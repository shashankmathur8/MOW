class Step {
  late String title;
  late String description;

  Step({required this.title, required this.description});


}