class MovementErrorResponse {
  Fault? fault;

  MovementErrorResponse({this.fault});

  MovementErrorResponse.fromJson(Map<String, dynamic> json) {
    fault = json['fault'] != null ? new Fault.fromJson(json['fault']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.fault != null) {
      data['fault'] = this.fault!.toJson();
    }
    return data;
  }
}

class Fault {
  String? faultstring;
  Detail? detail;

  Fault({this.faultstring, this.detail});

  Fault.fromJson(Map<String, dynamic> json) {
    faultstring = json['faultstring'];
    detail =
        json['detail'] != null ? new Detail.fromJson(json['detail']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['faultstring'] = this.faultstring;
    if (this.detail != null) {
      data['detail'] = this.detail!.toJson();
    }
    return data;
  }
}

class Detail {
  String? errorcode;

  Detail({this.errorcode});

  Detail.fromJson(Map<String, dynamic> json) {
    errorcode = json['errorcode'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['errorcode'] = this.errorcode;
    return data;
  }
}
