import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/data/remote/inventory_remote_data_source.dart';
import 'package:slb_gt_mobile/app/data/repository/inventory_repo.dart';

import '../model/request/bit_movment_param.dart';
import '../model/response/bit_movement_response.dart';

class InventoryRepoImpl implements InventoryRepo {
  final InventoryRemoteDataSource _remoteSource =
      Get.find(tag: (InventoryRemoteDataSource).toString());

  @override
  Future<BitMovementResponseModel> bitMovement(BitMovementParam queryParam) {
    return _remoteSource.bitMovement(queryParam);
  }
}
