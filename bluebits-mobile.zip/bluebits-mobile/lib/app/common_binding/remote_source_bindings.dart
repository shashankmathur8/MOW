import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/data/remote/inventory_remote_data_source.dart';
import 'package:slb_gt_mobile/app/data/remote/inventory_remote_data_source_impl.dart';

class RemoteSourceBindings implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut<InventoryRemoteDataSource>(
      () => InventoryRemoteDataSourceImpl(),
      tag: (InventoryRemoteDataSource).toString(),
    );
  }
}
