import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/common_binding/realm_binding.dart';
import 'package:slb_gt_mobile/app/common_binding/remote_source_bindings.dart';
import 'package:slb_gt_mobile/app/common_binding/repository_bindings.dart';
import 'package:slb_gt_mobile/app/core/base/lifecyle_controller.dart';
import 'package:slb_gt_mobile/app/utils/msal_login.dart';

import '../core/connectivity_utils/connectivity_controller.dart';

class InitialBinding implements Bindings {
  @override
  void dependencies() {
    Get.put(ConnectivityController());
    RealmBinding().dependencies();
    Get.put(LifeCycleController());
    RepositoryBindings().dependencies();
    RemoteSourceBindings().dependencies();
    init();
  }

  static init() async {
    await AADAuthentication.instance.initializingObject();
  }
}
