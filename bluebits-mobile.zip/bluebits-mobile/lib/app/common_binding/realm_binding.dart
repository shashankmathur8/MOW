import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/common_binding/realm_initial.dart';

// ignore: camel_case_types
class RealmBinding extends Bindings {
  @override
  void dependencies() async {
    Get.put<RealmInitial>(
      // ignore: unnecessary_cast
      RealmInitial.initialSync(),
      tag: (RealmInitial).toString(),
    );
  }
}
