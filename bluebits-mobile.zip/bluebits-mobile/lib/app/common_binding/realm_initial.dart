import 'package:device_info_plus/device_info_plus.dart';
import 'package:get/get.dart';
import 'package:realm/realm.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:slb_gt_mobile/app/core/base/base_controller.dart';
import 'package:slb_gt_mobile/app/core/connectivity_utils/connectivity_controller.dart';
import 'package:slb_gt_mobile/app/core/utils/logger_common.dart';
import 'package:slb_gt_mobile/app/core/values/app_strings.dart';
import 'package:slb_gt_mobile/app/core/values/app_utils.dart';
import 'package:slb_gt_mobile/app/core/values/preference_constants.dart';
import 'package:slb_gt_mobile/app/data/model/mongo_schema_model/app_logger.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/model/consignment_model.dart';
import 'package:slb_gt_mobile/app/modules/consign_bits/model/schema/pricebook_schema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/bitSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/bitState.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/consignmentQueueSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/consignmentSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/customerSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/movementQueue.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/recentSearchesSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/requestbitSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/rigsSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/storagelocSchema.dart';
import 'package:slb_gt_mobile/app/modules/inventory/models/truckUserMapping.dart';
import 'package:slb_gt_mobile/app/modules/notification/schema/notification_schema.dart';
import 'package:slb_gt_mobile/app/modules/ticketing_bill_bits/model/schema/ticketing_Queue_schema.dart';
import 'package:slb_gt_mobile/flavors/build_config.dart';
import '../data/model/mongo_schema_model/bit_movement.dart';
import '../modules/inventory/controller/inventory_controller.dart';
import '../modules/inventory/models/deviceTokenStorage.dart';
import '../modules/inventory/models/fields_name.dart';
import '../modules/login/controller/login_controller.dart';
import '../modules/ticketing_bill_bits/model/billedBits.dart';
import '../modules/ticketing_bill_bits/model/sales_representative_schema.dart';
import '../modules/ticketing_bill_bits/model/schema/return_Queue_schema.dart';
import '../modules/ticketing_bill_bits/model/schema/ticketing_schema.dart';
import '../modules/ticketing_bill_bits/model/ticketing_model.dart';
import '../modules/ticketing_bill_bits/model/wells_schema.dart';

class RealmInitial extends BaseController {
  late Realm realm;
  late Realm disconectedRealm;
  late var config;
  late RealmResults<RecentSearchesData> recentSearches;
  late RealmResults<TruckUserMapping> userEntitlements;
  var isInternetThereWhileInitialize = false;
  final ConnectivityController connectivity = Get.find();
  final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
  late SharedPreferences prefs;

  Future<bool> isDeviceOnline() async {
    final isConnected = connectivity.isConnected.value;
    return isConnected;
  }

  Future<void> initialSetup() async {
    prefs = await _prefs;
    await initRealm();
    await syncRealm();
  }

  RealmInitial.initialSync() {
    initialSetup();
  }

  Future<Realm> initDisconectedRealm() async {
    /* Initial Setup */
    String appId = BuildConfig.instance.config.urlConfigBasedOnEnv.realmAppId ??
        ''; //bsfe-app-jjfdj
    final appConfig = AppConfiguration(appId);
    final app = App(appConfig);

    /* anonymous All bytes transferred!login*/
    //final user = await app.logIn(Credentials.anonymous());

    /* API key login */ //5AirbJlq9iTGg7gTTwrfu0T2lHBph448IbsKFpN7NsKetFrGm88ssPgY2ilUv2GJ
    final apiKeyCredentials = Credentials.apiKey(
        BuildConfig.instance.config.urlConfigBasedOnEnv.realmAppKey ?? '');
    final user = await app.logIn(
        apiKeyCredentials); //await isDeviceOnline() ? await app.logIn(apiKeyCredentials) : await app.logIn(Credentials.anonymous());

    /* check connectivity and open Realm */
    config = Configuration.flexibleSync(user, [Well.schema]);

    // Only use asynchronous open if app is online.

    realm = await initiateRealmObject();

    print('realm initialisation done');
    return realm;

    /* read data to realm */
  }

  Future<Realm> initRealm() async {
    /* Initial Setup */
    String appId = BuildConfig.instance.config.urlConfigBasedOnEnv.realmAppId ??
        ''; //bsfe-app-jjfdj
    final appConfig = AppConfiguration(appId);
    final app = App(appConfig);

    /* anonymous login*/
    //final user = await app.logIn(Credentials.anonymous());

    /* API key login */ //5AirbJlq9iTGg7gTTwrfu0T2lHBph448IbsKFpN7NsKetFrGm88ssPgY2ilUv2GJ
    final apiKeyCredentials = Credentials.apiKey(
        BuildConfig.instance.config.urlConfigBasedOnEnv.realmAppKey ?? '');
    final user = await app.logIn(
        apiKeyCredentials); //await isDeviceOnline() ? await app.logIn(apiKeyCredentials) : await app.logIn(Credentials.anonymous());

    /* check connectivity and open Realm */
    config = Configuration.flexibleSync(user, [
      Bit.schema,
      Rig.schema,
      Customer.schema,
      RequestBit.schema,
      PriceBook.schema,
      PriceBookLines.schema,
      BitMovement.schema,
      BitMovementRequest.schema,
      BitMovementResponse.schema,
      BitMovementRequestBitsInfo.schema,
      PriceBookLinesFlatLevelItems.schema,
      PriceBookLinesHighLevelItems.schema,
      PriceBookLinesLowLevelItems.schema,
      PriceBookLinesSuperHighLevelItems.schema,
      RecentSearchesData.schema,
      DeviceTokenStorage.schema,
      TruckUserMapping.schema,
      MovementQueue.schema,
      MovementQueueBits.schema,
      Consignment.schema,
      ConsignmentBits.schema,
      ConsignmentDigitalAttachments.schema,
      ConsignmentManualAttachments.schema,
      ConsignmentBitsPriceBookDetails.schema,
      BitState.schema,
      FieldsName.schema,
      BilledBits.schema,
      BilledBitsList.schema,
      AppLogger.schema,
      ConsignmentQueue.schema,
      ConsignmentQueueBits.schema,
      StorageLocation.schema,
      Notification.schema,
      SalesRepresentative.schema,
      Ticket.schema,
      TicketQueue.schema,
      TicketManualAttachments.schema,
      TicketDigitalAttachments.schema,
      TicketQueueBits.schema,
      TicketBitsPriceBookDetails.schema,
      TicketBits.schema,
      Well.schema,
      ReturnQueue.schema,
      ReturnQueueBits.schema
    ]);

    // Only use asynchronous open if app is online.

    realm = await initiateRealmObject();

    print('realm initialisation done');
    return realm;

    /* read data to realm */
  }

  Future<Realm> initiateRealmObject() async {
    Realm realmLocal;
    if (await isDeviceOnline()) {
      isInternetThereWhileInitialize = true;
      // If the device is online, download changes and then open the realm.
      realmLocal = await Realm.open(config);
    } else {
      isInternetThereWhileInitialize = false;
      // If the device is offline, open the realm immediately
      // and automatically sync changes in the background when the device is online.
      realmLocal = Realm(config);
    }

    return realmLocal;
  }

  Future<void> getCurrentRealmObject() async {
    var currentStatusOfInternet = await isDeviceOnline();
    if (currentStatusOfInternet != isInternetThereWhileInitialize) {
      realm = await initiateRealmObject();
    }
  }

  RealmResults<Rig> getRigs() {
    var rigs = realm.all<Rig>();
    print('Rigs : ${rigs.length}');
    return rigs;
  }

  Rig getRig(String rig) {
    var rigs = realm.all<Rig>().query("number == \$0 ", [rig]);
    return rigs.first;
  }

  SalesRepresentative getTicketCEC(String cEC) {
    var cec = realm.all<SalesRepresentative>().query("value == \$0 ", [cEC]);
    return cec.first;
  }

  SalesRepresentative getDE(String dE) {
    var de = realm.all<SalesRepresentative>().query("value == \$0 ", [dE]);
    return de.first;
  }

  RealmResults<Customer> getCustomers(String country) {
    var customer = realm
        .all<Customer>()
        .query("category == \$0 AND isActive == \$1", ['SLS_ACCT', true]);
    //.query("category == \$0 AND isActive == \$1 AND country == \$2", ['SLS_ACCT', true, country]);//keep commented this line
    ApplicationLogger().printInfo(
        "customer country:- $country, length:- ${customer.length}",
        'getCustomers()');
    return customer;
  }

  RealmResults<Well> getWell(String country, String state) {
    final wells = realm.all<Well>().query(
        "country == \$0 AND state == \$1 LIMIT(10) SORT(name ASC)",
        [country, state]);
    ApplicationLogger().printInfo("${wells.length}", "Well Length");
    return wells;
  }

  Future<RealmResults<Customer>> getShipTo(String customerNumber) async {
    /* var customer = await realm.all<Customer>().query(
        "category == \$0 AND isActive == \$1 AND number == \$2",
        ['SLS_ACCT', true, customerNumber]);
    var billAccount = await realm.all<Customer>().query(
        "category == \$0 AND isActive == \$1 AND parentId == \$2",
        ['BILL_ACCT', true, customer.first.customerReferenceId.toString()]);
    //customers where parentId == slsaccountCustomerReferenceId&& category == BILL_ACCT && isActive == true
    var shipTo = realm.all<Customer>().query(
        "category == \$0 AND isActive == \$1 AND parentId == \$2",
        ['SHIP_TO', true, billAccount.first.customerReferenceId.toString()]);
    //filter customer where parentId == billaccountCustomerReferenceId && category == SHIP_TO && isActive == true
    return shipTo; */
    // To be used after changes in Data

    var shipTo = await realm.all<Customer>().query(
        "category == \$0 AND isActive == \$1 AND number == \$2 LIMIT(10) SORT(addressLine1 ASC) ",
        ['SHIP_TO', true, customerNumber]);
    return shipTo;
  }

  Customer getAddressCustomer(String customerNumber) {
    var customer = realm.find<Customer>(ObjectId.fromHexString(customerNumber));

    return customer!;
  }

  Future<RealmResults<Customer>> getBillTo(String customerNumber) async {
    /*var customer = await realm.all<Customer>().query(
        "category == \$0 AND isActive == \$1 AND number == \$2",
        ['SLS_ACCT', true, customerNumber]);
    var billAccount = await realm.all<Customer>().query(
        "category == \$0 AND isActive == \$1 AND parentId == \$2",
        ['BILL_ACCT', true, customer.first.customerReferenceId.toString()]);

    var billTo = realm.all<Customer>().query(
        "category == \$0 AND isActive == \$1 AND parentId == \$2",
        ['BILL_TO', true, billAccount.first.customerReferenceId.toString()]);
    return billTo;*/
    // To be used after data changes

    var billTo = await realm.all<Customer>().query(
        "category == \$0 AND isActive == \$1 AND number == \$2  LIMIT(10) SORT(addressLine1 ASC)",
        ['BILL_TO', true, customerNumber]);
    return billTo;
  }

  Future<RealmResults<SalesRepresentative>> getCEC(String plantId) async {
    var cec = await realm.all<SalesRepresentative>().query(
        "role == \$0 AND plantId == \$1 LIMIT(10) SORT(fullName ASC) ",
        ['CE_USER', plantId]);
    return cec;
  }

  Future<RealmResults<SalesRepresentative>> getDesignEngg(
      String plantId) async {
    var designEngineers = await realm.all<SalesRepresentative>().query(
        "role == \$0 AND plantId == \$1 LIMIT(10) SORT(fullName ASC) ",
        ['DSGN_EGR', plantId]);
    return designEngineers;
  }

  RealmResults<Well> searchWell(
      String value, String country, String state, int listLength) {
    var well = realm.all<Well>().query(
        "name CONTAINS[c] '$value' AND country == \$0 AND state == \$1 LIMIT($listLength) SORT(name ASC) ",
        [country, state]);
    print('getWell searchWell $value $country $state length:- ${well.length}');
    return well;
  }

  RealmResults<Customer> searchBillTo(
      String value, String customerNumber, int listLength) {
    var billTo = realm.all<Customer>().query(
        "addressLine1 CONTAINS[c] '$value' AND category == \$0 AND isActive == \$1 AND number == \$2 LIMIT($listLength) SORT(addressLine1 ASC)",
        ['BILL_TO', true, customerNumber]);

    return billTo;
  }

  RealmResults<Customer> searchShipTo(
      String value, String customerNumber, int listLength) {
    var shipTo = realm.all<Customer>().query(
        "addressLine1 CONTAINS[c] '$value' AND category == \$0 AND isActive == \$1 AND number == \$2 LIMIT($listLength) SORT(addressLine1 ASC)",
        ['SHIP_TO', true, customerNumber]);
    return shipTo;
  }

  RealmResults<SalesRepresentative> searchedCEC(
      String value, String plantId, int listLength) {
    var cec = realm.all<SalesRepresentative>().query(
        "fullName CONTAINS[c] '$value' AND role == \$0 AND plantId == \$1 LIMIT($listLength) SORT(fullName ASC)",
        ['CE_USER', plantId]);
    return cec;
  }

  RealmResults<SalesRepresentative> searchedDesignEngg(
      String value, String plantId, int listLength) {
    /* var designEngg = realm.all<SalesRepresentative>().query(
        "fullName CONTAINS[c] '$value' AND plantId == '$plantId' LIMIT($listLength) SORT(fullName ASC) ");
    return designEngg;*/

    var designEngg = realm.all<SalesRepresentative>().query(
        "fullName CONTAINS[c] '$value' AND plantId == '$plantId' AND role == 'DSGN_EGR' LIMIT($listLength) SORT(fullName ASC) ");
    return designEngg;

    //  designEngg =  designEngg.query("role == \$0 AND plantId == \$1 SORT(fullName ASC) ", ['DSGN_EGR', plantId]);
    // return designEngg.toList();
  }

  RealmResults<Customer> getCustomer(String customerNumber) {
    var customer = realm.all<Customer>().query(
        "category == \$0 AND isActive == \$1 AND number == \$2",
        ['SLS_ACCT', true, customerNumber]);
    return customer;
  }

  RealmResults<PriceBook> getPriceBooksList(String country) {
    var priceBooks = realm
        .all<PriceBook>()
        .query('isActive == \$0 AND country BEGINSWITH \$1', [true, country]);
    print('PriceBooks : ${priceBooks.length}');
    return priceBooks;
  }

  RealmResults<Bit> getBits() {
    var bits = realm.all<Bit>();
    print('Bits : ${bits.length}');
    return bits;
  }

  String getBitStorageLoc(String serialNbr) {
    var bits = realm.all<Bit>().query('serialNumber == \$0', [serialNbr]);
    print('Bits : ${bits.length}');
    return bits.first.storageLoc.toString();
  }

  String getBitPlant(String serialNbr) {
    var bits = realm.all<Bit>().query('serialNumber == \$0', [serialNbr]);
    return bits.first.plant.toString();
  }

  RealmResults<Notification> getNotifications() {
    String? userTruckMapping =
        prefs.getString(PreferenceConstants.userTruckMapping);
    var notifications = realm.all<Notification>().query(
        "truckUserMappingId == '$userTruckMapping' OR truckUserMappingId == 'ALL' SORT(createdAt DESC)");
    return notifications;
  }

  Bits getBitFromMap(var Bitmap) {
    var bits;
    bits = realm.all<Bit>().query('serialNumber == \$0', [Bitmap['srNO']]);

    return Bits(bit: bits.first, lineItem: Bitmap['lineItems']);
  }

  TicketingBit getTicketBitFromMap(var Bitmap) {
    var bits;
    bits = realm.all<Bit>().query('serialNumber == \$0', [Bitmap['srNO']]);

    return TicketingBit(bit: bits.first, lineItem: Bitmap['lineItems']);
  }

  List<Bit> getBitFromSerialNbr(String query) {
    return realm.all<Bit>().query("serialNumber IN $query").toList();
  }

  RealmResults<StorageLocation> getStorageLoc(String plantID) {
    var storageLoc =
        realm.all<StorageLocation>().query('plantId == \$0', [plantID]);
    print("storageLoc : ${storageLoc.length}");
    return storageLoc;
  }

  RealmResults<StorageLocation> getOtherTrucksinSamePlant(
      String plantID, String storageLocationId) {
    var storageLoc = realm.all<StorageLocation>().query(
        "plantId == \$0 AND storageLocationType=='TRK' AND storageLocationId!=\$1",
        [plantID, storageLocationId]);
    return storageLoc;
  }

  RealmResults<BilledBits> getBilledBits() {
    var billedBits = realm.all<BilledBits>();
    print('billedBits : ${billedBits.length}');
    return billedBits;
  }

  RealmResults<BitState> getBitsState() {
    var bitsState = realm.all<BitState>();
    print('Bitstate : ${bitsState.length}');
    return bitsState;
  }

  RealmResults<FieldsName> getFields() {
    var fieldsName = realm.all<FieldsName>();
    print('FieldsName : ${fieldsName.length}');
    return fieldsName;
  }

  RealmResults<TruckUserMapping> getUserEntitlements(String email) {
    userEntitlements =
        realm.all<TruckUserMapping>().query('mailId == \$0', ['${email}']);
    print('UserEntitlements : ${userEntitlements.length}');
    return userEntitlements;
  }

  RealmResults<TruckUserMapping> loadUserEntitlements() {
    return userEntitlements;
  }

  RealmResults<DeviceTokenStorage> getDeviceToken() {
    var deviceToken = realm.all<DeviceTokenStorage>();
    print('DeviceToken : ${deviceToken.length}');
    return deviceToken;
  }

  List<Bit> getSearchedBits(String value, String storageLoc, String plant) {
    var bits = realm.all<Bit>().query(
        "inch CONTAINS[c] '$value' OR milim CONTAINS[c] '$value' OR serialNumber CONTAINS[c] '$value' OR bitType CONTAINS[c] '$value' OR materialNumber CONTAINS[c] '$value' ");
    if (storageLoc != AppStrings.otherDistrictValue) {
      bits = bits.query("storageLoc == '$storageLoc' AND plant == '$plant'");
    } else {
      bits = bits.query("plant != '$plant'");
    }
    print('SearchedBits : ${bits.length}');
    return bits.toList();
  }

  List<Consignment> getSearchedConsignedBits(String value, String userEmail) {
    var bits = realm.all<Consignment>().query(
        "createdBy == '$userEmail' AND (consignmentId CONTAINS[c]'$value' OR "
            "customerName CONTAINS[c] '$value' OR rigName CONTAINS[c] '$value' OR bits.serialNumber CONTAINS[c] '$value')");

    ApplicationLogger().printInfo(
        "getSearchedConsignedBits length ====== ${bits.length}",
        "getSearchedConsignedBits");
    return bits.toList();
  }

  List<Ticket> getSearchedTicketBits(String value, String userEmail) {
    var bits = realm.all<Ticket>().query(
        "createdBy == '$userEmail' AND ticketLater == false AND (ticketingId CONTAINS[c]'$value' OR "
            "customerName CONTAINS[c] '$value' OR rigName CONTAINS[c] '$value' OR bits.serialNumber CONTAINS[c] '$value')");

    ApplicationLogger().printInfo(
        "getSearchedTicketBits length ====== ${bits.length}",
        "getSearchedTicketBits");
    return bits.toList();
  }

  List<Ticket> getSearchedTicketLaterBits(String value, String userEmail) {
    var bits = realm.all<Ticket>().query(
        "createdBy == '$userEmail' AND ticketLater == true AND (ticketingId CONTAINS[c]'$value' OR "
            "customerName CONTAINS[c] '$value' OR rigName CONTAINS[c] '$value' OR bits.serialNumber CONTAINS[c] '$value')");

    ApplicationLogger().printInfo(
        "getSearchedTicketLaterBits length ====== ${bits.length}",
        "getSearchedTicketLaterBits");
    return bits.toList();
  }

  List<Consignment> getConsignDraft(String consignID) {
    var bits = realm.all<Consignment>().query("consignmentId == '$consignID' ");
    return bits.toList();
  }

  RealmResults<Consignment> getConsignedBits(String userEmail) {
    var bits = realm.all<Consignment>().query("createdBy == '$userEmail' ");
    ApplicationLogger().printInfo(
        "UserConsignments fetched for USer ${userEmail} and length ====== ${bits.length}",
        "fetchConsignments");
    return bits;
  }

  RealmResults<Ticket> getTicketBits(String userEmail) {
    var bits = realm
        .all<Ticket>()
        .query("createdBy == '$userEmail' AND ticketLater == false");
    return bits;
  }

  RealmResults<Ticket> getTicketLaterBits(String userEmail) {
    var ticketLaterBits = realm
        .all<Ticket>()
        .query("createdBy == '$userEmail' AND ticketLater == true");
    return ticketLaterBits;
  }

  List<Bit> fetchMyTruckBitsFilter(List<String> list,
      {String value = '', String query = ''}) {
    var bits = realm
        .all<Bit>()
        .query("storageLoc == \$0 AND plant ==\$1 $value $query".trim(), list);
    return bits.toList();
  }

  List<Bit> fetchMyDistrictBitsFilter(List<String> list,
      {String value = '', String query = ''}) {
    //baseLocationID == storageLoc in bit
    var bits = realm.all<Bit>().query(
        "storageLoc == \$0 AND  plant == \$1 $value $query".trim(), list);
    return bits.toList();
  }

  List<Bit> fetchOtherDistrictFilter(List<String> list,
      {String value = '', String query = ''}) {
    var bits = realm.all<Bit>();
    list.forEach((element) {
      List<String> temp = [];
      temp.add(element);
      bits = bits.query("plant != \$0 $value $query".trim(), temp);
    });

    return bits.toList();
  }

  RealmResults<RecentSearchesData> getRecentSearches() {
    recentSearches = realm.all<RecentSearchesData>();
    print('RecentSearches : ${recentSearches.length}');
    return recentSearches;
  }

  Future<bool> insertBitRequest(Map<String, dynamic> dictValues) async {
    await getCurrentRealmObject();
    final result = await realm.writeAsync(() {
      final requestAdded = RequestBit(ObjectId(),
          bitType: dictValues['bitType'],
          comments: dictValues['comments'],
          customerName: (dictValues['customer'] as Customer).name,
          jobType: dictValues['jobType'],
          probability: dictValues['probability'],
          requestBitByDate: dictValues['requestBitBy'],
          requestedBy: prefs.getString(PreferenceConstants.userEmail),
          rigName: (dictValues['rig'] as Rig).name,
          size: dictValues['size'],
          truckUserMappingId:
              prefs.getString(PreferenceConstants.userTruckMapping),
          isEmailSent: false);
      var resultAdd = realm.add(requestAdded);
      if (resultAdd != null) {
        return true;
      } else {
        return false;
      }
    });

    return true;
  }

  Future<bool> insertConsignedBitRequest(
    String customerEmail,
    List<Bits> selectedBits,
    PriceBook pb,
    Rig? rig,
    Customer? customer,
    List<Bit> consignedBits,
    String status,
    String attachmentString,
    String consignmentID,
    String draftObjectID,
    String? quoteID,
  ) async {
    LoginController loginController = Get.find();
    List<ConsignmentBits> cbList = [];
    List<ConsignmentBitsPriceBookDetails> pbList = [];
    var objectId = ObjectId();
    if (draftObjectID != "") {
      objectId = ObjectId.fromHexString(draftObjectID);
    }

    printLog('insertConsignedBitRequest() Start:- ${DateTime.now()}');
    final result = await realm.writeAsync(() {
      selectedBits.forEach((selectedBit) {
        pbList.clear();
        if (selectedBit.lineItem != null) {
          selectedBit.lineItem!.forEach((lineItem) {
            pbList.add(ConsignmentBitsPriceBookDetails(
                bestPrice: lineItem.bestPrice,
                comments: lineItem.comments,
                commercialAgreementId: "",
                currency: lineItem.currency,
                customerContactName: customer == null ? "" : customer.number,
                discountAmount: lineItem.discountAmount,
                discountPercentage: lineItem.discountPercentage!.toInt(),
                priceBookId: lineItem.priceBookId,
                pricePerUnit: lineItem.pricePerUnit.toString(),
                pricingId: lineItem.pricingId.toString(),
                unitDrilled: lineItem.unitDrilled.toString(),
                unitPrice: lineItem.unitPrice.toString(),
                hlMaterialNumber: lineItem.hLReference,
                llMaterialNumber: lineItem.materialNumber,
                uom: lineItem.uOM,
                lineCondition: lineItem.lineCondition));
          });
        }
        cbList.add(ConsignmentBits(
            materialId: selectedBit.bit?.materialNumber ?? "",
            priceBookDetails: pbList,
            serialNumber: selectedBit.bit?.serialNumber ?? "",
            bom: selectedBit.bit?.materialNumber ?? "",
            iadcCode: selectedBit.bit?.iadcCode ?? "",
            noOfRuns: selectedBit.bit?.numberOfRuns ?? "",
            pinConnection: selectedBit.bit?.pinSize ?? "",
            isBlocked: false,
            status: "-",
            transactionMessage: "",
            size: '${selectedBit.bit?.inch} / ${selectedBit.bit?.milim}',
            type: selectedBit.bit?.bitType ?? ""));
      });

      /*
      User Details
      */
      final requestAdded = Consignment(objectId,
          digitalAttachments: [
            ConsignmentDigitalAttachments(draftQuote: ["attachmentString"])
          ],
          activityId: "",
          operationId: "",
          bits: cbList,
          projectId: "",
          wBSNumber: "",
          cEC: "CEC",
          isEmailSent: false,
          consignmentId: consignmentID,
          createdAt: DateTime.now(),
          createdBy: loginController.userEmail,
          createdByFullName: loginController.userName,
          customerEmail: customerEmail,
          customerId: customer == null ? "" : customer.number ?? '',
          customerName: customer == null ? "" : customer.name ?? '',
          designEngineer: "Design Engineer",
          finalPdf: attachmentString,
          modifiedAt: DateTime.now(),
          gTQuoteId: quoteID ?? '',
          manualAttachments: [
            ConsignmentManualAttachments(draftQuote: ["attachmentString"])
          ],
          modifiedBy: loginController.userEmail,
          modifiedByFullName: loginController.userName,
          rigContractor: rig == null ? '' : rig.drillingContractor ?? '',
          rigId: rig == null ? "" : rig.number ?? '',
          rigName: rig == null ? "" : rig.name ?? '',
          status: status,
          truckUserMappingId:
              loginController.userDetailsList.first.id.toString());
      var resultAdd = realm.add(requestAdded, update: true);
      if (status == AppStrings.processing) {
        insertConsignedBitQueue(consignedBits, objectId.toString());
      }

      printLog('insertConsignedBitRequest() End:- ${DateTime.now()}');
      if (resultAdd != null) {
        return true;
      } else {
        return false;
      }
    });

    return true;
  }

  Future<bool> insertTicketingBitRequest(
      String customerEmail,
      List<TicketingBit> selectedBits,
      PriceBook pb,
      Consignment consignment,
      List<Bit> consignedBits,
      String status,
      String attachmentString,
      String consignmentID,
      String draftObjectID,
      String? quoteID,
      TicketingModel ticketingModel,
      Well? well,
      bool ticketLater) async {
    LoginController loginController = Get.find();
    List<TicketBits> cbList = [];
    List<TicketBitsPriceBookDetails> pbList = [];
    var objectId = ObjectId();
    if (draftObjectID != "") {
      objectId = ObjectId.fromHexString(draftObjectID);
    }

    printLog('insertConsignedBitRequest() Start:- ${DateTime.now()}');
    final result = await realm.writeAsync(() {
      selectedBits.forEach((selectedBit) {
        pbList.clear();
        if (selectedBit.lineItem != null) {
          selectedBit.lineItem!.forEach((lineItem) {
            pbList.add(TicketBitsPriceBookDetails(
                bestPrice: lineItem.bestPrice,
                comments: lineItem.comments,
                commercialAgreementId: "",
                currency: lineItem.currency,
                customerContactName: "",
                discountAmount: lineItem.discountAmount,
                discountPercentage: lineItem.discountPercentage?.toInt(),
                hlMaterialNumber: lineItem.hLReference.toString(),
                llMaterialNumber: lineItem.materialNumber.toString(),
                priceBookId: lineItem.priceBookId,
                pricePerUnit: lineItem.pricePerUnit.toString(),
                pricingId: lineItem.pricingId.toString(),
                unitDrilled: lineItem.unitDrilled.toString(),
                unitPrice: lineItem.unitPrice.toString(),
                uom: lineItem.uOM));
          });
        }
        cbList.add(TicketBits(
            billFlag: ticketLater ? 'N' : 'Y',
            // to be changed to N for bil later
            pickupFlag:
                getPickUPFlag(ticketingModel.consumptionType.toString()),
            materialId: selectedBit.bit?.materialNumber ?? "",
            priceBookDetails: pbList,
            serialNumber: selectedBit.bit?.serialNumber ?? "",
            bom: selectedBit.bit?.materialNumber ?? "",
            iadcCode: selectedBit.bit?.iadcCode ?? "",
            noOfRuns: selectedBit.bit?.numberOfRuns ?? "",
            pinConnection: selectedBit.bit?.pinSize ?? "",
            size: '${selectedBit.bit?.inch} / ${selectedBit.bit?.milim}',
            type: selectedBit.bit?.bitType ?? ""));
      });

      /*
      User Details
      */
      final requestAdded = Ticket(objectId,
          billToCustomerId: ticketingModel.billTo != null
              ? ticketingModel.billTo?.id.toString()
              : "",
          consignmentGuid: ticketingModel.consignmentGUID,
          //consignment UID
          consumptionType: ticketingModel.consumptionType,
          endDate: ticketingModel.endDate == null
              ? DateTime.now()
              : ticketingModel.endDate,
          lat: ticketingModel.lat ?? "",
          long: ticketingModel.long ?? "",
          shipToCustomerId: ticketingModel.shipTo != null
              ? ticketingModel.shipTo?.id.toString()
              : "",
          startDate: ticketingModel.startDate == null
              ? DateTime.now()
              : ticketingModel.startDate,
          wellId: ticketingModel.well?.wellId,
          wellName: ticketingModel.well?.name,
          wellNumber: ticketingModel.well?.number,
          ticketingId: ticketingModel.ticketingID,
          ticketLater: ticketLater,
          digitalAttachments: [
            TicketDigitalAttachments(draftQuote: ["attachmentString"])
          ],
          activityId: "",
          operationId: "",
          bits: cbList,
          projectId: "",
          wBSNumber: "",
          cEC: ticketingModel.cec?.value ?? "",
          //null
          isEmailSent: false,
          consignmentId: consignment.consignmentId,
          // check
          createdAt: DateTime.now(),
          createdBy: loginController.userEmail,
          createdByFullName: loginController.userName,
          customerEmail: consignment.customerEmail ?? "",
          customerId: consignment.customerId ?? "",
          customerName: consignment.customerName ?? "",
          designEngineer: ticketingModel.designEngineer?.value ?? "",
          // check
          finalPdf: attachmentString,
          gTQuoteId: consignment.gTQuoteId ?? '',
          manualAttachments: [
            TicketManualAttachments(draftQuote: ["attachmentString"])
          ],
          modifiedBy: loginController.userEmail,
          modifiedByFullName: loginController.userName,
          rigContractor: consignment.rigContractor ?? "",
          rigId: consignment.rigId ?? "",
          rigName: consignment.rigName ?? "",
          status: status,
          truckUserMappingId:
              loginController.userDetailsList.first.id.toString());
      var resultAdd = realm.add(requestAdded, update: true);
      if (status == AppStrings.processing) {
        insertTicketingBitQueue(
            consignedBits, objectId.toString(), consignment.id.toString());
      }

      printLog('insertTicketingBitQueue() End:- ${DateTime.now()}');
      if (resultAdd != null) {
        return true;
      } else {
        return false;
      }
    });

    return true;
  }

  Future<bool> insertReturnBitQueue(List<Bit> consignedBits,
      Consignment consignment, String returnTicketID) async {
    LoginController loginController = Get.find();
    List<ReturnQueueBits> cbList = [];
    consignedBits.forEach((element) {
      cbList.add(ReturnQueueBits(
        comments: "",
        materialId: element.materialNumber,
        runFlag: "N",
        serialNumber: element.serialNumber,
        uom: element.uom,
        valuationType: element.batchNumber,
      ));
    });
    final result = await realm.writeAsync(() {
      var objectId = ObjectId();
      final requestAdded = ReturnQueue(objectId,
          comments: "",
          long: "",
          lat: "",
          bits: cbList,
          consignmentDate: consignment.createdAt,
          consignmentNumber: consignment.id.toString(),
          createdAt: DateTime.now(),
          createdBy: loginController.userEmail,
          createdByFullName: loginController.userName,
          modifiedBy: loginController.userEmail,
          modifiedByFullName: loginController.userName,
          destinationPlant: loginController.userDetailsList.first.plantId,
          destinationStorageLocation:
              loginController.userDetailsList.first.storageLocationId,
          modifiedAt: DateTime.now(),
          returnTicketNumber: returnTicketID,
          sourcePlant: getBitPlant(cbList.first.serialNumber.toString()),
          sourceStorageLocation:
              getBitStorageLoc(cbList.first.serialNumber.toString()),
          truckUserMappingId:
              loginController.userDetailsList.first.id.toString());
      var resultAdd = realm.add(requestAdded);
      if (resultAdd != null) {
        return true;
      } else {
        return false;
      }
    });
    var returnItems = realm.all<ReturnQueue>();
    print(returnItems.length);
    return true;
  }

  Future<bool> insertTicketingBitQueue(
      List<Bit> consignedBits, String ticketingID, String consignmentID) async {
    LoginController loginController = Get.find();
    List<TicketQueueBits> cbList = [];
    consignedBits.forEach((element) {
      cbList.add(TicketQueueBits(
        billFlag: "",
        pickupFlag: "",
        uom: element.uom ?? "",
        valuationType: element.batchNumber ?? "",
        materialId: element.materialNumber ?? "",
        serialNumber: element.serialNumber ?? "",
      ));
    });
    final result = await realm.writeAsync(() {
      var objectId = ObjectId();
      final requestAdded = TicketQueue(objectId,
          ticketId: ticketingID,
          destinationPlant:
              loginController.userDetailsList.first.plantId.toString(),
          destinationStorageLocation: "",
          modifiedAt: DateTime.now(),
          sourcePlant: loginController.userDetailsList.first.plantId.toString(),
          sourceStorageLocation:
              getBitStorageLoc(cbList.first.serialNumber.toString()),
          bits: cbList,
          consignmentId: consignmentID,
          createdAt: DateTime.now(),
          createdBy: loginController.userEmail,
          createdByFullName: loginController.userName,
          modifiedBy: loginController.userEmail,
          modifiedByFullName: loginController.userName,
          truckUserMappingId:
              loginController.userDetailsList.first.id.toString());
      var resultAdd = realm.add(requestAdded);
      if (resultAdd != null) {
        return true;
      } else {
        return false;
      }
    });

    return true;
  }

  Future<bool> insertConsignedBitQueue(
    List<Bit> consignedBits,
    String consignmentID,
  ) async {
    LoginController loginController = Get.find();
    List<ConsignmentQueueBits> cbList = [];
    consignedBits.forEach((element) {
      cbList.add(ConsignmentQueueBits(
        uom: element.uom ?? "",
        valuationType: element.batchNumber ?? "",
        materialId: element.materialNumber ?? "",
        serialNumber: element.serialNumber ?? "",
      ));
    });
    final result = await realm.writeAsync(() {
      var objectId = ObjectId();
      final requestAdded = ConsignmentQueue(objectId,
          lat: "",
          long: "",
          destinationPlant:
              loginController.userDetailsList.first.plantId.toString(),
          destinationStorageLocation: "",
          modifiedAt: DateTime.now(),
          sourcePlant: loginController.userDetailsList.first.plantId.toString(),
          sourceStorageLocation: loginController
              .userDetailsList.first.storageLocationId
              .toString(),
          bits: cbList,
          consignmentId: consignmentID,
          createdAt: DateTime.now(),
          createdBy: loginController.userEmail,
          createdByFullName: loginController.userName,
          modifiedBy: loginController.userEmail,
          modifiedByFullName: loginController.userName,
          truckUserMappingId:
              loginController.userDetailsList.first.id.toString());
      var resultAdd = realm.add(requestAdded);
      if (resultAdd != null) {
        return true;
      } else {
        return false;
      }
    });

    return true;
  }

  ///
  ///
  ///Commented due to Empty Model
  Future<bool> insertBilledBitRequest(
      String
          status /*
      List<Bit> billedBits,
      String status,
      String attachmentString,
      String customerName,
      String dateConsigned,
      String officeSalesMan,
      String well,
      String cec*/
      ) async {
    List<BilledBitsList> cbList = [];
    /*billedBits.forEach((element) {
      cbList.add(BilledBitsList(
          bom: element.materialNumber,
          iadcCode: element.iadcCode,
          noOfRuns: element.numberOfRuns.toString(),
          pinConnection: element.pinSize,
          serialNumber: element.serialNumber,
          size: element.bitSize,
          type: element.bitType));
    });*/
    final result = await realm.writeAsync(() {
      var objectId = ObjectId();
      final requestAdded = BilledBits(
        objectId,
        attachment: "",
        //attachmentString,
        billedBitsList: cbList,
        billingID: objectId.toString(),
        startDate: DateTime.now().toString(),
        endDate: DateTime.now().toString(),
        noOfBilledBits: "",
        //cbList.length.toString(),
        officeSalesMan: "",
        // officeSalesMan,
        well: "",
        status: status,
        cec: "", //cec
      );
      var resultAdd = realm.add(requestAdded);
      if (resultAdd != null) {
        return true;
      } else {
        return false;
      }
    });

    return true;
  }

  Future<bool> insertRecentSearches(List<String> searchValues) async {
    await getCurrentRealmObject();
    if (searchValues.length > 5) {
      searchValues = searchValues.sublist(searchValues.length - 5);
    }
    var objectId;
    RealmResults<RecentSearchesData> currentUserObjectID = recentSearches
        .query("userName == \$0", [userEntitlements.first.mailId.toString()]);
    if (currentUserObjectID.length < 1) {
      objectId = ObjectId();
    } else {
      objectId = currentUserObjectID.first.id;
    }
    final result = await realm.writeAsync(() {
      var recentSearchDataObject = RecentSearchesData(objectId,
          userName: userEntitlements.first.mailId.toString(),
          recentSearches: searchValues);
      var resultAdd = realm.add(recentSearchDataObject, update: true);
      if (resultAdd != null) {
        return true;
      } else {
        return false;
      }
    });
    return true;
  }

  Future<bool> insertDeviceID(
      String deviceToken, String email, ObjectId? id) async {
    final DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    final iosInfo = await deviceInfo.iosInfo;
    String? deviceId = iosInfo.identifierForVendor;
    print(deviceId);
    deviceId = deviceId?.replaceAll("-", "");
    await getCurrentRealmObject();
    var objectIdValue = getDeviceToken().query('userName == \$0', ['${email}']);

    final result = await realm.writeAsync(() {
      var deviceIDTokenObject = DeviceTokenStorage(
          objectIdValue.length > 0 ? objectIdValue.first.id : ObjectId(),
          userName: email,
          truckUserMappingId: id.toString(),
          deviceID: deviceId,
          deviceToken: deviceToken);
      var resultAdd = realm.add(deviceIDTokenObject, update: true);
      if (resultAdd != null) {
        return true;
      } else {
        return false;
      }
    });
    return true;
  }

  Future<bool> insertBitMovementRequest(
      List<Bit> bits,
      String email,
      String userName,
      bool isTruckMovement,
      LoginController loginController,
      String reasonForBlock,
      bool isTrkToTrk,
      StorageLocation? toTrkLoc) async {
    await getCurrentRealmObject();
    List<MovementQueueBits> movementQueueBits = [];
    var sourcePlant;
    var sourceStorageLocation;

    bits.forEach((element) {
      movementQueueBits.add(MovementQueueBits(
          materialId: element.materialNumber,
          serialNumber: element.serialNumber,
          uom: element.uom,
          valuationType: element.batchNumber));
      sourcePlant = element.plant;
      sourceStorageLocation = element.storageLoc;
    });
////true trk to wh
    ///false wh to trk
    ///
/*

Trk to wh

StorageLocationId -> BaseLocationID

WH to TRk
BaselocationID -> storageLocationId
*/
    String dest = "";
    String source = "";
    if (isTruckMovement) {
      dest = loginController.userDetailsList.first.storageLocationId.toString();
      source = loginController.userDetailsList.first.baseLocationId.toString();
    } else {
      dest = loginController.userDetailsList.first.baseLocationId.toString();
      source =
          loginController.userDetailsList.first.storageLocationId.toString();
    }

    if (isTrkToTrk) {
      dest = toTrkLoc!.storageLocationId.toString();
    }

    ApplicationLogger().printInfo('Source:- $source , Destination:- $dest',
        'RealmInitial.insertBitMovementRequest');

    var movementQueue = MovementQueue(ObjectId(),
        bits: movementQueueBits,
        createdAt: DateTime.now(),
        createdBy: email,
        lat: "",
        long: "",
        createdByFullName: userName,
        destinationPlant:
            loginController.userDetailsList.first.plantId.toString(),
        destinationStorageLocation: dest,
        modifiedAt: DateTime.now(),
        modifiedBy: email,
        modifiedByFullName: userName,
        sourcePlant: sourcePlant,
        sourceStorageLocation: source,
        truckUserMappingId: prefs.getString(PreferenceConstants
            .userTruckMapping)); /*"${email}-${sourcePlant}-${sourceStorageLocation}");*/

    List<BitState> bitsStatesList = [];

    bits.forEach((element) {
      bitsStatesList.add(BitState(ObjectId(),
          bitSerialNumber: element.serialNumber,
          reasonForBlock: reasonForBlock,
          isBlocked: true));
    });

    final result = await realm.writeAsync(() {
      final requestAdded = movementQueue;

      //TODO
      var resultAdd = realm.add(requestAdded);
      bitsStatesList.forEach((element) {
        realm.add(element);
      });

      if (resultAdd != null) {
        return true;
      } else {
        return false;
      }
    });
    return true;
  }

  Future<bool> insertAppLogs(
      String message, String logLevel, String origin) async {
    await getCurrentRealmObject();

    final result = await realm.writeAsync(() {
      final requestAdded = AppLogger(ObjectId(),
          alias: prefs.getString(PreferenceConstants.userEmail),
          date: DateTime.now().toString(),
          message: message,
          origin: origin,
          type: logLevel,
          userTruckMappingId:
              prefs.getString(PreferenceConstants.userTruckMapping));

      var resultAdd = realm.add(requestAdded);
      print('${resultAdd} result added');

      if (resultAdd != null) {
        return true;
      } else {
        return false;
      }
    });
    return true;
  }

  updateRealmSync(String countryFinal, String stateFinal) {
    if (countryFinal != country && stateFinal != state) {
      country = countryFinal;
      state = stateFinal;
      syncRealm();
    }
  }

  String country = "";
  String state = "";
  static var isSyncDone = false.obs;

  Future syncRealm() async {
    /*To track the state of the synchronization*/
    if (config != null) {
      await Realm.open(config, onProgressCallback: (syncProgress) {
        if (syncProgress.transferableBytes == syncProgress.transferredBytes) {
          // isSyncDone.value=true;
          print('All bytes transferred!');
        }
      });

      /* Add subsription query if required otherwise add to get all objects of type */
      ApplicationLogger().printInfo("Before Realm Sub", "syncRealm");
      realm.subscriptions.update((mutableSubscriptions) {
        mutableSubscriptions.add(realm.all<Customer>());
        mutableSubscriptions.add(realm.all<Rig>());
        mutableSubscriptions.add(realm.all<BitMovement>());
        mutableSubscriptions.add(realm.all<Bit>());
        mutableSubscriptions.add(realm.all<RequestBit>());
        mutableSubscriptions.add(realm.all<PriceBook>());
        mutableSubscriptions.add(realm.all<AppLogger>());
        mutableSubscriptions.add(realm.all<DeviceTokenStorage>());
        mutableSubscriptions.add(realm.all<RecentSearchesData>());
        mutableSubscriptions.add(realm.all<TruckUserMapping>());
        mutableSubscriptions.add(realm.all<MovementQueue>());
        mutableSubscriptions.add(realm.all<Consignment>());
        mutableSubscriptions.add(realm.all<BitState>());
        mutableSubscriptions.add(realm.all<FieldsName>());
        mutableSubscriptions.add(realm.all<BilledBits>());
        mutableSubscriptions.add(realm.all<ConsignmentQueue>());
        mutableSubscriptions.add(realm.all<StorageLocation>());
        mutableSubscriptions.add(realm.all<Notification>());
        mutableSubscriptions.add(realm.all<SalesRepresentative>());
        mutableSubscriptions.add(realm.all<Ticket>());
        mutableSubscriptions.add(realm.all<TicketQueue>());
        mutableSubscriptions.add(
            realm.query<Well>(
                "country == \$0 AND state == \$1", [country, state]),
            name: "wells",
            update: true);
        mutableSubscriptions.add(realm.all<ReturnQueue>());

        // can add any query here.https://www.mongodb.com/docs/realm/sdk/flutter/sync/manage-sync-subscriptions/
      });
      ApplicationLogger()
          .printInfo("After Realm Sub-->> $country - $state", "syncRealm");
      await realm.subscriptions.waitForSynchronization();
      // Let changes sync to and from server
      await realm.syncSession.waitForUpload();
      await realm.syncSession.waitForDownload();
      //api Call
      try {
        InventoryController inventoryController = Get.find();
        Future.delayed(const Duration(seconds: 5));
        inventoryController.fetchFiledName();
        inventoryController.fetchData();
      } catch (e) {
        ApplicationLogger().printInfo(e.toString(), 'syncRealm');
      }
      isSyncDone.value = true;
      print('Sync successfully done');
      //InventoryBinding().dependencies();
    }
  }

  TicketingLineItems getTicketingLineItem(
      String pbID, String pricingID, String country) {
    var temp =
        getPriceBooksList(country).query('priceBookId == \$0', ['${pbID}']);
    var eme = null;
    temp.first.lines.forEach((element) {
      element.lowLevelItems.forEach((element2) {
        var temp = element2.pricingId;
        if (pricingID == temp.toString()) {
          eme = element2;
        }
      });
    });
    return TicketingLineItems(
      priceBookId: pbID,
      currency: eme.currency,
      hLReference: eme.hLReference,
      isActive: eme.isActive,
      masterCode: eme.masterCode,
      materialDescription: eme.materialDescription,
      materialLocalDescription: eme.materialLocalDescription,
      materialLocalNumber: eme.materialLocalNumber,
      materialNumber: eme.materialNumber,
      pricingId: eme.pricingId,
      sHLReference: eme.sHLReference,
      uOM: eme.uOM,
      unitPrice: eme.unitPrice,
      bestPrice: 0.0,
      comments: '',
      discountAmount: 0.0,
      discountPercentage: 0.0,
      unitDrilled: 0.0,
      pricePerUnit: 0.0,
      isExpanded: true,
      isDuplicate: false,
    );
  }

  LineItems getLineItem(String pbID, String pricingID, String country) {
    var temp =
        getPriceBooksList(country).query('priceBookId == \$0', ['${pbID}']);
    var eme = null;
    temp.first.lines.forEach((element) {
      element.lowLevelItems.forEach((element2) {
        var temp = element2.pricingId;
        if (pricingID == temp.toString()) {
          eme = element2;
        }
      });
    });
    return LineItems(
        priceBookId: pbID,
        currency: eme.currency,
        hLReference: eme.hLReference,
        isActive: eme.isActive,
        masterCode: eme.masterCode,
        materialDescription: eme.materialDescription,
        materialLocalDescription: eme.materialLocalDescription,
        materialLocalNumber: eme.materialLocalNumber,
        materialNumber: eme.materialNumber,
        pricingId: eme.pricingId,
        sHLReference: eme.sHLReference,
        uOM: eme.uOM,
        unitPrice: eme.unitPrice,
        bestPrice: 0.0,
        comments: '',
        discountAmount: 0.0,
        discountPercentage: 0.0,
        unitDrilled: 0.0,
        pricePerUnit: 0.0,
        isExpanded: true,
        isDuplicate: false,
        lineCondition: "");
  }

  Future<void> setBitListStatusToBlock(
      List<Bit> bit, String reasonForBlock) async {
    List<BitState> bitsStatesList = [];
    bit!.forEach((bit) {
      bitsStatesList.add(BitState(ObjectId(),
          bitSerialNumber: bit.serialNumber,
          reasonForBlock: reasonForBlock,
          isBlocked: true));
    });
    await realm.writeAsync(() {
      bitsStatesList.forEach((element) {
        realm.add(element);
      });
    });
  }

  Future<void> setBitListStatusToUnBlock(
      List<Bit> bits, String reasonForUnBlock) async {
    List<String> serialNumber = [];
    bits.forEach((bit) {
      if (bit != null) {
        serialNumber.add('\'${bit.serialNumber!}\'');
      }
    });
    var query =
        serialNumber.toString().replaceAll('[', '{').replaceAll(']', '}');
    await setBitListStatusToUnBlockRealm(query);
  }

  Future<void> setBitListStatusToUnBlockOnOtherModel(
      RealmList<ConsignmentBits> bits, String reasonForUnBlock) async {
    List<String> serialNumber = [];
    bits.forEach((bit) {
      if (bit != null) {
        serialNumber.add('\'${bit.serialNumber!}\'');
      }
    });
    var query =
        serialNumber.toString().replaceAll('[', '{').replaceAll(']', '}');
    await setBitListStatusToUnBlockRealm(query);
  }

  Future<void> setBitListStatusToUnBlockRealm(String query) async {
    ApplicationLogger().printInfo('Delete draft bit unblock Query:- $query',
        'setBitListStatusToUnBlockRealm');
    await realm.writeAsync(() {
      RealmResults<BitState> draftObject =
          realm.query<BitState>("bitSerialNumber IN $query");
      draftObject.forEach((bit) {
        bit.isBlocked = false;
      });
      if (draftObject.isNotEmpty) {
        realm.addAll(draftObject, update: true);
      }
    });
  }

  Future<bool> deleteDraftFromConsignedBits(String? draftObjectID) async {
    if (draftObjectID != null) {
      RealmResults<Consignment> draftObject =
          realm.query<Consignment>('consignmentId == \$0', [draftObjectID]);
      var lastBitsSerialNum = draftObject.first.bits.first.serialNumber;
      if (lastBitsSerialNum != null && lastBitsSerialNum.isNotEmpty) {
        lastBitsSerialNum = '{\'$lastBitsSerialNum\'}';
        await setBitListStatusToUnBlockRealm(lastBitsSerialNum);
      }
      await realm.writeAsync(() async {
        ApplicationLogger().printInfo(
            'draftObject length:- ${draftObject.length}',
            'deleteDraftFromConsignedBits');

        if (draftObject.isNotEmpty) {
          realm.delete(draftObject[0]);
        }
      });
    }
    return true;
  }

  Future<bool> deleteDraftFromTicketedBits(String? draftObjectID) async {
    if (draftObjectID != null) {
      RealmResults<Ticket> draftObject =
          realm.query<Ticket>('ticketingId == \$0', [draftObjectID]);

      await realm.writeAsync(() async {
        ApplicationLogger().printInfo(
            'draftObject length:- ${draftObject.length}',
            'deleteDraftFromTicketedBits');

        if (draftObject.isNotEmpty) {
          realm.delete(draftObject[0]);
        }
      });
    }
    return true;
  }

  getPickUPFlag(String consumptionType) {
    if (consumptionType == "Rental" || consumptionType == "Rental + DBR") {
      return "Y";
    }
    return "N";
  }

  getSingleWell(String? wellId, String? wellNumber) {
    // final wells = realm.all<Well>().query("country == \$0 AND state == \$1",[country,state]);
    final wells = realm.all<Well>().query('wellId == \$0 AND number == \$1 ',
        [wellId.toString(), wellNumber.toString()]); //.query("SORT(name ASC)");
    return wells.first;
  }

  getConsignment(String consignmentID) {
    final consignment =
        realm.all<Consignment>().query("consignmentId == \$0", [consignmentID]);
    return consignment.first;
  }
}
