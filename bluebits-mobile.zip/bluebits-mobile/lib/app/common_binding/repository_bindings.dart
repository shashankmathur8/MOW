import 'package:get/get.dart';
import 'package:slb_gt_mobile/app/data/repository/inventory_repo.dart';
import 'package:slb_gt_mobile/app/data/repository/inventory_repo_impl.dart';

class RepositoryBindings implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut<InventoryRepo>(
      () => InventoryRepoImpl(),
      tag: (InventoryRepo).toString(),
    );
  }
}
